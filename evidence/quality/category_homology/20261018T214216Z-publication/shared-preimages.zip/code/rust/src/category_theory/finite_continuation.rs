
use crate::finite_moore::{FiniteMoore, MooreError, MooreQuotient};
use std::collections::{BTreeMap, VecDeque};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ContinuationError {
    Machine(MooreError),
    OutsideCarrier,
    OutsideAlphabet,
    WorkLimit,
    CertificateMismatch,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PartialDynamics {
    reports: Vec<usize>,
    transitions: Vec<Vec<Option<usize>>>,
    machine: FiniteMoore,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DistinguishingWord {
    pub left: usize,
    pub right: usize,
    pub word: Vec<usize>,
    pub left_answer: Option<usize>,
    pub right_answer: Option<usize>,
}

impl PartialDynamics {
    pub fn new(
        reports: Vec<usize>,
        transitions: Vec<Vec<Option<usize>>>,
        inputs: usize,
    ) -> Result<Self, ContinuationError> {
        if reports.is_empty() {
            return Err(ContinuationError::Machine(MooreError::EmptyCarrier));
        }
        if transitions.len() != reports.len() || transitions.iter().any(|r| r.len() != inputs) {
            return Err(ContinuationError::Machine(MooreError::TransitionShape));
        }
        if transitions
            .iter()
            .flatten()
            .flatten()
            .any(|&t| t >= reports.len())
        {
            return Err(ContinuationError::Machine(
                MooreError::TransitionOutsideCarrier,
            ));
        }
        let mut labels = BTreeMap::new();
        let mut outputs = Vec::new();
        for label in reports
            .iter()
            .copied()
            .map(Some)
            .chain(std::iter::once(None))
        {
            let next = labels.len();
            outputs.push(*labels.entry(label).or_insert(next));
        }
        let dead = reports.len();
        let mut total: Vec<Vec<usize>> = transitions
            .iter()
            .map(|row| row.iter().map(|t| t.unwrap_or(dead)).collect())
            .collect();
        total.push(vec![dead; inputs]);
        let machine =
            FiniteMoore::new(outputs, total, inputs).map_err(ContinuationError::Machine)?;
        Ok(Self {
            reports,
            transitions,
            machine,
        })
    }

    pub fn reports(&self) -> &[usize] {
        &self.reports
    }
    pub fn transitions(&self) -> &[Vec<Option<usize>>] {
        &self.transitions
    }
    pub fn quotient(&self) -> MooreQuotient {
        self.machine.behavioral_quotient()
    }
    pub fn verify_quotient(&self, q: &MooreQuotient) -> bool {
        self.machine.verify_quotient(q)
    }

    pub fn run(&self, start: usize, word: &[usize]) -> Result<Option<usize>, ContinuationError> {
        if start >= self.reports.len() {
            return Err(ContinuationError::OutsideCarrier);
        }
        if word.iter().any(|&a| a >= self.machine.input_count()) {
            return Err(ContinuationError::OutsideAlphabet);
        }
        let mut state = Some(start);
        for &a in word {
            state = state.and_then(|s| self.transitions[s][a]);
        }
        Ok(state)
    }

    pub fn quotient_operations(&self) -> Vec<Vec<Option<usize>>> {
        let q = self.quotient();
        let dead = q.state_to_block[self.reports.len()];
        q.quotient.transitions()[..dead]
            .iter()
            .map(|row| {
                row.iter()
                    .map(|&t| if t == dead { None } else { Some(t) })
                    .collect()
            })
            .collect()
    }

    pub fn distinguish(
        &self,
        left: usize,
        right: usize,
        max_pairs: usize,
    ) -> Result<Option<DistinguishingWord>, ContinuationError> {
        if left >= self.reports.len() || right >= self.reports.len() {
            return Err(ContinuationError::OutsideCarrier);
        }
        if max_pairs == 0 {
            return Err(ContinuationError::WorkLimit);
        }
        let mut paths = BTreeMap::from([((left, right), Vec::new())]);
        let mut queue = VecDeque::from([(left, right)]);
        while let Some((l, r)) = queue.pop_front() {
            let word = paths[&(l, r)].clone();
            if self.machine.reports()[l] != self.machine.reports()[r] {
                return Ok(Some(DistinguishingWord {
                    left,
                    right,
                    word,
                    left_answer: self.reports.get(l).copied(),
                    right_answer: self.reports.get(r).copied(),
                }));
            }
            for a in 0..self.machine.input_count() {
                let pair = (
                    self.machine.transitions()[l][a],
                    self.machine.transitions()[r][a],
                );
                if !paths.contains_key(&pair) {
                    if paths.len() >= max_pairs {
                        return Err(ContinuationError::WorkLimit);
                    }
                    let mut next = word.clone();
                    next.push(a);
                    paths.insert(pair, next);
                    queue.push_back(pair);
                }
            }
        }
        Ok(None)
    }

    pub fn verify_distinction(&self, c: &DistinguishingWord) -> Result<(), ContinuationError> {
        let l = self.run(c.left, &c.word)?.map(|s| self.reports[s]);
        let r = self.run(c.right, &c.word)?.map(|s| self.reports[s]);
        if l == r || l != c.left_answer || r != c.right_answer {
            return Err(ContinuationError::CertificateMismatch);
        }
        Ok(())
    }
}
