# [TFQ-0029] Keep 1/302 as a ratio of rational loop coefficients

> **Stage**: `FINITE_QCD` | **Status**: `COMPUTATIONAL_CONTROL`  
> **UUID**: `7649baf2-020a-5e79-8482-00fb4b6ab887`  
> **Parent Derivation**: [TFQ-0028](tfq_0028_state_the_beta0_window_as_rational_arithmetic_and_repeat_the_map_s_withheld.md)

---

## 1. Abstract & Formal Statement

qcd_beta1(3, n_f) is recorded as 102 - (38/3)*n_f. At n_f=16 the Rust control and Lean qcd_beta1_and_banks_zaks_fixed_point record beta0=1/3, beta1=-302/3, and the ratio -beta0/beta1 = 1/302. Python qcd_beta1 repeats the same rational expression. This is a ratio of two loop coefficients inside the finite control. It is not an infrared fixed-point statement about a continuum gauge theory, and the 12-decimal running enclosure in Part D is not an input to the ratio. A float approximation of 1/302 cannot authorize the rational identity, which is already exact over Q.

### Governing Obligation
Keep 1/302 as a ratio of rational loop coefficients.

---

## 2. Derivation Context & Mathematical Grounding

In accordance with strict constructive principles:
- **Zero Floating-Point Cheating**: All quantities must be evaluated using exact integer combinatorial logic, discrete fractions, or exact field extensions (e.g. cyclotomic / Gaussian integer arithmetic).
- **Explicit Valuation**: No continuum limits, Hilbert topologies, or measure spaces may be assumed prior to their explicit constructive descent.

---

## 3. Multi-Tier Code & Proof Witnesses

### Lean 4 Theorems
- [`lean4/quantum_mechanics/FiniteQM.lean`](../../code/lean4/)

### Sovereign Rust Certifiers (Exact Rational Arithmetic)
- [`omega_engine/crates_rs/omega_quantum_physics/src/quantum_import_finite_maps/qcd_beta0_wilson_confinement_control.rs`](../../code/rust/src/)

### Python Oracles & Numerical Evaluators
- [`omega_engine_atlas/coda_atlas/F004_papers/006_finite_qm/python/finite_qm/use_cases/qcd_beta0_wilson_confinement_control.py`](../../code/python/)

---

## 4. Downstream Derivations (Outgoing DAG Links)

- [TFQ-0030](tfq_0030_limit_the_confinement_certificate_to_the_declared_strong_coupling_formulae.md)

---

## 5. Audit Trail & Primary Source Lineage

- **Atlas Lineage**: `F001.S000`
- **Primary Source Paths**:
  - `omega_engine_atlas/coda_atlas/F001_quantum/S000_finite_quantum_mechanics/shelf.yaml`
