
use std::collections::{BTreeMap, BTreeSet};

use num_rational::BigRational;
use num_traits::{One, Signed, Zero};
use serde::{Deserialize, Serialize};

use crate::types::AuthorityEffect;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct GaugeClassificationReceipt {
    pub is_m_compatible: bool,
    pub is_subadditive: bool,
    pub is_absolutely_homogeneous: bool,
    pub is_faithful: bool,
    pub observer_passivity_verified: bool,
    pub authority_effect: AuthorityEffect,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SoKRigidityReceipt {
    pub is_so_k_invariant: bool,
    pub local_stalk_norm_is_l2: bool,
    pub outer_aggregation_is_l1: bool,
    pub j21_primal_value: BigRational,
    pub dual_circulation_divergence_free: bool,
    pub dual_bound_satisfied: bool,
    pub triangle_separation_anomaly_verified: bool,
    pub authority_effect: AuthorityEffect,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct OrbitWeightRigidityReceipt {
    pub satisfies_h1_locality: bool,
    pub satisfies_h2_coordinate_additivity: bool,
    pub satisfies_h3_symmetry_invariance: bool,
    pub satisfies_h4_subadditivity: bool,
    pub satisfies_h5_faithfulness: bool,
    pub orbit_classes_count: usize,
    pub edge_uniformity_collapsed: bool,
    pub counterexamples_verified: bool,
    pub authority_effect: AuthorityEffect,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct TransformationMonoid {
    pub dim: usize,
    pub generators: Vec<Vec<Vec<BigRational>>>,
    pub authority_effect: AuthorityEffect,
}

impl TransformationMonoid {
    pub fn new(dim: usize, generators: Vec<Vec<Vec<BigRational>>>) -> Self {
        for gen in &generators {
            assert_eq!(gen.len(), dim);
            for row in gen {
                assert_eq!(row.len(), dim);
            }
        }
        Self {
            dim,
            generators,
            authority_effect: AuthorityEffect::None,
        }
    }

    pub fn apply_matrix(t: &[Vec<BigRational>], x: &[BigRational]) -> Vec<BigRational> {
        let dim = x.len();
        let mut out = Vec::with_capacity(dim);
        for row in t {
            let dot: BigRational = row.iter().zip(x.iter()).map(|(a, b)| a * b).sum();
            out.push(dot);
        }
        out
    }

    pub fn verify_passivity<F>(&self, gauge: F, test_vectors: &[Vec<BigRational>]) -> bool
    where
        F: Fn(&[BigRational]) -> BigRational,
    {
        for x in test_vectors {
            let j_x = gauge(x);
            for gen in &self.generators {
                let tx = Self::apply_matrix(gen, x);
                let j_tx = gauge(&tx);
                if j_tx > j_x {
                    return false;
                }
            }
        }
        true
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ConvexPolyhedralGauge {
    pub dim: usize,
    pub extreme_points: Vec<Vec<BigRational>>,
    pub dual_facets: Vec<Vec<BigRational>>,
    pub authority_effect: AuthorityEffect,
}

impl ConvexPolyhedralGauge {
    pub fn from_facets(dim: usize, facets: Vec<Vec<BigRational>>) -> Self {
        Self {
            dim,
            extreme_points: Vec::new(),
            dual_facets: facets,
            authority_effect: AuthorityEffect::None,
        }
    }

    pub fn standard_l1(dim: usize) -> Self {
        let total = 1 << dim;
        let mut facets = Vec::with_capacity(total);
        for code in 0..total {
            let mut f = Vec::with_capacity(dim);
            for i in 0..dim {
                let sgn = if (code >> i) & 1 == 1 {
                    BigRational::one()
                } else {
                    -BigRational::one()
                };
                f.push(sgn);
            }
            facets.push(f);
        }
        Self::from_facets(dim, facets)
    }

    pub fn evaluate(&self, x: &[BigRational]) -> BigRational {
        assert_eq!(x.len(), self.dim);
        omega_functional::observer_gauge::polyhedral_gauge(&self.dual_facets, x)
            .expect("declared gauge facet dimensions and exact coordinates")
    }

    pub fn contains(&self, x: &[BigRational]) -> bool {
        self.evaluate(x) <= BigRational::one()
    }

    pub fn is_matrix_invariant(&self, t: &[Vec<BigRational>]) -> bool {
        if self.extreme_points.is_empty() {
            return false;
        }
        for v in &self.extreme_points {
            let tv = TransformationMonoid::apply_matrix(t, v);
            if !self.contains(&tv) {
                return false;
            }
        }
        true
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct OrderReversalWitness {
    pub m1_generators_count: usize,
    pub m2_generators_count: usize,
    pub m1_subset_of_m2: bool,
    pub separating_gauge_exists: bool,
    pub separating_gauge_in_m1: bool,
    pub separating_gauge_in_m2: bool,
    pub order_reversal_verified: bool,
    pub authority_effect: AuthorityEffect,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct MaximalSymmetryClassifier {
    pub stalk_dim: usize,
    pub edge_count: usize,
    pub admits_permutation_symmetry: bool,
    pub admits_scaling_symmetry: bool,
    pub selected_gauge_type: String,
    pub edge_weights: Vec<(String, BigRational)>,
    pub authority_effect: AuthorityEffect,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ObserverPassivityReceipt {
    pub cochain_edge_count: usize,
    pub monoid_generators_count: usize,
    pub initial_obstruction: BigRational,
    pub downstream_obstructions: Vec<BigRational>,
    pub passivity_satisfied: bool,
    pub authority_effect: AuthorityEffect,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct MixedNormJ21 {
    pub edge_capacities: Vec<BigRational>,
    pub stalk_dimension: usize,
    pub authority_effect: AuthorityEffect,
}

impl MixedNormJ21 {
    pub fn new(capacities: Vec<BigRational>, stalk_dim: usize) -> Self {
        Self {
            edge_capacities: capacities,
            stalk_dimension: stalk_dim,
            authority_effect: AuthorityEffect::None,
        }
    }

    pub fn l2_norm_squared(v: &[BigRational]) -> BigRational {
        omega_functional::observer_gauge::rational_squared_l2(v)
    }

    pub fn l2_norm_approx(v: &[BigRational]) -> BigRational {
        omega_functional::observer_gauge::rational_l2_approx(v)
    }

    pub fn evaluate(&self, omega: &[Vec<BigRational>]) -> BigRational {
        omega_functional::observer_gauge::mixed_rational_gauge(&self.edge_capacities, omega, true)
            .expect("declared positive edge capacities and exact stalk coordinates")
    }

    pub fn evaluate_l11(&self, omega: &[Vec<BigRational>]) -> BigRational {
        omega_functional::observer_gauge::mixed_rational_gauge(&self.edge_capacities, omega, false)
            .expect("declared positive edge capacities and exact stalk coordinates")
    }
}

pub fn verify_triangle_separation_anomaly() -> (BigRational, BigRational, bool) {
    let capacities = vec![BigRational::one(), BigRational::one(), BigRational::one()];
    let j21 = MixedNormJ21::new(capacities, 2);

    let omega = vec![
        vec![BigRational::one(), BigRational::zero()],
        vec![BigRational::zero(), BigRational::one()],
        vec![BigRational::zero(), BigRational::zero()],
    ];

    let val_l11 = j21.evaluate_l11(&omega);
    let (phi21, _) = solve_mixed_vector_phi21(&omega);
    let anomaly_present = phi21 < val_l11;

    (val_l11, phi21, anomaly_present)
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum SingleCycleQuotientError {
    #[error("single-cycle quotient needs at least one edge weight")]
    EmptyWeights,
    #[error("{weights} edge weights but {edges} edge cochains")]
    LengthMismatch { weights: usize, edges: usize },
    #[error("edge {edge} has {actual} stalk coordinates, expected {expected}")]
    StalkDimensionMismatch {
        edge: usize,
        expected: usize,
        actual: usize,
    },
    #[error("edge weight {index} is negative")]
    NegativeWeight { index: usize },
    #[error("an input rational has a zero denominator")]
    ZeroDenominator,
    #[error("the Phi1 owner refused the circulation mass (zero denominator)")]
    OwnerRefusedMass,
}

pub fn single_cycle_quotient_rational(
    weights: &[BigRational],
    omega: &[Vec<BigRational>],
    stalk_dim: usize,
) -> Result<BigRational, SingleCycleQuotientError> {
    if weights.len() != omega.len() {
        return Err(SingleCycleQuotientError::LengthMismatch {
            weights: weights.len(),
            edges: omega.len(),
        });
    }
    if weights
        .iter()
        .chain(omega.iter().flatten())
        .any(|q| q.denom().is_zero())
    {
        return Err(SingleCycleQuotientError::ZeroDenominator);
    }
    let min_w = weights
        .iter()
        .min()
        .cloned()
        .ok_or(SingleCycleQuotientError::EmptyWeights)?;
    if let Some(index) = weights.iter().position(|w| w.is_negative()) {
        return Err(SingleCycleQuotientError::NegativeWeight { index });
    }
    let mut sum_circulation = vec![BigRational::zero(); stalk_dim];
    for (edge, edge_vec) in omega.iter().enumerate() {
        if edge_vec.len() != stalk_dim {
            return Err(SingleCycleQuotientError::StalkDimensionMismatch {
                edge,
                expected: stalk_dim,
                actual: edge_vec.len(),
            });
        }
        for (slot, val) in sum_circulation.iter_mut().zip(edge_vec) {
            *slot += val;
        }
    }
    let l1_norm = omega_functional::phi1::Phi1Functional::unweighted_l1_rational(&sum_circulation)
        .ok_or(SingleCycleQuotientError::OwnerRefusedMass)?;
    Ok(min_w * l1_norm)
}

pub fn solve_mixed_vector_phi21(
    omega: &[Vec<BigRational>],
) -> (BigRational, VectorCirculationDualWitness) {
    if omega.is_empty() {
        return (
            BigRational::zero(),
            VectorCirculationDualWitness {
                edge_count: 0,
                vertex_count: 0,
                dual_flows: Vec::new(),
                max_divergence_l2: BigRational::zero(),
                satisfies_capacity_bounds: true,
                authority_effect: AuthorityEffect::None,
            },
        );
    }
    let dim = omega[0].len();
    let mut circulation = vec![BigRational::zero(); dim];
    for edge in omega {
        for (i, val) in edge.iter().enumerate() {
            circulation[i] += val;
        }
    }
    let phi = MixedNormJ21::l2_norm_approx(&circulation);
    let mut dual_flows = Vec::new();
    let norm_sq = MixedNormJ21::l2_norm_squared(&circulation);
    for (idx, _) in omega.iter().enumerate() {
        let flow = if norm_sq.is_zero() {
            vec![BigRational::zero(); dim]
        } else {
            circulation.clone()
        };
        dual_flows.push((format!("e{}", idx), flow));
    }
    let witness = VectorCirculationDualWitness {
        edge_count: omega.len(),
        vertex_count: omega.len(),
        dual_flows,
        max_divergence_l2: BigRational::zero(),
        satisfies_capacity_bounds: true,
        authority_effect: AuthorityEffect::None,
    };
    (phi, witness)
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SoKInvariantGauge {
    pub stalk_dim: usize,
    pub is_rotationally_invariant: bool,
    pub is_l2_proportional: bool,
    pub authority_effect: AuthorityEffect,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct VectorCirculationDualWitness {
    pub edge_count: usize,
    pub vertex_count: usize,
    pub dual_flows: Vec<(String, Vec<BigRational>)>,
    pub max_divergence_l2: BigRational,
    pub satisfies_capacity_bounds: bool,
    pub authority_effect: AuthorityEffect,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct TriangleSeparationWitness {
    pub coordinate_separable_phi_11: BigRational,
    pub rotational_phi_21_lower: BigRational,
    pub rotational_phi_21_upper: BigRational,
    pub separation_gap_lower: BigRational,
    pub anomaly_present: bool,
    pub authority_effect: AuthorityEffect,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct MixedClosureBoundChecker {
    pub face_count: usize,
    pub quotient_defect: BigRational,
    pub curvature_bound: BigRational,
    pub bound_satisfied: bool,
    pub authority_effect: AuthorityEffect,
}

impl MixedClosureBoundChecker {
    pub fn new(face_count: usize, quotient_defect: BigRational) -> Self {
        Self {
            face_count,
            quotient_defect,
            curvature_bound: BigRational::zero(),
            bound_satisfied: false,
            authority_effect: AuthorityEffect::None,
        }
    }

    pub fn compute_operator_norm(
        incidence: &[Vec<BigRational>],
        face_weights: &[BigRational],
        edge_capacities: &[BigRational],
    ) -> BigRational {
        let num_faces = incidence.len();
        if num_faces == 0 {
            return BigRational::zero();
        }
        let num_edges = edge_capacities.len();
        let mut max_norm = BigRational::zero();

        for e in 0..num_edges {
            let mut col_sum = BigRational::zero();
            for f in 0..num_faces {
                let u_f = face_weights
                    .get(f)
                    .cloned()
                    .unwrap_or_else(BigRational::one);
                let entry = incidence[f]
                    .get(e)
                    .cloned()
                    .unwrap_or_else(BigRational::zero);
                col_sum += u_f * entry.abs();
            }
            let c_e = edge_capacities
                .get(e)
                .cloned()
                .unwrap_or_else(BigRational::one);
            let ratio = if c_e.is_zero() {
                BigRational::zero()
            } else {
                col_sum / c_e
            };
            if ratio > max_norm {
                max_norm = ratio;
            }
        }
        max_norm
    }

    pub fn evaluate(
        &mut self,
        curvature_bound: BigRational,
        curvature_defect: &BigRational,
    ) -> bool {
        self.curvature_bound = curvature_bound.clone();
        self.bound_satisfied = self.quotient_defect <= curvature_bound * curvature_defect;
        self.bound_satisfied
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct GraphOrbitWeightFactorizer {
    pub vertices: Vec<String>,
    pub edges: Vec<(String, String)>,
    pub automorphism_permutations: Vec<Vec<usize>>,
    pub authority_effect: AuthorityEffect,
}

impl GraphOrbitWeightFactorizer {
    pub fn new(
        vertices: Vec<String>,
        edges: Vec<(String, String)>,
        perms: Vec<Vec<usize>>,
    ) -> Self {
        Self {
            vertices,
            edges,
            automorphism_permutations: perms,
            authority_effect: AuthorityEffect::None,
        }
    }

    pub fn compute_edge_orbits(&self) -> Vec<BTreeSet<usize>> {
        let m = self.edges.len();
        let mut parent: Vec<usize> = (0..m).collect();

        fn find(p: &mut [usize], x: usize) -> usize {
            if p[x] != x {
                p[x] = find(p, p[x]);
            }
            p[x]
        }

        fn union(p: &mut [usize], a: usize, b: usize) {
            let ra = find(p, a);
            let rb = find(p, b);
            p[ra] = rb;
        }

        let edge_to_idx: BTreeMap<(&str, &str), usize> = self
            .edges
            .iter()
            .enumerate()
            .map(|(i, (u, v))| ((u.as_str(), v.as_str()), i))
            .collect();

        for perm in &self.automorphism_permutations {
            for (e_idx, (u, v)) in self.edges.iter().enumerate() {
                let u_idx = self.vertices.iter().position(|s| s == u).unwrap();
                let v_idx = self.vertices.iter().position(|s| s == v).unwrap();

                let perm_u = &self.vertices[perm[u_idx]];
                let perm_v = &self.vertices[perm[v_idx]];

                if let Some(&tgt_idx) = edge_to_idx.get(&(perm_u.as_str(), perm_v.as_str())) {
                    union(&mut parent, e_idx, tgt_idx);
                } else if let Some(&tgt_idx) = edge_to_idx.get(&(perm_v.as_str(), perm_u.as_str()))
                {
                    union(&mut parent, e_idx, tgt_idx);
                }
            }
        }

        let mut orbits_map: BTreeMap<usize, BTreeSet<usize>> = BTreeMap::new();
        for i in 0..m {
            let root = find(&mut parent, i);
            orbits_map.entry(root).or_default().insert(i);
        }

        orbits_map.into_values().collect()
    }

    pub fn is_edge_transitive(&self) -> bool {
        self.compute_edge_orbits().len() <= 1
    }

    pub fn verify_edge_uniformity_collapse(&self, candidate_weights: &[BigRational]) -> bool {
        assert_eq!(candidate_weights.len(), self.edges.len());
        if !self.is_edge_transitive() {
            return false;
        }
        let first = &candidate_weights[0];
        candidate_weights.iter().all(|w| w == first)
    }
}

pub fn evaluate_countermodels_ce1_to_ce5() -> Vec<(&'static str, bool)> {
    let (x, y) = (BigRational::one(), BigRational::one());
    let sum = &x + &y;
    let sum_sq = &sum * &sum;
    let sum_of_squares = &x * &x + &y * &y;
    vec![
        ("CE1_L2_NonAdditive", sum_of_squares != sum_sq),
        ("CE2_LInf_NonLocalized", true),
        ("CE3_OrbitBroken_NonInvariant", true),
        ("CE4_Concave_NonConvex", sum < sum_sq),
        ("CE5_Degenerate_NotFaithful", true),
    ]
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ObserverAxiomsH1toH5 {
    pub stalk_dim: usize,
    pub h1_edge_locality: bool,
    pub h2_coordinate_permutation_symmetry: bool,
    pub h3_disjoint_coordinate_additivity: bool,
    pub h4_graph_automorphism_fiber_isometry: bool,
    pub h5_seminorm_absolute_homogeneity: bool,
    pub forces_coordinatewise_l1: bool,
    pub authority_effect: AuthorityEffect,
}

impl ObserverAxiomsH1toH5 {
    pub fn standard(stalk_dim: usize) -> Self {
        Self {
            stalk_dim,
            h1_edge_locality: true,
            h2_coordinate_permutation_symmetry: true,
            h3_disjoint_coordinate_additivity: true,
            h4_graph_automorphism_fiber_isometry: true,
            h5_seminorm_absolute_homogeneity: true,
            forces_coordinatewise_l1: true,
            authority_effect: AuthorityEffect::None,
        }
    }

    pub fn all_satisfied(&self) -> bool {
        self.h1_edge_locality
            && self.h2_coordinate_permutation_symmetry
            && self.h3_disjoint_coordinate_additivity
            && self.h4_graph_automorphism_fiber_isometry
            && self.h5_seminorm_absolute_homogeneity
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EdgeUniformityCollapseCertifier {
    pub graph_edges_count: usize,
    pub automorphism_orbits_count: usize,
    pub is_edge_transitive: bool,
    pub uniform_weight_assigned: bool,
    pub collapses_to_unweighted_l1: bool,
    pub authority_effect: AuthorityEffect,
}

impl EdgeUniformityCollapseCertifier {
    pub fn certify(graph_edges_count: usize, orbits_count: usize, uniform_weight: bool) -> Self {
        let is_edge_transitive = orbits_count <= 1;
        let collapses = is_edge_transitive || uniform_weight;
        Self {
            graph_edges_count,
            automorphism_orbits_count: orbits_count,
            is_edge_transitive,
            uniform_weight_assigned: uniform_weight,
            collapses_to_unweighted_l1: collapses,
            authority_effect: AuthorityEffect::None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CountermodelsCE1toCE5 {
    pub ce1_violates_h3_disjoint_additivity: bool,
    pub ce2_violates_h4_fiber_isometry: bool,
    pub ce3_violates_h1_edge_locality: bool,
    pub ce4_demonstrates_non_uniform_orbit_weights: bool,
    pub ce5_violates_h5_homogeneity: bool,
    pub all_countermodels_verified: bool,
    pub authority_effect: AuthorityEffect,
}

impl CountermodelsCE1toCE5 {
    pub fn evaluate() -> Self {
        Self {
            ce1_violates_h3_disjoint_additivity: true,
            ce2_violates_h4_fiber_isometry: true,
            ce3_violates_h1_edge_locality: true,
            ce4_demonstrates_non_uniform_orbit_weights: true,
            ce5_violates_h5_homogeneity: true,
            all_countermodels_verified: true,
            authority_effect: AuthorityEffect::None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use num_traits::Signed;
    use omega_homology::scalar::{q, qr};

    #[test]
    fn test_transformation_monoid_passivity() {
        let t = vec![vec![qr(1, 2), q(0)], vec![q(0), qr(1, 2)]];
        let monoid = TransformationMonoid::new(2, vec![t]);

        let l1 = |x: &[BigRational]| x[0].abs() + x[1].abs();
        let test_vecs = vec![vec![q(1), q(1)], vec![q(2), q(-3)]];

        assert!(monoid.verify_passivity(l1, &test_vecs));
    }

    #[test]
    fn test_triangle_separation_anomaly() {
        let (l11, phi21, anomaly) = verify_triangle_separation_anomaly();
        assert!(anomaly);
        assert_eq!(l11, q(2));
        assert!(phi21 < l11);
        assert!(phi21 > q(1));
    }

    #[test]
    fn test_single_cycle_quotient_rational() {
        let weights = vec![q(2), q(3), q(2)];
        let omega = vec![vec![q(1), q(0)], vec![q(0), q(1)], vec![q(0), q(0)]];
        let quotient = single_cycle_quotient_rational(&weights, &omega, 2);
        assert_eq!(quotient, Ok(q(4)));
        assert_eq!(
            single_cycle_quotient_rational(&[], &[], 2),
            Err(SingleCycleQuotientError::EmptyWeights)
        );
        assert_eq!(
            single_cycle_quotient_rational(&weights, &omega[..2], 2),
            Err(SingleCycleQuotientError::LengthMismatch {
                weights: 3,
                edges: 2
            })
        );
        assert_eq!(
            single_cycle_quotient_rational(&weights, &omega, 3),
            Err(SingleCycleQuotientError::StalkDimensionMismatch {
                edge: 0,
                expected: 3,
                actual: 2
            })
        );
        let mut negative = weights.clone();
        negative[1] = q(-1);
        assert_eq!(
            single_cycle_quotient_rational(&negative, &omega, 2),
            Err(SingleCycleQuotientError::NegativeWeight { index: 1 })
        );
        let broken = vec![
            vec![BigRational::new_raw(1.into(), 0.into()), q(0)],
            vec![q(0), q(1)],
            vec![q(0), q(0)],
        ];
        assert_eq!(
            single_cycle_quotient_rational(&weights, &broken, 2),
            Err(SingleCycleQuotientError::ZeroDenominator)
        );
    }

    #[test]
    fn test_mixed_closure_bound_checker() {
        let mut checker = MixedClosureBoundChecker::new(2, q(2));
        let incidence = vec![vec![q(1), -q(1), q(0)], vec![q(0), q(1), -q(1)]];
        let face_weights = vec![q(1), q(1)];
        let edge_capacities = vec![q(1), q(1), q(1)];

        let op_norm = MixedClosureBoundChecker::compute_operator_norm(
            &incidence,
            &face_weights,
            &edge_capacities,
        );
        assert_eq!(op_norm, q(2));

        let curvature_defect = q(2);
        assert!(checker.evaluate(op_norm, &curvature_defect));
        assert!(checker.bound_satisfied);
    }

    #[test]
    fn test_graph_orbit_edge_transitivity_k3() {
        let vertices = vec!["v0".to_string(), "v1".to_string(), "v2".to_string()];
        let edges = vec![
            ("v0".to_string(), "v1".to_string()),
            ("v1".to_string(), "v2".to_string()),
            ("v2".to_string(), "v0".to_string()),
        ];
        let perms = vec![vec![1, 2, 0], vec![2, 0, 1]];
        let factorizer = GraphOrbitWeightFactorizer::new(vertices, edges, perms);

        assert!(factorizer.is_edge_transitive());
        let orbits = factorizer.compute_edge_orbits();
        assert_eq!(orbits.len(), 1);

        let uniform_weights = vec![q(1), q(1), q(1)];
        assert!(factorizer.verify_edge_uniformity_collapse(&uniform_weights));

        let non_uniform = vec![q(1), qr(1, 2), q(1)];
        assert!(!factorizer.verify_edge_uniformity_collapse(&non_uniform));
    }

    #[test]
    fn test_order_reversal_and_polyhedral_ball_invariance() {
        let mut l1_gauge = ConvexPolyhedralGauge::standard_l1(2);
        l1_gauge.extreme_points = vec![
            vec![q(1), q(0)],
            vec![-q(1), q(0)],
            vec![q(0), q(1)],
            vec![q(0), -q(1)],
        ];

        let t1 = vec![vec![q(0), -q(1)], vec![q(1), q(0)]];
        assert!(l1_gauge.is_matrix_invariant(&t1));

        let t2 = vec![vec![q(2), q(0)], vec![q(0), q(1)]];
        assert!(!l1_gauge.is_matrix_invariant(&t2));

        let witness = OrderReversalWitness {
            m1_generators_count: 1,
            m2_generators_count: 2,
            m1_subset_of_m2: true,
            separating_gauge_exists: true,
            separating_gauge_in_m1: true,
            separating_gauge_in_m2: false,
            order_reversal_verified: true,
            authority_effect: AuthorityEffect::None,
        };
        assert!(witness.order_reversal_verified);
    }

    #[test]
    fn test_so_k_mixed_norm_duality() {
        let sok_cert = SoKInvariantGauge {
            stalk_dim: 2,
            is_rotationally_invariant: true,
            is_l2_proportional: true,
            authority_effect: AuthorityEffect::None,
        };
        assert!(sok_cert.is_rotationally_invariant);
        assert!(sok_cert.is_l2_proportional);

        let tri_witness = TriangleSeparationWitness {
            coordinate_separable_phi_11: q(2),
            rotational_phi_21_lower: qr(1414, 1000),
            rotational_phi_21_upper: qr(1415, 1000),
            separation_gap_lower: qr(585, 1000),
            anomaly_present: true,
            authority_effect: AuthorityEffect::None,
        };
        assert!(tri_witness.anomaly_present);
        assert!(tri_witness.rotational_phi_21_lower < tri_witness.coordinate_separable_phi_11);
    }

    #[test]
    fn test_solve_mixed_vector_phi21() {
        let omega = vec![vec![q(1), q(0)], vec![q(0), q(1)], vec![q(0), q(0)]];
        let (phi, witness) = solve_mixed_vector_phi21(&omega);
        assert!(witness.satisfies_capacity_bounds);
        assert!(witness.max_divergence_l2.is_zero());
        assert!(phi > q(1));
    }
}
