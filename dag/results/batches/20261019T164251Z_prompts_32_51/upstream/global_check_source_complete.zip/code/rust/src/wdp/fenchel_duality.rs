
use num_rational::BigRational;
use num_traits::Signed;
use omega_functional::l1_seminorm::L1Seminorm;
use omega_functional::phi1::VerifiedExactPhi1;
use omega_solvers::solver_lp_phi1_quotient::solve_exact_phi1;
use serde::{Deserialize, Serialize};

use crate::cochains::{coboundary_rows, named_graph_carrier};
use crate::error::WdpError;
use crate::types::AuthorityEffect;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum EdgeSaturationStatus {
    SaturatedPositive,
    SaturatedNegative,
    GaugeInactive,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FenchelDualityReceipt {
    phi1: VerifiedExactPhi1,
    edge_statuses: Vec<EdgeSaturationStatus>,
    authority_effect: AuthorityEffect,
}

impl FenchelDualityReceipt {
    pub fn phi1(&self) -> &VerifiedExactPhi1 {
        &self.phi1
    }

    pub fn edge_statuses(&self) -> &[EdgeSaturationStatus] {
        &self.edge_statuses
    }

    pub fn authority_effect(&self) -> AuthorityEffect {
        self.authority_effect
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct WeightedComplex {
    pub vertices: Vec<String>,
    pub edges: Vec<(String, String)>,
    pub capacities: Vec<BigRational>,
    pub authority_effect: AuthorityEffect,
}

impl WeightedComplex {
    pub fn new(
        vertices: Vec<String>,
        edges: Vec<(String, String)>,
        capacities: Vec<BigRational>,
    ) -> Self {
        assert_eq!(
            edges.len(),
            capacities.len(),
            "Each edge must have a capacity"
        );
        for c in &capacities {
            assert!(c.is_positive(), "Capacities must be strictly positive");
        }
        Self {
            vertices,
            edges,
            capacities,
            authority_effect: AuthorityEffect::None,
        }
    }

    pub fn l1_quotient_presentation(&self) -> Result<L1Seminorm, WdpError> {
        let carrier = named_graph_carrier(
            &self.vertices,
            &self.edges,
            &[],
            self.capacities.clone(),
            "omega_wdp::WeightedComplex",
        )?;
        Ok(L1Seminorm::new(
            coboundary_rows(carrier.d0()),
            carrier.weights().to_vec(),
        )?)
    }

    pub fn solve_fenchel_duality(
        &self,
        omega: &[BigRational],
    ) -> Result<FenchelDualityReceipt, WdpError> {
        let phi1 = solve_exact_phi1(&self.l1_quotient_presentation()?, omega)?;

        let edge_statuses = phi1
            .dual_witness()
            .iter()
            .zip(&self.capacities)
            .map(|(psi_e, cap)| {
                if psi_e == cap {
                    EdgeSaturationStatus::SaturatedPositive
                } else if *psi_e == -cap {
                    EdgeSaturationStatus::SaturatedNegative
                } else {
                    EdgeSaturationStatus::GaugeInactive
                }
            })
            .collect();

        Ok(FenchelDualityReceipt {
            phi1,
            edge_statuses,
            authority_effect: AuthorityEffect::None,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use num_traits::Zero;
    use omega_functional::phi1::Phi1Functional;
    use omega_homology::scalar::q;

    #[test]
    fn test_fenchel_rockafellar_zero_duality_gap_triangle() {
        let vertices = vec!["0".to_string(), "1".to_string(), "2".to_string()];
        let edges = vec![
            ("0".to_string(), "1".to_string()),
            ("1".to_string(), "2".to_string()),
            ("0".to_string(), "2".to_string()),
        ];
        let capacities = vec![q(1), q(1), q(1)];
        let complex = WeightedComplex::new(vertices, edges, capacities);

        let exact_omega = vec![q(2), q(3), q(5)];
        let receipt1 = complex.solve_fenchel_duality(&exact_omega).unwrap();
        assert!(receipt1.phi1().value().is_zero());
        assert_eq!(receipt1.authority_effect(), AuthorityEffect::None);

        let cycle_omega = vec![q(1), q(1), q(0)];
        let receipt2 = complex.solve_fenchel_duality(&cycle_omega).unwrap();
        assert_eq!(receipt2.phi1().value(), &q(2));
        assert!(receipt2
            .edge_statuses()
            .iter()
            .all(|status| *status != EdgeSaturationStatus::GaugeInactive));

        for receipt in [receipt1, receipt2] {
            let replayed =
                Phi1Functional::verify_exact_certificate(receipt.phi1().certificate().clone())
                    .unwrap();
            assert_eq!(replayed.value(), receipt.phi1().value());
        }
    }
}
