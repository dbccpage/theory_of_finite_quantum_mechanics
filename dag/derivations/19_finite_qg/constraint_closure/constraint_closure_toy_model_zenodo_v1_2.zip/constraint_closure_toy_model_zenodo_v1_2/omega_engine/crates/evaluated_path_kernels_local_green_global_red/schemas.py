import math
from typing import Any
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.core import (
    ComposedPath,
    create_state,
    create_path_segment,
    create_composed_path,
)
from omega_engine.crates.type.refusal import Refusal, Result


def require_nonempty_str(row: dict[str, Any], key: str) -> str:
    value = row.get(key)
    if not isinstance(value, str):
        raise ValueError(f"{key} must be a string")
    value = value.strip()
    if not value:
        raise ValueError(f"{key} cannot be empty")
    return value


def require_bool(row: dict[str, Any], key: str) -> bool:
    value = row.get(key)
    if not isinstance(value, bool):
        raise ValueError(f"{key} must be a boolean")
    return value


def require_nonnegative_finite_float(row: dict[str, Any], key: str) -> float:
    value = row.get(key)
    if value is None:
        raise ValueError(f"{key} is required")
    if isinstance(value, bool):
        raise ValueError(f"{key} must be numeric, not boolean")
    try:
        x = float(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"{key} must be numeric") from e
    if not math.isfinite(x):
        raise ValueError(f"{key} must be finite")
    if x < 0:
        raise ValueError(f"{key} must be non-negative")
    return x


def validate_and_normalize_row(row: dict[str, Any]) -> Result[ComposedPath]:
    """Validate and normalize a raw row into a ComposedPath.

    Returns a typed ``Result``: a ``ComposedPath`` on success, or a ``Refusal``
    on any schema violation. No raw ValueError escapes this boundary -- the
    field-extraction helpers may raise internally, but they are caught here and
    converted to a Refusal so the replay boundary always sees a typed result.
    """
    if not isinstance(row, dict):
        return Refusal(
            "row must be a JSON object/dict",
            details={"row_type": type(row).__name__},
        )

    try:
        required_keys = {
            "task_id",
            "example_type",
            "source_state",
            "boundary_state",
            "target_state",
            "first_local_pass",
            "second_local_pass",
            "global_pass",
            "first_cost",
            "second_cost",
        }
        for key in required_keys:
            if key not in row:
                raise ValueError(f"Missing required field: {key}")

        example_type = require_nonempty_str(row, "example_type")
        if example_type not in {"swe", "hwe", "tau"}:
            raise ValueError(f"Unknown example type: {example_type}")

        task_id = require_nonempty_str(row, "task_id")
        source_state = require_nonempty_str(row, "source_state")
        boundary_state = require_nonempty_str(row, "boundary_state")
        target_state = require_nonempty_str(row, "target_state")

        first_cost = require_nonnegative_finite_float(row, "first_cost")
        second_cost = require_nonnegative_finite_float(row, "second_cost")

        first_pass = require_bool(row, "first_local_pass")
        second_pass = require_bool(row, "second_local_pass")
        global_pass = require_bool(row, "global_pass")

        composed_cost = None
        if "composed_cost" in row and row["composed_cost"] is not None:
            composed_cost = require_nonnegative_finite_float(row, "composed_cost")

        label = row.get("label", "")
        if not isinstance(label, str):
            raise ValueError("label must be a string")

        metadata = row.get("metadata", {})
        if not isinstance(metadata, dict):
            raise ValueError("metadata must be an object/dict")

        if "label" in metadata:
            raise ValueError("metadata dictionary cannot contain the key 'label'")
    except ValueError as exc:
        return Refusal(str(exc), details={"stage": "field_extraction"})

    merged_metadata = {**metadata, "label": label, "example_type": example_type}

    s_a = create_state(id=source_state)
    if isinstance(s_a, Refusal):
        return s_a
    s_b = create_state(id=boundary_state)
    if isinstance(s_b, Refusal):
        return s_b
    s_c = create_state(id=target_state)
    if isinstance(s_c, Refusal):
        return s_c

    seg1 = create_path_segment(
        id=f"{task_id}_seg1",
        source=s_a,
        target=s_b,
        cost=first_cost,
        eval_pass=first_pass,
        metadata=dict(merged_metadata),
    )
    if isinstance(seg1, Refusal):
        return seg1

    seg2 = create_path_segment(
        id=f"{task_id}_seg2",
        source=s_b,
        target=s_c,
        cost=second_cost,
        eval_pass=second_pass,
        metadata=dict(merged_metadata),
    )
    if isinstance(seg2, Refusal):
        return seg2

    return create_composed_path(
        id=task_id,
        first=seg1,
        second=seg2,
        global_eval_pass=global_pass,
        composed_cost=composed_cost,
        metadata=dict(merged_metadata),
    )



