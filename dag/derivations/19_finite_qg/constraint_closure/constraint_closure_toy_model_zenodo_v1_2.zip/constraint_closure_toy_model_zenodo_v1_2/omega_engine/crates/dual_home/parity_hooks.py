"""Compatibility façade for decomposed parity hooks.

Types live under ``omega_engine.crates.type.parity``.
Registry metadata lives under ``omega_engine.crates.parity.registry``.
Independent mirrors live under ``omega_engine.crates.parity.mirrors``.
Executable comparisons live under ``omega_engine.crates.parity.checks``.

AuthorityEffect: None.
"""

from ..type.parity import ParityReceipt, ProdBindingStatus, SymbolHome
from ..parity.registry import (
    SYMBOL_REGISTRY,
    list_symbols,
    math_path_for,
    prod_binding_status,
)
from ..parity.validation import _require_finite_matrix, _require_finite_vector
from ..parity.ffi import try_ffi_callable as _try_ffi_callable
from ..parity.mirrors.functional import (
    prod_mirror_gamma2 as _prod_mirror_gamma2,
    prod_mirror_residual_l1 as _prod_mirror_residual_l1,
)
from ..parity.mirrors.linear_algebra import prod_mirror_matmul as _prod_mirror_matmul
from ..parity.mirrors.xi import prod_mirror_xi_compute as _prod_mirror_xi_compute
from ..parity.mirrors.dual import (
    prod_mirror_display_dual_witness as _prod_mirror_display_dual_witness,
    prod_mirror_float_dual_checks as _prod_mirror_float_dual_checks,
)
from ..parity.checks import (
    call_dual_witness,
    call_float_dual_checks,
    call_gamma2,
    call_gram_schmidt,
    call_matmul,
    call_residual_l1,
    call_xi,
)

__all__ = [
    "ParityReceipt",
    "ProdBindingStatus",
    "SYMBOL_REGISTRY",
    "SymbolHome",
    "call_dual_witness",
    "call_float_dual_checks",
    "call_gamma2",
    "call_gram_schmidt",
    "call_matmul",
    "call_residual_l1",
    "call_xi",
    "list_symbols",
    "math_path_for",
    "prod_binding_status",
]
