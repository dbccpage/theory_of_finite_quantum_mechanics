"""monad shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Monad:
    """Best-effort shell for a labeled monad (T, η, μ).

    Holds endofunctor + unit + multiply refs only; law discharge is external.
    """

    label: str
    endofunctor_ref: str = ""
    unit_ref: str = ""
    multiply_ref: str = ""
    category_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Monad":
        return cls(label=label)

    @classmethod
    def with_structure(
        cls,
        label: str,
        endofunctor_ref: str,
        unit_ref: str,
        multiply_ref: str,
    ) -> "Monad":
        return cls(
            label=label,
            endofunctor_ref=endofunctor_ref,
            unit_ref=unit_ref,
            multiply_ref=multiply_ref,
        )

    def with_note(self, note: str) -> "Monad":
        self.notes.append(note)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.endofunctor_ref:
            raise ValueError("empty endofunctor_ref")
        if not self.unit_ref:
            raise ValueError("empty unit_ref")
        if not self.multiply_ref:
            raise ValueError("empty multiply_ref")



