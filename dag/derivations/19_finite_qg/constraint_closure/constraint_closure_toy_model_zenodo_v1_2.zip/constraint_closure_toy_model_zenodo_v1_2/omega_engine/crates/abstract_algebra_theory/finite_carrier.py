"""Finite sets, vector spaces, and maps for exact algebraic computations.

Enforces finite bounds to prevent infinite-dimensional or analytic leaks.
"""

from fractions import Fraction
from typing import Any, Dict, List, Tuple


def to_fraction(value: Any) -> Fraction:
    """Convert an int/float/Fraction coefficient to an EXACT rational.

    Every finite Python ``float`` is a dyadic rational, so ``Fraction(value)``
    captures its *exact* binary value (e.g. ``Fraction(0.1)`` is
    ``3602879701896397/36028797018963968``, NOT ``1/10``). This is the whole
    point of the exact Q1 certificate (audit U3): a float-shadow near-miss that
    would wrongly pass under float ``==`` is refused under exact arithmetic.

    Genuinely non-rational floats (``nan``/``inf``) are rejected; pass
    ``Fraction(1, 10)`` when you mean the exact rational 1/10.
    """
    if isinstance(value, Fraction):
        return value
    if isinstance(value, int):
        return Fraction(value)
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise ValueError(f"Non-rational float {value!r} has no exact Fraction")
        return Fraction(value)
    # bool is an int subclass; anything else is a contract violation.
    raise TypeError(f"Cannot convert {value!r} of type {type(value)} to Fraction")


def exact_coeffs(vec: "Vector") -> Dict[Any, Fraction]:
    """Exact-rational view of a Vector's coefficients (zeros dropped)."""
    out: Dict[Any, Fraction] = {}
    for k, v in vec.coeffs.items():
        f = to_fraction(v)
        if f != 0:
            out[k] = f
    return out


class FiniteSet:
    """A finite set of elements."""

    def __init__(self, elements: List[Any]) -> None:
        self.elements = list(
            dict.fromkeys(elements)
        )  # preserve order, remove duplicates

    def __contains__(self, item: Any) -> bool:
        return item in self.elements

    def __len__(self) -> int:
        return len(self.elements)

    def __repr__(self) -> str:
        return f"FiniteSet({self.elements!r})"


class Vector:
    """A vector in a finite vector space, represented as a linear combination of basis elements."""

    def __init__(self, coeffs: Dict[Any, float]) -> None:
        # filter out zero coefficients
        self.coeffs = {k: v for k, v in coeffs.items() if v != 0}

    def __add__(self, other: "Vector") -> "Vector":
        res = dict(self.coeffs)
        for k, v in other.coeffs.items():
            res[k] = res.get(k, 0.0) + v
        return Vector(res)

    def __sub__(self, other: "Vector") -> "Vector":
        res = dict(self.coeffs)
        for k, v in other.coeffs.items():
            res[k] = res.get(k, 0.0) - v
        return Vector(res)

    def __mul__(self, scalar: float) -> "Vector":
        return Vector({k: v * scalar for k, v in self.coeffs.items()})

    def is_zero(self) -> bool:
        return len(self.coeffs) == 0

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Vector):
            return NotImplemented
        return self.coeffs == other.coeffs

    def __repr__(self) -> str:
        if not self.coeffs:
            return "0"
        terms = [f"{v}*{k}" for k, v in self.coeffs.items()]
        return " + ".join(terms)


def exact_difference(x: "Vector", y: "Vector") -> Dict[Any, Fraction]:
    """Exact-rational ``x - y`` as ``{basis: Fraction}`` (zeros dropped)."""
    xf = exact_coeffs(x)
    yf = exact_coeffs(y)
    out: Dict[Any, Fraction] = dict(xf)
    for k, v in yf.items():
        out[k] = out.get(k, Fraction(0)) - v
    return {k: v for k, v in out.items() if v != 0}


def exact_dicts_equal(a: Dict[Any, Fraction], b: Dict[Any, Fraction]) -> bool:
    """Equality of two exact-coefficient dicts (zeros already dropped)."""
    return a == b


class FiniteVectorSpace:
    """A vector space over a finite basis."""

    def __init__(self, basis: List[Any]) -> None:
        self.basis = FiniteSet(basis)

    def zero(self) -> Vector:
        return Vector({})

    def basis_element(self, element: Any) -> Vector:
        if element not in self.basis:
            raise ValueError(f"Basis element {element} not in space basis {self.basis}")
        return Vector({element: 1.0})

    def make_vector(self, coeffs: Dict[Any, float]) -> Vector:
        for k in coeffs:
            if k not in self.basis:
                raise ValueError(f"Element {k} not in space basis {self.basis}")
        return Vector(coeffs)

    def __repr__(self) -> str:
        return f"FiniteVectorSpace(basis={self.basis.elements!r})"


class FiniteMap:
    """A map between two finite sets."""

    def __init__(
        self, domain: FiniteSet, codomain: FiniteSet, mapping: Dict[Any, Any]
    ) -> None:
        self.domain = domain
        self.codomain = codomain
        self.mapping = mapping
        # validate map
        for k, v in mapping.items():
            if k not in domain:
                raise ValueError(f"Key {k} not in domain {domain}")
            if v not in codomain:
                raise ValueError(f"Value {v} not in codomain {codomain}")

    def evaluate(self, x: Any) -> Any:
        if x not in self.domain:
            raise ValueError(f"Input {x} not in domain {self.domain}")
        return self.mapping[x]


class MatrixMap:
    """A linear map between two FiniteVectorSpaces."""

    def __init__(
        self,
        domain: FiniteVectorSpace,
        codomain: FiniteVectorSpace,
        matrix: Dict[Tuple[Any, Any], float],
    ) -> None:
        # matrix is represented as dict: (codomain_basis_element, domain_basis_element) -> coeff
        self.domain = domain
        self.codomain = codomain
        self.matrix = matrix
        # Reject matrix entries whose basis symbols are not in the declared
        # domain/codomain.
        for out_basis, in_basis in matrix:
            if out_basis not in codomain.basis:
                raise ValueError(
                    f"Output basis {out_basis!r} not in codomain basis {codomain.basis}"
                )
            if in_basis not in domain.basis:
                raise ValueError(
                    f"Input basis {in_basis!r} not in domain basis {domain.basis}"
                )

    def apply(self, v: Vector) -> Vector:
        """Applies linear map to a vector.

        The input vector's coefficient basis must be a subset of the domain
        basis; a foreign basis symbol raises ValueError.
        """
        for in_basis in v.coeffs:
            if in_basis not in self.domain.basis:
                raise ValueError(
                    f"Vector basis symbol {in_basis!r} not in domain basis {self.domain.basis}"
                )
        res_coeffs: Dict[Any, float] = {}
        for (out_basis, in_basis), coeff in self.matrix.items():
            in_val = v.coeffs.get(in_basis, 0.0)
            if in_val != 0.0:
                res_coeffs[out_basis] = res_coeffs.get(out_basis, 0.0) + coeff * in_val
        return Vector(res_coeffs)

    __call__ = apply

    def apply_exact(self, v: "Vector") -> Dict[Any, Fraction]:
        """Apply the linear map in EXACT rational arithmetic.

        Returns a dict of ``{out_basis: Fraction}``. Matrix coeffs and the input
        vector coeffs are converted to ``Fraction`` BEFORE any multiply/add, so
        the result carries no float rounding. This is the load-bearing primitive
        for the exact Q1 certificate (audit U3): never multiply in float and
        reinterpret the product as exact.
        """
        for in_basis in v.coeffs:
            if in_basis not in self.domain.basis:
                raise ValueError(
                    f"Vector basis symbol {in_basis!r} not in domain basis {self.domain.basis}"
                )
        v_exact = exact_coeffs(v)
        res: Dict[Any, Fraction] = {}
        for (out_basis, in_basis), coeff in self.matrix.items():
            in_val = v_exact.get(in_basis)
            if in_val is None:
                continue
            res[out_basis] = (
                res.get(out_basis, Fraction(0)) + to_fraction(coeff) * in_val
            )
        return {k: val for k, val in res.items() if val != 0}

    def compose(self, other: "MatrixMap") -> "MatrixMap":
        """Composes self o other (apply other, then self)."""
        if self.domain.basis.elements != other.codomain.basis.elements:
            raise ValueError("Incompatible spaces for composition")

        new_matrix: Dict[Tuple[Any, Any], float] = {}
        for (c_basis, b_basis), coeff_self in self.matrix.items():
            for (b_basis_prime, a_basis), coeff_other in other.matrix.items():
                if b_basis == b_basis_prime:
                    val = coeff_self * coeff_other
                    pair = (c_basis, a_basis)
                    new_matrix[pair] = new_matrix.get(pair, 0.0) + val
        return MatrixMap(other.domain, self.codomain, new_matrix)

    def is_zero(self) -> bool:
        return all(v == 0.0 for v in self.matrix.values())

