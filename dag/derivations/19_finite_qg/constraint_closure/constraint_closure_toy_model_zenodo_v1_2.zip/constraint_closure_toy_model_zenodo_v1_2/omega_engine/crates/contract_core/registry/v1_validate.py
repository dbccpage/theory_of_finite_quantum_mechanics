from omega_engine.crates.contract_core.kinds import AuthorityEffect
from omega_engine.crates.contract_core.registry.v1_types import OmegaContractV1
from omega_engine.crates.contract_core.registry.v1_vocabulary import (
    is_known_terminal,
    is_known_refusal,
)


def validate_v1(c: OmegaContractV1) -> None:
    findings = []

    if c.schema_version != "omega.contract.v1":
        findings.append(
            f"schema_version must be omega.contract.v1, got {c.schema_version}"
        )

    # Nomos structured URN (Forms A/B/C). Prefix-only is insufficient.
    from omega_engine.crates.contract_core.nomos_urn import is_well_formed_nomos_urn

    if not is_well_formed_nomos_urn(c.contract_id):
        findings.append(
            f"contract_id must be a well-formed Nomos urn:omega: URN, got {c.contract_id}"
        )

    if c.kind.is_math():
        if c.descriptor.authority_effect != AuthorityEffect.None_:
            findings.append("math contract must declare authority_effect: none")
        if c.descriptor.runtime_enforcement:
            findings.append("math contract must declare runtime_enforcement: false")

    if not c.kind.is_math() and c.role is None and c.kind.default_role() is None:
        findings.append(f"role required for non-math kind {c.kind}")

    for t in c.descriptor.terminals.may_support:
        if not is_known_terminal(t):
            findings.append(f"unknown terminal: {t}")
    for t in c.descriptor.terminals.may_emit:
        if not is_known_terminal(t):
            findings.append(f"unknown terminal: {t}")

    for r in c.descriptor.refusals.may_emit:
        if not is_known_refusal(r):
            findings.append(f"unknown refusal: {r}")

    for po in c.descriptor.dependencies.proof_obligations:
        if not is_well_formed_po(po):
            findings.append(f"malformed proof obligation: {po}")

    if findings:
        raise ValueError(findings)


def is_well_formed_po(s: str) -> bool:
    if "-" not in s:
        return False
    prefix, rest = s.split("-", 1)
    if prefix not in ("PO", "SG", "OB"):
        return False
    if not rest:
        return False
    if not all(ch.isalnum() or ch == "-" for ch in rest):
        return False
    if not any(ch.isalnum() for ch in rest):
        return False
    return True


