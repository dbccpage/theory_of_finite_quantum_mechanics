"""monoidal_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class MonoidalCategory:
    """Best-effort monoidal category shell (tensor/unit/coherence as strings)."""

    label: str
    underlying_category: str = ""
    tensor: str = ""
    unit_object: str = ""
    associator_ref: str = ""
    left_unitor_ref: str = ""
    right_unitor_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "MonoidalCategory":
        return cls(label=label)

    @classmethod
    def with_structure(
        cls,
        label: str,
        underlying_category: str,
        tensor: str,
        unit_object: str,
        associator_ref: str,
        left_unitor_ref: str,
        right_unitor_ref: str,
    ) -> "MonoidalCategory":
        return cls(
            label=label,
            underlying_category=underlying_category,
            tensor=tensor,
            unit_object=unit_object,
            associator_ref=associator_ref,
            left_unitor_ref=left_unitor_ref,
            right_unitor_ref=right_unitor_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.underlying_category:
            raise ValueError("empty underlying_category")
        if not self.tensor:
            raise ValueError("empty tensor")
        if not self.unit_object:
            raise ValueError("empty unit_object")
        if not self.associator_ref:
            raise ValueError("empty associator_ref")
        if not self.left_unitor_ref:
            raise ValueError("empty left_unitor_ref")
        if not self.right_unitor_ref:
            raise ValueError("empty right_unitor_ref")



