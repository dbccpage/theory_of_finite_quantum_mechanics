"""compact_closed shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class CompactClosed:
    """Best-effort compact closed category shell."""

    label: str
    monoidal_ref: str = ""
    left_dual_ref: str = ""
    right_dual_ref: str = ""
    unit_ref: str = ""
    counit_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "CompactClosed":
        return cls(label=label)

    @classmethod
    def with_duals(
        cls,
        label: str,
        monoidal_ref: str,
        dual_ref: str,
        unit_ref: str,
        counit_ref: str,
    ) -> "CompactClosed":
        return cls(
            label=label,
            monoidal_ref=monoidal_ref,
            left_dual_ref=dual_ref,
            right_dual_ref=dual_ref,
            unit_ref=unit_ref,
            counit_ref=counit_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.monoidal_ref:
            raise ValueError("empty monoidal_ref")
        if not self.left_dual_ref:
            raise ValueError("empty left_dual_ref")
        if not self.right_dual_ref:
            raise ValueError("empty right_dual_ref")
        if not self.unit_ref:
            raise ValueError("empty unit_ref")
        if not self.counit_ref:
            raise ValueError("empty counit_ref")



