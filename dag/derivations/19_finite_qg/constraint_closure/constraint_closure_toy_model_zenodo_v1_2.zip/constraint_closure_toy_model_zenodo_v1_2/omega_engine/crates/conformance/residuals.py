from __future__ import annotations
from pydantic import ConfigDict
r"""
Conformance residuals: making **vacuity** a computed number.

AuthorityEffect: None.

Why this module exists
----------------------
The obstruction calculus detects *residual*: :math:`\Phi_1 > 0` says no section exists.
It cannot detect *vacuity*, because a vacuous claim has residual **zero** --- that is
precisely why vacuous claims pass. Every defect found in this package's review rounds had
residual zero:

* ``nu_e`` computed without :math:`Q_e` --- identical to the correct value on the only
  witness the estate exercised;
* ``a_e`` omitting the D1 cross term --- likewise identical on that witness;
* Wigner--Yanase monotonicity claimed for all CPTP, then for all unital CPTP --- both false,
  both passing because the fixtures were dephasing-only;
* a Gleason "countermodel" that was not a frame function --- the check asked only whether a
  number differed from Born's;
* ``rho_ddot`` missing a factor of :math:`-i` --- invisible to any trace norm, since
  :math:`\|iM\|_1 = \|M\|_1`;
* an evaluator swapped between two papers --- 300 tests stayed green.

None of these produce an obstruction. So the engine, as a residual detector, says GREEN for
all of them. This module closes that blind spot by defining three residuals that are
**nonzero exactly when a claim cannot fail**, in the same shape the engine already handles:
a non-negative integer that is zero iff exact.

The three residuals
-------------------
``adequacy``     a declared wrong form that **no** witness in the family separates from the
                 right one. The generalization of "a test on a degenerate witness is
                 vacuous, not weak."
``mutation``     a declared mutation of the implementation that **no** check kills.
``attribution``  a quantity the source states that the evaluator does **not** reproduce.

Each returns a :class:`Residual` with an integer ``value``, zero iff conformant, plus the
specific witnesses/mutants/quantities responsible. Zero is ``ExactConformance``; nonzero is
``ClosedResidual`` --- the estate's own terminal vocabulary, because this is the same kind
of object.
"""


import math
from dataclasses import field
from pydantic.dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence

__all__ = [
    "Residual",
    "WrongForm",
    "adequacy_residual",
    "mutation_residual",
    "attribution_residual",
    "combine",
]


# --------------------------------------------------------------------------- result type


@dataclass(config=ConfigDict(arbitrary_types_allowed=True, frozen=True))
class Residual:
    r"""A conformance residual. ``value == 0`` iff the claim is exact under this check."""

    kind: str
    value: int
    total_checked: int
    failures: List[Dict[str, Any]] = field(default_factory=list)
    detail: str = ""

    @property
    def is_exact(self) -> bool:
        return self.value == 0

    @property
    def terminal(self) -> str:
        """The estate's terminal vocabulary: this residual is the same kind of object."""
        return "ExactConformance" if self.is_exact else "ClosedResidual"

    def as_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind,
            "residual": self.value,
            "checked": self.total_checked,
            "terminal": self.terminal,
            "failures": self.failures,
            "detail": self.detail,
            "authority_effect": "None",
        }


def combine(residuals: Sequence[Residual]) -> Dict[str, Any]:
    """Aggregate. The total is exact iff every component is."""
    total = sum(r.value for r in residuals)
    return {
        "total_residual": total,
        "terminal": "ExactConformance" if total == 0 else "ClosedResidual",
        "components": {r.kind: r.as_dict() for r in residuals},
        "authority_effect": "None",
    }


# ------------------------------------------------------------------- 1. witness adequacy


@dataclass(config=ConfigDict(arbitrary_types_allowed=True, frozen=True))
class WrongForm:
    r"""A plausible **wrong definition** of a quantity, and why it is plausible.

    Not a mutation of the code --- a mutation of the *mathematics*. ``nu_e`` without
    :math:`Q_e` is a wrong form; a typo is not. The point is that these are the errors a
    competent person actually makes, so a witness family that cannot separate them is not
    testing the definition.
    """

    name: str
    fn: Callable[..., Any]
    why_plausible: str


def _close(a: Any, b: Any, atol: float) -> bool:
    """Structural closeness for scalars, bools and flat numeric sequences."""
    if isinstance(a, bool) or isinstance(b, bool):
        return bool(a) == bool(b)
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        if math.isnan(a) or math.isnan(b):
            return math.isnan(a) and math.isnan(b)
        return abs(float(a) - float(b)) <= atol
    if isinstance(a, str) or isinstance(b, str):
        return a == b
    try:
        pa, pb = list(a), list(b)
    except TypeError:
        return a == b
    return len(pa) == len(pb) and all(_close(x, y, atol) for x, y in zip(pa, pb))


def adequacy_residual(
    quantity: str,
    correct: Callable[..., Any],
    wrong_forms: Sequence[WrongForm],
    witnesses: Mapping[str, Any],
    atol: float = 1e-9,
) -> Residual:
    r"""Residual = the number of wrong forms **no** witness separates from the correct one.

    ``witnesses`` maps a witness name to the argument tuple/dict passed to each callable.
    A wrong form is *separated* if some witness makes the correct and wrong values differ by
    more than ``atol``.

    This is the check that would have caught defects D1 and D5 at authoring time. On the
    estate's only witness --- :math:`H = \sigma_x\otimes\sigma_x`, :math:`\rho_0 = |00\rangle\langle 00|`
    --- both wrong forms agree with the correct one to machine precision, so the residual is
    2 and the gate blocks. Adding a non-interacting Hamiltonian drives it to 0.

    A quantity with no declared wrong forms scores residual ``0`` but is reported as
    ``UNCHECKED`` in ``detail``: nothing was ruled out, and that is not the same as exact.
    """
    if not wrong_forms:
        return Residual(
            kind=f"adequacy:{quantity}",
            value=0,
            total_checked=0,
            detail="UNCHECKED - no wrong forms declared; nothing was ruled out",
        )
    if not witnesses:
        return Residual(
            kind=f"adequacy:{quantity}",
            value=len(wrong_forms),
            total_checked=len(wrong_forms),
            failures=[
                {"wrong_form": w.name, "separated_by": None, "why_plausible": w.why_plausible}
                for w in wrong_forms
            ],
            detail="no witnesses declared, so nothing can be separated",
        )

    failures: List[Dict[str, Any]] = []
    for wf in wrong_forms:
        separating: Optional[str] = None
        for wname, args in witnesses.items():
            got_right = _apply(correct, args)
            got_wrong = _apply(wf.fn, args)
            if not _close(got_right, got_wrong, atol):
                separating = wname
                break
        if separating is None:
            failures.append(
                {
                    "wrong_form": wf.name,
                    "why_plausible": wf.why_plausible,
                    "separated_by": None,
                    "verdict": (
                        "NO witness in the declared family distinguishes this wrong form "
                        "from the correct one -- any test over this family is vacuous"
                    ),
                }
            )

    return Residual(
        kind=f"adequacy:{quantity}",
        value=len(failures),
        total_checked=len(wrong_forms),
        failures=failures,
        detail=f"{len(wrong_forms) - len(failures)}/{len(wrong_forms)} wrong forms separated "
        f"by {len(witnesses)} witness(es)",
    )


def _apply(fn: Callable[..., Any], args: Any) -> Any:
    """Call ``fn`` with a witness argument: a mapping is kwargs, a sequence is args."""
    try:
        if isinstance(args, Mapping):
            return fn(**args)
        if isinstance(args, (list, tuple)):
            return fn(*args)
        return fn(args)
    except Exception as exc:  # a raising form is separated by its exception type
        return f"__raised__:{type(exc).__name__}"


# ------------------------------------------------------------------------- 2. mutation


def mutation_residual(
    subject: str,
    mutations: Mapping[str, Callable[[], bool]],
) -> Residual:
    """Residual = the number of declared mutations that **no** check kills.

    Each entry maps a mutation name to a callable returning ``True`` when the mutation is
    **caught** (some check fails under it). Surviving mutations are the residual.

    This is the discipline that found the 74-test stub failure and the evaluator swap; here
    it is the gate rather than something run by hand.
    """
    if not mutations:
        return Residual(
            kind=f"mutation:{subject}",
            value=0,
            total_checked=0,
            detail="UNCHECKED - no mutations declared",
        )

    failures: List[Dict[str, Any]] = []
    for name, probe in mutations.items():
        try:
            caught = bool(probe())
        except Exception as exc:
            caught = True  # the mutation broke something loudly; that counts as caught
            _ = exc
        if not caught:
            failures.append(
                {
                    "mutation": name,
                    "verdict": "survived - no check distinguishes it from the original",
                }
            )

    return Residual(
        kind=f"mutation:{subject}",
        value=len(failures),
        total_checked=len(mutations),
        failures=failures,
        detail=f"{len(mutations) - len(failures)}/{len(mutations)} mutations killed",
    )


# ---------------------------------------------------------------------- 3. attribution


def attribution_residual(
    claim: str,
    declared: Mapping[str, float],
    produced: Mapping[str, Any],
    atol: float = 1e-9,
) -> Residual:
    """Residual = declared source quantities the evaluator fails to reproduce.

    ``declared`` are the numbers the *source* states; ``produced`` is what the evaluator
    actually returned. A missing key and a wrong value are both residual, because both mean
    the evaluator is not bound to this source.
    """
    if not declared:
        return Residual(
            kind=f"attribution:{claim}",
            value=0,
            total_checked=0,
            detail="UNCHECKED - no source quantities declared; nothing is attributed",
        )

    failures: List[Dict[str, Any]] = []
    for name, expected in declared.items():
        if name not in produced:
            failures.append(
                {"quantity": name, "expected": expected, "got": None, "reason": "not produced"}
            )
            continue
        got = produced[name]
        if not isinstance(got, (int, float, bool)) or not _close(got, expected, atol):
            failures.append(
                {
                    "quantity": name,
                    "expected": expected,
                    "got": got,
                    "reason": "value does not match the source",
                }
            )

    return Residual(
        kind=f"attribution:{claim}",
        value=len(failures),
        total_checked=len(declared),
        failures=failures,
        detail=f"{len(declared) - len(failures)}/{len(declared)} source quantities reproduced",
    )



