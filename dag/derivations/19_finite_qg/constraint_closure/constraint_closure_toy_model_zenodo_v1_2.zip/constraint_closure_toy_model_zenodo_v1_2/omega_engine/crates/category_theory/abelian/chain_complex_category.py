"""chain_complex_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Category of chain complexes (bounded or degree-windowed). Degree bounds are
shape metadata only. Concrete boundary-law complexes and homology computation
live in ``omega_homology`` (conceptual link in docs comments only).
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class ChainComplexCategory:
    """Best-effort shell for Ch(A) / Kom(A) with optional degree window."""

    label: str
    degree_min: int = 0
    degree_max: int = 0
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "ChainComplexCategory":
        return cls(label=label)

    @classmethod
    def with_degree_bounds(
        cls, label: str, degree_min: int, degree_max: int
    ) -> "ChainComplexCategory":
        return cls(label=label, degree_min=degree_min, degree_max=degree_max)

    def with_note(self, note: str) -> "ChainComplexCategory":
        self.notes.append(note)
        return self

    def degree_span(self) -> Optional[int]:
        """Span of the declared degree window, or None if bounds are inverted."""
        if self.degree_min <= self.degree_max:
            return self.degree_max - self.degree_min
        return None

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if self.degree_min > self.degree_max:
            raise ValueError(
                f"degree_min {self.degree_min} > degree_max {self.degree_max}"
            )



