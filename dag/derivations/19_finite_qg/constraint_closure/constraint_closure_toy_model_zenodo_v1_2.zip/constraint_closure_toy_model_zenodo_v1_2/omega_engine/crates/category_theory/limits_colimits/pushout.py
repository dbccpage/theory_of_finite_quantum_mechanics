"""pushout shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Pushout:
    """Best-effort shell for a pushout of a span A ← C → B."""

    label: str
    pushout_object: str = ""
    left_target: str = ""
    right_target: str = ""
    span_base: str = ""
    morphism_f: str = ""
    morphism_g: str = ""
    injection_left: str = ""
    injection_right: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Pushout":
        return cls(label=label)

    @classmethod
    def of_span(
        cls,
        label: str,
        pushout_object: str,
        left_target: str,
        right_target: str,
        span_base: str,
        morphism_f: str,
        morphism_g: str,
        injection_left: str,
        injection_right: str,
    ) -> "Pushout":
        return cls(
            label=label,
            pushout_object=pushout_object,
            left_target=left_target,
            right_target=right_target,
            span_base=span_base,
            morphism_f=morphism_f,
            morphism_g=morphism_g,
            injection_left=injection_left,
            injection_right=injection_right,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.pushout_object:
            raise ValueError("empty pushout_object")
        if not self.left_target:
            raise ValueError("empty left_target")
        if not self.right_target:
            raise ValueError("empty right_target")
        if not self.span_base:
            raise ValueError("empty span_base")
        if not self.morphism_f:
            raise ValueError("empty morphism_f")
        if not self.morphism_g:
            raise ValueError("empty morphism_g")
        if not self.injection_left:
            raise ValueError("empty injection_left")
        if not self.injection_right:
            raise ValueError("empty injection_right")



