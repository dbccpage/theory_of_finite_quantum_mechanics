"""Finite Category Law Validation Suite."""

from __future__ import annotations
from typing import List
from .finite_category import DeclaredFiniteCategory


def validate_finite_category(category: DeclaredFiniteCategory) -> List[str]:
    """Validates identity existence, domain/codomain composition rules, and associativity laws."""
    errors: List[str] = []

    for obj in category.objects:
        if obj not in category.identities:
            errors.append(f"Missing identity for object '{obj}'")

    for (f, g), composite in category.compositions.items():
        bound_f = category.boundary_of(f)
        bound_g = category.boundary_of(g)
        bound_comp = category.boundary_of(composite)

        if bound_f is None:
            errors.append(f"Morphism '{f}' in composition ({f}, {g}) is undeclared")
            continue
        if bound_g is None:
            errors.append(f"Morphism '{g}' in composition ({f}, {g}) is undeclared")
            continue
        if bound_comp is None:
            errors.append(f"Composite morphism '{composite}' is undeclared")
            continue

        if bound_f[1] != bound_g[0]:
            errors.append(
                f"Morphism domain/codomain mismatch: '{f}' targets '{bound_f[1]}', but '{g}' sources from '{bound_g[0]}'"
            )

        if bound_comp != (bound_f[0], bound_g[1]):
            errors.append(
                f"Composite boundary mismatch for {g} ∘ {f}: expected ({bound_f[0]}, {bound_g[1]}), got {bound_comp}"
            )

    for mor_name, mor in category.morphisms.items():
        id_src = category.identity_of(mor.source)
        id_tgt = category.identity_of(mor.target)

        if id_src:
            comp_left = category.compose(id_src, mor_name)
            if comp_left is not None and comp_left != mor_name:
                errors.append(
                    f"Left identity law fails for '{mor_name}': id ∘ f = {comp_left}"
                )

        if id_tgt:
            comp_right = category.compose(mor_name, id_tgt)
            if comp_right is not None and comp_right != mor_name:
                errors.append(
                    f"Right identity law fails for '{mor_name}': f ∘ id = {comp_right}"
                )

    for (f, g), gf in category.compositions.items():
        for (g_prime, h), hg in category.compositions.items():
            if g == g_prime:
                h_gf = category.compose(gf, h)
                hg_f = category.compose(f, hg)
                if h_gf is not None and hg_f is not None and h_gf != hg_f:
                    errors.append(
                        f"Associativity fails for trio ({f}, {g}, {h}): {h_gf} != {hg_f}"
                    )

    return errors


from typing import Any  


class _RustSurfaceMeta(type):
    def __getattr__(cls, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {cls.__name__}.{name} is not ported"
            )

        return unavailable


class _RustSurfaceObject(metaclass=_RustSurfaceMeta):
    def __getattr__(self, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {type(self).__name__}.{name} is not ported"
            )

        return unavailable


def check_object_references(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``check_object_references``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_validation.rs::check_object_references"
    )


def check_nonempty_names(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``check_nonempty_names``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_validation.rs::check_nonempty_names"
    )


def check_identity_totality(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``check_identity_totality``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_validation.rs::check_identity_totality"
    )


def check_identity_laws(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``check_identity_laws``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_validation.rs::check_identity_laws"
    )


def check_composition_totality(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``check_composition_totality``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_validation.rs::check_composition_totality"
    )


def check_composition_closure(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``check_composition_closure``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_validation.rs::check_composition_closure"
    )


def check_composition_boundaries(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``check_composition_boundaries``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_validation.rs::check_composition_boundaries"
    )


def check_associativity(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``check_associativity``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_validation.rs::check_associativity"
    )



