"""Evaluated Path Kernel Composition (Gluing Conditions G1-G4)."""

from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional, Sequence
import math


@dataclass
class CompositionRecord:
    composition_id: str
    left_trace_id: str
    right_trace_id: str
    boundary_state: str
    composed_cost: Optional[float] = None
    delta_eval: int = 0


def g2_action_additive(
    comp: CompositionRecord, left_cost: float, right_cost: float, tol: float = 1e-6
) -> Optional[bool]:
    """G2 - Action Additivity check: A[γ₂∘γ₁] = A[γ₁] + A[γ₂]."""
    if comp.composed_cost is None:
        return None
    return abs(comp.composed_cost - (left_cost + right_cost)) <= tol


def g3_evaluator_factorizes(comp: CompositionRecord) -> bool:
    """G3 - Evaluator Factorization check: E(γ₂∘γ₁) = E(γ₁) · E(γ₂)."""
    return comp.delta_eval == 0


def evaluator_residual(
    comps: List[CompositionRecord],
    left_costs: List[float],
    right_costs: List[float],
    beta: float = 1.0,
) -> float:
    """Calculates defect-corrected evaluator residual R_Eval = Σ Δ_E · exp(-β(A₁ + A₂))."""
    res = 0.0
    for comp, c1, c2 in zip(comps, left_costs, right_costs):
        res += comp.delta_eval * math.exp(-beta * (c1 + c2))
    return res


from dataclasses import dataclass
from typing import Any


class _RustSurfaceMeta(type):
    def __getattr__(cls, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {cls.__name__}.{name} is not ported"
            )

        return unavailable


class _RustSurfaceObject(metaclass=_RustSurfaceMeta):
    def __getattr__(self, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {type(self).__name__}.{name} is not ported"
            )

        return unavailable


def boundary_in_slice(
    boundary_state: str,
    allowed_states: Sequence[str],
) -> bool:
    """Best-effort G1: boundary state is in the declared slice set."""
    return boundary_state in set(allowed_states)


@dataclass
class CompositionReport:
    """Aggregate G2/G3/G1-rate report (Python twin of Rust CompositionReport)."""

    n: int
    g3_factorization_rate: float
    g2_action_additive_rate: Optional[float]
    boundary_in_slice_rate: float
    evaluator_residual: float


def analyze_composition(
    comps: List[CompositionRecord],
    left_costs: List[float],
    right_costs: List[float],
    allowed_boundary_states: Sequence[str],
    *,
    beta: float = 1.0,
    tol: float = 1e-6,
) -> CompositionReport:
    """Analyze checkable composition conditions over records.

    Python signature is ledger-free (costs passed in parallel lists) while
    preserving G2/G3/G1 rates and R_Eval semantics from Rust ``analyze_composition``.
    """
    if not comps:
        raise ValueError("EmptyPathSet: compositions list is empty")
    if not (len(comps) == len(left_costs) == len(right_costs)):
        raise ValueError("comps and cost lists must have equal length")
    n = len(comps)
    g3_pass = sum(1 for c in comps if g3_evaluator_factorizes(c))
    g2_checked = 0
    g2_pass = 0
    in_slice = 0
    for comp, c1, c2 in zip(comps, left_costs, right_costs):
        g2 = g2_action_additive(comp, c1, c2, tol=tol)
        if g2 is not None:
            g2_checked += 1
            if g2:
                g2_pass += 1
        if boundary_in_slice(comp.boundary_state, allowed_boundary_states):
            in_slice += 1
    g2_rate: Optional[float] = (g2_pass / g2_checked) if g2_checked else None
    residual = evaluator_residual(comps, left_costs, right_costs, beta=beta)
    return CompositionReport(
        n=n,
        g3_factorization_rate=g3_pass / n,
        g2_action_additive_rate=g2_rate,
        boundary_in_slice_rate=in_slice / n,
        evaluator_residual=residual,
    )




