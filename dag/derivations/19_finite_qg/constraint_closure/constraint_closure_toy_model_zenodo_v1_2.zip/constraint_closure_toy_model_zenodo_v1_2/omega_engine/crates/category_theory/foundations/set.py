"""set shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Set:
    """Best-effort shell for a labeled set (elements as string tags)."""

    label: str
    elements: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Set":
        return cls(label=label)

    @classmethod
    def with_elements(cls, label: str, elements: List[str]) -> "Set":
        return cls(label=label, elements=list(elements))

    def cardinality(self) -> int:
        return len(self.elements)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        for i, e in enumerate(self.elements):
            if not e:
                raise ValueError(f"empty element tag at index {i}")



