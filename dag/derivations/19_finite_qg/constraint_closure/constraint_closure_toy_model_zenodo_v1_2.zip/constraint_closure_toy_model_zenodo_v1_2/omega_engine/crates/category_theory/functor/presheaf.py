"""presheaf shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Presheaf:
    """Best-effort shell for a presheaf on a category reference."""

    label: str
    category_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Presheaf":
        return cls(label=label)

    @classmethod
    def on_category(cls, label: str, category_ref: str) -> "Presheaf":
        return cls(label=label, category_ref=category_ref)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.category_ref:
            raise ValueError("empty category_ref")



