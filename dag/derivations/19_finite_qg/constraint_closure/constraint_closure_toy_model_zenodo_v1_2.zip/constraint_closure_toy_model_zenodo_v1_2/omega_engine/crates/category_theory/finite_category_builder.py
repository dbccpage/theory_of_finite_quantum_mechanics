"""Finite Category Builder."""

from __future__ import annotations
from .finite_category import DeclaredFiniteCategory, ValidatedFiniteCategory
from .finite_category_validation import validate_finite_category


class FiniteCategoryBuilder:
    def __init__(self, name: str) -> None:
        self._category = DeclaredFiniteCategory(name=name)

    def object(self, name: str) -> FiniteCategoryBuilder:
        self._category.add_object(name)
        return self

    def morphism(self, name: str, source: str, target: str) -> FiniteCategoryBuilder:
        self._category.add_morphism(name, source, target)
        return self

    def identity(self, object_name: str, morphism_name: str) -> FiniteCategoryBuilder:
        self._category.add_identity(object_name, morphism_name)
        return self

    def composition(
        self, first: str, second: str, composite: str
    ) -> FiniteCategoryBuilder:
        self._category.set_composition(first, second, composite)
        return self

    def build_declared(self) -> DeclaredFiniteCategory:
        return self._category

    def build_validated(self) -> ValidatedFiniteCategory:
        errors = validate_finite_category(self._category)
        if errors:
            raise ValueError(f"Category validation failed: {'; '.join(errors)}")
        return ValidatedFiniteCategory(category=self._category)


from dataclasses import dataclass  
from typing import Any  


class _RustSurfaceMeta(type):
    def __getattr__(cls, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {cls.__name__}.{name} is not ported"
            )

        return unavailable


class _RustSurfaceObject(metaclass=_RustSurfaceMeta):
    def __getattr__(self, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {type(self).__name__}.{name} is not ported"
            )

        return unavailable


@dataclass(init=False)
class DeclaredFiniteCategoryBuilder(_RustSurfaceObject):
    """Structural mirror of Rust ``DeclaredFiniteCategoryBuilder``."""

    category: Any = None

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        names = ("category",)
        if len(args) > len(names):
            raise TypeError(
                "DeclaredFiniteCategoryBuilder received too many positional arguments"
            )
        for fld, value in zip(names, args):
            setattr(self, fld, value)
        for fld in names[len(args) :]:
            setattr(self, fld, kwargs.pop(fld, None))
        for fld, value in kwargs.items():
            setattr(self, fld, value)


def new(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``new``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::new"
    )


def walking_arrow(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``walking_arrow``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::walking_arrow"
    )


def object(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``object``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::object"
    )


def morphism(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``morphism``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::morphism"
    )


def identity(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``identity``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::identity"
    )


def identity_checked(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``identity_checked``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::identity_checked"
    )


def identity_object(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``identity_object``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::identity_object"
    )


def composition(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``composition``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::composition"
    )


def path_composition(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``path_composition``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::path_composition"
    )


def identity_compositions(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``identity_compositions``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::identity_compositions"
    )


def build(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``build``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::build"
    )


def build_validated(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``build_validated``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_category_theory/src/finite_category_builder.rs::build_validated"
    )




