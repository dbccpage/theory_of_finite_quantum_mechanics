from typing import Sequence
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.core import ComposedPath
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.simulation import simulate_tau_paths


def run_tau_simulation(n: int = 1000, seed: int = 7) -> Sequence[ComposedPath]:
    return simulate_tau_paths(n=n, seed=seed)
