"""Typed functors between executable category presentations.

A functor maps both objects and arrows and must preserve:

* arrow typing: ``f: A -> B`` maps to ``F(f): F(A) -> F(B)``;
* identities: ``F(id_A) = id_F(A)``;
* composition: ``F(g o f) = F(g) o F(f)``.

The validators in this module check those obligations over every declared
object and arrow in the finite source presentation.  Equality of callable
target arrows is evaluated on samples belonging to the *target* object
``F(A)``.  Missing samples produce an inconclusive report rather than a
vacuous success.
"""

from __future__ import annotations
from dataclasses import dataclass
from operator import eq
from typing import (
    Any,
    Callable,
    Dict,
    Iterable,
    List,
    Mapping,
    Optional,
    Tuple,
)

from .category import Category
from .morphism import (
    EquationResult,
    EquationStatus,
    Morphism,
    MorphismEquation,
    compose,
)


class FunctorError(ValueError):
    """Base class for malformed functors and functor operations."""


class FunctorDomainError(FunctorError):
    """Raised when mapping an object or arrow outside the source category."""


class FunctorTypingError(FunctorError):
    """Raised when an object or arrow image does not land in the target category."""


class FunctorCompositionError(FunctorError):
    """Raised when two functors cannot be composed."""


@dataclass(frozen=True)
class FunctorLawFailure:
    """One failed or inconclusive functor obligation."""

    law: str
    message: str
    equation: Optional[EquationResult] = None
    source_object: Any = None
    source_morphisms: Tuple[Morphism, ...] = ()


@dataclass(frozen=True)
class FunctorLawReport:
    """Finite validation report for a functor."""

    object_checks: int = 0
    morphism_checks: int = 0
    identity_checks: int = 0
    composition_checks: int = 0
    failures: Tuple[FunctorLawFailure, ...] = ()
    inconclusive: Tuple[FunctorLawFailure, ...] = ()

    @property
    def passed(self) -> bool:
        return not self.failures and not self.inconclusive

    @property
    def checked_equations(self) -> int:
        return self.identity_checks + self.composition_checks

    def __bool__(self) -> bool:
        return self.passed


class _ReportBuilder:
    """Mutable internal accumulator for immutable public reports."""

    def __init__(self) -> None:
        self.object_checks = 0
        self.morphism_checks = 0
        self.identity_checks = 0
        self.composition_checks = 0
        self.failures: List[FunctorLawFailure] = []
        self.inconclusive: List[FunctorLawFailure] = []

    def record_equation(self, finding: FunctorLawFailure) -> None:
        equation = finding.equation
        if equation is None:
            self.failures.append(finding)
        elif equation.status is EquationStatus.FAIL:
            self.failures.append(finding)
        elif equation.status is EquationStatus.INCONCLUSIVE:
            self.inconclusive.append(finding)

    def build(self) -> FunctorLawReport:
        return FunctorLawReport(
            object_checks=self.object_checks,
            morphism_checks=self.morphism_checks,
            identity_checks=self.identity_checks,
            composition_checks=self.composition_checks,
            failures=tuple(self.failures),
            inconclusive=tuple(self.inconclusive),
        )


class Functor:
    """A candidate functor ``F: source -> target``.

    Mapping results are cached.  This makes repeated law checks use one stable
    image per source object and per symbolic source arrow; a stateful mapping
    callback cannot quietly return a different image on a later obligation.
    """

    def __init__(
        self,
        name: str,
        source: Category,
        target: Category,
        obj_map: Callable[[Any], Any],
        morph_map: Callable[[Morphism], Morphism],
    ) -> None:
        if not callable(obj_map):
            raise TypeError("obj_map must be callable")
        if not callable(morph_map):
            raise TypeError("morph_map must be callable")
        self.name = name
        self.source = source
        self.target = target
        self.obj_map = obj_map
        self.morph_map = morph_map
        self._object_cache: Dict[Any, Any] = {}
        self._morphism_cache: Dict[Morphism, Morphism] = {}

    def maps_object(self, obj: Any) -> Any:
        """Map a source object and enforce that its image is a target object."""

        if obj not in self.source.objects:
            raise FunctorDomainError(
                f"{obj!r} is not an object of source category {self.source.name}"
            )
        if obj not in self._object_cache:
            image = self.obj_map(obj)
            if image not in self.target.objects:
                raise FunctorTypingError(
                    f"{self.name} maps source object {obj!r} to {image!r}, "
                    f"which is not in target category {self.target.name}"
                )
            self._object_cache[obj] = image
        return self._object_cache[obj]

    def maps_morphism(self, morph: Morphism) -> Morphism:
        """Map a source arrow and enforce the expected target hom-set."""

        if not isinstance(morph, Morphism):
            raise TypeError("maps_morphism expects a Morphism")
        if (
            morph.source not in self.source.objects
            or morph.target not in self.source.objects
        ):
            raise FunctorDomainError(
                f"Arrow {morph.name!r} has endpoints outside {self.source.name}"
            )
        if morph not in self._morphism_cache:
            image = self.morph_map(morph)
            if not isinstance(image, Morphism):
                raise FunctorTypingError(
                    f"{self.name} mapped {morph.name!r} to a non-Morphism value"
                )
            expected_source = self.maps_object(morph.source)
            expected_target = self.maps_object(morph.target)
            if image.source != expected_source or image.target != expected_target:
                raise FunctorTypingError(
                    f"{self.name} maps {morph.name}: "
                    f"{morph.source!r} -> {morph.target!r} to {image.name}: "
                    f"{image.source!r} -> {image.target!r}; expected "
                    f"{expected_source!r} -> {expected_target!r}"
                )
            self._morphism_cache[morph] = image
        return self._morphism_cache[morph]

    def map(self, value: Any) -> Any:
        """Map a source object or morphism."""

        if isinstance(value, Morphism):
            return self.maps_morphism(value)
        return self.maps_object(value)

    def clear_cache(self) -> None:
        """Clear cached images, primarily for controlled test setup."""

        self._object_cache.clear()
        self._morphism_cache.clear()

    def _check_structure(
        self,
        report: _ReportBuilder,
        *,
        require_registered_images: bool,
    ) -> None:
        for obj in self.source.objects:
            report.object_checks += 1
            try:
                self.maps_object(obj)
            except (FunctorError, TypeError) as exc:
                report.failures.append(
                    FunctorLawFailure(
                        law="object_typing",
                        message=str(exc),
                        source_object=obj,
                    )
                )

        for morph in self.source.iter_morphisms():
            report.morphism_checks += 1
            try:
                image = self.maps_morphism(morph)
                if require_registered_images and not self.target.contains_morphism(
                    image
                ):
                    report.failures.append(
                        FunctorLawFailure(
                            law="morphism_membership",
                            message=(
                                f"Image {image.name!r} of {morph.name!r} is typed "
                                f"correctly but is not a declared arrow of "
                                f"{self.target.name}"
                            ),
                            source_morphisms=(morph,),
                        )
                    )
            except (FunctorError, TypeError) as exc:
                report.failures.append(
                    FunctorLawFailure(
                        law="morphism_typing",
                        message=str(exc),
                        source_morphisms=(morph,),
                    )
                )

    def _check_identities(
        self,
        report: _ReportBuilder,
        target_test_inputs: Mapping[Any, Iterable[Any]],
        *,
        value_equal: Callable[[Any, Any], bool],
        require_samples: bool,
    ) -> None:
        for obj in self.source.objects:
            report.identity_checks += 1
            try:
                mapped_obj = self.maps_object(obj)
                mapped_identity = self.maps_morphism(self.source.identity(obj))
                target_identity = self.target.identity(mapped_obj)
                equation = MorphismEquation(
                    mapped_identity,
                    target_identity,
                ).check(
                    target_test_inputs.get(mapped_obj, ()),
                    value_equal=value_equal,
                    require_samples=require_samples,
                )
                report.record_equation(
                    FunctorLawFailure(
                        law="identity",
                        message=f"F(id_{obj!r}) = id_F({obj!r})",
                        equation=equation,
                        source_object=obj,
                    )
                )
            except (FunctorError, TypeError, KeyError, ValueError) as exc:
                report.failures.append(
                    FunctorLawFailure(
                        law="identity",
                        message=str(exc),
                        source_object=obj,
                    )
                )

    def _check_compositions(
        self,
        report: _ReportBuilder,
        target_test_inputs: Mapping[Any, Iterable[Any]],
        *,
        value_equal: Callable[[Any, Any], bool],
        require_samples: bool,
    ) -> None:
        for outer, inner in self.source.composable_pairs():
            report.composition_checks += 1
            try:
                source_composite = compose(outer, inner)
                mapped_composite = self.maps_morphism(source_composite)
                composite_of_images = compose(
                    self.maps_morphism(outer),
                    self.maps_morphism(inner),
                )
                mapped_source = self.maps_object(inner.source)
                equation = MorphismEquation(
                    mapped_composite,
                    composite_of_images,
                ).check(
                    target_test_inputs.get(mapped_source, ()),
                    value_equal=value_equal,
                    require_samples=require_samples,
                )
                report.record_equation(
                    FunctorLawFailure(
                        law="composition",
                        message=(
                            f"F({outer.name} o {inner.name}) = "
                            f"F({outer.name}) o F({inner.name})"
                        ),
                        equation=equation,
                        source_object=inner.source,
                        source_morphisms=(outer, inner),
                    )
                )
            except (FunctorError, TypeError, KeyError, ValueError) as exc:
                report.failures.append(
                    FunctorLawFailure(
                        law="composition",
                        message=str(exc),
                        source_object=inner.source,
                        source_morphisms=(outer, inner),
                    )
                )

    def validate(
        self,
        target_test_inputs: Mapping[Any, Iterable[Any]],
        *,
        value_equal: Callable[[Any, Any], bool] = eq,
        require_samples: bool = True,
        require_registered_images: bool = True,
    ) -> FunctorLawReport:
        """Validate functor typing, membership, identity, and composition laws.

        ``target_test_inputs`` must be keyed by target-category objects.  To
        test a law with source domain ``A``, the checker uses samples stored
        under ``F(A)``.
        """

        report = _ReportBuilder()
        self._check_structure(
            report,
            require_registered_images=require_registered_images,
        )
        self._check_identities(
            report,
            target_test_inputs,
            value_equal=value_equal,
            require_samples=require_samples,
        )
        self._check_compositions(
            report,
            target_test_inputs,
            value_equal=value_equal,
            require_samples=require_samples,
        )
        return report.build()

    def __repr__(self) -> str:
        return f"Functor({self.name}: {self.source.name} -> {self.target.name})"


def identity_functor(category: Category, *, name: Optional[str] = None) -> Functor:
    """Return the identity functor on ``category``."""

    return Functor(
        name=name or f"Id_{category.name}",
        source=category,
        target=category,
        obj_map=lambda obj: obj,
        morph_map=lambda morph: morph,
    )


def compose_functors(
    outer: Functor,
    inner: Functor,
    *,
    name: Optional[str] = None,
) -> Functor:
    """Return ``outer o inner``."""

    if inner.target is not outer.source:
        raise FunctorCompositionError(
            f"Cannot compose {outer.name} after {inner.name}: "
            "inner.target and outer.source are not the same category"
        )
    return Functor(
        name=name or f"({outer.name} o {inner.name})",
        source=inner.source,
        target=outer.target,
        obj_map=lambda obj: outer.maps_object(inner.maps_object(obj)),
        morph_map=lambda morph: outer.maps_morphism(inner.maps_morphism(morph)),
    )


def check_identity_preservation(
    functor: Functor,
    test_inputs: Mapping[Any, Iterable[Any]],
    *,
    value_equal: Callable[[Any, Any], bool] = eq,
    require_samples: bool = True,
) -> bool:
    """Backward-compatible predicate for the functor identity law.

    Samples are keyed by target objects, not source objects.
    """

    report = _ReportBuilder()
    functor._check_identities(
        report,
        test_inputs,
        value_equal=value_equal,
        require_samples=require_samples,
    )
    return report.build().passed


def check_composition_preservation(
    functor: Functor,
    test_inputs: Mapping[Any, Iterable[Any]],
    *,
    value_equal: Callable[[Any, Any], bool] = eq,
    require_samples: bool = True,
) -> bool:
    """Backward-compatible predicate for the functor composition law.

    Samples are keyed by target objects, not source objects.
    """

    report = _ReportBuilder()
    functor._check_compositions(
        report,
        test_inputs,
        value_equal=value_equal,
        require_samples=require_samples,
    )
    return report.build().passed


