"""discrete_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List

from .category import MorphismTriple


@dataclass
class DiscreteCategoryShell:
    """Best-effort discrete category shell on an object set."""

    label: str
    objects: List[str] = field(default_factory=list)
    morphisms: List[MorphismTriple] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "DiscreteCategoryShell":
        return cls(label=label)

    @classmethod
    def on_objects(cls, label: str, objects: List[str]) -> "DiscreteCategoryShell":
        morphisms = [
            MorphismTriple(source=o, target=o, name=f"id_{o}") for o in objects
        ]
        return cls(label=label, objects=list(objects), morphisms=morphisms)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        for i, o in enumerate(self.objects):
            if not o:
                raise ValueError(f"empty object tag at index {i}")
        for i, m in enumerate(self.morphisms):
            if not m.source or not m.target or not m.name:
                raise ValueError(f"empty morphism field at index {i}")
            if m.source != m.target:
                raise ValueError(
                    f"non-identity morphism at index {i}: "
                    f"{m.source} → {m.target} ({m.name})"
                )



