r"""
The conformance gate: one command, one non-negative integer, zero iff exact.

AuthorityEffect: None. The gate diagnoses; it mints nothing and promotes nothing.

Run it::

    cd omega_engine/research/ooutwire_docs
    python -m omega_engine.crates.conformance.gate            # human readable
    python -m omega_engine.crates.conformance.gate --json     # machine readable
    python -m omega_engine.crates.conformance.gate --receipt  # + head-SHA receipt
    python -m omega_engine.crates.conformance.gate --enforce  # exit 1 on residual

**REPORT-ONLY BY DEFAULT.** This exits 0 even with a nonzero residual, so it never blocks a
push. This is development, and a gate that stops work is worse than one that tells you
something and gets out of the way.

To make it block, either pass ``--enforce`` or set ``OMEGA_CONFORMANCE_GATE=1`` --- the same
opt-in shape the repo already uses for ``OMEGA_IMPACTED_GATE``. Turn it on when a surface
stops moving, not before.

What the number means
---------------------
``total_residual = 0``   every declared vector reproduced, every declared wrong form
                         separated by some witness, every declared source quantity matched.
``total_residual > 0``   the report names exactly which vector, wrong form or quantity, and
                         why it was declared plausible in the first place.

The second case is the one that matters. It is not "a test failed" --- it is "this claim
cannot fail", which is the defect class the obstruction calculus is structurally blind to:
a vacuous claim has :math:`\Phi_1 = 0`, so a residual detector calls it exact.
"""

from __future__ import annotations
import argparse
import hashlib
import json
import platform
import subprocess
import sys
from typing import Any, Dict

from .runner import run_all


def _git(*args: str) -> str:
    try:
        return subprocess.run(
            ["git", *args], capture_output=True, text=True, check=False
        ).stdout.strip()
    except Exception:
        return ""


def build_report(with_receipt: bool = False) -> Dict[str, Any]:
    rep = run_all()
    if with_receipt:
        import numpy, scipy, sympy

        body = json.dumps(rep, sort_keys=True, separators=(",", ":"))
        rep["receipt"] = {
            "head_sha": _git("rev-parse", "HEAD"),
            "dirty": bool(_git("status", "--porcelain")),
            "report_sha256": hashlib.sha256(body.encode()).hexdigest(),
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "numpy": numpy.__version__,
            "scipy": scipy.__version__,
            "sympy": sympy.__version__,
        }
    return rep


def _enforcing(flag: bool) -> bool:
    """Blocking is opt-in, matching the repo's existing ``OMEGA_IMPACTED_GATE`` shape."""
    import os

    return bool(flag or os.environ.get("OMEGA_CONFORMANCE_GATE", "0") == "1")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Finite-QM conformance gate (report-only by default)")
    ap.add_argument("--json", action="store_true", help="emit the machine-readable report")
    ap.add_argument("--receipt", action="store_true", help="attach a head-SHA-bound receipt")
    ap.add_argument(
        "--enforce",
        action="store_true",
        help="exit 1 on a nonzero residual (default: report only, always exit 0). "
        "OMEGA_CONFORMANCE_GATE=1 does the same.",
    )
    args = ap.parse_args(argv)

    rep = build_report(with_receipt=args.receipt)
    enforce_all = _enforcing(args.enforce)
    rep["enforce_all"] = enforce_all
    # Block only on LOCKED quantities, unless --enforce promotes everything.
    blocking = rep["total_residual"] if enforce_all else rep["blocking_residual"]
    rep["would_block"] = blocking != 0

    if args.json:
        print(json.dumps(rep, indent=2, default=str))
        return 1 if blocking else 0

    print("=" * 74)
    print(" FINITE-QM CONFORMANCE GATE")
    print("=" * 74)
    print(f" vectors checked : {rep['vectors_checked']}")
    print(f" total residual  : {rep['total_residual']}")
    print(f" terminal        : {rep['terminal']}")
    print()
    for q, res in sorted(rep["quantities"].items()):
        mark = "ok  " if res["residual"] == 0 else "FAIL"
        lock = "LOCKED " if res.get("enforcement") == "block" else "open   "
        print(f"  [{mark}] {lock} {q:16s} residual={res['residual']}/{res['checked']}")
        for f in res["failures"]:
            print(f"           vector: {f['id']}")
            if "mismatches" in f:
                for k, v in f["mismatches"].items():
                    print(f"             {k}: expected {v['expected']!r}, observed {v['observed']!r}")
            elif "reason" in f:
                print(f"             {f['reason']}")
            print(f"             why this vector exists: {f.get('why', '')}")

    if rep["total_residual"]:
        print()
        print(" A nonzero residual here is NOT 'a test failed'. It is 'this claim cannot")
        print(" fail' -- the defect class a residual detector is blind to, because a vacuous")
        print(" claim has Phi_1 = 0 and therefore reads as exact.")

    if "receipt" in rep:
        print()
        print(" receipt:")
        for k, v in rep["receipt"].items():
            print(f"   {k:14s} {v}")

    print()
    if rep["locked_quantities"]:
        print(f" locked (block on residual): {', '.join(rep['locked_quantities'])}")
    print(f" open   (report only)      : {', '.join(rep['unlocked_quantities']) or '-'}")
    if not blocking:
        print(" verdict: does NOT block. Lock a quantity by setting its vector file's")
        print('          \"enforcement\" to \"block\" once that surface has converged.')
    else:
        print(" verdict: BLOCKS -- a LOCKED quantity has a nonzero residual.")
    print()
    print(" AuthorityEffect: None")
    return 1 if blocking else 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())


