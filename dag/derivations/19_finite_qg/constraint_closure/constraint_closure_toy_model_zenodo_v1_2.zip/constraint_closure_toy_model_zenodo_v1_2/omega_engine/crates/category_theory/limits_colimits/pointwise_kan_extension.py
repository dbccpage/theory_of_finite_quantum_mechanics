"""pointwise_kan_extension shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List

from .kan_extension import KanExtensionKind


@dataclass
class PointwiseKanExtension:
    """Best-effort shell for a pointwise Kan extension."""

    label: str
    kind: KanExtensionKind = KanExtensionKind.LAN
    functor_f: str = ""
    along_k: str = ""
    extension_functor: str = ""
    pointwise_formula: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "PointwiseKanExtension":
        return cls(label=label)

    @classmethod
    def lan_pointwise(
        cls,
        label: str,
        functor_f: str,
        along_k: str,
        extension_functor: str,
        pointwise_formula: str,
    ) -> "PointwiseKanExtension":
        return cls(
            label=label,
            kind=KanExtensionKind.LAN,
            functor_f=functor_f,
            along_k=along_k,
            extension_functor=extension_functor,
            pointwise_formula=pointwise_formula,
        )

    @classmethod
    def ran_pointwise(
        cls,
        label: str,
        functor_f: str,
        along_k: str,
        extension_functor: str,
        pointwise_formula: str,
    ) -> "PointwiseKanExtension":
        return cls(
            label=label,
            kind=KanExtensionKind.RAN,
            functor_f=functor_f,
            along_k=along_k,
            extension_functor=extension_functor,
            pointwise_formula=pointwise_formula,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.functor_f:
            raise ValueError("empty functor_f")
        if not self.along_k:
            raise ValueError("empty along_k")
        if not self.extension_functor:
            raise ValueError("empty extension_functor")
        if not self.pointwise_formula:
            raise ValueError("empty pointwise_formula")



