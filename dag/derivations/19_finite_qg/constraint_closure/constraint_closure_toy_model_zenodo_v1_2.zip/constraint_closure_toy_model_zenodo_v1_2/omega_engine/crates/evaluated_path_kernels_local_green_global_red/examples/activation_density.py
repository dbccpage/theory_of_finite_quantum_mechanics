from typing import Any
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.simulation import (
    activation_density_curve,
)


def run_activation_reversal(seed: int = 7) -> list[dict[str, Any]]:
    del seed
    return activation_density_curve()



