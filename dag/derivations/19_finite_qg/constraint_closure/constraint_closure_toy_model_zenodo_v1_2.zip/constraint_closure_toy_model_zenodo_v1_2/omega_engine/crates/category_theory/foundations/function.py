"""function shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class MappingPair:
    """A single domain→codomain pair tag (not a formal graph)."""

    domain_element: str
    codomain_element: str


@dataclass
class Function:
    """Best-effort shell for a labeled function between labeled sets."""

    label: str
    domain_label: str = ""
    codomain_label: str = ""
    pairs: List[MappingPair] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Function":
        return cls(label=label)

    @classmethod
    def between(cls, label: str, domain_label: str, codomain_label: str) -> "Function":
        return cls(
            label=label,
            domain_label=domain_label,
            codomain_label=codomain_label,
        )

    def with_pair(self, domain_element: str, codomain_element: str) -> None:
        self.pairs.append(
            MappingPair(
                domain_element=domain_element,
                codomain_element=codomain_element,
            )
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.domain_label:
            raise ValueError("empty domain_label")
        if not self.codomain_label:
            raise ValueError("empty codomain_label")
        for i, p in enumerate(self.pairs):
            if not p.domain_element or not p.codomain_element:
                raise ValueError(f"empty mapping tag at pair index {i}")



