"""nat_trans_components shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class NatTransComponents:
    """Best-effort shell for component data attached to a nat-trans reference."""

    label: str
    nat_trans_ref: str = ""
    components: List[Tuple[str, str]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "NatTransComponents":
        return cls(label=label)

    @classmethod
    def for_nat_trans(
        cls, label: str, nat_trans_ref: str, components: List[Tuple[str, str]]
    ) -> "NatTransComponents":
        return cls(
            label=label,
            nat_trans_ref=nat_trans_ref,
            components=list(components),
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.nat_trans_ref:
            raise ValueError("empty nat_trans_ref")
        for i, (obj, mor) in enumerate(self.components):
            if not obj or not mor:
                raise ValueError(f"empty component tag at index {i}")



