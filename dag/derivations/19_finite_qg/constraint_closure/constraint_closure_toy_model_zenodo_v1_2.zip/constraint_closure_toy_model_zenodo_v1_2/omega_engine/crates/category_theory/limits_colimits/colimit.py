"""colimit shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List

from .cone import Cocone


@dataclass
class Colimit:
    """Best-effort shell for a colimit of a diagram (diagram_ref + colimiting cocone)."""

    label: str
    diagram_ref: str = ""
    cocone: Cocone = field(default_factory=lambda: Cocone(label=""))
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Colimit":
        return cls(label=label)

    @classmethod
    def of_diagram(cls, label: str, diagram_ref: str, cocone: Cocone) -> "Colimit":
        return cls(label=label, diagram_ref=diagram_ref, cocone=cocone)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.diagram_ref:
            raise ValueError("empty diagram_ref")
        try:
            self.cocone.validate_shell()
        except ValueError as e:
            raise ValueError(f"cocone: {e}") from e



