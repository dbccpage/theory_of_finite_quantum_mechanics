"""LGGR II organizational gluing + LGGR III EPK->GTLA overlay (Python mirror).

What this module refuses to encode
----------------------------------
LGGR II §4 states a boxed condition::

    G_rep(b) AND G_auth(b) AND G_time(b)  ==>  E_G(b) = product_i E_i(b)

and immediately types it ``[DEFINITION]``, not a theorem: *"This box is not a
fresh theorem. ... the three conditions are defined to name the ways that
factorization can fail at an organizational boundary, not derived premises that
force it."*

Lemma 4.4 then closes it in the negative, mechanized: *"If G_rep is read only as
representational sufficiency ... then G_rep AND G_auth AND G_time does not imply
E_G = product_i E_i."* The finite Boolean witness is ``E_1 = E_2 = 1``,
``E_G = 0``, representation ``R = (1,1,0)``, with ``G_auth`` and ``G_time`` true.
(Lean: ``PaperAE005.weak_boundary_sufficiency_does_not_force_factorization``,
axiom-free.) Strengthening ``G_rep`` into product-sufficiency makes it equivalent
to evaluator factorization itself, so it is not an independent premise either.

Therefore there is **no** function here asserting the gates imply factorization.
:func:`gate_sufficiency_status` exists precisely to say why that claim is
unavailable under either reading.

**The contrapositive is refuted too.** A proposition and its contrapositive are
logically equivalent, so once Lemma 4.4 refutes the implication it equally refutes
``delta_E != 0 => not G_rep or not G_auth or not G_time``. The Lemma 4.4 witness is
a counterexample to both: all three gates hold and ``delta_E == -1``. An earlier
revision of this docstring claimed the contrapositive was still load-bearing; that
was wrong.

What survives: a nonzero ``delta_E`` exhibits evaluator non-factorization **in the
declared model**. Under the weak gate definitions it neither identifies nor entails
failure of any particular upstream gate.

The published reference stub ``020/code/lggr_ii_organizational_gluing.py``
implements ``is_closure_eligible`` as ``owner.has_authority and
owner.has_accountability`` — ``G_auth`` alone — under a name that reads as
sufficiency. :func:`closure_eligibility` keeps the check but returns a type that
cannot be mistaken for a certificate.

AuthorityEffect: None.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from enum import Enum
from typing import Mapping, Sequence

from omega_engine.crates.evaluated_path_kernels_local_green_global_red.verdict import LggrVerdict, VerdictKind

__all__ = [
    "OrganizationalGate",
    "GRepReading",
    "GateSufficiencyStatus",
    "gate_sufficiency_status",
    "Lemma44Witness",
    "BoundaryOwner",
    "ClosureEligibility",
    "closure_eligibility",
    "GateChecklistReading",
    "gate_checklist",
    "GtlaRole",
    "GTLA_ROLE_MAP",
]


class OrganizationalGate(str, Enum):
    """The named closure conditions of LGGR II §4.1.

    ``GEval`` is included because §5 and §8 list it. Note that the published
    manuscript writes the conjunction as
    ``G_rep AND G_auth AND G_time AND G_eval AND G_eval`` — ``G_eval`` appears
    **twice** (020 lines 209 and 323). That is a defect in the published text,
    recorded in the residual ledger, and deliberately not reproduced here.
    """

    GRep = "G_rep"
    GAuth = "G_auth"
    GTime = "G_time"
    GEval = "G_eval"


class GRepReading(str, Enum):
    """How ``G_rep`` is being read. Load-bearing, not stylistic."""

    Weak = "Weak"
    ProductSufficiency = "ProductSufficiency"


class GateSufficiencyStatus(str, Enum):
    """Why the gate conjunction cannot be used as a sufficiency claim.

    There is deliberately no member meaning "the gates imply factorization".
    """

    RefutedByLemma44 = "RefutedByLemma44"
    CircularWithFactorization = "CircularWithFactorization"


def gate_sufficiency_status(reading: GRepReading) -> GateSufficiencyStatus:
    """Status of the §4 box under a declared reading. Never returns "sufficient"."""
    if reading is GRepReading.Weak:
        return GateSufficiencyStatus.RefutedByLemma44
    return GateSufficiencyStatus.CircularWithFactorization


@dataclass(frozen=True, slots=True)
class Lemma44Witness:
    """The finite Boolean witness of LGGR II Lemma 4.4."""

    local_left_pass: bool = True
    local_right_pass: bool = True
    global_pass: bool = False
    representation: tuple[bool, bool, bool] = (True, True, False)
    g_auth: bool = True
    g_time: bool = True

    def weak_g_rep_holds(self) -> bool:
        """``E_G`` is recoverable from the representation by projection."""
        return self.representation[2] == self.global_pass

    def factorization_holds(self) -> bool:
        """``E_G == E_1 . E_2``."""
        return self.global_pass == (self.local_left_pass and self.local_right_pass)


@dataclass(frozen=True, slots=True)
class BoundaryOwner:
    """Authority over the local validators, accountability to the global evaluator."""

    name: str
    has_authority: bool
    has_accountability: bool


class ClosureEligibility(str, Enum):
    """Result of the ``G_auth`` check.

    LGGR II is explicit that this is **necessary and not sufficient**: *"This is
    necessary for the declared packet shape and not sufficient for empirical
    success or authority."*
    """

    RequiredFieldPresent = "RequiredFieldPresent"
    NoDeclaredOwner = "NoDeclaredOwner"
    OwnerLacksAuthority = "OwnerLacksAuthority"
    OwnerLacksAccountability = "OwnerLacksAccountability"
    OwnerLacksAuthorityAndAccountability = "OwnerLacksAuthorityAndAccountability"

    def required_field_present(self) -> bool:
        """Whether the ``G_auth`` field is present. The name says field, not
        closure, deliberately."""
        return self is ClosureEligibility.RequiredFieldPresent

    def certifies_closure(self) -> bool:
        """**Always False**, for every member."""
        return False


def closure_eligibility(owner: BoundaryOwner | None) -> ClosureEligibility:
    """Check ``G_auth`` for a boundary."""
    if owner is None:
        return ClosureEligibility.NoDeclaredOwner
    if owner.has_authority and owner.has_accountability:
        return ClosureEligibility.RequiredFieldPresent
    if not owner.has_authority and owner.has_accountability:
        return ClosureEligibility.OwnerLacksAuthority
    if owner.has_authority and not owner.has_accountability:
        return ClosureEligibility.OwnerLacksAccountability
    return ClosureEligibility.OwnerLacksAuthorityAndAccountability


@dataclass(frozen=True, slots=True)
class GateChecklistReading:
    """A verdict reported alongside the caller's own gate declarations.

    ``candidates`` restates what the caller declared as not holding. It is **not**
    inferred from the defect — Lemma 4.4 forbids that inference.
    """

    kind: str
    candidates: tuple[OrganizationalGate, ...] = ()
    contradicts_declaration: bool = False
    authority_effect: str = field(default="None")


def gate_checklist(
    verdict: LggrVerdict,
    declared: Mapping[OrganizationalGate, bool]
    | Sequence[tuple[OrganizationalGate, bool]],
) -> GateChecklistReading:
    """Report a verdict alongside the caller's own gate declarations.

    Performs **no inference**: ``candidates`` is a filter over what the caller
    declared, not a deduction from ``delta_E``. Lemma 4.4 forbids the deduction.

    Takes the :class:`LggrVerdict` rather than a raw defect, so an oracle-extracted
    reading cannot be laundered into a gate attribution.
    """
    items = list(declared.items()) if isinstance(declared, Mapping) else list(declared)
    if verdict.kind is VerdictKind.OracleExtractedUnsound:
        return GateChecklistReading(kind="NoSoundReading")
    if verdict.kind in (
        VerdictKind.GreenOracleNeeded,
        VerdictKind.GreenNumericallySupported,
    ):
        return GateChecklistReading(kind="ObservedZeroNotCertified")

    candidates = tuple(
        sorted(
            {gate for gate, holds in items if not holds},
            key=lambda g: g.value,
        )
    )
    return GateChecklistReading(
        kind="SomeConditionFailed",
        candidates=candidates,
        contradicts_declaration=not candidates,
    )


class GtlaRole(str, Enum):
    """The six GTLA roles the EPK diagnostic surface maps onto (LGGR III).

    The published stub returns these as a hardcoded ``dict``; they are a closed
    set, so they are typed here.
    """

    Foc = "FOC"
    Fda = "FDA"
    Mur = "MUR"
    Or = "OR"
    Cs = "CS"
    A = "A"

    @property
    def epk_responsibility(self) -> str:
        return GTLA_ROLE_MAP[self]

    @property
    def authority_effect(self) -> str:
        """**Always** ``"None"``, for every role — including ``Fda``, whose
        receipts the paper marks non-authoritative by name."""
        return "None"


GTLA_ROLE_MAP: dict[GtlaRole, str] = {
    GtlaRole.Foc: "Finite Obstruction - Defect Ledger (Delta_E, Delta_P, Delta_C, Delta_R)",
    GtlaRole.Fda: "Finite Descent - Non-authoritative terminal policy receipts",
    GtlaRole.Mur: "Certified Transport - Representation boundary loss exposure",
    GtlaRole.Or: "Observer Relative - Observer-dependent diagnostic metrics",
    GtlaRole.Cs: "Finite Shadow - Discrete trace sums without continuum limit",
    GtlaRole.A: "Residual Closure - Refusal & audit feedback signals",
}





