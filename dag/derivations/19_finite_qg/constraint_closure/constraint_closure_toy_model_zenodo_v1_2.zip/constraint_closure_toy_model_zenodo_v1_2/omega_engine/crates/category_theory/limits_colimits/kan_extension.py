"""kan_extension shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from enum import Enum
from typing import List


class KanExtensionKind(str, Enum):
    """Left or right Kan extension kind."""

    LAN = "lan"
    RAN = "ran"


@dataclass
class KanExtension:
    """Best-effort shell for a (global) Kan extension along a functor."""

    label: str
    kind: KanExtensionKind = KanExtensionKind.LAN
    functor_f: str = ""
    along_k: str = ""
    extension_functor: str = ""
    unit_counit_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "KanExtension":
        return cls(label=label)

    @classmethod
    def lan(
        cls,
        label: str,
        functor_f: str,
        along_k: str,
        extension_functor: str,
    ) -> "KanExtension":
        return cls(
            label=label,
            kind=KanExtensionKind.LAN,
            functor_f=functor_f,
            along_k=along_k,
            extension_functor=extension_functor,
        )

    @classmethod
    def ran(
        cls,
        label: str,
        functor_f: str,
        along_k: str,
        extension_functor: str,
    ) -> "KanExtension":
        return cls(
            label=label,
            kind=KanExtensionKind.RAN,
            functor_f=functor_f,
            along_k=along_k,
            extension_functor=extension_functor,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.functor_f:
            raise ValueError("empty functor_f")
        if not self.along_k:
            raise ValueError("empty along_k")
        if not self.extension_functor:
            raise ValueError("empty extension_functor")



