"""hlevel shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Homotopy h-level / n-type classification shell (shape only).
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class HLevel:
    """Best-effort shell for an h-level claim on a type reference.

    Convention: ``level`` uses the integer n in "is-n-type", with n ≥ -2.
    """

    label: str
    level: int = 0
    type_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "HLevel":
        return cls(label=label)

    @classmethod
    def for_type(cls, label: str, type_ref: str, level: int) -> "HLevel":
        return cls(label=label, type_ref=type_ref, level=level)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if self.level < -2:
            raise ValueError(f"h-level {self.level} < -2")



