from pydantic import ConfigDict
from pydantic.dataclasses import dataclass
from typing import List


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class IdentityWitness:
    object_id: str
    object_kind: str
    canonical_name: str
    aliases: List[str]
    conserved_across_edges: bool
    identity_loss_risk: bool
    note: str

    @classmethod
    def tiger(cls) -> "IdentityWitness":
        return cls(
            object_id="tiger",
            object_kind="exemplar",
            canonical_name="the tiger",
            aliases=["animal", "predator", "symbol", "Q-level object"],
            conserved_across_edges=True,
            identity_loss_risk=False,
            note="One tiger, many names across layers — compression allowed, impersonation not.",
        )

    @classmethod
    def bar(cls) -> "IdentityWitness":
        return cls(
            object_id="bar",
            object_kind="exemplar",
            canonical_name="the bar",
            aliases=[
                "business",
                "venue",
                "inventory system",
                "liability surface",
                "cash-flow engine",
            ],
            conserved_across_edges=True,
            identity_loss_risk=False,
            note="One bar, many names across layers — compression allowed, impersonation not.",
        )


def classification_preserves_identity(iw: IdentityWitness) -> bool:
    return iw.conserved_across_edges and not iw.identity_loss_risk


