"""EPK obstruction diagnostics for the hot path.

EPK identifies trace/composition obstruction; it NEVER certifies truth
(``authority`` is always False). Computes the gluing defects:

    delta_e  evaluator gluing defect  E_g - E1*E2  in {-1,0,+1}
    delta_p  proposal/transition defect
    delta_c  cost (coordination) defect
    delta_r  residual risk defect
    delta_total = delta_p + lambda*delta_c + mu*delta_r
"""

from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Optional

try:
    from omega_engine.crates.omega_mvp.models import EPKDefects, EPKReport
except ImportError:
    @dataclass(frozen=True)
    class EPKDefects:
        delta_e: float
        delta_p: float
        delta_c: float
        delta_r: float
        delta_total: float

    @dataclass(frozen=True)
    class EPKReport:
        enabled: bool
        status: str
        z_mass: float
        defects: EPKDefects
        authority: bool = False

_EPS = 1e-9


@dataclass
class PathTrace:
    eval_pass: int
    prob: float = 1.0
    cost: float = 1.0
    risk: float = 0.0


def compute_epk(
    left: PathTrace,
    right: PathTrace,
    *,
    global_eval: Optional[int] = None,
    transition_factor: float = 1.0,
    coordination_cost: float = 0.0,
    interface_risk: float = 0.0,
    lambda_: float = 1.0,
    mu_: float = 1.0,
    beta: float = 1.0,
) -> EPKReport:
    e1, e2 = int(left.eval_pass), int(right.eval_pass)
    e_g = e1 * e2 if global_eval is None else int(global_eval)
    delta_e = float(e_g - e1 * e2)

    p1 = max(_EPS, left.prob)
    p2 = max(_EPS, right.prob)
    joint_prob = max(_EPS, p1 * p2 * transition_factor)
    delta_p = (-math.log(joint_prob)) - ((-math.log(p1)) + (-math.log(p2)))

    delta_c = float(coordination_cost)
    delta_r = float(interface_risk)
    delta_total = delta_p + lambda_ * delta_c + mu_ * delta_r

    z_mass = e1 * math.exp(-beta * left.cost) + e2 * math.exp(-beta * right.cost)

    return EPKReport(
        enabled=True,
        status="diagnostic",
        z_mass=z_mass,
        defects=EPKDefects(
            delta_e=delta_e,
            delta_p=delta_p,
            delta_c=delta_c,
            delta_r=delta_r,
            delta_total=delta_total,
        ),
        authority=False,
    )


def clean_composition() -> EPKReport:
    """Two valid segments that glue consistently: all defects zero."""
    return compute_epk(PathTrace(1, 1.0, 1.0, 0.0), PathTrace(1, 1.0, 1.0, 0.0))


def hidden_failure() -> EPKReport:
    """Local-green / global-red: both locals pass but composition fails (delta_e = -1)."""
    return compute_epk(
        PathTrace(1, 1.0, 1.0, 0.0), PathTrace(1, 1.0, 1.0, 0.0), global_eval=0
    )




