import argparse
import csv
import json
import math
import sys
from pathlib import Path
from typing import Any

from omega_engine.crates.evaluated_path_kernels_local_green_global_red.fixtures import (
    canonical_hidden_failure_fixture,
)
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.metrics import calculate_metrics
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.reports import (
    generate_csv_report,
    generate_json_report,
    generate_markdown_report,
)
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.schemas import (
    validate_and_normalize_row,
)
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.simulation import (
    activation_density_curve,
    simulate_hwe_paths,
    simulate_poe_moe_paths,
    simulate_swe_paths,
    simulate_tau_paths,
)
from omega_engine.crates.type.refusal import Refusal

REPORT_DIR = Path("reports")


def _positive_int(raw: str) -> int:
    try:
        value = int(raw)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("must be an integer") from exc
    if value <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return value


def _seed(raw: str) -> int:
    try:
        return int(raw)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("seed must be an integer") from exc


def _finite_nonnegative_float(raw: str) -> float:
    try:
        value = float(raw)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("must be a float") from exc
    if not math.isfinite(value):
        raise argparse.ArgumentTypeError("must be finite")
    if value < 0.0:
        raise argparse.ArgumentTypeError("must be non-negative")
    return value


def _write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _write_metric_reports(example: str, report: Any, beta: float, seed: int) -> None:
    _write_text(
        REPORT_DIR / f"{example}_report.json",
        generate_json_report(report, example, beta, seed),
    )
    _write_text(
        REPORT_DIR / f"{example}_report.csv",
        generate_csv_report(report, example, beta, seed),
    )
    _write_text(
        REPORT_DIR / f"{example}_report.md",
        generate_markdown_report(report, example, beta, seed),
    )


def _print_metric_summary(report: Any) -> None:
    print(f"LPR: {report.lpr:.3f}")
    print(f"GPR: {report.gpr:.3f}")
    print(f"AvgDelta: {report.avg_delta_eval:.3f}")
    print(f"NGD: {report.ngd:.3f}")
    print(f"PGD: {report.positive_defect_rate:.3f}")
    print(f"ZDR: {report.zero_defect_rate:.3f}")
    print(f"EGD: {report.egd:.3f}")


def run_demo() -> None:
    print("Running canonical single-path failure:")
    report = calculate_metrics(canonical_hidden_failure_fixture())
    _print_metric_summary(report)
    print(f"GPR-LPR: {report.gpr - report.lpr:.3f}")
    _write_metric_reports("demo", report, 1.0, 7)


def _run_path_simulation(example_type: str, n: int, beta: float, seed: int) -> None:
    if example_type == "swe":
        paths = simulate_swe_paths(n, seed)
    elif example_type == "hwe":
        paths = simulate_hwe_paths(n, seed)
    elif example_type == "tau":
        paths = simulate_tau_paths(n, seed)
    else:
        raise ValueError(f"unknown simulation type: {example_type}")

    report = calculate_metrics(
        paths,
        notes={
            "evidence_class": "SyntheticSimulation",
            "rke_status": "not_computed",
            "rke_reason": "sampled synthetic paths are not an exact boundary-product fixture",
        },
    )
    _print_metric_summary(report)
    _write_metric_reports(example_type, report, beta, seed)


def _run_activation(seed: int) -> None:
    results = activation_density_curve()
    print(
        "| Active Experts (M) | Base Capability | Cross-Coupling Conflict | Actual Success Rate | Calculated Defect |"
    )
    print("| :--- | :--- | :--- | :--- | :--- |")
    for row in results:
        print(
            f"| {row['active_experts']} | {row['capability'] * 100:.1f}% | "
            f"{row['defect'] * 100:.1f}% | {row['success'] * 100:.1f}% | "
            f"{row['calculated_defect']:.4f} |"
        )

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    csv_path = REPORT_DIR / "activation_report.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "active_experts",
                "max_experts",
                "alpha",
                "capability",
                "defect",
                "success",
                "calculated_defect",
                "evidence_class",
                "seed",
            ],
            lineterminator="\n",
        )
        writer.writeheader()
        for row in results:
            writer.writerow(
                {**row, "evidence_class": "SyntheticSimulation", "seed": seed}
            )

    lines = [
        "# Activation Density Reversal Report",
        "",
        "Evidence class: SyntheticSimulation.",
        "",
        "| Active Experts (M) | Base Capability | Cross-Coupling Conflict | Actual Success Rate | Calculated Defect |",
        "| :--- | :--- | :--- | :--- | :--- |",
    ]
    for row in results:
        lines.append(
            f"| {row['active_experts']} | {row['capability'] * 100:.1f}% | "
            f"{row['defect'] * 100:.1f}% | {row['success'] * 100:.1f}% | "
            f"{row['calculated_defect']:.4f} |"
        )
    _write_text(REPORT_DIR / "activation_report.md", "\n".join(lines) + "\n")


def _run_poe_moe(n: int, seed: int) -> None:
    results = simulate_poe_moe_paths(n, seed)
    moe = results["moe"]
    poe = results["poe"]
    print("| Architecture | Success (Pass) Rate | Hallucination Rate | Refusal Rate |")
    print("| :--- | :--- | :--- | :--- |")
    print(
        f"| **MoE Routing** (Single Expert) | {moe['success_rate'] * 100:.1f}% | "
        f"{moe['hallucination_rate'] * 100:.1f}% | {moe['refusal_rate'] * 100:.1f}% |"
    )
    print(
        f"| **PoE Stacking** (Consensus) | {poe['success_rate'] * 100:.1f}% | "
        f"{poe['hallucination_rate'] * 100:.1f}% | {poe['refusal_rate'] * 100:.1f}% |"
    )

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    with (REPORT_DIR / "poe_moe_report.csv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "architecture",
                "success_rate",
                "hallucination_rate",
                "refusal_rate",
                "evidence_class",
                "seed",
                "n",
            ],
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerow(
            {
                "architecture": "moe",
                **moe,
                "evidence_class": "SyntheticSimulation",
                "seed": seed,
                "n": n,
            }
        )
        writer.writerow(
            {
                "architecture": "poe",
                **poe,
                "evidence_class": "SyntheticSimulation",
                "seed": seed,
                "n": n,
            }
        )

    lines = [
        "# PoE vs MoE Verification Stack Tradeoffs",
        "",
        "Evidence class: SyntheticSimulation.",
        "",
        "| Architecture | Success (Pass) Rate | Hallucination Rate | Refusal Rate |",
        "| :--- | :--- | :--- | :--- |",
        f"| **MoE Routing** | {moe['success_rate'] * 100:.1f}% | {moe['hallucination_rate'] * 100:.1f}% | {moe['refusal_rate'] * 100:.1f}% |",
        f"| **PoE Stacking** | {poe['success_rate'] * 100:.1f}% | {poe['hallucination_rate'] * 100:.1f}% | {poe['refusal_rate'] * 100:.1f}% |",
    ]
    _write_text(REPORT_DIR / "poe_moe_report.md", "\n".join(lines) + "\n")


def _run_analyze(file_path: str, beta: float, seed: int) -> None:
    paths = []
    path = Path(file_path)
    with path.open("r", encoding="utf-8") as handle:
        for line_idx, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
                if not isinstance(row, dict):
                    raise ValueError("JSONL row must be an object")
            except (json.JSONDecodeError, ValueError) as exc:
                print(f"Error parsing line {line_idx}: {exc}", file=sys.stderr)
                sys.exit(1)
            result = validate_and_normalize_row(row)
            if isinstance(result, Refusal):
                print(
                    f"Error parsing line {line_idx}: {result.reason}", file=sys.stderr
                )
                sys.exit(1)
            paths.append(result)

    report = calculate_metrics(paths)
    print(f"Analyzed {len(paths)} paths from {path}:")
    _print_metric_summary(report)
    _write_metric_reports(path.stem, report, beta, seed)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Evaluated Path Kernels simulation and analysis harness."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser(
        "demo", help="Run the canonical single-path hidden failure demo."
    )

    sim_parser = subparsers.add_parser("simulate", help="Run synthetic simulations.")
    sim_subparsers = sim_parser.add_subparsers(dest="type", required=True)

    for example_type in ["swe", "hwe", "tau"]:
        child = sim_subparsers.add_parser(
            example_type, help=f"Simulate {example_type.upper()} scenario."
        )
        child.add_argument(
            "--n", type=_positive_int, default=1000, help="Number of trajectories"
        )
        child.add_argument(
            "--beta",
            type=_finite_nonnegative_float,
            default=1.0,
            help="Inference temperature",
        )
        child.add_argument("--seed", type=_seed, default=7, help="Random seed")

    act_parser = sim_subparsers.add_parser(
        "activation", help="Simulate activation density reversal."
    )
    act_parser.add_argument("--seed", type=_seed, default=7, help="Random seed")

    pm_parser = sim_subparsers.add_parser(
        "poe-moe", help="Simulate PoE vs MoE verification stacks."
    )
    pm_parser.add_argument(
        "--n", type=_positive_int, default=1000, help="Number of trajectories"
    )
    pm_parser.add_argument("--seed", type=_seed, default=7, help="Random seed")

    analyze_parser = subparsers.add_parser(
        "analyze", help="Analyze custom JSONL fixtures."
    )
    analyze_parser.add_argument("file", help="Path to JSONL file")
    analyze_parser.add_argument(
        "--beta",
        type=_finite_nonnegative_float,
        default=1.0,
        help="Inference temperature",
    )
    analyze_parser.add_argument("--seed", type=_seed, default=7, help="Random seed")

    args = parser.parse_args()

    if args.command == "demo":
        run_demo()
    elif args.command == "simulate" and args.type in {"swe", "hwe", "tau"}:
        _run_path_simulation(args.type, args.n, args.beta, args.seed)
    elif args.command == "simulate" and args.type == "activation":
        _run_activation(args.seed)
    elif args.command == "simulate" and args.type == "poe-moe":
        _run_poe_moe(args.n, args.seed)
    elif args.command == "analyze":
        _run_analyze(args.file, args.beta, args.seed)
    else:
        parser.error("unknown command")


if __name__ == "__main__":
    main()



