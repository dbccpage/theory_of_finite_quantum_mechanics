"""arrow_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List

from .category import MorphismTriple


@dataclass
class ArrowCategoryShell:
    """Best-effort arrow category shell Arr(C)."""

    label: str
    base_label: str = ""
    arrow_objects: List[MorphismTriple] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "ArrowCategoryShell":
        return cls(label=label)

    @classmethod
    def of_base(cls, label: str, base_label: str) -> "ArrowCategoryShell":
        return cls(label=label, base_label=base_label)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.base_label:
            raise ValueError("empty base_label")
        for i, m in enumerate(self.arrow_objects):
            if not m.source or not m.target or not m.name:
                raise ValueError(f"empty arrow_object field at index {i}")



