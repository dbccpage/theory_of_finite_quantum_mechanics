"""fibered_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class FiberedCategoryShell:
    """Best-effort fibered category shell over a base."""

    label: str
    total_label: str = ""
    base_label: str = ""
    cloven: bool = False
    fibers: List[Tuple[str, str]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "FiberedCategoryShell":
        return cls(label=label)

    @classmethod
    def over(
        cls, label: str, total_label: str, base_label: str
    ) -> "FiberedCategoryShell":
        return cls(label=label, total_label=total_label, base_label=base_label)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.total_label:
            raise ValueError("empty total_label")
        if not self.base_label:
            raise ValueError("empty base_label")
        for i, (b, f) in enumerate(self.fibers):
            if not b or not f:
                raise ValueError(f"empty fiber entry at index {i}")



