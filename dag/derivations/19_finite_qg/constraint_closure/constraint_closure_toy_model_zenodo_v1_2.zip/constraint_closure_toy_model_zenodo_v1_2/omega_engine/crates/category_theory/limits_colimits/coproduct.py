"""coproduct shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Coproduct:
    """Best-effort shell for a (binary or multi-summand) coproduct."""

    label: str
    coproduct_object: str = ""
    summands: List[str] = field(default_factory=list)
    injections: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Coproduct":
        return cls(label=label)

    @classmethod
    def binary(
        cls,
        label: str,
        coproduct_object: str,
        left: str,
        right: str,
        injection_left: str,
        injection_right: str,
    ) -> "Coproduct":
        return cls(
            label=label,
            coproduct_object=coproduct_object,
            summands=[left, right],
            injections=[injection_left, injection_right],
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.coproduct_object:
            raise ValueError("empty coproduct_object")
        if not self.summands:
            raise ValueError("empty summands")
        for i, s in enumerate(self.summands):
            if not s:
                raise ValueError(f"empty summand at index {i}")
        for i, j in enumerate(self.injections):
            if not j:
                raise ValueError(f"empty injection at index {i}")
        if self.injections and len(self.injections) != len(self.summands):
            raise ValueError("injections length must match summands length")



