"""discrete_fibration shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class DiscreteFibrationShell:
    """Best-effort discrete fibration shell p: total → base."""

    label: str
    total_label: str = ""
    base_label: str = ""
    object_map: List[Tuple[str, str]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "DiscreteFibrationShell":
        return cls(label=label)

    @classmethod
    def between(
        cls, label: str, total_label: str, base_label: str
    ) -> "DiscreteFibrationShell":
        return cls(label=label, total_label=total_label, base_label=base_label)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.total_label:
            raise ValueError("empty total_label")
        if not self.base_label:
            raise ValueError("empty base_label")
        for i, (t, b) in enumerate(self.object_map):
            if not t or not b:
                raise ValueError(f"empty object_map entry at index {i}")



