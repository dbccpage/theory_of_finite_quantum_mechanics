"""LGGR asymmetric verdict — Python mirror of ``omega_engine.crates.evaluated_path_kernels_local_green_global_red::verdict``.

LGGR II (paper 020) §3.1 fixes an asymmetry between the two readings of the
evaluator gluing defect ``delta_E = E_g - product(E_i)``:

===========  =========================  ==============================================
``delta_E``  Reading                    Soundness (verbatim from §3.1)
===========  =========================  ==============================================
``-1``       local green, global red    *"Sound as a detection. ... exhibited, not
                                        inferred."*
``0``        boundary "closed"          *"Unsound as a certificate."*
===========  =========================  ==============================================

and states the consequence directly:

    *"a red verdict reports something; a green verdict reports the absence of
    something the detector may simply be unable to see. A green boundary is
    therefore ``OracleNeeded`` — not ``ExactClass`` — until an adequacy certificate
    excludes the collapses above."*

``omega_engine.crates.evaluated_path_kernels_local_green_global_red.defects.evaluator_gluing_defect`` computes ``delta_E`` and returns a
bare ``int``, with nothing gating how a zero is read. This module supplies the
gate: a green cannot be produced without an adequacy verdict, and even a supported
one is never an exactness claim.

There is deliberately **no bare** ``Green`` **state**.

AuthorityEffect: None.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from enum import Enum

from omega_engine.crates.evaluated_path_kernels_local_green_global_red.adequacy import (
    AdequacyKind,
    DetectorAdequacyVerdict,
    StructuralFailure,
    UndeclaredReason,
)

__all__ = [
    "EvaluatorProvenance",
    "GreenUnsoundReason",
    "VerdictKind",
    "LggrVerdict",
    "LggrVerdictError",
    "DefectOutOfRangeError",
    "DefectInternallyInconsistentError",
    "classify",
]


class EvaluatorProvenance(str, Enum):
    """Where ``E_1``, ``E_2``, ``E_g`` came from.

    LGGR II §7.3: *"Under an oracle extractor, neither verdict direction is sound
    — the §3.1 asymmetry does not rescue the red verdict here, because the red is
    no longer exhibited."*
    """

    Exhibited = "Exhibited"
    OracleExtracted = "OracleExtracted"


class GreenUnsoundReason(str, Enum):
    """Why a ``delta_E == 0`` reading cannot be taken as a certificate."""

    AdequacyUndeclared = "AdequacyUndeclared"
    CapacityEvidenceMissing = "CapacityEvidenceMissing"
    AlignedValidatorFamily = "AlignedValidatorFamily"
    ConstantEvaluator = "ConstantEvaluator"
    ConstantLocalProduct = "ConstantLocalProduct"
    NoNegativeDefectWitness = "NoNegativeDefectWitness"
    BlindSpotsUndeclared = "BlindSpotsUndeclared"
    EmptyCorpus = "EmptyCorpus"
    OtherStructuralInadequacy = "OtherStructuralInadequacy"
    CapacityCounterevidence = "CapacityCounterevidence"
    CapacityUnresolved = "CapacityUnresolved"


_STRUCTURAL_TO_REASON: dict[StructuralFailure, GreenUnsoundReason] = {
    StructuralFailure.EmptyCorpus: GreenUnsoundReason.EmptyCorpus,
    StructuralFailure.GlobalEqualsLocalProduct: GreenUnsoundReason.AlignedValidatorFamily,
    StructuralFailure.EvaluatorConstantLocalLeft: GreenUnsoundReason.ConstantEvaluator,
    StructuralFailure.EvaluatorConstantLocalRight: GreenUnsoundReason.ConstantEvaluator,
    StructuralFailure.EvaluatorConstantGlobal: GreenUnsoundReason.ConstantEvaluator,
    StructuralFailure.LocalProductConstant: GreenUnsoundReason.ConstantLocalProduct,
    StructuralFailure.MissingNgdWitness: GreenUnsoundReason.NoNegativeDefectWitness,
    StructuralFailure.MissingBlindSpotDeclaration: GreenUnsoundReason.BlindSpotsUndeclared,
}


class VerdictKind(str, Enum):
    """The asymmetric readings. Note the absence of a bare ``Green``."""

    Red = "Red"
    PositiveGluingDefect = "PositiveGluingDefect"
    GreenOracleNeeded = "GreenOracleNeeded"
    GreenNumericallySupported = "GreenNumericallySupported"
    OracleExtractedUnsound = "OracleExtractedUnsound"


class LggrVerdictError(ValueError):
    """Refusal to classify a reading at all."""


class DefectOutOfRangeError(LggrVerdictError):
    """``delta_E`` is defined only on ``{-1, 0, +1}``."""


class DefectInternallyInconsistentError(LggrVerdictError):
    """``delta_E`` disagrees with ``E_g - E_1.E_2``."""


@dataclass(frozen=True, slots=True)
class LggrVerdict:
    """One classified reading.

    ``authority_effect`` is fixed at ``"None"`` for every value, and
    :meth:`certifies_closure` is ``False`` for every value.
    """

    kind: VerdictKind
    delta_eval: int
    local_product: bool
    global_pass: bool
    reasons: tuple[GreenUnsoundReason, ...] = ()
    authority_effect: str = field(default="None")

    def is_sound_detection(self) -> bool:
        """True only for an exhibited ``Red``. Every green is False — that is the
        §3.1 asymmetry — and so is an oracle-extracted red."""
        return self.kind is VerdictKind.Red

    def certifies_closure(self) -> bool:
        """**Always False.** ``GreenNumericallySupported`` is the strongest
        reachable label and it is still not a certificate."""
        return False

    def evidence_ceiling(self) -> str:
        """Capped at ``BoundaryChecked``, mirroring the Rust ceiling assignment and
        the rule ``omega_business_contracts`` enforces on prospective findings.

        LGGR II §6.0: *"A gluing defect in a model of an organization is not a
        proven fact about that organization."*
        """
        if self.kind in (VerdictKind.Red, VerdictKind.PositiveGluingDefect):
            return "BoundaryChecked"
        if self.kind is VerdictKind.GreenNumericallySupported:
            return "LocalReplay"
        return "ShapeOnly"


def _green_unsound_reasons(
    adequacy: DetectorAdequacyVerdict,
) -> list[GreenUnsoundReason]:
    """Project an adequacy verdict onto the reasons a green stays unsound.

    Returns an empty list **only** for ``NumericallySupported``, so an empty result
    is a faithful test for "green is permitted".
    """
    if adequacy.kind is AdequacyKind.NumericallySupported:
        return []
    if adequacy.kind is AdequacyKind.NotEvaluated:
        return [GreenUnsoundReason.AdequacyUndeclared]
    if adequacy.kind is AdequacyKind.Undeclared:
        if adequacy.undeclared_reason is UndeclaredReason.CapacityEvidenceMissing:
            return [GreenUnsoundReason.CapacityEvidenceMissing]
        return [GreenUnsoundReason.AdequacyUndeclared]
    if adequacy.kind is AdequacyKind.NumericalCounterevidence:
        return [GreenUnsoundReason.CapacityCounterevidence]
    if adequacy.kind is AdequacyKind.NumericalUnresolved:
        return [GreenUnsoundReason.CapacityUnresolved]

    reasons = {
        _STRUCTURAL_TO_REASON.get(f, GreenUnsoundReason.OtherStructuralInadequacy)
        for f in adequacy.structural_failures
    }
    if not reasons:
        reasons = {GreenUnsoundReason.OtherStructuralInadequacy}
    return sorted(reasons, key=lambda r: r.value)


def classify(
    delta_eval: int,
    local_product: bool,
    global_pass: bool,
    adequacy: DetectorAdequacyVerdict | None = None,
    provenance: EvaluatorProvenance = EvaluatorProvenance.Exhibited,
) -> LggrVerdict:
    """Classify one evaluator gluing defect under the §3.1 asymmetry.

    ``adequacy=None`` means the protocol was never run, which is itself a reason a
    green stays unsound — never a licence to skip the gate.

    The gate in one sentence: **a zero defect can never be reported as supported
    unless an adequacy verdict says NumericallySupported.**
    """
    if isinstance(delta_eval, bool) or not isinstance(delta_eval, int):
        raise LggrVerdictError("delta_eval must be an int")
    if not isinstance(local_product, bool) or not isinstance(global_pass, bool):
        raise LggrVerdictError("local_product and global_pass must be bools")

    if delta_eval not in (-1, 0, 1):
        raise DefectOutOfRangeError(
            f"evaluator gluing defect out of range: delta_eval = {delta_eval}, "
            "expected -1, 0, or +1"
        )
    implied = int(global_pass) - int(local_product)
    if delta_eval != implied:
        raise DefectInternallyInconsistentError(
            f"malformed gluing defect: delta_eval = {delta_eval} but global_pass = "
            f"{global_pass} and local_product = {local_product} imply {implied}"
        )

    if provenance is EvaluatorProvenance.OracleExtracted:
        return LggrVerdict(
            kind=VerdictKind.OracleExtractedUnsound,
            delta_eval=delta_eval,
            local_product=local_product,
            global_pass=global_pass,
        )

    if delta_eval == -1:
        return LggrVerdict(
            kind=VerdictKind.Red,
            delta_eval=delta_eval,
            local_product=local_product,
            global_pass=global_pass,
        )
    if delta_eval == 1:
        return LggrVerdict(
            kind=VerdictKind.PositiveGluingDefect,
            delta_eval=delta_eval,
            local_product=local_product,
            global_pass=global_pass,
        )

    reasons = (
        [GreenUnsoundReason.AdequacyUndeclared]
        if adequacy is None
        else _green_unsound_reasons(adequacy)
    )
    if reasons:
        return LggrVerdict(
            kind=VerdictKind.GreenOracleNeeded,
            delta_eval=delta_eval,
            local_product=local_product,
            global_pass=global_pass,
            reasons=tuple(reasons),
        )
    return LggrVerdict(
        kind=VerdictKind.GreenNumericallySupported,
        delta_eval=delta_eval,
        local_product=local_product,
        global_pass=global_pass,
    )





