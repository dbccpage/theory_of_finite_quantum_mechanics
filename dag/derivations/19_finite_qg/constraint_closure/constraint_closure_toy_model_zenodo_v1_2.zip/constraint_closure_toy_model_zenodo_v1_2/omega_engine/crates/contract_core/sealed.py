class Sealed:
    """Marker class mirroring Rust's Sealed trait."""

    pass
