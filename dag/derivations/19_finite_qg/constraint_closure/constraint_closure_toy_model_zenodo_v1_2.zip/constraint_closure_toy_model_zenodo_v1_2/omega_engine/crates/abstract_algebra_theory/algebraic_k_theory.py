"""AlgebraicKTheory: K-groups K_*(R) for rings and schemes.

Conforms to urn:omega:math:algebraic_k_theory:v0.1.0.
AuthorityEffect: None.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple


CONTRACT_ID = "urn:omega:math:algebraic_k_theory:v0.1.0"

VALID_CONSTRUCTIONS = frozenset({
    "plus",
    "Q",
    "Waldhausen",
    "infinity_categorical",
})


@dataclass(frozen=True)
class KGroup:
    """A single K-group K_n(R).

    Attributes:
        degree: Non-negative integer n.
        group_description: Description of the abelian group K_n(R).
        generators: Optional generator descriptions.
    """

    degree: int
    group_description: str
    generators: Tuple[str, ...] = ()

    def validate(self) -> list[str]:
        """Return list of validation errors."""
        errors: list[str] = []
        if self.degree < 0:
            errors.append(f"degree must be non-negative, got {self.degree}")
        if not self.group_description:
            errors.append("group_description must be non-empty")
        return errors


@dataclass(frozen=True)
class AlgebraicKTheory:
    """Algebraic K-theory K_*(R) for a ring R or scheme X.

    K_0(R) is the Grothendieck group of finitely generated projective
    R-modules. K_1(R) = GL(R)/E(R).

    Attributes:
        base_description: Description of the base ring or scheme.
        construction: One of "plus", "Q", "Waldhausen", "infinity_categorical".
        k_groups: Tuple of computed K-groups.
    """

    base_description: str
    construction: str
    k_groups: Tuple[KGroup, ...]

    def validate(self) -> list[str]:
        """Return list of validation errors."""
        errors: list[str] = []

        if not self.base_description:
            errors.append("base_description must be non-empty")

        if self.construction not in VALID_CONSTRUCTIONS:
            errors.append(
                f"construction {self.construction!r} not in "
                f"{sorted(VALID_CONSTRUCTIONS)}"
            )

        seen_degrees: set[int] = set()
        for i, kg in enumerate(self.k_groups):
            sub = kg.validate()
            for e in sub:
                errors.append(f"k_group[{i}]: {e}")
            if kg.degree in seen_degrees:
                errors.append(f"duplicate K-group degree {kg.degree}")
            seen_degrees.add(kg.degree)

        return errors

    def k(self, n: int) -> KGroup | None:
        """Look up K_n by degree. Returns None if not computed."""
        for kg in self.k_groups:
            if kg.degree == n:
                return kg
        return None


def make_k_theory_integers() -> AlgebraicKTheory:
    """K-theory of the integers Z.

    K_0(Z) = Z (rank of free modules).
    K_1(Z) = Z/2 (det: GL(Z) → {±1}).
    K_2(Z) = Z/2 (Milnor, 1971).
    """
    return AlgebraicKTheory(
        base_description="Z (integers)",
        construction="plus",
        k_groups=(
            KGroup(degree=0, group_description="Z", generators=("[Z]",)),
            KGroup(degree=1, group_description="Z/2", generators=("[-1]",)),
            KGroup(degree=2, group_description="Z/2"),
        ),
    )


def make_k_theory_field(field_name: str) -> AlgebraicKTheory:
    """K-theory of a field F.

    K_0(F) = Z (dimension of vector spaces).
    K_1(F) = F* (units of F).
    """
    return AlgebraicKTheory(
        base_description=f"Field {field_name}",
        construction="plus",
        k_groups=(
            KGroup(
                degree=0,
                group_description="Z",
                generators=("[F]",),
            ),
            KGroup(
                degree=1,
                group_description=f"{field_name}*",
                generators=(f"units of {field_name}",),
            ),
        ),
    )
