"""cone / cocone shells for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class ConeLeg:
    """One cone/cocone leg: diagram index → morphism label."""

    index: str
    morphism_label: str


@dataclass
class Cone:
    """Best-effort shell for a cone over a diagram (apex + legs)."""

    label: str
    apex: str = ""
    legs: List[ConeLeg] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Cone":
        return cls(label=label)

    @classmethod
    def with_apex(cls, label: str, apex: str) -> "Cone":
        return cls(label=label, apex=apex)

    def with_leg(self, index: str, morphism_label: str) -> None:
        self.legs.append(ConeLeg(index=index, morphism_label=morphism_label))

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.apex:
            raise ValueError("empty apex")
        for i, leg in enumerate(self.legs):
            if not leg.index or not leg.morphism_label:
                raise ValueError(f"empty leg tag at index {i}")


@dataclass
class Cocone:
    """Best-effort shell for a cocone under a diagram (nadir + legs)."""

    label: str
    nadir: str = ""
    legs: List[ConeLeg] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Cocone":
        return cls(label=label)

    @classmethod
    def with_nadir(cls, label: str, nadir: str) -> "Cocone":
        return cls(label=label, nadir=nadir)

    def with_leg(self, index: str, morphism_label: str) -> None:
        self.legs.append(ConeLeg(index=index, morphism_label=morphism_label))

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.nadir:
            raise ValueError("empty nadir")
        for i, leg in enumerate(self.legs):
            if not leg.index or not leg.morphism_label:
                raise ValueError(f"empty leg tag at index {i}")



