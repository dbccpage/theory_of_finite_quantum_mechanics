"""equalizer shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Equalizer:
    """Best-effort shell for an equalizer of a parallel pair."""

    label: str
    equalizer_object: str = ""
    source: str = ""
    target: str = ""
    morphism_f: str = ""
    morphism_g: str = ""
    equalizer_morphism: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Equalizer":
        return cls(label=label)

    @classmethod
    def of_pair(
        cls,
        label: str,
        equalizer_object: str,
        source: str,
        target: str,
        morphism_f: str,
        morphism_g: str,
        equalizer_morphism: str,
    ) -> "Equalizer":
        return cls(
            label=label,
            equalizer_object=equalizer_object,
            source=source,
            target=target,
            morphism_f=morphism_f,
            morphism_g=morphism_g,
            equalizer_morphism=equalizer_morphism,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.equalizer_object:
            raise ValueError("empty equalizer_object")
        if not self.source:
            raise ValueError("empty source")
        if not self.target:
            raise ValueError("empty target")
        if not self.morphism_f:
            raise ValueError("empty morphism_f")
        if not self.morphism_g:
            raise ValueError("empty morphism_g")
        if not self.equalizer_morphism:
            raise ValueError("empty equalizer_morphism")



