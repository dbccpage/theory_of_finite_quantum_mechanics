"""EPK Error types."""

from __future__ import annotations
class EpkError(Exception):
    """Base class for EPK errors."""

    pass


class DefectThresholdExceededError(EpkError):
    """Raised when path kernel defect count exceeds allowable threshold."""

    pass


class UngluedSegmentError(EpkError):
    """Raised when trace boundary segments cannot be glued."""

    pass


class LedgerIntegrityError(EpkError):
    """Raised when EPK trace ledger fails hash or sequence validation."""

    pass

