"""adjoint functor theorem shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Hypothesis/conclusion labels for an AFT-style claim — shape only.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class AdjointFunctorTheoremShell:
    """Best-effort shell for an adjoint-functor-theorem claim record."""

    label: str
    functor_ref: str = ""
    adjoint_side: str = ""
    hypotheses: List[str] = field(default_factory=list)
    solution_set_condition: str = ""
    claimed_adjoint: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "AdjointFunctorTheoremShell":
        return cls(label=label)

    @classmethod
    def for_functor(
        cls, label: str, functor_ref: str, adjoint_side: str
    ) -> "AdjointFunctorTheoremShell":
        return cls(
            label=label,
            functor_ref=functor_ref,
            adjoint_side=adjoint_side,
        )

    def with_hypothesis(self, hypothesis: str) -> "AdjointFunctorTheoremShell":
        self.hypotheses.append(hypothesis)
        return self

    def with_solution_set(self, condition: str) -> "AdjointFunctorTheoremShell":
        self.solution_set_condition = condition
        return self

    def with_claimed_adjoint(self, claimed: str) -> "AdjointFunctorTheoremShell":
        self.claimed_adjoint = claimed
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.functor_ref:
            raise ValueError("empty functor_ref")
        if not self.adjoint_side:
            raise ValueError("empty adjoint_side")
        for i, h in enumerate(self.hypotheses):
            if not h:
                raise ValueError(f"empty hypothesis tag at index {i}")



