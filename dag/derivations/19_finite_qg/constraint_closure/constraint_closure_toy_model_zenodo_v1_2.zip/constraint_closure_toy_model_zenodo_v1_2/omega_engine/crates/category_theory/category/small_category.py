"""small_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List

from .category import FiniteCategoryShell, MorphismTriple


@dataclass
class SmallCategoryShell:
    """Best-effort small-category shell (finite presentation + smallness claim)."""

    label: str
    presentation: FiniteCategoryShell = field(
        default_factory=lambda: FiniteCategoryShell(label="")
    )
    claims_small: bool = True
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "SmallCategoryShell":
        return cls(label=label, presentation=FiniteCategoryShell.new(label))

    @classmethod
    def from_presentation(
        cls, presentation: FiniteCategoryShell
    ) -> "SmallCategoryShell":
        return cls(
            label=presentation.label, presentation=presentation, claims_small=True
        )

    def objects(self) -> List[str]:
        return self.presentation.objects

    def morphisms(self) -> List[MorphismTriple]:
        return self.presentation.morphisms

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.claims_small:
            raise ValueError("claims_small must be true for SmallCategoryShell")
        self.presentation.validate_shell()



