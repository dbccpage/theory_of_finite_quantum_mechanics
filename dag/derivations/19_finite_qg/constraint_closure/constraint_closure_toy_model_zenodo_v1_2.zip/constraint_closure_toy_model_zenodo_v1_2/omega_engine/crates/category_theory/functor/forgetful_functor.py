"""forgetful_functor shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class ForgetfulFunctor:
    """Best-effort shell for a forgetful functor between labeled categories."""

    label: str
    source_category: str = ""
    target_category: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "ForgetfulFunctor":
        return cls(label=label)

    @classmethod
    def between(
        cls, label: str, source_category: str, target_category: str
    ) -> "ForgetfulFunctor":
        return cls(
            label=label,
            source_category=source_category,
            target_category=target_category,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.source_category:
            raise ValueError("empty source_category")
        if not self.target_category:
            raise ValueError("empty target_category")



