"""Port of ``omega_solvers/src/certifiers/hodge_certificate_checker.rs``.

UNIT-WEIGHT diagnostic checker only (weight_profile_id = "unit_weights_v1"):
the dual box constraint is |p_e| <= 1+tol, i.e. unit-l-infinity. Do NOT use this
to validate weighted Phi_1 certificates (those require |p_e| <= omega_e).

Checks an L1 Hodge certificate: dual box constraint |p_e| <= 1+tol, dual
annihilator d0* p = 0, and primal-dual gap |primal_obj - dual_obj| <= tol.
Fails CLOSED: malformed shape, non-finite values, or invalid tolerance are
typed rejections, never IndexError/silent acceptance.
"""

from __future__ import annotations
import math
from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Sequence

WEIGHT_PROFILE_ID = "unit_weights_v1"


class CertRejectReason(Enum):
    DualBoundViolation = auto()
    DualAnnihilatorViolation = auto()
    PrimalDualGapViolation = auto()
    ShapeMismatch = auto()
    NonFiniteInput = auto()
    InvalidTolerance = auto()


def _all_finite(xs) -> bool:
    return all(math.isfinite(float(x)) for x in xs)


class CertStatus:
    """``CertStatus`` enum: ``Accept`` or ``Reject(reason)``."""

    def __init__(self, accept: bool, reason: CertRejectReason | None = None):
        self.accept = accept
        self.reason = reason

    @classmethod
    def new_accept(cls) -> "CertStatus":
        return cls(True)

    @classmethod
    def reject(cls, reason: CertRejectReason) -> "CertStatus":
        return cls(False, reason)

    def __eq__(self, other):
        return (
            isinstance(other, CertStatus)
            and self.accept == other.accept
            and self.reason == other.reason
        )

    def __repr__(self):
        return (
            "CertStatus.Accept" if self.accept else f"CertStatus.Reject({self.reason})"
        )


@dataclass
class HodgeCertificate:
    tau: Sequence[float]
    primal_alpha: Sequence[float]
    dual_witness: Sequence[float]


def check_hodge_certificate(graph, cert: HodgeCertificate, tol: float) -> CertStatus:
    if not math.isfinite(tol) or tol < 0:
        return CertStatus.reject(CertRejectReason.InvalidTolerance)
    edge_count = len(graph.edges())
    node_count = graph.num_nodes()
    if (
        len(cert.tau) != edge_count
        or len(cert.dual_witness) != edge_count
        or len(cert.primal_alpha) != node_count
    ):
        return CertStatus.reject(CertRejectReason.ShapeMismatch)
    if not (
        _all_finite(cert.tau)
        and _all_finite(cert.dual_witness)
        and _all_finite(cert.primal_alpha)
    ):
        return CertStatus.reject(CertRejectReason.NonFiniteInput)

    for p in cert.dual_witness:
        if abs(p) > 1.0 + tol:
            return CertStatus.reject(CertRejectReason.DualBoundViolation)

    div: List[float] = [0.0] * graph.num_nodes()
    for idx, (u, v) in enumerate(graph.edges()):
        div[u] -= cert.dual_witness[idx]
        div[v] += cert.dual_witness[idx]
    for d in div:
        if abs(d) > tol:
            return CertStatus.reject(CertRejectReason.DualAnnihilatorViolation)

    residual = [0.0] * len(graph.edges())
    for idx, (u, v) in enumerate(graph.edges()):
        grad = cert.primal_alpha[v] - cert.primal_alpha[u]
        residual[idx] = cert.tau[idx] - grad

    primal_obj = sum(abs(x) for x in residual)

    dual_obj = sum(t * p for t, p in zip(cert.tau, cert.dual_witness))

    if abs(primal_obj - dual_obj) > tol:
        return CertStatus.reject(CertRejectReason.PrimalDualGapViolation)

    return CertStatus.new_accept()


__all__ = [
    "CertRejectReason",
    "CertStatus",
    "HodgeCertificate",
    "check_hodge_certificate",
    "WEIGHT_PROFILE_ID",
]
