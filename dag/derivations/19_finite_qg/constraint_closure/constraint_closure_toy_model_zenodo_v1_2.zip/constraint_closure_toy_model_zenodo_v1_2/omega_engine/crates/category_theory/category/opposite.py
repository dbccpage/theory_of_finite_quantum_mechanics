"""opposite category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List

from .category import MorphismTriple


@dataclass
class OppositeCategoryShell:
    """Best-effort opposite-category shell wrapping a base label."""

    label: str
    base_label: str = ""
    reversed_morphisms: List[MorphismTriple] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str, base_label: str) -> "OppositeCategoryShell":
        return cls(label=label, base_label=base_label)

    @classmethod
    def reverse_of(
        cls,
        label: str,
        base_label: str,
        base_morphisms: List[MorphismTriple],
    ) -> "OppositeCategoryShell":
        reversed_morphisms = [
            MorphismTriple(source=m.target, target=m.source, name=m.name)
            for m in base_morphisms
        ]
        return cls(
            label=label,
            base_label=base_label,
            reversed_morphisms=reversed_morphisms,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.base_label:
            raise ValueError("empty base_label")
        for i, m in enumerate(self.reversed_morphisms):
            if not m.source or not m.target or not m.name:
                raise ValueError(f"empty reversed morphism field at index {i}")



