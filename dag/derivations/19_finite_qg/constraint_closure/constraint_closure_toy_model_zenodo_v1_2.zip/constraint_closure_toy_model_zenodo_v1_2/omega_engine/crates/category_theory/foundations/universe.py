"""universe shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Related contract (if present): ``urn:omega:math:type_universe:v0.1.0``.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Universe:
    """Best-effort shell for a type-universe level record (U_i)."""

    label: str
    level: int = 0
    cumulative: bool = True
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Universe":
        return cls(label=label)

    @classmethod
    def at_level(cls, label: str, level: int) -> "Universe":
        return cls(label=label, level=level, cumulative=True)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if self.level < 0:
            raise ValueError(f"universe level {self.level} < 0")



