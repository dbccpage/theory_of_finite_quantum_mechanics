"""vertical_composition shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class VerticalComposition:
    """Best-effort shell for a vertical composition claim on nat-trans refs."""

    label: str
    outer_nat_trans_ref: str = ""
    inner_nat_trans_ref: str = ""
    result_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "VerticalComposition":
        return cls(label=label)

    @classmethod
    def of(
        cls, label: str, outer_nat_trans_ref: str, inner_nat_trans_ref: str
    ) -> "VerticalComposition":
        return cls(
            label=label,
            outer_nat_trans_ref=outer_nat_trans_ref,
            inner_nat_trans_ref=inner_nat_trans_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.outer_nat_trans_ref:
            raise ValueError("empty outer_nat_trans_ref")
        if not self.inner_nat_trans_ref:
            raise ValueError("empty inner_nat_trans_ref")



