from typing import Any
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.simulation import (
    simulate_poe_moe_paths,
)


def run_poe_moe(n: int = 1000, seed: int = 7) -> dict[str, Any]:
    return simulate_poe_moe_paths(n=n, seed=seed)



