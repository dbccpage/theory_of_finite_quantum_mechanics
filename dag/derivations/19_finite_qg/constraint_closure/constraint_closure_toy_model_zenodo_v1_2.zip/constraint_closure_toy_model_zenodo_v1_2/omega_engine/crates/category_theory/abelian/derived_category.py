"""derived_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Derived category of an abelian category (localization of chain complexes
at quasi-isomorphisms). Shape only: records the base abelian label.
Computational homology of complexes is owned by ``omega_homology`` (docs link).
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class DerivedCategory:
    """Best-effort shell for a derived-category claim."""

    label: str
    base_abelian_label: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "DerivedCategory":
        return cls(label=label)

    @classmethod
    def of_abelian(cls, label: str, base_abelian_label: str) -> "DerivedCategory":
        return cls(label=label, base_abelian_label=base_abelian_label)

    def with_note(self, note: str) -> "DerivedCategory":
        self.notes.append(note)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.base_abelian_label:
            raise ValueError("empty base_abelian_label")



