"""density_comonad shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class DensityComonad:
    """Best-effort shell for the density comonad Lan_K K."""

    label: str
    functor_k: str = ""
    domain_category_ref: str = ""
    codomain_category_ref: str = ""
    comonad_ref: str = ""
    lan_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "DensityComonad":
        return cls(label=label)

    @classmethod
    def of_functor(
        cls,
        label: str,
        functor_k: str,
        domain_category_ref: str,
        codomain_category_ref: str,
        comonad_ref: str,
    ) -> "DensityComonad":
        return cls(
            label=label,
            functor_k=functor_k,
            domain_category_ref=domain_category_ref,
            codomain_category_ref=codomain_category_ref,
            comonad_ref=comonad_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.functor_k:
            raise ValueError("empty functor_k")
        if not self.domain_category_ref:
            raise ValueError("empty domain_category_ref")
        if not self.codomain_category_ref:
            raise ValueError("empty codomain_category_ref")
        if not self.comonad_ref:
            raise ValueError("empty comonad_ref")



