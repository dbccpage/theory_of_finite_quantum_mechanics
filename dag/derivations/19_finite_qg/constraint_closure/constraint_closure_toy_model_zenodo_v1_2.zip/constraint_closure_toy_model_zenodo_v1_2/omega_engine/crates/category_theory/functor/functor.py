"""functor shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class Functor:
    """Best-effort shell for a labeled functor between labeled categories."""

    label: str
    source_category: str = ""
    target_category: str = ""
    object_map: List[Tuple[str, str]] = field(default_factory=list)
    morphism_map: List[Tuple[str, str]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Functor":
        return cls(label=label)

    @classmethod
    def between(
        cls, label: str, source_category: str, target_category: str
    ) -> "Functor":
        return cls(
            label=label,
            source_category=source_category,
            target_category=target_category,
        )

    def with_object_map(self, object_map: List[Tuple[str, str]]) -> "Functor":
        self.object_map = list(object_map)
        return self

    def with_morphism_map(self, morphism_map: List[Tuple[str, str]]) -> "Functor":
        self.morphism_map = list(morphism_map)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.source_category:
            raise ValueError("empty source_category")
        if not self.target_category:
            raise ValueError("empty target_category")
        for i, (a, b) in enumerate(self.object_map):
            if not a or not b:
                raise ValueError(f"empty object_map tag at index {i}")
        for i, (a, b) in enumerate(self.morphism_map):
            if not a or not b:
                raise ValueError(f"empty morphism_map tag at index {i}")



