"""Conformance harness: vacuity as a computed residual. AuthorityEffect: None."""

from .residuals import (
    Residual,
    WrongForm,
    adequacy_residual,
    attribution_residual,
    combine,
    mutation_residual,
)
from .runner import available, load_vectors, run_all, run_quantity

__all__ = [
    "Residual",
    "WrongForm",
    "adequacy_residual",
    "attribution_residual",
    "mutation_residual",
    "combine",
    "available",
    "load_vectors",
    "run_quantity",
    "run_all",
]
