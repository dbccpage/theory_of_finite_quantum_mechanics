"""constant_functor shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class ConstantFunctor:
    """Best-effort shell for a constant functor between labeled categories."""

    label: str
    source_category: str = ""
    target_category: str = ""
    constant_object: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "ConstantFunctor":
        return cls(label=label)

    @classmethod
    def constant(
        cls,
        label: str,
        source_category: str,
        target_category: str,
        constant_object: str,
    ) -> "ConstantFunctor":
        return cls(
            label=label,
            source_category=source_category,
            target_category=target_category,
            constant_object=constant_object,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.source_category:
            raise ValueError("empty source_category")
        if not self.target_category:
            raise ValueError("empty target_category")
        if not self.constant_object:
            raise ValueError("empty constant_object")



