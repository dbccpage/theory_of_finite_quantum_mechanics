"""monoidal_functor shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class MonoidalFunctor:
    """Best-effort monoidal functor shell."""

    label: str
    domain_monoidal: str = ""
    codomain_monoidal: str = ""
    functor_ref: str = ""
    tensorator_ref: str = ""
    unit_comparison_ref: str = ""
    strong_claimed: bool = False
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "MonoidalFunctor":
        return cls(label=label)

    @classmethod
    def between(
        cls,
        label: str,
        domain_monoidal: str,
        codomain_monoidal: str,
        functor_ref: str,
    ) -> "MonoidalFunctor":
        return cls(
            label=label,
            domain_monoidal=domain_monoidal,
            codomain_monoidal=codomain_monoidal,
            functor_ref=functor_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.domain_monoidal:
            raise ValueError("empty domain_monoidal")
        if not self.codomain_monoidal:
            raise ValueError("empty codomain_monoidal")
        if not self.functor_ref:
            raise ValueError("empty functor_ref")



