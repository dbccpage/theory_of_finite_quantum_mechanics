"""Diagnostic Contract Subsystem Implementation.

Conforms strictly to contract specification:
    urn:omega:evidence:diagnostic:v1.0.0
    (omega_engine/crates/omega_contracts/src/contract_canonical_definitions/02_core_evidence/diagnostic.contract.yaml)

Doctrine:
- Diagnostic is a read-only health reporting component.
- Emits factual findings and measurement references.
- Does not prescribe treatment, schedule control flow, classify admissibility, terminalize, mutate, authorize, or execute.
- AuthorityEffect: EvidenceOnly default; CheckedDiagnosticReport is FactOnly when checked.
"""

from __future__ import annotations
import hashlib
import json
from dataclasses import field
from pydantic.dataclasses import dataclass
from typing import Any, Dict, List, Optional

CONTRACT_ID = "urn:omega:evidence:diagnostic:v1.0.0"
SCHEMA_VERSION = "omega.contract.v1"


@dataclass(frozen=True)
class DiagnosticFinding:
    """Individual diagnostic health finding observation."""

    finding_id: str
    code: str
    message: str
    severity: str  # "INFO" | "WARNING" | "DEFECT" | "CRITICAL"
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class DiagnosticReport:
    """Raw diagnostic health report envelope conforming to urn:omega:evidence:diagnostic:v1.0.0."""

    diagnostic_id: str
    subject: str
    findings: List[DiagnosticFinding]
    measurements: List[str] = field(default_factory=list)
    certificate_refs: List[str] = field(default_factory=list)
    report_hash: str = field(default_factory=str)
    authority_effect: str = "EvidenceOnly"

    def compute_hash(self) -> str:
        payload = {
            "diagnostic_id": self.diagnostic_id,
            "subject": self.subject,
            "findings": [
                {
                    "finding_id": f.finding_id,
                    "code": f.code,
                    "severity": f.severity,
                    "message": f.message,
                }
                for f in self.findings
            ],
            "measurements": [str(m) for m in self.measurements],
            "certificate_refs": [str(c) for c in self.certificate_refs],
            "authority_effect": self.authority_effect,
        }
        raw_bytes = json.dumps(payload, sort_keys=True).encode("utf-8")
        return hashlib.sha256(raw_bytes).hexdigest()


@dataclass(frozen=True)
class CheckedDiagnosticReport:
    """Verified diagnostic report envelope (FactOnly)."""

    report: DiagnosticReport
    checked_subject_hash: str
    checked_finding_hashes: List[str]
    checker_ref: str
    authority_effect: str = "FactOnly"


class Diagnostic:
    """Read-only health evidence reporter."""

    def __init__(self, diagnostic_id: str, diagnostic_version: str = "v1.0.0"):
        self.diagnostic_id = diagnostic_id
        self.diagnostic_version = diagnostic_version

    def generate_report(
        self,
        subject: str,
        findings: List[DiagnosticFinding],
        measurements: Optional[List[str]] = None,
        certificate_refs: Optional[List[str]] = None,
    ) -> DiagnosticReport:
        """Generate a deterministic DiagnosticReport envelope."""
        m_list = measurements or []
        c_list = certificate_refs or []
        report = DiagnosticReport(
            diagnostic_id=self.diagnostic_id,
            subject=subject,
            findings=findings,
            measurements=m_list,
            certificate_refs=c_list,
            authority_effect="EvidenceOnly",
        )
        report_hash = report.compute_hash()
        return DiagnosticReport(
            diagnostic_id=report.diagnostic_id,
            subject=report.subject,
            findings=report.findings,
            measurements=report.measurements,
            certificate_refs=report.certificate_refs,
            report_hash=report_hash,
            authority_effect="EvidenceOnly",
        )

    def check_report(self, report: DiagnosticReport, checker_ref: str = "diagnostic_checker") -> CheckedDiagnosticReport:
        """Verify diagnostic report structure and return CheckedDiagnosticReport."""
        subj_hash = hashlib.sha256(report.subject.encode("utf-8")).hexdigest()
        finding_hashes = [
            hashlib.sha256(f"{f.finding_id}:{f.code}".encode("utf-8")).hexdigest()
            for f in report.findings
        ]
        return CheckedDiagnosticReport(
            report=report,
            checked_subject_hash=subj_hash,
            checked_finding_hashes=finding_hashes,
            checker_ref=checker_ref,
            authority_effect="FactOnly",
        )


def verify_diagnostic_contract(diag_instance: Diagnostic) -> bool:
    """Verify that a diagnostic instance conforms to urn:omega:evidence:diagnostic:v1.0.0."""
    return (
        isinstance(diag_instance, Diagnostic)
        and hasattr(diag_instance, "diagnostic_id")
        and hasattr(diag_instance, "generate_report")
    )


__all__ = [
    "CONTRACT_ID",
    "SCHEMA_VERSION",
    "DiagnosticFinding",
    "DiagnosticReport",
    "CheckedDiagnosticReport",
    "Diagnostic",
    "verify_diagnostic_contract",
]




