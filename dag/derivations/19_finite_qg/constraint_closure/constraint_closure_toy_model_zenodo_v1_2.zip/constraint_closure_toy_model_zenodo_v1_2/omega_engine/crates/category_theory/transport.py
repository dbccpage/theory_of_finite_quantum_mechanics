"""Transport certificates, squares, loss ledgers, and coherence checks.

Manages how data moves across representations (CODA-MUR) without silent loss.
"""

from enum import Enum
from typing import Any, List, Optional, Tuple
from omega_engine.crates.type.refusal import Refusal, Result


class TransportAxis(Enum):
    """Declared transport axis (§4 lens / §11.3, spine §III.6.1.1).

    The two CODA-MUR axes are replayed *separately*:

    - ``VERTICAL``   = restriction / coarse-graining (within a representation).
    - ``HORIZONTAL`` = representation translation (across representations).
    - ``MIXED``      = an undecomposed vertical+horizontal axis. A transport that
      declares ``MIXED`` carries no unique factorization and must be refused
      (``DiagonalTransportRefusal``) unless a declared factorization system
      supplies the decomposition.
    """

    VERTICAL = "vertical"  
    HORIZONTAL = "horizontal"  
    MIXED = "mixed"  


class TransportRefusal(Refusal):
    """Refusal representing a transport failure or coherence violation."""

    def __init__(self, reason: str, details: Any = None) -> None:
        super().__init__(f"TransportRefusal: {reason}", details)


class CochainTransportRefusal(TransportRefusal):
    """Refusal: a transport map was treated as a differential d₀/d₁ (§4, spine §III.6.1).

    "Transport is not a differential" -- the inter-layer map ``f_{n→m}`` is
    *certified transport*; treating it as ``d₀``/``d₁`` is a category error whose
    obstruction lives in the transport cone, not in a fiber cochain complex.
    """

    def __init__(self, role: str, details: Any = None) -> None:
        super().__init__(
            "CochainTransport",
            details
            or f"transport map treated as differential {role!r}; "
            "transport is not a differential (spine §III.6.1)",
        )


class DiagonalTransportRefusal(TransportRefusal):
    """Refusal: a transport carries an undecomposed mixed vertical+horizontal axis.

    Per §11.3, a single undecomposed mixed-axis operator is refused; no unique
    factorization is inferred from packet shape alone.
    """

    def __init__(self, details: Any = None) -> None:
        super().__init__(
            "DiagonalTransport",
            details
            or "undecomposed mixed vertical+horizontal axis; supply a declared "
            "factorization or split into separate vertical/horizontal squares",
        )


class TransportCertificate:
    """Certificate for moving carrier data from source to target representation."""

    def __init__(
        self,
        source_repr: str,
        target_repr: str,
        map_func: Any,
        coherence_witness: Any,
        axis: TransportAxis = TransportAxis.HORIZONTAL,
        factorization: Optional[Any] = None,
        role: str = "transport",
    ) -> None:
        self.source_repr = source_repr
        self.target_repr = target_repr
        self.map_func = map_func
        self.coherence_witness = coherence_witness
        self.axis = axis
        self.factorization = factorization
        self.role = role

    def validate(self) -> Result[bool]:
        """Validate that the certificate carries a coherence witness and callable map.

        Also enforces the §4 / §11.3 axis discipline:
          - a map declared with role ``d0``/``d1`` is a ``CochainTransportRefusal``
            (transport is not a differential);
          - a ``MIXED``-axis transport with no declared factorization is a
            ``DiagonalTransportRefusal``.

        Returns bare ``True`` on success; otherwise a typed ``TransportRefusal``.
        """
        if self.role in ("d0", "d1", "differential"):
            return CochainTransportRefusal(
                self.role,
                f"Certificate {self.source_repr} -> {self.target_repr} declared as "
                f"differential {self.role!r}; transport is not a differential",
            )
        if self.axis is TransportAxis.MIXED and self.factorization is None:
            return DiagonalTransportRefusal(
                f"Certificate {self.source_repr} -> {self.target_repr} carries an "
                "undecomposed mixed vertical+horizontal axis with no declared factorization",
            )
        if self.coherence_witness is None:
            return TransportRefusal(
                "MissingCoherenceWitness",
                f"Certificate {self.source_repr} -> {self.target_repr} has no coherence witness",
            )
        if not callable(self.map_func):
            return TransportRefusal(
                "NonCallableMapFunc",
                f"Certificate {self.source_repr} -> {self.target_repr} map_func is not callable",
            )
        return True

    def __repr__(self) -> str:
        return f"TransportCertificate({self.source_repr} -> {self.target_repr})"


class LossLedger:
    """An append-only ledger tracking information loss during transport."""

    def __init__(self) -> None:
        self._entries: List[Tuple[str, str, float]] = []

    def record_loss(self, source: str, target: str, loss: float) -> Result[bool]:
        """Record a transport loss at runtime.

        This is the operational add path: a negative loss is a runtime data
        violation and is reported as a typed ``TransportRefusal`` (not raised).
        Returns bare ``True`` on success.
        """
        if loss < 0:
            return TransportRefusal(
                "NegativeLoss",
                f"Loss must be non-negative, got {loss} for {source} -> {target}",
            )
        self._entries.append((source, target, loss))
        return True

    @property
    def total_loss(self) -> float:
        return sum(loss for _, _, loss in self._entries)

    def entries(self) -> List[Tuple[str, str, float]]:
        return list(self._entries)


class TransportSquare:
    """A vertical/horizontal restriction square mapping horizontal & vertical operations."""

    def __init__(
        self,
        top_left: str,
        top_right: str,
        bottom_left: str,
        bottom_right: str,
        horizontal_top: Any,
        horizontal_bottom: Any,
        vertical_left: Any,
        vertical_right: Any,
    ) -> None:
        self.top_left = top_left
        self.top_right = top_right
        self.bottom_left = bottom_left
        self.bottom_right = bottom_right
        self.horizontal_top = horizontal_top
        self.horizontal_bottom = horizontal_bottom
        self.vertical_left = vertical_left
        self.vertical_right = vertical_right

    def check_commutativity(self, x: Any) -> Result[bool]:
        """Verify that the vertical/horizontal square commutes for a given input.

        Returns bare ``True`` when both pathways agree; otherwise a typed
        ``TransportRefusal``.
        """
        y1 = self.horizontal_top(x)
        path1 = self.vertical_right(y1)

        y2 = self.vertical_left(x)
        path2 = self.horizontal_bottom(y2)

        if path1 != path2:
            return TransportRefusal(
                "TransportSquareViolation",
                f"Square does not commute on {x}: {path1} != {path2}",
            )
        return True


def check_pasting(
    t1: TransportCertificate,
    t2: TransportCertificate,
    t_comp: TransportCertificate,
    x: Any,
) -> Result[bool]:
    """Verify composition of two transport steps against the declared composite."""
    for cert in (t1, t2, t_comp):
        cert_check = cert.validate()
        if isinstance(cert_check, Refusal):
            return cert_check

    if t1.target_repr != t2.source_repr:
        return TransportRefusal(
            "IncompatibleSteps", f"{t1.target_repr} != {t2.source_repr}"
        )

    comp_val = t_comp.map_func(x)
    iter_val = t2.map_func(t1.map_func(x))

    if comp_val != iter_val:
        return TransportRefusal(
            "PastingCoherenceViolation",
            f"Composed transport result {comp_val} != Iterated transport result {iter_val}",
        )
    return True


def check_no_silent_loss(ledger: LossLedger, expected_loss: float) -> Result[bool]:
    """Ensure ledger records the exact expected loss, refusing any unledgered discrepancy."""
    if abs(ledger.total_loss - expected_loss) > 1e-9:
        return TransportRefusal(
            "SilentLossDetected",
            f"Ledger recorded {ledger.total_loss} loss, but expected {expected_loss}",
        )
    return True



