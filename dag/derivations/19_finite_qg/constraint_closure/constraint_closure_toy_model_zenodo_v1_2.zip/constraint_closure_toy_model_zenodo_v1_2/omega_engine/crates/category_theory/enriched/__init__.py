"""Enriched shells for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Mirrors ``omega_engine/crates/omega_category_theory/src/enriched/``.
"""

from .enriched_category import EnrichedCategory, HomObjectEntry
from .enriched_functor import EnrichedFunctor
from .enriched_natural_transformation import EnrichedNaturalTransformation
from .enriched_adjunction import EnrichedAdjunction
from .base_category import BaseCategory
from .enriched_presheaf import EnrichedPresheaf
from .weighted_limit import WeightedLimit
from .weighted_colimit import WeightedColimit

__all__ = [
    "EnrichedCategory",
    "HomObjectEntry",
    "EnrichedFunctor",
    "EnrichedNaturalTransformation",
    "EnrichedAdjunction",
    "BaseCategory",
    "EnrichedPresheaf",
    "WeightedLimit",
    "WeightedColimit",
]

