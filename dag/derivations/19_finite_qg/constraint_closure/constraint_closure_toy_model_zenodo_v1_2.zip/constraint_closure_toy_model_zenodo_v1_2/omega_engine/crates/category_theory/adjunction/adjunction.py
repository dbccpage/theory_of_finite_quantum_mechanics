"""adjunction shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
L ⊣ R declared by left/right functor labels plus unit/counit refs.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class AdjunctionShell:
    """Best-effort shell for an adjunction L ⊣ R.

    Records functor labels and references to unit/counit shells (by label).
    Does not certify triangle identities or hom-set bijections.
    """

    label: str
    left_functor: str = ""
    right_functor: str = ""
    unit_ref: str = ""
    counit_ref: str = ""
    source_category: str = ""
    target_category: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "AdjunctionShell":
        return cls(label=label)

    @classmethod
    def between(
        cls,
        label: str,
        left_functor: str,
        right_functor: str,
        unit_ref: str,
        counit_ref: str,
    ) -> "AdjunctionShell":
        return cls(
            label=label,
            left_functor=left_functor,
            right_functor=right_functor,
            unit_ref=unit_ref,
            counit_ref=counit_ref,
        )

    def with_categories(
        self, source_category: str, target_category: str
    ) -> "AdjunctionShell":
        self.source_category = source_category
        self.target_category = target_category
        return self

    def with_note(self, note: str) -> "AdjunctionShell":
        self.notes.append(note)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.left_functor:
            raise ValueError("empty left_functor")
        if not self.right_functor:
            raise ValueError("empty right_functor")
        if not self.unit_ref:
            raise ValueError("empty unit_ref")
        if not self.counit_ref:
            raise ValueError("empty counit_ref")



