from pydantic import ConfigDict
import os
import yaml  # type: ignore[import-untyped]
from typing import List
from dataclasses import field
from pydantic.dataclasses import dataclass
from omega_engine.crates.contract_core.registry.v1_types import OmegaContractV1, from_dict
from omega_engine.crates.contract_core.registry.v1_validate import validate_v1
from omega_engine.crates.contract_core.validate import validate_registry


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class V1LoadReport:
    loaded: int = 0
    contract_ids: List[str] = field(default_factory=list)
    findings: List[str] = field(default_factory=list)


def load_v1_dir(directory: str) -> V1LoadReport:
    report = V1LoadReport()
    descriptors = []

    yaml_files = collect_yaml(directory)
    for path in yaml_files:
        try:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
        except Exception as ex:
            report.findings.append(f"{path}: io: {ex}")
            continue

        try:
            shallow = yaml.safe_load(text)
        except Exception:
            # Skip invalid YAML files silently as per Rust loader
            continue

        if not isinstance(shallow, dict):
            continue

        if shallow.get("schema_version") != "omega.contract.v1":
            continue

        try:
            c = from_dict(shallow)
        except Exception as ex:
            report.findings.append(f"{path}: parse: {ex}")
            continue

        report.loaded += 1
        report.contract_ids.append(c.contract_id)

        try:
            validate_v1(c)
        except ValueError as errs:
            # errs.args[0] is the list of findings
            for e in errs.args[0]:
                report.findings.append(f"{path}: {e}")
        except Exception as ex:
            report.findings.append(f"{path}: {ex}")

        for e in intra_file_consistency(c):
            report.findings.append(f"{path}: {e}")

        descriptors.append(c.to_descriptor())

    try:
        validate_registry(descriptors)
    except Exception as ex:
        report.findings.append(f"registry: {ex}")

    return report


def intra_file_consistency(c: OmegaContractV1) -> List[str]:
    out: List[str] = []
    if c.math is None or not isinstance(c.math, dict):
        return out
    codomain = c.math.get("codomain")
    if codomain is None or not isinstance(codomain, dict):
        return out

    classes = codomain.get("classes")
    if isinstance(classes, list):
        for cl in classes:
            if not isinstance(cl, str):
                continue
            if cl not in c.descriptor.terminals.may_support:
                out.append(
                    f"unknown terminal: math.codomain class {cl!r} not declared in terminals.may_support"
                )

    meta_outcomes = codomain.get("meta_outcomes")
    if isinstance(meta_outcomes, list):
        for outcome in meta_outcomes:
            if not isinstance(outcome, str):
                continue
            if outcome not in c.descriptor.refusals.may_emit:
                out.append(
                    f"unknown refusal: math.codomain meta_outcome {outcome!r} not declared in refusals.may_emit"
                )

    return out


def collect_yaml(directory: str) -> List[str]:
    out: List[str] = []
    for root, _, files in os.walk(directory):
        for f in files:
            if f.endswith(".contract.yaml"):
                out.append(os.path.join(root, f).replace("\\", "/"))
    out.sort()
    return out





