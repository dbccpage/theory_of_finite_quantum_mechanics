"""enriched_adjunction shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class EnrichedAdjunction:
    """Best-effort enriched adjunction shell."""

    label: str
    left_adjoint: str = ""
    right_adjoint: str = ""
    base_monoidal_v: str = ""
    hom_iso_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "EnrichedAdjunction":
        return cls(label=label)

    @classmethod
    def with_adjoints(
        cls,
        label: str,
        left_adjoint: str,
        right_adjoint: str,
        base_monoidal_v: str,
    ) -> "EnrichedAdjunction":
        return cls(
            label=label,
            left_adjoint=left_adjoint,
            right_adjoint=right_adjoint,
            base_monoidal_v=base_monoidal_v,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.left_adjoint:
            raise ValueError("empty left_adjoint")
        if not self.right_adjoint:
            raise ValueError("empty right_adjoint")
        if not self.base_monoidal_v:
            raise ValueError("empty base_monoidal_v")



