"""coalgebra_for_comonad shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class CoalgebraForComonad:
    """Best-effort shell for a labeled W-coalgebra (carrier + structure map)."""

    label: str
    carrier_label: str = ""
    structure_map_label: str = ""
    comonad_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "CoalgebraForComonad":
        return cls(label=label)

    @classmethod
    def with_structure(
        cls,
        label: str,
        carrier_label: str,
        structure_map_label: str,
        comonad_ref: str,
    ) -> "CoalgebraForComonad":
        return cls(
            label=label,
            carrier_label=carrier_label,
            structure_map_label=structure_map_label,
            comonad_ref=comonad_ref,
        )

    def with_note(self, note: str) -> "CoalgebraForComonad":
        self.notes.append(note)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.carrier_label:
            raise ValueError("empty carrier_label")
        if not self.structure_map_label:
            raise ValueError("empty structure_map_label")
        if not self.comonad_ref:
            raise ValueError("empty comonad_ref")



