from typing import List
from omega_engine.crates.contract_core.kinds import AuthorityEffect
from omega_engine.crates.type.evidence import EvidenceCeiling
from .row import (
    ReconciliationRow,
    ClaimDelta,
    VerifyResult,
    TerminalStatus,
    AuthorityBasis,
    authority_rank,
)
from .cochain_validity import TriState


def validate_row(row: ReconciliationRow) -> List[str]:
    findings = []

    # Invariant I — PrimitiveDifference: a non-factoring observable MUST name a residual class
    if (
        not row.primitive_difference.factors_through_quotient
        and not row.primitive_difference.residual_class
    ):
        findings.append(
            "invariant-I: primitive difference does not factor through the quotient yet "
            "declares no residual_class"
        )

    # Invariant II — cochain validity: compute d₁∘d₀ over the row's carried F2 matrices
    computed = row.cochain_validity.computed_d1_d0_zero()
    # (a) a verifiably-nonzero d1∘d0 is only admissible if terminalized as malformed
    if computed == TriState.False_ and row.terminal_status.status not in (
        TerminalStatus.RepresentationMalformed,
        TerminalStatus.CochainInvalid,
    ):
        findings.append(
            "invariant-II: computed d1∘d0 != 0 but terminal status is not "
            "RepresentationMalformed/CochainInvalid"
        )
    # (b) closes the declared-trust gap: a row may not declare a d1_d0_zero that disagrees with its matrices
    if row.cochain_validity.d1_d0_zero != computed:
        findings.append(
            "invariant-II: declared d1_d0_zero disagrees with computed d1∘d0 over the carried matrices"
        )

    # Invariant III — identity conservation: classification may not erase identity
    if (
        row.identity_witness.identity_loss_risk
        or not row.identity_witness.conserved_across_edges
    ):
        findings.append(
            "invariant-III: identity is at risk or not conserved across edges "
            "(impersonation, not compression)"
        )

    # Demand: authority (counterfeit guard)
    if (
        row.claim_delta in (ClaimDelta.Accurate, ClaimDelta.Undersold)
        and row.authority_basis
        and all(b.basis == AuthorityBasis.None_ for b in row.authority_basis)
    ):
        findings.append(
            "demand-authority: counterfeit authority — every declared basis is None"
        )

    # Authority-ceiling drift: a declared effect may never exceed the role-pinned ceiling
    if authority_rank(row.declared_authority_effect) > authority_rank(
        row.role_pinned_ceiling
    ):
        findings.append(
            "ceiling drift: declared_authority_effect exceeds the role-pinned ceiling"
        )

    # Law 2 (authority bounded by evidence): a fact-or-stronger effect cannot rest on shape-only evidence
    fact_or_stronger = row.declared_authority_effect not in (
        AuthorityEffect.None_,
        AuthorityEffect.EvidenceOnly,
    )
    if fact_or_stronger and row.evidence_ceiling == EvidenceCeiling.SHAPE_ONLY:
        findings.append(
            "Law 2: declared authority is FactOnly-or-stronger but evidence ceiling is ShapeOnly"
        )

    # Demand: terminal descent
    if not row.terminal_status.reason:
        findings.append("demand-terminal-descent: terminal_status.reason is empty")

    open_or_unknown = row.terminal_status.status in (
        TerminalStatus.OpenObstruction,
        TerminalStatus.BudgetUnknown,
        TerminalStatus.NoRule,
    )
    if open_or_unknown and not row.routed_work:
        findings.append(
            "demand-terminal-descent: open/unknown/no-rule terminal status with empty routed_work"
        )

    if (
        row.claim_delta in (ClaimDelta.Oversold, ClaimDelta.Missing)
        and not row.routed_work
    ):
        findings.append(
            "demand-terminal-descent: oversold/missing claim with empty routed_work"
        )

    # O1: a Refuted verdict means the defect was refuted, so the row must collapse to Accurate
    if (
        row.verify_verdict.result == VerifyResult.Refuted
        and row.claim_delta != ClaimDelta.Accurate
    ):
        findings.append("O1: verification refuted while claim_delta is not Accurate")

    # Two-axis honesty: prose mechanization is not Lean mechanization
    claimed_lower = row.claimed.lower()
    claims_machine_checked = any(
        t in claimed_lower
        for t in [
            "machine-checked",
            "machine checked",
            "lean-verified",
            "lean verified",
        ]
    )
    if (
        row.proof_status.status == "MECHANIZED"
        and row.proof_status.lean_status != "MECHANIZED"
        and claims_machine_checked
    ):
        findings.append(
            "two-axis: claims machine-checked but lean_status is not MECHANIZED"
        )

    return findings


