"""Phi1 obstruction mass computation.

Solves the L1 optimization problem:
min_{alpha} ||x - d0(alpha)||_1
using a floating-point linear program (scipy ``linprog``) as a diagnostic of
the L1 obstruction mass. This is NOT an exact algebraic certificate.
"""

from typing import Any, Dict
import numpy as np
from scipy.optimize import linprog

from .finite_carrier import Vector
from omega_engine.crates.homology_theory.cochain_complex import CochainComplex
from omega_engine.crates.type.refusal import Result, Refusal


class PrimalCertificate:
    """Contains the primal optimal repair vector alpha and computed minimal mass."""

    def __init__(self, alpha: Vector, mass: float) -> None:
        self.alpha = alpha
        self.mass = mass

    def __repr__(self) -> str:
        return f"PrimalCertificate(mass={self.mass:.6f}, alpha={self.alpha!r})"


class DualCertificate:
    """An UNVERIFIED dual CANDIDATE for the L1 obstruction lower bound.

    Holds the dual values returned by the floating-point LP solver. The dual
    feasibility/optimality conditions are NOT checked here, so this is a
    candidate, not a verified certificate. In particular the following are NOT
    yet checked: ``||dual||_inf <= 1``, ``D0^T dual == 0``, and
    ``dual(x) == primal.mass``.
    """

    def __init__(self, dual_values: Dict[Any, float]) -> None:
        self.dual_values = dual_values

    def __repr__(self) -> str:
        return f"DualCertificate(dual_values={self.dual_values!r})"


class Phi1Witness:
    """Combines primal and dual certificates to prove bounds on Phi1 mass."""

    def __init__(self, primal: PrimalCertificate, dual: DualCertificate) -> None:
        self.primal = primal
        self.dual = dual

    def __repr__(self) -> str:
        return f"Phi1Witness(primal={self.primal!r}, dual={self.dual!r})"


def compute_phi1_lp_float(cochain: CochainComplex, x: Vector) -> Result[Phi1Witness]:
    """Floating-point LP diagnostic of the L1 obstruction mass.

    Computes ``min_alpha ||x - d0(alpha)||_1`` via scipy ``linprog`` and returns
    a witness bundling a primal repair vector and an UNVERIFIED dual candidate.
    This is NOT an exact algebraic certificate: the result is a floating-point
    diagnostic and the dual feasibility/bound conditions are not checked.
    """
    c0_basis = cochain.C0.basis.elements
    c1_basis = cochain.C1.basis.elements

    if not c1_basis:
        return Phi1Witness(
            PrimalCertificate(cochain.C0.zero(), 0.0), DualCertificate({})
        )

    # 1. Build matrix D0 of shape (len(c1_basis), len(c0_basis))
    D0 = np.zeros((len(c1_basis), len(c0_basis)))
    c0_basis_to_idx = {b: i for i, b in enumerate(c0_basis)}
    c1_basis_to_idx = {b: i for i, b in enumerate(c1_basis)}

    for (out_b, in_b), coeff in cochain.d0.matrix.items():
        if out_b in c1_basis_to_idx and in_b in c0_basis_to_idx:
            D0[c1_basis_to_idx[out_b], c0_basis_to_idx[in_b]] = coeff

    # 2. Vector x representation
    x_vec = np.zeros(len(c1_basis))
    for b, coeff in x.coeffs.items():
        if b in c1_basis_to_idx:
            x_vec[c1_basis_to_idx[b]] = coeff

    # 3. Formulate LP:
    # Variables: alpha_plus (n), alpha_minus (n), u (m)
    # Objective: min sum(u_i)
    # Subject to:
    # D0 * (alpha_plus - alpha_minus) - u <= x
    # -D0 * (alpha_plus - alpha_minus) - u <= -x
    # alpha_plus >= 0, alpha_minus >= 0, u >= 0
    n = len(c0_basis)
    m = len(c1_basis)

    c = np.concatenate([np.zeros(2 * n), np.ones(m)])

    # Inequality constraints: A_ub * var <= b_ub
    # [ D0, -D0, -I ]
    # [ -D0, D0, -I ]
    ident = np.eye(m)
    A_ub = np.block([[D0, -D0, -ident], [-D0, D0, -ident]])
    b_ub = np.concatenate([x_vec, -x_vec])

    bounds = [(0, None)] * (2 * n + m)

    res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")

    if not res.success or res.x is None or res.fun is None:
        return Refusal("LPOptimizationFailed", details=res.message)

    # Extract optimal alpha
    alpha_plus = res.x[:n]
    alpha_minus = res.x[n : 2 * n]
    alpha_opt = alpha_plus - alpha_minus

    alpha_coeffs = {
        c0_basis[i]: float(alpha_opt[i]) for i in range(n) if abs(alpha_opt[i]) > 1e-9
    }
    optimal_alpha = cochain.C0.make_vector(alpha_coeffs)

    primal = PrimalCertificate(optimal_alpha, float(res.fun))

    # Extract duals for certification
    # scipy linprog highs solver stores inequality duals in res.ineqlin.marginals
    dual_vals = {}
    if (
        res.ineqlin is not None
        and hasattr(res.ineqlin, "marginals")
        and res.ineqlin.marginals is not None
    ):
        marginals = res.ineqlin.marginals
        # The dual values certify the mass lower bound
        for i, b in enumerate(c1_basis):
            dual_vals[b] = float(marginals[i] - marginals[i + m])
    else:
        # Fallback if marginals are not available
        dual_vals = {b: 0.0 for b in c1_basis}

    dual = DualCertificate(dual_vals)

    return Phi1Witness(primal, dual)


# Backward-compatible alias. Historically this function was named
# ``compute_phi1_exact``; that name overclaimed (the LP is floating-point and
# not an exact algebraic certificate). The alias is retained for compatibility.
compute_phi1_exact = compute_phi1_lp_float



