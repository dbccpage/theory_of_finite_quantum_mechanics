"""category shell (finite presentation) for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class MorphismTriple:
    """Named morphism boundary triple: (source, target, name)."""

    source: str
    target: str
    name: str


@dataclass
class FiniteCategoryShell:
    """Best-effort finite category shell: objects, morphisms, identity keys."""

    label: str
    objects: List[str] = field(default_factory=list)
    morphisms: List[MorphismTriple] = field(default_factory=list)
    identity_map: Dict[str, str] = field(default_factory=dict)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "FiniteCategoryShell":
        return cls(label=label)

    @classmethod
    def with_objects(cls, label: str, objects: List[str]) -> "FiniteCategoryShell":
        identity_map: Dict[str, str] = {}
        morphisms: List[MorphismTriple] = []
        for o in objects:
            id_name = f"id_{o}"
            identity_map[o] = id_name
            morphisms.append(MorphismTriple(source=o, target=o, name=id_name))
        return cls(
            label=label,
            objects=list(objects),
            morphisms=morphisms,
            identity_map=identity_map,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        for i, o in enumerate(self.objects):
            if not o:
                raise ValueError(f"empty object tag at index {i}")
        for i, m in enumerate(self.morphisms):
            if not m.source or not m.target or not m.name:
                raise ValueError(f"empty morphism field at index {i}")
        for obj, id_name in self.identity_map.items():
            if not obj or not id_name:
                raise ValueError("empty identity_map key or value")



