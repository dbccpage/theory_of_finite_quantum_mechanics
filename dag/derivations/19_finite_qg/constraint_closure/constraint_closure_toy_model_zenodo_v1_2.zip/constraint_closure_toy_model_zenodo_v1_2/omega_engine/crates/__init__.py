"""Universe Anomalonica Omega Engine Canonical Subsystems and Extended Mathematical Theories.

Exports the 33 core contract-conforming subsystems alongside CODA's extended mathematical theories.
Dynamic lazy-loading via __getattr__ isolates individual subsystems, avoiding circular import deadlocks.
"""

from importlib import import_module
from types import ModuleType

__all__ = [
    # 33 Core Canonical Subsystems
    "boundary",
    "carrier",
    "category_theory",
    "coboundary",
    "contract_core",
    "discrete_deformation_algebra",
    "engine",
    "evaluator",
    "functional",
    "homology_theory",
    "homotopy_type_theory",
    "invariant",
    "kernel",
    "lift",
    "linear_algebra_theory",
    "majorana",
    "measurement",
    "observable",
    "observer",
    "obstruction_theory",
    "operator",
    "pipeline",
    "prime",
    "projection_obstruction",
    "prompt_civilization",
    "quantum_physics",
    "replay",
    "residuals",
    "runtime",
    "solver",
    "state",
    "type",
    # CODA Extended Mathematical Theories & Facades
    "abstract_algebra_theory",
    "adapter",
    "applications",
    "certificate",
    "conformance",
    "deformation_theory",
    "diagnostic",
    "dual_home",
    "evaluated_path_kernels_local_green_global_red",
    "holonomy_theory",
    "ontology_pd",
    "omega_mvp",
    "packet",
    "parity",
    "q",
    "search",
    "sheaf_theory",
    "terminalizers",
    "topology_theory",
    "topos_theory",
    "trace",
    "witness",
    "finite_qm",
    "library_ingest",
]

_LAZY_SUBMODULES = set(__all__)


def __getattr__(name: str) -> ModuleType:
    """Load one public subsystem on first access.

    A package import is an architectural boundary, not an instruction to boot
    every solver and optional numerical dependency. Keeping the public names
    lazy lets focused DDA, homology, and packet workflows run independently.
    """
    if name not in _LAZY_SUBMODULES:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = import_module(f"{__name__}.{name}")
    globals()[name] = module
    return module


def __dir__() -> list[str]:
    return sorted(set(globals()) | _LAZY_SUBMODULES)
