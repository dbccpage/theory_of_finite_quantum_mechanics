"""Universe Anomalonica Deformation Theory Package.

DGLA, Maurer–Cartan, gauge equivalence, obstruction/extension (exact path).
AuthorityEffect: None.
"""

from omega_engine.crates.deformation_theory.dgla import DGLA
from omega_engine.crates.deformation_theory.maurer_cartan import (
    MaurerCartanElement,
    DeformationComplex,
    ObstructionClass,
)

__all__ = [
    "DGLA",
    "MaurerCartanElement",
    "DeformationComplex",
    "ObstructionClass",
]
