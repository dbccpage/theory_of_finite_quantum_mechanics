"""Package. AuthorityEffect: None."""
