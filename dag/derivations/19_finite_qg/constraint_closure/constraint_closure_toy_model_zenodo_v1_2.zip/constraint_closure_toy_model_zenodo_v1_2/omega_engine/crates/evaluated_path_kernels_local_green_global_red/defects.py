import math
from typing import Any
from .core import ComposedPath
from omega_engine.crates.type.refusal import Result
from omega_engine.crates.category_theory.transport import DiagonalTransportRefusal
from omega_engine.crates.sheaf_theory.cech_gate import cech_gate, CechConsistent



def evaluator_gluing_defect(path: ComposedPath) -> int:
    if not isinstance(path, ComposedPath):
        raise ValueError("path must be a ComposedPath")
    local_product = int(path.first.eval_pass) * int(path.second.eval_pass)
    return int(path.global_eval_pass) - local_product


def action_gluing_defect(path: ComposedPath) -> float | None:
    if not isinstance(path, ComposedPath):
        raise ValueError("path must be a ComposedPath")
    if path.composed_cost is None:
        return None
    return path.composed_cost - path.first.cost - path.second.cost


def cost_gluing_defect(path: ComposedPath) -> float:
    """Compute the EPK cost defect Δ_C = C_g - C_1 - C_2.

    If composed_cost is None, it defaults to G2 action additivity (defect = 0.0).
    """
    if not isinstance(path, ComposedPath):
        raise ValueError("path must be a ComposedPath")
    c1 = path.first.cost
    c2 = path.second.cost
    c_global = path.composed_cost if path.composed_cost is not None else (c1 + c2)
    return float(c_global - c1 - c2)


def proposal_gluing_defect(path: ComposedPath, eps: float = 1e-9) -> float:
    """Compute the log-space proposal defect Δ_P = -log P(g) + log P(1) + log P(2).

    Defaults to G4 boundary sufficiency (defect = 0.0) if global probability is not specified.
    """
    if not isinstance(path, ComposedPath):
        raise ValueError("path must be a ComposedPath")
    if isinstance(eps, bool) or not isinstance(eps, (int, float)) or eps <= 0.0:
        raise ValueError("eps must be a positive float")

    p1 = max(
        eps,
        float(
            getattr(
                path.first,
                "prob",
                path.first.metadata.get(
                    "prob", path.first.metadata.get("proposal_prob", 1.0)
                ),
            )
        ),
    )
    p2 = max(
        eps,
        float(
            getattr(
                path.second,
                "prob",
                path.second.metadata.get(
                    "prob", path.second.metadata.get("proposal_prob", 1.0)
                ),
            )
        ),
    )

    p_global_raw = getattr(
        path,
        "prob",
        path.metadata.get("prob", path.metadata.get("proposal_prob", None)),
    )
    if p_global_raw is None:
        p_global = p1 * p2
    else:
        p_global = max(eps, float(p_global_raw))

    return float(-math.log(p_global) + math.log(p1) + math.log(p2))


def residual_risk_gluing_defect(path: ComposedPath) -> float:
    """Compute the EPK residual risk defect Δ_R = R_g - R_1 - R_2.

    Defaults to G2 action additivity (defect = 0.0) if global risk is not specified.
    """
    if not isinstance(path, ComposedPath):
        raise ValueError("path must be a ComposedPath")

    r1 = float(
        getattr(
            path.first,
            "risk",
            path.first.metadata.get(
                "risk", path.first.metadata.get("residual_risk", 0.0)
            ),
        )
    )
    r2 = float(
        getattr(
            path.second,
            "risk",
            path.second.metadata.get(
                "risk", path.second.metadata.get("residual_risk", 0.0)
            ),
        )
    )

    r_global_raw = getattr(
        path,
        "risk",
        path.metadata.get("risk", path.metadata.get("residual_risk", None)),
    )
    if r_global_raw is None:
        r_global = r1 + r2
    else:
        r_global = float(r_global_raw)

    return float(r_global - r1 - r2)


def total_gluing_defect(
    path: ComposedPath, lambda_: float = 1.0, mu_: float = 1.0
) -> float:
    """Compute the EPK total defect Δ_total = Δ_P + λ Δ_C + μ Δ_R."""
    if not isinstance(path, ComposedPath):
        raise ValueError("path must be a ComposedPath")
    if (
        isinstance(lambda_, bool)
        or not isinstance(lambda_, (int, float))
        or not math.isfinite(lambda_)
    ):
        raise ValueError("lambda_ must be finite numeric")
    if (
        isinstance(mu_, bool)
        or not isinstance(mu_, (int, float))
        or not math.isfinite(mu_)
    ):
        raise ValueError("mu_ must be finite numeric")

    dp = proposal_gluing_defect(path)
    dc = cost_gluing_defect(path)
    dr = residual_risk_gluing_defect(path)
    return float(dp + lambda_ * dc + mu_ * dr)


def verify_epk_transport_axis(path: ComposedPath) -> Result[bool]:
    """Verify that vertical and horizontal transport axes are separated.

    Returns DiagonalTransportRefusal if a mixed-axis edge does not carry a
    replayable square certificate.
    """
    if not isinstance(path, ComposedPath):
        raise ValueError("path must be a ComposedPath")

    for seg in (path.first, path.second):
        axis = seg.metadata.get("axis")
        if axis == "mixed":
            has_square = "chi_square" in seg.metadata or "factorization" in seg.metadata
            if not has_square:
                return DiagonalTransportRefusal(
                    f"Segment {seg.id} carries an undecomposed mixed vertical+horizontal "
                    "axis with no axis-separated factorization or square certificate"
                )
    return True


def attach_cech_diagnostic(
    path: ComposedPath,
    sections: Any,
    delta0: Any,
    delta1: Any,
    z: Any,
) -> Result[CechConsistent]:
    """Attach the replayed Cech contextual-obstruction gate diagnostic."""
    if not isinstance(path, ComposedPath):
        raise ValueError("path must be a ComposedPath")
    return cech_gate(sections, delta0, delta1, z)


from dataclasses import dataclass
from typing import Any


class _RustSurfaceMeta(type):
    def __getattr__(cls, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {cls.__name__}.{name} is not ported"
            )

        return unavailable


class _RustSurfaceObject(metaclass=_RustSurfaceMeta):
    def __getattr__(self, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {type(self).__name__}.{name} is not ported"
            )

        return unavailable


@dataclass(init=False)
class GluingDefect(_RustSurfaceObject):
    """Structural mirror of Rust ``GluingDefect``."""

    delta_eval: Any = None
    local_product: Any = None
    global_pass: Any = None

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        names = ("delta_eval", "local_product", "global_pass")
        if len(args) > len(names):
            raise TypeError("GluingDefect received too many positional arguments")
        for fld, value in zip(names, args):
            setattr(self, fld, value)
        for fld in names[len(args) :]:
            setattr(self, fld, kwargs.pop(fld, None))
        for fld, value in kwargs.items():
            setattr(self, fld, value)






