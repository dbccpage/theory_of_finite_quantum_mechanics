"""product_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class ProductCategoryShell:
    """Best-effort product category shell C × D."""

    label: str
    left_factor_label: str = ""
    right_factor_label: str = ""
    object_pairs: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "ProductCategoryShell":
        return cls(label=label)

    @classmethod
    def of(
        cls, label: str, left_factor_label: str, right_factor_label: str
    ) -> "ProductCategoryShell":
        return cls(
            label=label,
            left_factor_label=left_factor_label,
            right_factor_label=right_factor_label,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.left_factor_label:
            raise ValueError("empty left_factor_label")
        if not self.right_factor_label:
            raise ValueError("empty right_factor_label")
        for i, p in enumerate(self.object_pairs):
            if not p:
                raise ValueError(f"empty object_pair tag at index {i}")



