from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from .finite_carrier import FiniteVectorSpace, MatrixMap
from omega_engine.crates.type.refusal import Refusal


@dataclass
class CochainComplex:
    C0: FiniteVectorSpace
    C1: FiniteVectorSpace
    C2: FiniteVectorSpace
    d0: MatrixMap
    d1: MatrixMap

    def check_d1_d0_zero(self) -> Any:
        for elem in self.C0.basis.elements:
            v0 = self.C0.make_vector({elem: 1.0})
            v1 = self.d0(v0)
            v2 = self.d1(v1)
            for val in v2.coeffs.values():
                if abs(val) > 1e-9:
                    return Refusal(reason="Coboundary law violation: d1 . d0 != 0")
        return True


