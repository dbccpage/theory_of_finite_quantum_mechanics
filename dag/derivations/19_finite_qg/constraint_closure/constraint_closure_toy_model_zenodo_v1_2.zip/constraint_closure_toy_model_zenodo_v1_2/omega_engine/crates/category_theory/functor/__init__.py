"""Functor shells for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Mirrors ``omega_engine/crates/omega_category_theory/src/functor/``.
"""

from ..functor_runtime import (
    Functor,
    FunctorError,
    FunctorDomainError,
    FunctorTypingError,
    FunctorCompositionError,
    check_composition_preservation,
    check_identity_preservation,
)
from .functor import Functor as FunctorShell
from .faithful_functor import FaithfulFunctor
from .full_functor import FullFunctor
from .essentially_surjective import EssentiallySurjective
from .equivalence_of_categories import EquivalenceOfCategories
from .isomorphism_of_categories import IsomorphismOfCategories
from .natural_transformation import NaturalTransformation
from .nat_trans_components import NatTransComponents
from .vertical_composition import VerticalComposition
from .horizontal_composition import HorizontalComposition
from .functor_category import FunctorCategory
from .yoneda import Yoneda
from .representable_functor import RepresentableFunctor
from .hom_functor import HomFunctor
from .presheaf import Presheaf
from .copresheaf import Copresheaf
from .forgetful_functor import ForgetfulFunctor
from .free_functor import FreeFunctor
from .identity_functor import IdentityFunctor
from .constant_functor import ConstantFunctor
from .diagonal_functor import DiagonalFunctor

__all__ = [
    "Functor",
    "FunctorError",
    "FunctorDomainError",
    "FunctorTypingError",
    "FunctorCompositionError",
    "FaithfulFunctor",
    "FullFunctor",
    "EssentiallySurjective",
    "EquivalenceOfCategories",
    "IsomorphismOfCategories",
    "NaturalTransformation",
    "NatTransComponents",
    "VerticalComposition",
    "HorizontalComposition",
    "FunctorCategory",
    "Yoneda",
    "RepresentableFunctor",
    "HomFunctor",
    "Presheaf",
    "Copresheaf",
    "ForgetfulFunctor",
    "FreeFunctor",
    "IdentityFunctor",
    "ConstantFunctor",
    "DiagonalFunctor",
]

