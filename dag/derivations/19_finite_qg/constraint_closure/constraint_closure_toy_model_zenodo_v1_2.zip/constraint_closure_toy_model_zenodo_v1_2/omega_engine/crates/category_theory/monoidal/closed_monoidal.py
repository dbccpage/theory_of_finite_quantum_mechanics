"""closed_monoidal shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class ClosedMonoidal:
    """Best-effort closed monoidal shell (internal-hom ref)."""

    label: str
    monoidal_ref: str = ""
    internal_hom_ref: str = ""
    evaluation_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "ClosedMonoidal":
        return cls(label=label)

    @classmethod
    def with_internal_hom(
        cls, label: str, monoidal_ref: str, internal_hom_ref: str
    ) -> "ClosedMonoidal":
        return cls(
            label=label, monoidal_ref=monoidal_ref, internal_hom_ref=internal_hom_ref
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.monoidal_ref:
            raise ValueError("empty monoidal_ref")
        if not self.internal_hom_ref:
            raise ValueError("empty internal_hom_ref")



