"""product shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Product:
    """Best-effort shell for a (binary or multi-factor) product."""

    label: str
    product_object: str = ""
    factors: List[str] = field(default_factory=list)
    projections: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Product":
        return cls(label=label)

    @classmethod
    def binary(
        cls,
        label: str,
        product_object: str,
        left: str,
        right: str,
        projection_left: str,
        projection_right: str,
    ) -> "Product":
        return cls(
            label=label,
            product_object=product_object,
            factors=[left, right],
            projections=[projection_left, projection_right],
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.product_object:
            raise ValueError("empty product_object")
        if not self.factors:
            raise ValueError("empty factors")
        for i, f in enumerate(self.factors):
            if not f:
                raise ValueError(f"empty factor at index {i}")
        for i, p in enumerate(self.projections):
            if not p:
                raise ValueError(f"empty projection at index {i}")
        if self.projections and len(self.projections) != len(self.factors):
            raise ValueError("projections length must match factors length")



