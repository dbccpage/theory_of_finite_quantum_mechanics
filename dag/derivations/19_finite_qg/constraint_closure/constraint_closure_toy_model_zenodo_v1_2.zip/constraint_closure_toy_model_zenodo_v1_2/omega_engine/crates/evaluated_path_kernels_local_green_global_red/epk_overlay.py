"""EPK 6-role CODA_LA overlay + LGGR organizational gluing.

Key Responsibilities:
  - 6 CODA_LA role overlay (OE-021): FOC, FDA, MUR, OR, CS, A
  - G1-G4 composition gates
  - Proposal-weighted kernel Z_theta
  - Integration readiness (all 6 role gates)

AuthorityEffect: None.
"""

import math
from dataclasses import field
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Tuple


# --- EPK Trace (OE-019) ---

@dataclass
class ET:
    """Evaluated path kernel trace.

    e1: local stage 1 pass {0,1}
    e2: local stage 2 pass {0,1}
    eg: global pass {0,1}
    """
    e1: int
    e2: int
    eg: int

    @property
    def lp(self) -> int:
        """Local product E1*E2."""
        return self.e1 * self.e2

    @property
    def de(self) -> int:
        """Delta_E = E_g - E1*E2."""
        return self.eg - self.lp


# --- EPK Metrics (OE-019 §1.6) ---

def em(traces: List[ET]) -> Dict[str, float]:
    """Compute EPK metrics from trace batch.

    Returns: LPR, GPR, NGD, PGD, ZDR, EGD, dE (mean delta_E).
    """
    if not traces:
        return {"LPR": 0.0, "GPR": 0.0, "NGD": 0.0, "PGD": 0.0,
                "ZDR": 0.0, "EGD": 0.0, "dE": 0.0}
    n = len(traces)
    lpc = sum(1 for t in traces if t.lp == 1)
    gpc = sum(1 for t in traces if t.eg == 1)
    ngd = sum(1 for t in traces if t.lp == 1 and t.eg == 0)
    pgd = sum(1 for t in traces if t.lp == 0 and t.eg == 1)
    zdr = sum(1 for t in traces if t.lp == t.eg)
    return {
        "LPR": lpc / n,
        "GPR": gpc / n,
        "NGD": ngd / n,
        "PGD": pgd / n,
        "ZDR": zdr / n,
        "EGD": (ngd + pgd) / n,
        "dE": (gpc - lpc) / n,
    }


# --- Proposal Trace (OE-021 §2) ---

@dataclass
class PT:
    """Proposal trace for weighted kernel.

    eg: E(gamma) {0,1}
    pm: P_theta(gamma|S_a) >= 0
    c: C[gamma] >= 0 (cost)
    r: R[gamma] >= 0 (residual risk)
    """
    eg: int
    pm: float
    c: float
    r: float


def zk(traces: List[PT], lm: float = 1.0, mu: float = 1.0) -> float:
    """Z_theta(S_b|S_a) = sum E*P*exp(-lm*C - mu*R)."""
    return sum(t.eg * t.pm * math.exp(-lm * t.c - mu * t.r) for t in traces)


# --- G1-G4 composition gates (OE-019/020) ---

@dataclass
class G4:
    """G1-G4 composition gate declarations.

    g1: boundary declared
    g2: cost additive
    g3: evaluator factorizes
    g4: proposal factorizes (conditional independence)
    """
    g1: bool = False
    g2: bool = False
    g3: bool = False
    g4: bool = False

    @property
    def ok(self) -> bool:
        return self.g1 and self.g2 and self.g3 and self.g4


# --- Organizational boundary owner (OE-020) ---

@dataclass
class BO:
    """Boundary owner for organizational gluing.

    au: has authority
    ac: has accountability
    """
    au: bool
    ac: bool

    @property
    def ok(self) -> bool:
        return self.au and self.ac


# --- Organizational evaluator cut (OE-020) ---

@dataclass
class OC:
    """Organizational evaluator cut.

    le: local evaluator passes [E1, E2, ...]
    ge: global evaluator pass
    bo: boundary owner (optional)
    """
    le: List[int] = field(default_factory=list)
    ge: int = 0
    bo: Optional[BO] = None

    @property
    def lp(self) -> int:
        """Local product."""
        r = 1
        for e in self.le:
            r *= e
        return r

    @property
    def gd(self) -> int:
        """Gluing defect = E_g - prod(E_i)."""
        return self.ge - self.lp


# --- 6 CODA_LA role gates (OE-021 §6-§11) ---

class R6(Enum):
    """6 CODA_LA roles."""
    FOC = auto()  # finite obstruction calculus
    FDA = auto()  # finite descent authority (evidence only)
    MUR = auto()  # certified transport (boundary loss)
    OR = auto()   # observer relative
    CS = auto()   # finite shadow
    A = auto()    # residual closure (non-authority feedback)


@dataclass
class RG:
    """Per-role gate status.

    foc: FOC comparison envelope declared
    fda: FDA authority separation confirmed
    mur: MUR transport certificate present
    or_: OR observer envelope declared
    cs: CS finite shadow confirmed
    a: A non-authority feedback firewall
    ic: implementation contract present
    """
    foc: bool = False
    fda: bool = False
    mur: bool = False
    or_: bool = False
    cs: bool = False
    a: bool = False
    ic: bool = False

    @property
    def ok(self) -> bool:
        """Integration readiness: all 7 gates."""
        return (self.foc and self.fda and self.mur
                and self.or_ and self.cs and self.a and self.ic)

    def missing(self) -> List[str]:
        """List missing gates."""
        mm = []
        for nm, v in [("FOC", self.foc), ("FDA", self.fda),
                       ("MUR", self.mur), ("OR", self.or_),
                       ("CS", self.cs), ("A", self.a), ("IC", self.ic)]:
            if not v:
                mm.append(nm)
        return mm


# --- FOC trichotomy (OE-021 §6) ---

class FC(Enum):
    """CODA-FOC diagnostic trichotomy."""
    EC = auto()   # ExactClass (phi1 < eps)
    CR = auto()   # ClosedResidual (gamma2 < eps, phi1 > eps)
    ACF = auto()  # ActiveClosureFailure (gamma2 > eps)
    RF = auto()   # Refused (undeclared carrier/degree/comparison)


def foc_classify(p1: float, g2: float, eps: float = 1e-6,
                 carrier_declared: bool = True) -> FC:
    """FOC trichotomy classification."""
    if not carrier_declared:
        return FC.RF
    if p1 < eps:
        return FC.EC
    if g2 < eps:
        return FC.CR
    return FC.ACF


# --- Defect ledger (OE-021 §3) ---

@dataclass
class DL:
    """Signed defect ledger (Delta_E, Delta_P, Delta_C, Delta_R).

    de: evaluator defect
    dp: proposal defect
    dc: cost defect
    dr: residual risk defect
    """
    de: float = 0.0
    dp: float = 0.0
    dc: float = 0.0
    dr: float = 0.0

    @property
    def dt(self) -> float:
        """Delta_total = de + dp + dc + dr."""
        return self.de + self.dp + self.dc + self.dr


# --- EPK overlay engine ---

class EO:
    """EPK 6-role overlay engine.

    Integrates:
      - EPK trace metrics (OE-019)
      - Organizational gluing (OE-020)
      - 6 CODA_LA role gates (OE-021)
      - G1-G4 composition gates
      - FOC trichotomy
      - Defect ledger
      - Proposal-weighted kernel
    """

    def __init__(self):
        self.rg = RG()
        self.g4 = G4()
        self.dl = DL()
        self.traces: List[ET] = []
        self.cuts: List[OC] = []

    def add_trace(self, e1: int, e2: int, eg: int) -> ET:
        """Record an evaluated path kernel trace."""
        t = ET(e1=e1, e2=e2, eg=eg)
        self.traces.append(t)
        self.dl.de = float(t.de)
        return t

    def add_cut(self, le: List[int], ge: int,
                bo: Optional[BO] = None) -> OC:
        """Record an organizational evaluator cut."""
        c = OC(le=le, ge=ge, bo=bo)
        self.cuts.append(c)
        return c

    def metrics(self) -> Dict[str, float]:
        """Compute EPK metrics from accumulated traces."""
        return em(self.traces)

    def kernel(self, proposals: List[PT],
               lm: float = 1.0, mu: float = 1.0) -> float:
        """Compute proposal-weighted EPK kernel Z_theta."""
        return zk(proposals, lm=lm, mu=mu)

    def classify(self, p1: float, g2: float,
                 carrier_declared: bool = True) -> FC:
        """FOC trichotomy classification."""
        return foc_classify(p1, g2, carrier_declared=carrier_declared)

    def set_gates(self, **kw: bool) -> None:
        """Set role gates by name (foc, fda, mur, or_, cs, a, ic)."""
        for k, v in kw.items():
            if hasattr(self.rg, k):
                setattr(self.rg, k, v)

    def set_g4(self, **kw: bool) -> None:
        """Set G1-G4 gates (g1, g2, g3, g4)."""
        for k, v in kw.items():
            if hasattr(self.g4, k):
                setattr(self.g4, k, v)

    @property
    def ready(self) -> bool:
        """Integration readiness: all 6 role gates + IC + G1-G4."""
        return self.rg.ok and self.g4.ok

    def status(self) -> Dict[str, Any]:
        """Full diagnostic status snapshot."""
        m = self.metrics()
        return {
            "n": len(self.traces),
            "m": m,
            "rg": self.rg.ok,
            "rg_miss": self.rg.missing(),
            "g4": self.g4.ok,
            "dl": {"de": self.dl.de, "dp": self.dl.dp,
                   "dc": self.dl.dc, "dr": self.dl.dr,
                   "dt": self.dl.dt},
            "cuts": len(self.cuts),
            "ready": self.ready,
            "ae": "None",
        }





