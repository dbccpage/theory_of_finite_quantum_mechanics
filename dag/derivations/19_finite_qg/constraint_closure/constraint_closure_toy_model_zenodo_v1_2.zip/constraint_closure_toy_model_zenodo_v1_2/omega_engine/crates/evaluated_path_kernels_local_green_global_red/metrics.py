import math
from dataclasses import field
from dataclasses import dataclass
from typing import Mapping, Sequence, Any
from types import MappingProxyType
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.core import ComposedPath
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.defects import (
    evaluator_gluing_defect,
    action_gluing_defect,
)


def _require_probability(value: float, name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a probability, not bool")
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite")
    if value < 0.0 or value > 1.0:
        raise ValueError(f"{name} must be in [0, 1]")
    return value


def _require_finite(value: float, name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be finite numeric, not bool")
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite")
    return value


def _require_optional_nonnegative(value: float | None, name: str) -> float | None:
    if value is None:
        return None
    value = _require_finite(value, name)
    if value < 0.0:
        raise ValueError(f"{name} must be non-negative")
    return value


def _freeze_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType(
            {key: _freeze_value(item) for key, item in value.items()}
        )
    if isinstance(value, list | tuple):
        return tuple(_freeze_value(item) for item in value)
    if isinstance(value, set | frozenset):
        return frozenset(_freeze_value(item) for item in value)
    return value


def _freeze_notes(notes: Mapping[str, Any]) -> Mapping[str, Any]:
    if not isinstance(notes, Mapping):
        raise ValueError("notes must be a mapping")
    return MappingProxyType({key: _freeze_value(value) for key, value in notes.items()})


@dataclass(frozen=True, slots=True)
class MetricReport:
    n: int
    lpr: float
    gpr: float
    avg_delta_eval: float
    ngd: float
    positive_defect_rate: float
    zero_defect_rate: float
    egd: float
    rke: float | None = None
    nrke: float | None = None
    avg_action_defect: float | None = None
    notes: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if isinstance(self.n, bool) or not isinstance(self.n, int):
            raise ValueError("n must be an integer")
        if self.n <= 0:
            raise ValueError("n must be positive")

        object.__setattr__(self, "lpr", _require_probability(self.lpr, "lpr"))
        object.__setattr__(self, "gpr", _require_probability(self.gpr, "gpr"))
        object.__setattr__(
            self,
            "avg_delta_eval",
            _require_finite(self.avg_delta_eval, "avg_delta_eval"),
        )
        object.__setattr__(self, "ngd", _require_probability(self.ngd, "ngd"))
        object.__setattr__(
            self,
            "positive_defect_rate",
            _require_probability(self.positive_defect_rate, "positive_defect_rate"),
        )
        object.__setattr__(
            self,
            "zero_defect_rate",
            _require_probability(self.zero_defect_rate, "zero_defect_rate"),
        )
        object.__setattr__(self, "egd", _require_probability(self.egd, "egd"))
        object.__setattr__(self, "rke", _require_optional_nonnegative(self.rke, "rke"))
        object.__setattr__(
            self, "nrke", _require_optional_nonnegative(self.nrke, "nrke")
        )
        if self.avg_action_defect is not None:
            object.__setattr__(
                self,
                "avg_action_defect",
                _require_finite(self.avg_action_defect, "avg_action_defect"),
            )
        object.__setattr__(self, "notes", _freeze_notes(self.notes))


def calculate_metrics(
    paths: Sequence[ComposedPath],
    rke: float | None = None,
    nrke: float | None = None,
    notes: Mapping[str, Any] | None = None,
) -> MetricReport:
    if not paths:
        raise ValueError("at least one composed path is required")
    if notes is None:
        notes = {}

    n = len(paths)
    lpr_sum = 0
    gpr_sum = 0
    delta_eval_sum = 0
    ngd_count = 0
    pgd_count = 0
    zdr_count = 0
    egd_count = 0

    action_defect_sum = 0.0
    action_defect_count = 0

    for path in paths:
        first_pass = path.first.eval_pass
        second_pass = path.second.eval_pass
        lpr_sum += 1 if (first_pass and second_pass) else 0

        gpr_sum += 1 if path.global_eval_pass else 0

        delta = evaluator_gluing_defect(path)
        if delta not in {-1, 0, 1}:
            raise ValueError(f"invalid evaluator gluing defect: {delta}")
        delta_eval_sum += delta

        if delta == -1:
            ngd_count += 1
        elif delta == 1:
            pgd_count += 1
        elif delta == 0:
            zdr_count += 1

        if delta != 0:
            egd_count += 1

        act_def = action_gluing_defect(path)
        if act_def is not None:
            act_def = _require_finite(act_def, "action_gluing_defect")
            action_defect_sum += act_def
            action_defect_count += 1

    lpr = lpr_sum / n
    gpr = gpr_sum / n
    avg_delta_eval = delta_eval_sum / n
    ngd = ngd_count / n
    positive_defect_rate = pgd_count / n
    zero_defect_rate = zdr_count / n
    egd = egd_count / n

    avg_action_defect = (
        action_defect_sum / action_defect_count if action_defect_count > 0 else None
    )

    report = MetricReport(
        n=n,
        lpr=lpr,
        gpr=gpr,
        avg_delta_eval=avg_delta_eval,
        ngd=ngd,
        positive_defect_rate=positive_defect_rate,
        zero_defect_rate=zero_defect_rate,
        egd=egd,
        rke=rke,
        nrke=nrke,
        avg_action_defect=avg_action_defect,
        notes=notes,
    )
    validate_metric_identity(report)
    return report


def validate_metric_identity(report: MetricReport, tol: float = 1e-9) -> None:
    tol = _require_finite(tol, "tol")
    if tol <= 0.0:
        raise ValueError("tol must be positive")

    lhs = report.gpr - report.lpr
    rhs = report.avg_delta_eval
    if abs(lhs - rhs) > tol:
        raise ValueError(f"Metric identity failed: GPR-LPR={lhs}, avg_delta={rhs}")

    partition_sum = report.ngd + report.positive_defect_rate + report.zero_defect_rate
    if abs(partition_sum - 1.0) > tol:
        raise ValueError(
            f"Defect rate partition unity failed: NGD+PGD+ZDR={partition_sum}"
        )

    if abs(report.egd - (report.ngd + report.positive_defect_rate)) > tol:
        raise ValueError(
            f"EGD consistency check failed: egd={report.egd}, NGD+PGD={report.ngd + report.positive_defect_rate}"
        )


from dataclasses import dataclass
from typing import Any


class _RustSurfaceMeta(type):
    def __getattr__(cls, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {cls.__name__}.{name} is not ported"
            )

        return unavailable


class _RustSurfaceObject(metaclass=_RustSurfaceMeta):
    def __getattr__(self, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {type(self).__name__}.{name} is not ported"
            )

        return unavailable


IDENTITY_TOL: Any = None


@dataclass(init=False)
class EpkMetrics(_RustSurfaceObject):
    """Structural mirror of Rust ``EpkMetrics``."""

    n: Any = None
    lpr: Any = None
    gpr: Any = None
    avg_delta_eval: Any = None
    ngd: Any = None
    positive_defect_rate: Any = None
    zero_defect_rate: Any = None
    egd: Any = None
    rke: Any = None
    nrke: Any = None
    avg_action_defect: Any = None
    notes: Any = None

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        names = (
            "n",
            "lpr",
            "gpr",
            "avg_delta_eval",
            "ngd",
            "positive_defect_rate",
            "zero_defect_rate",
            "egd",
            "rke",
            "nrke",
            "avg_action_defect",
            "notes",
        )
        if len(args) > len(names):
            raise TypeError("EpkMetrics received too many positional arguments")
        for fld, value in zip(names, args):
            setattr(self, fld, value)
        for fld in names[len(args) :]:
            setattr(self, fld, kwargs.pop(fld, None))
        for fld, value in kwargs.items():
            setattr(self, fld, value)







