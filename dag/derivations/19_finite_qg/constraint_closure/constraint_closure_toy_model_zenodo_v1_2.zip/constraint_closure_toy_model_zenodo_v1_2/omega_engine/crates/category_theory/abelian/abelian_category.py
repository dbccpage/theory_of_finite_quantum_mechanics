"""abelian_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Abelian category = additive + kernels + cokernels (flags only). Does not
verify that every mono is a kernel or that coimage ≅ image.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class AbelianCategory:
    """Best-effort shell for an abelian-category claim.

    Stores the classical checklist as bools: additive structure, kernels, and
    cokernels. Shape validation only — no law discharge.
    """

    label: str
    additive: bool = False
    has_kernels: bool = False
    has_cokernels: bool = False
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "AbelianCategory":
        return cls(label=label)

    @classmethod
    def with_flags(
        cls,
        label: str,
        additive: bool,
        has_kernels: bool,
        has_cokernels: bool,
    ) -> "AbelianCategory":
        return cls(
            label=label,
            additive=additive,
            has_kernels=has_kernels,
            has_cokernels=has_cokernels,
        )

    @classmethod
    def claimed_abelian(cls, label: str) -> "AbelianCategory":
        """Convenience: all three abelian checklist flags set true."""
        return cls.with_flags(label, True, True, True)

    def with_note(self, note: str) -> "AbelianCategory":
        self.notes.append(note)
        return self

    def checklist_complete(self) -> bool:
        """Whether the stored flags match the classical abelian checklist."""
        return self.additive and self.has_kernels and self.has_cokernels

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")



