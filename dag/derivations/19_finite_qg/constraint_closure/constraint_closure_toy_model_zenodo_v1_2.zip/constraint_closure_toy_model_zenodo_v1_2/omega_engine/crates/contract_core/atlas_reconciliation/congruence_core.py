"""Contextual Congruence Core Partition Refinement (PCC Theorem C1 / C2).

Computes the minimal adequate quotient state space X_hat = X / Core_C(ker o)
via Hopcroft-style partition refinement in O(|C| * |X| log |X|) time.
"""

from typing import Callable, List
from omega_engine.crates.type.quotient import CongruenceCoreQuotient


def compute_congruence_core_quotient(
    num_states: int,
    action_contexts: List[Callable[[int], int]],
    observation_map: List[int],
) -> CongruenceCoreQuotient:
    """Compute the minimal adequate quotient state space X_hat = X / Core_C(ker o)."""
    if num_states == 0:
        return CongruenceCoreQuotient(
            equivalence_classes=[],
            class_map=[],
            stabilization_index=0,
            num_classes=0,
        )

    # Initial partition by observation value
    obs_to_states = {}
    for state, obs in enumerate(observation_map):
        obs_to_states.setdefault(obs, []).append(state)

    partition = list(obs_to_states.values())
    worklist = [cls[:] for cls in partition]

    iteration = 0
    while worklist:
        iteration += 1
        splitter = worklist.pop(0)
        splitter_set = set(splitter)

        for context in action_contexts:
            # Find predecessors under context: {s | context(s) in splitter_set}
            predecessors = {s for s in range(num_states) if context(s) in splitter_set}
            if not predecessors:
                continue

            new_partition = []
            for cls in partition:
                in_pred = [s for s in cls if s in predecessors]
                out_pred = [s for s in cls if s not in predecessors]

                if in_pred and out_pred:
                    new_partition.append(in_pred)
                    new_partition.append(out_pred)

                    if cls in worklist:
                        worklist.remove(cls)
                        worklist.append(in_pred)
                        worklist.append(out_pred)
                    else:
                        if len(in_pred) <= len(out_pred):
                            worklist.append(in_pred)
                        else:
                            worklist.append(out_pred)
                else:
                    new_partition.append(cls)

            partition = new_partition

    # Build class_map
    class_map = [0] * num_states
    for class_idx, cls in enumerate(partition):
        for state in cls:
            class_map[state] = class_idx

    return CongruenceCoreQuotient(
        equivalence_classes=partition,
        class_map=class_map,
        stabilization_index=iteration,
        num_classes=len(partition),
    )


