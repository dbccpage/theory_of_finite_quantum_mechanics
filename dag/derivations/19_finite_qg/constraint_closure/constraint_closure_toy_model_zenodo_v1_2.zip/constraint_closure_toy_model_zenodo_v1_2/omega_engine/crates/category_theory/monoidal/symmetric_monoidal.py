"""symmetric_monoidal shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class SymmetricMonoidal:
    """Best-effort symmetric monoidal shell (braiding ref)."""

    label: str
    monoidal_ref: str = ""
    braiding_ref: str = ""
    symmetric_claimed: bool = True
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "SymmetricMonoidal":
        return cls(label=label)

    @classmethod
    def with_braiding(
        cls, label: str, monoidal_ref: str, braiding_ref: str
    ) -> "SymmetricMonoidal":
        return cls(label=label, monoidal_ref=monoidal_ref, braiding_ref=braiding_ref)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.monoidal_ref:
            raise ValueError("empty monoidal_ref")
        if not self.braiding_ref:
            raise ValueError("empty braiding_ref")



