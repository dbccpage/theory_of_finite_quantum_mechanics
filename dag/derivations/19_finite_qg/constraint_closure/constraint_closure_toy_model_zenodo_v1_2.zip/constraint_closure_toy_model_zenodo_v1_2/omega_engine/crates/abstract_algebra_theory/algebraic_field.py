"""AlgebraicField: exact algebraic number field K = Q(alpha).

Conforms to urn:omega:math:algebraic_field:v1.0.0.
AuthorityEffect: None.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Optional, Tuple


CONTRACT_ID = "urn:omega:math:algebraic_field:v1.0.0"


@dataclass(frozen=True)
class AlgebraicField:
    """An algebraic number field K = Q(alpha).

    Represented via primitive generators, basis, and multiplication table
    supporting exact sign evaluation.

    Attributes:
        generators: Primitive generators alpha_i.
        degree: Extension degree [K : Q], must be positive.
        mult_table: Structure constants c_{ijk} such that
            e_i * e_j = sum_k c_{ijk} e_k.  Shape: degree x degree x degree.
        basis_labels: Human-readable labels for basis elements
            (e.g. ("1", "alpha", "alpha^2")).
    """

    generators: Tuple[complex, ...]
    degree: int
    mult_table: Tuple[Tuple[Tuple[complex, ...], ...], ...]
    basis_labels: Tuple[str, ...] = ()

    def validate(self) -> list[str]:
        """Return list of validation errors (empty = valid)."""
        errors: list[str] = []

        if self.degree <= 0:
            errors.append(f"degree must be positive, got {self.degree}")
            return errors

        if not self.generators:
            errors.append("generators must be non-empty")

        d = self.degree
        if len(self.mult_table) != d:
            errors.append(
                f"mult_table first dimension {len(self.mult_table)} != degree {d}"
            )
        else:
            for i, row in enumerate(self.mult_table):
                if len(row) != d:
                    errors.append(
                        f"mult_table[{i}] has {len(row)} entries, expected {d}"
                    )
                else:
                    for j, col in enumerate(row):
                        if len(col) != d:
                            errors.append(
                                f"mult_table[{i}][{j}] has {len(col)} entries, "
                                f"expected {d}"
                            )

        if self.basis_labels and len(self.basis_labels) != d:
            errors.append(
                f"basis_labels length {len(self.basis_labels)} != degree {d}"
            )

        return errors

    def multiply(
        self,
        a: Tuple[complex, ...],
        b: Tuple[complex, ...],
    ) -> Tuple[complex, ...]:
        """Multiply two elements expressed in the basis.

        a = sum_i a_i e_i,  b = sum_j b_j e_j
        a*b = sum_k (sum_{i,j} a_i b_j c_{ijk}) e_k
        """
        d = self.degree
        result = [0.0 + 0j] * d
        for i in range(d):
            for j in range(d):
                coeff = a[i] * b[j]
                if coeff == 0:
                    continue
                for k in range(d):
                    result[k] += coeff * self.mult_table[i][j][k]
        return tuple(result)

    def sign(self, element: Tuple[complex, ...]) -> int:
        """Exact sign determination for a real element.

        Returns +1, -1, or 0. For non-real elements, uses the real part.
        """
        val = sum(c.real for c in element)
        if val > 0:
            return 1
        if val < 0:
            return -1
        return 0


def make_rational_field() -> AlgebraicField:
    """Construct Q as a degree-1 algebraic field."""
    return AlgebraicField(
        generators=(1.0 + 0j,),
        degree=1,
        mult_table=(((1.0 + 0j,),),),
        basis_labels=("1",),
    )


def make_quadratic_field(d: int) -> AlgebraicField:
    """Construct Q(sqrt(d)) as a degree-2 algebraic field.

    Basis: {1, sqrt(d)}.
    Multiplication: sqrt(d) * sqrt(d) = d.
    """
    sqrt_d = complex(d) ** 0.5
    mt: Tuple[Tuple[Tuple[complex, ...], ...], ...] = (
        (
            (1.0 + 0j, 0.0 + 0j),
            (0.0 + 0j, 1.0 + 0j),
        ),
        (
            (0.0 + 0j, 1.0 + 0j),
            (complex(d), 0.0 + 0j),
        ),
    )
    return AlgebraicField(
        generators=(sqrt_d,),
        degree=2,
        mult_table=mt,
        basis_labels=("1", f"sqrt({d})"),
    )
