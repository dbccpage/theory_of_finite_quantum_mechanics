"""horizontal_composition shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class HorizontalComposition:
    """Best-effort shell for a horizontal composition claim on nat-trans refs."""

    label: str
    left_nat_trans_ref: str = ""
    right_nat_trans_ref: str = ""
    result_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "HorizontalComposition":
        return cls(label=label)

    @classmethod
    def of(
        cls, label: str, left_nat_trans_ref: str, right_nat_trans_ref: str
    ) -> "HorizontalComposition":
        return cls(
            label=label,
            left_nat_trans_ref=left_nat_trans_ref,
            right_nat_trans_ref=right_nat_trans_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.left_nat_trans_ref:
            raise ValueError("empty left_nat_trans_ref")
        if not self.right_nat_trans_ref:
            raise ValueError("empty right_nat_trans_ref")



