"""coslice_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class CosliceCategoryShell:
    """Best-effort coslice category shell under nadir."""

    label: str
    base_label: str = ""
    nadir: str = ""
    objects: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "CosliceCategoryShell":
        return cls(label=label)

    @classmethod
    def under(cls, label: str, base_label: str, nadir: str) -> "CosliceCategoryShell":
        return cls(label=label, base_label=base_label, nadir=nadir)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.base_label:
            raise ValueError("empty base_label")
        if not self.nadir:
            raise ValueError("empty nadir")
        for i, o in enumerate(self.objects):
            if not o:
                raise ValueError(f"empty object tag at index {i}")



