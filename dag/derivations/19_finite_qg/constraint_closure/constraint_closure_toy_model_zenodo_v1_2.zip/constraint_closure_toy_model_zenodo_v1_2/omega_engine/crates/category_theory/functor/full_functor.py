"""full_functor shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class FullFunctor:
    """Best-effort shell for a fullness claim on a functor reference."""

    label: str
    functor_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "FullFunctor":
        return cls(label=label)

    @classmethod
    def on_functor(cls, label: str, functor_ref: str) -> "FullFunctor":
        return cls(label=label, functor_ref=functor_ref)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.functor_ref:
            raise ValueError("empty functor_ref")



