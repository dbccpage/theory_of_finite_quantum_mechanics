V1_KNOWN_TERMINALS = {"ExactRepair", "StabilizedSurvivor", "OpenObstruction"}

V1_KNOWN_REFUSALS = {
    "Invalid",
    "Incomparable",
    "TriRefused(NumericUndecidable)",
    "NumericUndecidable",
    "UnknownTerminal",
    "UnknownRefusal",
}


def is_known_terminal(name: str) -> bool:
    return name in V1_KNOWN_TERMINALS


def is_known_refusal(name: str) -> bool:
    return name in V1_KNOWN_REFUSALS
