"""isomorphism_of_categories shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class IsomorphismOfCategories:
    """Best-effort shell for an isomorphism-of-categories claim."""

    label: str
    functor_ref: str = ""
    inverse_functor_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "IsomorphismOfCategories":
        return cls(label=label)

    @classmethod
    def between(
        cls, label: str, functor_ref: str, inverse_functor_ref: str
    ) -> "IsomorphismOfCategories":
        return cls(
            label=label,
            functor_ref=functor_ref,
            inverse_functor_ref=inverse_functor_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.functor_ref:
            raise ValueError("empty functor_ref")
        if not self.inverse_functor_ref:
            raise ValueError("empty inverse_functor_ref")



