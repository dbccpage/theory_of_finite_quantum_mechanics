"""exact_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Exact category shape: admissible short exact sequences. Optional bound on
tracked exact-sequence length is a diagnostic note only.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class ExactCategory:
    """Best-effort shell for an exact-category claim."""

    label: str
    max_exact_sequences: Optional[int] = None
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "ExactCategory":
        return cls(label=label)

    @classmethod
    def with_max_exact_sequences(
        cls, label: str, max_exact_sequences: int
    ) -> "ExactCategory":
        return cls(label=label, max_exact_sequences=max_exact_sequences)

    def with_note(self, note: str) -> "ExactCategory":
        self.notes.append(note)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if self.max_exact_sequences is not None and self.max_exact_sequences == 0:
            raise ValueError("max_exact_sequences must be > 0 when set")



