"""coend shell for omega_category_theory (hierarchical; legacy flat coend.py remains).

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Coend:
    """Best-effort shell for a coend ∫^c F(c,c) of a bifunctor."""

    label: str
    bifunctor_ref: str = ""
    indexing_category_ref: str = ""
    coend_object: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Coend":
        return cls(label=label)

    @classmethod
    def of_bifunctor(
        cls,
        label: str,
        bifunctor_ref: str,
        indexing_category_ref: str,
        coend_object: str,
    ) -> "Coend":
        return cls(
            label=label,
            bifunctor_ref=bifunctor_ref,
            indexing_category_ref=indexing_category_ref,
            coend_object=coend_object,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.bifunctor_ref:
            raise ValueError("empty bifunctor_ref")
        if not self.indexing_category_ref:
            raise ValueError("empty indexing_category_ref")
        if not self.coend_object:
            raise ValueError("empty coend_object")



