"""symmetric_monoidal_functor shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class SymmetricMonoidalFunctor:
    """Best-effort symmetric monoidal functor shell."""

    label: str
    domain_symmetric: str = ""
    codomain_symmetric: str = ""
    monoidal_functor_ref: str = ""
    braiding_preservation_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "SymmetricMonoidalFunctor":
        return cls(label=label)

    @classmethod
    def between(
        cls,
        label: str,
        domain_symmetric: str,
        codomain_symmetric: str,
        monoidal_functor_ref: str,
    ) -> "SymmetricMonoidalFunctor":
        return cls(
            label=label,
            domain_symmetric=domain_symmetric,
            codomain_symmetric=codomain_symmetric,
            monoidal_functor_ref=monoidal_functor_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.domain_symmetric:
            raise ValueError("empty domain_symmetric")
        if not self.codomain_symmetric:
            raise ValueError("empty codomain_symmetric")
        if not self.monoidal_functor_ref:
            raise ValueError("empty monoidal_functor_ref")



