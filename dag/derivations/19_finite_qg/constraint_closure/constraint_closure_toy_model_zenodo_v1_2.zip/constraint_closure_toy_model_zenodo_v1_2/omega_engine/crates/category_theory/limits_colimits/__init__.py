"""Limits / colimits shells for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Mirrors ``omega_engine/crates/omega_category_theory/src/limits_colimits/``.
Legacy flat modules ``limits.py``, ``colimits.py``, ``coend.py`` remain.
"""

from .cone import Cone, Cocone, ConeLeg
from .limit import Limit
from .colimit import Colimit
from .terminal_object import TerminalObject
from .initial_object import InitialObject
from .product import Product
from .coproduct import Coproduct
from .equalizer import Equalizer
from .coequalizer import Coequalizer
from .pullback import Pullback
from .pushout import Pushout
from .kernel_pair import KernelPair
from .cokernel_pair import CokernelPair
from .end import End
from .coend import Coend
from .kan_extension import KanExtension, KanExtensionKind
from .pointwise_kan_extension import PointwiseKanExtension
from .density_comonad import DensityComonad

__all__ = [
    "Cone",
    "Cocone",
    "ConeLeg",
    "Limit",
    "Colimit",
    "TerminalObject",
    "InitialObject",
    "Product",
    "Coproduct",
    "Equalizer",
    "Coequalizer",
    "Pullback",
    "Pushout",
    "KernelPair",
    "CokernelPair",
    "End",
    "Coend",
    "KanExtension",
    "KanExtensionKind",
    "PointwiseKanExtension",
    "DensityComonad",
]

