"""Append-only research ledger kernel owned above the research engine."""

from __future__ import annotations
from dataclasses import dataclass
import json
from typing import Any, Iterable

from omega_engine.crates.contract_core.kinds import AuthorityEffect
try:
    from omega_research_engine.evaluation import (
        GateReceipt,
        GateVerdict,
        LedgerLane,
        ResearchEvaluation,
        ResearchGate,
        ResearchTerminal,
    )
except ImportError:
    class GateReceipt: pass  # type: ignore
    class GateVerdict: pass  # type: ignore
    class LedgerLane: pass  # type: ignore
    class ResearchEvaluation: pass  # type: ignore
    class ResearchGate: pass  # type: ignore
    class ResearchTerminal: pass  # type: ignore

try:
    from omega_engine.crates.omega_symbol_game.research_packets import (
        ResearchProposal,
        ResearchSeedPacket,
        digest_payload,
    )
except ImportError:
    class ResearchProposal: pass  # type: ignore
    class ResearchSeedPacket: pass  # type: ignore
    def digest_payload(payload: Any) -> str:  # type: ignore
        return ""



@dataclass(frozen=True)
class LedgerEntry:
    sequence: int
    proposal_id: str
    packet_sha256: str
    proposal_sha256: str
    evaluation_sha256: str
    terminal: ResearchTerminal
    lane: LedgerLane
    previous_entry_sha256: str | None
    entry_sha256: str
    authority_effect: AuthorityEffect = AuthorityEffect.None_

    def canonical_payload(self, include_hash: bool = True) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "sequence": self.sequence,
            "proposal_id": self.proposal_id,
            "packet_sha256": self.packet_sha256,
            "proposal_sha256": self.proposal_sha256,
            "evaluation_sha256": self.evaluation_sha256,
            "terminal": self.terminal.value,
            "lane": self.lane.value,
            "previous_entry_sha256": self.previous_entry_sha256,
            "authority_effect": self.authority_effect.value,
        }
        if include_hash:
            payload["entry_sha256"] = self.entry_sha256
        return payload


class ResearchLedger:
    """In-memory append-only hash chain with idempotence and conflict refusal."""

    def __init__(self, entries: Iterable[LedgerEntry] = ()) -> None:
        self._entries: list[LedgerEntry] = []
        self._by_proposal_id: dict[str, LedgerEntry] = {}
        for entry in entries:
            self._append_existing(entry)

    @property
    def entries(self) -> tuple[LedgerEntry, ...]:
        return tuple(self._entries)

    @property
    def head_sha256(self) -> str | None:
        return self._entries[-1].entry_sha256 if self._entries else None

    def _append_existing(self, entry: LedgerEntry) -> None:
        if entry.sequence != len(self._entries) + 1:
            raise ValueError("ledger sequence is not contiguous")
        if entry.previous_entry_sha256 != self.head_sha256:
            raise ValueError("ledger hash-chain predecessor mismatch")
        expected_hash = digest_payload(entry.canonical_payload(include_hash=False))
        if entry.entry_sha256 != expected_hash:
            raise ValueError("ledger entry hash mismatch")
        if entry.proposal_id in self._by_proposal_id:
            raise ValueError("ledger proposal IDs must be unique")
        self._entries.append(entry)
        self._by_proposal_id[entry.proposal_id] = entry

    def append(
        self,
        packet: ResearchSeedPacket,
        proposal: ResearchProposal,
        evaluation: ResearchEvaluation,
    ) -> LedgerEntry:
        if evaluation.packet_sha256 != packet.packet_sha256:
            raise ValueError("evaluation is not bound to the seed packet")
        if proposal.seed_sha256 != packet.packet_sha256:
            raise ValueError("proposal is not bound to the seed packet")
        if evaluation.proposal_sha256 != proposal.proposal_sha256:
            raise ValueError("evaluation is not bound to the proposal")
        existing = self._by_proposal_id.get(proposal.proposal_id)
        if existing is not None:
            if existing.proposal_sha256 == proposal.proposal_sha256:
                return existing
            raise ValueError("append-only ledger refuses proposal ID rebinding")

        payload = {
            "sequence": len(self._entries) + 1,
            "proposal_id": proposal.proposal_id,
            "packet_sha256": packet.packet_sha256,
            "proposal_sha256": proposal.proposal_sha256,
            "evaluation_sha256": evaluation.evaluation_sha256,
            "terminal": evaluation.terminal.value,
            "lane": evaluation.lane.value,
            "previous_entry_sha256": self.head_sha256,
            "authority_effect": AuthorityEffect.None_.value,
        }
        entry = LedgerEntry(
            sequence=payload["sequence"],
            proposal_id=proposal.proposal_id,
            packet_sha256=packet.packet_sha256,
            proposal_sha256=proposal.proposal_sha256,
            evaluation_sha256=evaluation.evaluation_sha256,
            terminal=evaluation.terminal,
            lane=evaluation.lane,
            previous_entry_sha256=self.head_sha256,
            entry_sha256=digest_payload(payload),
        )
        self._append_existing(entry)
        return entry

    def canonical_jsonl(self) -> bytes:
        if not self._entries:
            return b""
        lines = [
            json.dumps(
                entry.canonical_payload(),
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            )
            for entry in self._entries
        ]
        return ("\n".join(lines) + "\n").encode("utf-8")


__all__ = [
    "GateReceipt",
    "GateVerdict",
    "LedgerEntry",
    "LedgerLane",
    "ResearchEvaluation",
    "ResearchGate",
    "ResearchLedger",
    "ResearchTerminal",
]




