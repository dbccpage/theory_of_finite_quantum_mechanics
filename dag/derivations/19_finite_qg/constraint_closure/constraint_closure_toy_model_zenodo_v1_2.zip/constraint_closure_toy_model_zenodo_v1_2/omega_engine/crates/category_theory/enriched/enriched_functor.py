"""enriched_functor shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class EnrichedFunctor:
    """Best-effort V-enriched functor shell."""

    label: str
    domain_enriched: str = ""
    codomain_enriched: str = ""
    base_monoidal_v: str = ""
    object_map_ref: str = ""
    hom_map_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "EnrichedFunctor":
        return cls(label=label)

    @classmethod
    def between(
        cls,
        label: str,
        domain_enriched: str,
        codomain_enriched: str,
        base_monoidal_v: str,
    ) -> "EnrichedFunctor":
        return cls(
            label=label,
            domain_enriched=domain_enriched,
            codomain_enriched=codomain_enriched,
            base_monoidal_v=base_monoidal_v,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.domain_enriched:
            raise ValueError("empty domain_enriched")
        if not self.codomain_enriched:
            raise ValueError("empty codomain_enriched")
        if not self.base_monoidal_v:
            raise ValueError("empty base_monoidal_v")



