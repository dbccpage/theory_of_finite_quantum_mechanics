"""Omega Layer Infrastructure implementation.

AuthorityEffect: None.
"""

from typing import Any, Dict


class InMemoryContractRepository:
    """In-memory contract repository."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self._contracts: Dict[str, Any] = {}

    def get(self, key: str) -> Any:
        return self._contracts.get(key)

    def save(self, key: str, value: Any) -> None:
        self._contracts[key] = value
