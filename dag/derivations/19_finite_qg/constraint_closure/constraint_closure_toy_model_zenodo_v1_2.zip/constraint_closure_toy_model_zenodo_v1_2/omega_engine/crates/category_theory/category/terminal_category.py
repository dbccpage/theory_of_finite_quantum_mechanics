"""terminal_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class TerminalCategoryShell:
    """Best-effort terminal category shell (one object, one id)."""

    label: str
    object: str = "∗"
    identity: str = "id"
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "TerminalCategoryShell":
        return cls(label=label)

    @classmethod
    def with_object(cls, label: str, object: str) -> "TerminalCategoryShell":
        return cls(label=label, object=object, identity=f"id_{object}")

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.object:
            raise ValueError("empty object")
        if not self.identity:
            raise ValueError("empty identity")



