"""diagonal_functor shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class DiagonalFunctor:
    """Best-effort shell for a diagonal functor on a category reference."""

    label: str
    category_ref: str = ""
    arity: int = 2
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "DiagonalFunctor":
        return cls(label=label, arity=2)

    @classmethod
    def on_category(cls, label: str, category_ref: str) -> "DiagonalFunctor":
        return cls(label=label, category_ref=category_ref, arity=2)

    @classmethod
    def with_arity(cls, label: str, category_ref: str, arity: int) -> "DiagonalFunctor":
        return cls(label=label, category_ref=category_ref, arity=arity)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.category_ref:
            raise ValueError("empty category_ref")
        if self.arity < 2:
            raise ValueError(f"arity {self.arity} < 2")



