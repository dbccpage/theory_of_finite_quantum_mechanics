"""base_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class BaseCategory:
    """Best-effort enrichment-base (monoidal V) shell."""

    label: str
    monoidal_ref: str = ""
    closed_ref: str = ""
    completeness_notes: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "BaseCategory":
        return cls(label=label)

    @classmethod
    def from_monoidal(cls, label: str, monoidal_ref: str) -> "BaseCategory":
        return cls(label=label, monoidal_ref=monoidal_ref)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.monoidal_ref:
            raise ValueError("empty monoidal_ref")



