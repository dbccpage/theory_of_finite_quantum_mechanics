"""cohomology_in_monoidal shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class CohomologyInMonoidal:
    """Best-effort cohomology-in-monoidal shell (diagnostic only)."""

    label: str
    monoidal_ref: str = ""
    complex_ref: str = ""
    degree: str = ""
    cohomology_object: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "CohomologyInMonoidal":
        return cls(label=label)

    @classmethod
    def at_degree(
        cls, label: str, monoidal_ref: str, complex_ref: str, degree: str
    ) -> "CohomologyInMonoidal":
        return cls(
            label=label,
            monoidal_ref=monoidal_ref,
            complex_ref=complex_ref,
            degree=degree,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.monoidal_ref:
            raise ValueError("empty monoidal_ref")
        if not self.complex_ref:
            raise ValueError("empty complex_ref")
        if not self.degree:
            raise ValueError("empty degree")



