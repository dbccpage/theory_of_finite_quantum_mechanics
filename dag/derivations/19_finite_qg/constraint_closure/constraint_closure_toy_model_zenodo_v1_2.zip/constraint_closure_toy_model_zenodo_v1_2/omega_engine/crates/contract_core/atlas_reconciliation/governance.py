from pydantic import ConfigDict
from enum import Enum
from typing import List, Optional
from pydantic.dataclasses import dataclass


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class GovernanceRecord:
    obstruction: str
    prior_rule: str
    proposed_rule: str
    zero_difference_relation: str
    residual_class: str
    authority_basis: str
    evidence_basis: str
    affected_roles: List[str]
    non_harm_consequences: str
    terminal_status: str

    def is_complete(self) -> bool:
        return (
            bool(self.obstruction)
            and bool(self.prior_rule)
            and bool(self.proposed_rule)
            and bool(self.zero_difference_relation)
            and bool(self.residual_class)
            and bool(self.authority_basis)
            and bool(self.evidence_basis)
            and bool(self.affected_roles)
            and bool(self.non_harm_consequences)
            and bool(self.terminal_status)
        )

    @classmethod
    def full_sample(cls) -> "GovernanceRecord":
        return cls(
            obstruction="authority surface declared but unpinned to a role ceiling",
            prior_rule="authority effect inferred ambiently from code",
            proposed_rule="authority effect must equal the role-pinned ceiling",
            zero_difference_relation="rename + path normalization only",
            residual_class="licenseD-LIFT",
            authority_basis="Lean-mechanized sealed authority type",
            evidence_basis="local replay + green CI-gated tests",
            affected_roles=["Blackrod", "Council"],
            non_harm_consequences="no public surface widened; defensive-only preserved",
            terminal_status="LicensedLift",
        )


class Role(Enum):
    Blackrod = "Blackrod"
    Woland = "Woland"
    Logos = "Logos"
    Pilate = "Pilate"
    Council = "Council"
    Model = "Model"


class Power(Enum):
    Diagnose = "Diagnose"
    Enforce = "Enforce"
    Block = "Block"
    Terminalize = "Terminalize"
    Vote = "Vote"
    WaiveEvidence = "WaiveEvidence"
    ReviseDoctrine = "ReviseDoctrine"


def role_may(role: Role, power: Power) -> bool:
    if role == Role.Blackrod:
        return power in (Power.Enforce, Power.Block)
    elif role == Role.Woland:
        return power == Power.Diagnose
    elif role == Role.Council:
        return power in (Power.Vote, Power.Diagnose)
    elif role == Role.Logos:
        return power == Power.Diagnose
    elif role == Role.Pilate:
        return power == Power.Diagnose
    elif role == Role.Model:
        return False
    return False


class GovKind(Enum):
    AuthorityExpansion = "AuthorityExpansion"
    EvidenceWaiver = "EvidenceWaiver"
    DoctrineMutation = "DoctrineMutation"
    ResidualPromotion = "ResidualPromotion"
    SelfCertification = "SelfCertification"
    BoundaryRelaxation = "BoundaryRelaxation"

    def label(self) -> str:
        mapping = {
            GovKind.AuthorityExpansion: "authority-expansion",
            GovKind.EvidenceWaiver: "evidence-waiver",
            GovKind.DoctrineMutation: "doctrine-mutation",
            GovKind.ResidualPromotion: "residual-promotion",
            GovKind.SelfCertification: "self-certification",
            GovKind.BoundaryRelaxation: "boundary-relaxation",
        }
        return mapping.get(self, "")


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class GovChange:
    kind: GovKind
    record: Optional[GovernanceRecord] = None

    @classmethod
    def authority_expansion_no_record(cls) -> "GovChange":
        return cls(kind=GovKind.AuthorityExpansion, record=None)

    @classmethod
    def licensed_lift_full_10_fields(cls) -> "GovChange":
        return cls(
            kind=GovKind.AuthorityExpansion, record=GovernanceRecord.full_sample()
        )

    @classmethod
    def council_self_certify(cls) -> "GovChange":
        return cls(kind=GovKind.SelfCertification, record=None)


def check_governance_strict(change: GovChange) -> List[str]:
    findings = []
    if change.kind == GovKind.SelfCertification:
        findings.append("governance: self-certification refused (no self-cert)")

    complete_lift = change.record is not None and change.record.is_complete()
    if not complete_lift:
        findings.append(
            f"governance: {change.kind.label()} requires a complete licensed lift (10-field record)"
        )
    return findings


