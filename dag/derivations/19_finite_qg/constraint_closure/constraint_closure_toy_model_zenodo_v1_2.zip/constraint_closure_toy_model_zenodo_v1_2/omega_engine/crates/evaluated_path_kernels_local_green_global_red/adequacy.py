"""Structural detector-adequacy gate for the Python EPK rail.

LGGR II (paper 020) §3.1 requires a ``DetectorAdequacy`` certificate before a
zero-defect reading may be treated as anything but ``OracleNeeded``. The Rust
crate implements that protocol in ``omega_engine/crates/omega_engine.crates.evaluated_path_kernels_local_green_global_red/src/adequacy.rs``;
the Python rail had **no adequacy concept at all**, so ``ngd = 0.0`` was reported
from corpora whose detector provably cannot return anything else.

This module supplies the gate on the Python side.

Scope, stated plainly
---------------------
This is a **structural subset** of the Rust protocol, not parity with it. It
implements the exact, cheap structural guards that catch the collapses §3.1 names
by hand, and the same five-stage control flow (declaration -> structural ->
evidence -> comparison) using the same verdict vocabulary. It does **not**
implement the Rust protocol's full failure taxonomy (carrier closure, projection
collisions, protected-direction magnitude policy, evidence digest reconciliation,
and the rest), and it computes no capacity evidence of its own — the caller
supplies it, exactly as the Rust entry point requires.

Consequently a ``NumericallySupported`` verdict from this module is weaker than
one from the Rust protocol. It is still never ``Adequate``: as ``adequacy.rs``
pins it, *"No verdict is `Adequate`; exact BSC-CERT remains open."*

AuthorityEffect: None.
"""

from __future__ import annotations
import hashlib
from dataclasses import field
from dataclasses import dataclass
from enum import Enum
from typing import Sequence

__all__ = [
    "AdequacyKind",
    "StructuralFailure",
    "UndeclaredReason",
    "CompositionObservation",
    "DetectorDeploymentDeclaration",
    "DetectorAdequacyVerdict",
    "evaluate_detector_adequacy",
]


class AdequacyKind(str, Enum):
    """Verdict kinds. Mirrors ``DetectorAdequacyVerdictKind`` plus an explicit
    ``NotEvaluated`` for "the protocol was never run"."""

    NotEvaluated = "NotEvaluated"
    Undeclared = "Undeclared"
    StructuralInadequate = "StructuralInadequate"
    NumericalCounterevidence = "NumericalCounterevidence"
    NumericallySupported = "NumericallySupported"
    NumericalUnresolved = "NumericalUnresolved"


class UndeclaredReason(str, Enum):
    DeploymentDeclarationMissing = "DeploymentDeclarationMissing"
    CapacityEvidenceMissing = "CapacityEvidenceMissing"


class StructuralFailure(str, Enum):
    """The exact structural guards implemented here.

    Names match their Rust counterparts, with the evaluator role expanded into
    separate members because Python enum members do not carry payloads.
    """

    EmptyCorpus = "EmptyCorpus"
    GlobalEqualsLocalProduct = "GlobalEqualsLocalProduct"
    EvaluatorConstantLocalLeft = "EvaluatorConstantLocalLeft"
    EvaluatorConstantLocalRight = "EvaluatorConstantLocalRight"
    EvaluatorConstantGlobal = "EvaluatorConstantGlobal"
    LocalProductConstant = "LocalProductConstant"
    MissingNgdWitness = "MissingNgdWitness"
    MissingBlindSpotDeclaration = "MissingBlindSpotDeclaration"


@dataclass(frozen=True, slots=True)
class CompositionObservation:
    """One observed ``(E_1, E_2, E_g)`` triple.

    Deliberately narrow: the structural guards need only the evaluator triple, and
    requiring a full ``ComposedPath`` would force callers to construct glued
    segments they may not have. Use :meth:`from_composed_path` when they do.
    """

    composed_id: str
    local_left_pass: bool
    local_right_pass: bool
    global_pass: bool

    def __post_init__(self) -> None:
        if not isinstance(self.composed_id, str) or not self.composed_id:
            raise ValueError("composed_id must be a non-empty string")
        for name in ("local_left_pass", "local_right_pass", "global_pass"):
            if not isinstance(getattr(self, name), bool):
                raise ValueError(f"{name} must be a bool")

    @property
    def local_product(self) -> bool:
        """``E_1 . E_2``. Boolean conjunction: the product of binary gates."""
        return self.local_left_pass and self.local_right_pass

    @property
    def delta_eval(self) -> int:
        """``delta_E = E_g - E_1.E_2`` in ``{-1, 0, +1}``."""
        return int(self.global_pass) - int(self.local_product)

    @classmethod
    def from_composed_path(cls, path) -> "CompositionObservation":
        """Project an :class:`omega_engine.crates.evaluated_path_kernels_local_green_global_red.core.ComposedPath` onto its evaluator triple."""
        return cls(
            composed_id=path.id,
            local_left_pass=bool(path.first.eval_pass),
            local_right_pass=bool(path.second.eval_pass),
            global_pass=bool(path.global_eval_pass),
        )


@dataclass(frozen=True, slots=True)
class DetectorDeploymentDeclaration:
    """What the deployment declares about itself.

    ``blind_spots`` is required to be non-empty: §3.1 demands a certificate naming
    *"known blind spots"*, and a declaration that names none has not done the work.
    """

    deployment_id: str
    epsilon: float
    blind_spots: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.deployment_id, str) or not self.deployment_id:
            raise ValueError("deployment_id must be a non-empty string")
        if isinstance(self.epsilon, bool) or not isinstance(self.epsilon, (int, float)):
            raise ValueError("epsilon must be numeric")
        if not _is_finite(self.epsilon) or self.epsilon < 0.0:
            raise ValueError("epsilon must be finite and non-negative")


@dataclass(frozen=True, slots=True)
class DetectorAdequacyVerdict:
    """The verdict. ``authority_effect`` is fixed at ``"None"`` for every value."""

    kind: AdequacyKind
    observed_corpus_digest: str
    structural_failures: tuple[StructuralFailure, ...] = ()
    undeclared_reason: UndeclaredReason | None = None
    capacity_value: float | None = None
    epsilon: float | None = None
    authority_effect: str = field(default="None")

    def permits_detector_adequate(self) -> bool:
        """The single condition under which Prime 002's ``detector_adequate``
        conjunct may be satisfied."""
        return self.kind is AdequacyKind.NumericallySupported


def _is_finite(x: float) -> bool:
    return x == x and x not in (float("inf"), float("-inf"))


def observed_corpus_digest(corpus: Sequence[CompositionObservation]) -> str:
    """Order-independent digest of the observed corpus.

    Rows are sorted by id so that re-ordering the same corpus does not change the
    digest, and the digest is therefore a stable identifier for replay.
    """
    hasher = hashlib.sha256()
    hasher.update(b"omega.epk.observed-corpus.v1\0")
    for obs in sorted(corpus, key=lambda o: o.composed_id):
        hasher.update(obs.composed_id.encode("utf-8"))
        hasher.update(
            bytes(
                (
                    int(obs.local_left_pass),
                    int(obs.local_right_pass),
                    int(obs.global_pass),
                )
            )
        )
        hasher.update(b"\0")
    return "sha256:" + hasher.hexdigest()


def _structural_failures(
    corpus: Sequence[CompositionObservation],
    declaration: DetectorDeploymentDeclaration,
) -> list[StructuralFailure]:
    failures: list[StructuralFailure] = []
    if not corpus:
        return [StructuralFailure.EmptyCorpus]

    if not declaration.blind_spots:
        failures.append(StructuralFailure.MissingBlindSpotDeclaration)

    if all(o.global_pass == o.local_product for o in corpus):
        failures.append(StructuralFailure.GlobalEqualsLocalProduct)

    for member, values in (
        (
            StructuralFailure.EvaluatorConstantLocalLeft,
            [o.local_left_pass for o in corpus],
        ),
        (
            StructuralFailure.EvaluatorConstantLocalRight,
            [o.local_right_pass for o in corpus],
        ),
        (StructuralFailure.EvaluatorConstantGlobal, [o.global_pass for o in corpus]),
    ):
        if len(set(values)) == 1:
            failures.append(member)

    if len({o.local_product for o in corpus}) == 1:
        failures.append(StructuralFailure.LocalProductConstant)

    if not any(o.delta_eval == -1 for o in corpus):
        failures.append(StructuralFailure.MissingNgdWitness)

    return failures


def evaluate_detector_adequacy(
    corpus: Sequence[CompositionObservation],
    *,
    declaration: DetectorDeploymentDeclaration | None = None,
    capacity_value: float | None = None,
) -> DetectorAdequacyVerdict:
    """Run the gate.

    Order mirrors the Rust protocol and is fail-closed: a missing declaration is
    reported without reading evidence, and structural failures are reported without
    reading evidence either. Numerical evidence is only ever consulted after the
    exact guards pass.
    """
    digest = observed_corpus_digest(corpus)

    if declaration is None:
        return DetectorAdequacyVerdict(
            kind=AdequacyKind.Undeclared,
            observed_corpus_digest=digest,
            undeclared_reason=UndeclaredReason.DeploymentDeclarationMissing,
        )

    failures = _structural_failures(corpus, declaration)
    if failures:
        return DetectorAdequacyVerdict(
            kind=AdequacyKind.StructuralInadequate,
            observed_corpus_digest=digest,
            structural_failures=tuple(failures),
        )

    if capacity_value is None:
        return DetectorAdequacyVerdict(
            kind=AdequacyKind.Undeclared,
            observed_corpus_digest=digest,
            undeclared_reason=UndeclaredReason.CapacityEvidenceMissing,
        )

    if isinstance(capacity_value, bool) or not isinstance(capacity_value, (int, float)):
        raise ValueError("capacity_value must be numeric")
    if not _is_finite(float(capacity_value)):
        return DetectorAdequacyVerdict(
            kind=AdequacyKind.NumericalUnresolved,
            observed_corpus_digest=digest,
            capacity_value=None,
            epsilon=declaration.epsilon,
        )

    kind = (
        AdequacyKind.NumericallySupported
        if float(capacity_value) <= declaration.epsilon
        else AdequacyKind.NumericalCounterevidence
    )
    return DetectorAdequacyVerdict(
        kind=kind,
        observed_corpus_digest=digest,
        capacity_value=float(capacity_value),
        epsilon=declaration.epsilon,
    )





