from pydantic import ConfigDict
from dataclasses import field
from pydantic.dataclasses import dataclass
from enum import Enum
from typing import List, Optional, Union
from omega_engine.crates.contract_core.sealed import Sealed


class SchemaRef:
    def __init__(self, ref_str: str) -> None:
        self.ref_str = ref_str

    def __repr__(self) -> str:
        return f"SchemaRef({self.ref_str!r})"


@dataclass(config=ConfigDict(arbitrary_types_allowed=True, frozen=True))
class SchemaHash:
    hash_bytes: bytes

    def __post_init__(self):
        if len(self.hash_bytes) != 32:
            raise ValueError("SchemaHash must be exactly 32 bytes")

    def __str__(self) -> str:
        return self.hash_bytes.hex()

    def __repr__(self) -> str:
        return f"SchemaHash({self.hash_bytes.hex()})"


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class BaseValidationWitness:
    validation_id: str
    schema_hash: SchemaHash
    validator_version: str


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class BaseValidationViolation:
    message: str


class MutabilityMode:
    pass


class ImmutableMode(MutabilityMode):
    def __repr__(self) -> str:
        return "Immutable"


class ControlledMode(MutabilityMode):
    def __init__(self, allowed_fields: List[str]) -> None:
        self.allowed_fields = allowed_fields

    def __repr__(self) -> str:
        return f"Controlled({self.allowed_fields!r})"


class BaseType(Sealed):
    @classmethod
    def schema(cls) -> SchemaRef:
        raise NotImplementedError()

    def validate(
        self,
    ) -> Optional[Union[BaseValidationWitness, BaseValidationViolation]]:
        raise NotImplementedError()


class ContractCategory(Enum):
    Constitution = "Constitution"
    State = "State"
    Evidence = "Evidence"
    Obstruction = "Obstruction"
    Action = "Action"
    OperatorCandidate = "OperatorCandidate"
    OperatorAlgebra = "OperatorAlgebra"
    Governance = "Governance"
    Execution = "Execution"
    Representation = "Representation"
    Product = "Product"
    Lifts = "Lifts"
    Math = "Math"


class ComponentRole(Enum):
    BaseType = "BaseType"
    Carrier = "Carrier"
    Packet = "Packet"
    CheckedPacket = "CheckedPacket"
    Certificate = "Certificate"
    CertificateKernel = "CertificateKernel"
    CertificateStore = "CertificateStore"
    CertificateApiInterface = "CertificateApiInterface"
    Witness = "Witness"
    Diagnostic = "Diagnostic"
    HealthModel = "HealthModel"
    Measurement = "Measurement"
    Observable = "Observable"
    Evaluator = "Evaluator"
    Validator = "Validator"
    Terminalizer = "Terminalizer"
    TerminalMapper = "TerminalMapper"
    Engine = "Engine"
    Kernel = "Kernel"
    Pipeline = "Pipeline"
    Runtime = "Runtime"
    Policy = "Policy"
    Search = "Search"
    Solver = "Solver"
    Replay = "Replay"
    Lift = "Lift"
    LiftLicense = "LiftLicense"
    LlmAdapter = "LlmAdapter"
    WebsiteApi = "WebsiteApi"
    SymbolGame = "SymbolGame"
    Packetization = "Packetization"
    StructureSweep = "StructureSweep"
    ProductKernelIntake = "ProductKernelIntake"
    FixedLayerOperatorAlgebra = "FixedLayerOperatorAlgebra"
    DeclaredActionCandidate = "DeclaredActionCandidate"
    RepresentationBoundary = "RepresentationBoundary"
    IntakeConstructor = "IntakeConstructor"
    ProposalGenerator = "ProposalGenerator"
    Trace = "Trace"
    AnalysisUnit = "AnalysisUnit"
    Boundary = "Boundary"
    AuthInterface = "AuthInterface"
    MathObject = "MathObject"
    MathComputation = "MathComputation"
    PublicVerifyService = "PublicVerifyService"
    SearchKernel = "SearchKernel"
    SolverKernel = "SolverKernel"
    CounterfeitDetector = "CounterfeitDetector"
    Constitution = "Constitution"


class AuthorityEffect(Enum):
    None_ = "none"
    EvidenceOnly = "evidence_only"
    FactOnly = "fact_only"
    RequiresEvaluator = "requires_evaluator"
    RequestsDecision = "requests_decision"
    AuthorizesTransition = "authorizes_transition"
    StateTransition = "state_transition"

    def is_execution(self) -> bool:
        return self == AuthorityEffect.StateTransition

    def is_license(self) -> bool:
        return self == AuthorityEffect.AuthorizesTransition

    def is_decision(self) -> bool:
        return self in (
            AuthorityEffect.RequiresEvaluator,
            AuthorityEffect.RequestsDecision,
        )

    def is_evidence_layer(self) -> bool:
        return self in (
            AuthorityEffect.None_,
            AuthorityEffect.EvidenceOnly,
            AuthorityEffect.FactOnly,
        )

    def is_certified(self) -> bool:
        return self != AuthorityEffect.None_

    def is_none(self) -> bool:
        return self == AuthorityEffect.None_


class ArtifactKind(Enum):
    StructureArtifact = "StructureArtifact"
    EvidenceEnvelope = "EvidenceEnvelope"
    FactEnvelope = "FactEnvelope"
    DecisionEnvelope = "DecisionEnvelope"
    ActionLicense = "ActionLicense"
    Action = "Action"
    Record = "Record"
    StateEnvelope = "StateEnvelope"
    CandidateEnvelope = "CandidateEnvelope"
    TerminalEnvelope = "TerminalEnvelope"
    CheckedTerminalEnvelope = "CheckedTerminalEnvelope"


class Capability(Enum):
    CarryLaws = "CarryLaws"
    ExecuteStateTransition = "ExecuteStateTransition"
    RuntimeMutation = "RuntimeMutation"
    OrchestrateRuntime = "OrchestrateRuntime"
    EmitAction = "EmitAction"
    ActionLicensing = "ActionLicensing"
    ApplyLift = "ApplyLift"
    Repair = "Repair"
    EmitDecision = "EmitDecision"
    PolicyInterpretation = "PolicyInterpretation"
    PolicyDefinition = "PolicyDefinition"
    Evaluation = "Evaluation"
    Validation = "Validation"
    AdmissibilityDecision = "AdmissibilityDecision"
    AuthorityPromotion = "AuthorityPromotion"
    EmitCertificate = "EmitCertificate"
    CertificateSigning = "CertificateSigning"
    StoreCertificate = "StoreCertificate"
    SelfCertification = "SelfCertification"
    TraceWriting = "TraceWriting"
    RawPayloadExposure = "RawPayloadExposure"
    PublicSigning = "PublicSigning"
    TerminalMapping = "TerminalMapping"
    Terminalization = "Terminalization"
    SolverExecution = "SolverExecution"
    CandidateGeneration = "CandidateGeneration"
    CallLlm = "CallLlm"
    MeasurementComputation = "MeasurementComputation"
    ComputePhi = "ComputePhi"
    ComputeGamma = "ComputeGamma"
    ComputeXi = "ComputeXi"
    ComputeQuotientMass = "ComputeQuotientMass"
    ComputeClosureDefect = "ComputeClosureDefect"
    ComputeCohomologicalStatus = "ComputeCohomologicalStatus"
    ComputeRefusalSignal = "ComputeRefusalSignal"
    SemanticTruthClaim = "SemanticTruthClaim"


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class CapabilityPolicy:
    forbidden: List[Capability] = field(default_factory=list)
    required: List[Capability] = field(default_factory=list)

    def forbids(self, capability: Capability) -> bool:
        return capability in self.forbidden

    def requires(self, capability: Capability) -> bool:
        return capability in self.required


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class KindDescriptor:
    category: ContractCategory
    role: ComponentRole
    authority_effect: AuthorityEffect
    capability_policy: CapabilityPolicy


class ContractStatus(Enum):
    Canonical = "Canonical"
    Staged = "Staged"
    Archived = "Archived"
    Deprecated = "Deprecated"





