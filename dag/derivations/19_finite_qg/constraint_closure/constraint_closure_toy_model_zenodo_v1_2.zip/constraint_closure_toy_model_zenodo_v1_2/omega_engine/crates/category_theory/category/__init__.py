"""Category hierarchy shells for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Mirrors ``omega_engine/crates/omega_category_theory/src/category/``.

Also re-exports the legacy finite-presentation API from the sibling
``category.py`` module file so package-root imports keep working.
"""

from __future__ import annotations
import importlib.util
from pathlib import Path

from .category import FiniteCategoryShell, MorphismTriple
from .small_category import SmallCategoryShell
from .opposite import OppositeCategoryShell
from .product_category import ProductCategoryShell
from .sum_category import SumCategoryShell
from .slice_category import SliceCategoryShell
from .coslice_category import CosliceCategoryShell
from .arrow_category import ArrowCategoryShell
from .discrete_category import DiscreteCategoryShell
from .terminal_category import TerminalCategoryShell
from .discrete_fibration import DiscreteFibrationShell
from .fibered_category import FiberedCategoryShell
from .opfibration import OpfibrationShell

import sys

_legacy_path = Path(__file__).resolve().parent.parent / "category.py"
_legacy_name = "omega_engine.crates.category_theory._legacy_category_module"
_spec = importlib.util.spec_from_file_location(_legacy_name, _legacy_path)
if _spec is None or _spec.loader is None:
    raise ImportError(f"cannot load legacy category module from {_legacy_path}")
_legacy = importlib.util.module_from_spec(_spec)
_legacy.__package__ = "omega_engine.crates.category_theory"
sys.modules[_legacy_name] = _legacy
_spec.loader.exec_module(_legacy)

Object = _legacy.Object
Category = _legacy.Category
CategoryLawFailure = _legacy.CategoryLawFailure
CategoryLawReport = _legacy.CategoryLawReport
DuplicateMorphismError = _legacy.DuplicateMorphismError
check_associativity_finite = _legacy.check_associativity_finite
Morphism = _legacy.Morphism
compose = _legacy.compose
identity = _legacy.identity

__all__ = [
    "FiniteCategoryShell",
    "MorphismTriple",
    "SmallCategoryShell",
    "OppositeCategoryShell",
    "ProductCategoryShell",
    "SumCategoryShell",
    "SliceCategoryShell",
    "CosliceCategoryShell",
    "ArrowCategoryShell",
    "DiscreteCategoryShell",
    "TerminalCategoryShell",
    "DiscreteFibrationShell",
    "FiberedCategoryShell",
    "OpfibrationShell",
    "Object",
    "Category",
    "CategoryLawFailure",
    "CategoryLawReport",
    "DuplicateMorphismError",
    "check_associativity_finite",
    "Morphism",
    "compose",
    "identity",
]



