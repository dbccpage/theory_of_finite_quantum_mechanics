"""limit shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List

from .cone import Cone


@dataclass
class Limit:
    """Best-effort shell for a limit of a diagram (diagram_ref + limiting cone)."""

    label: str
    diagram_ref: str = ""
    cone: Cone = field(default_factory=lambda: Cone(label=""))
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Limit":
        return cls(label=label)

    @classmethod
    def of_diagram(cls, label: str, diagram_ref: str, cone: Cone) -> "Limit":
        return cls(label=label, diagram_ref=diagram_ref, cone=cone)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.diagram_ref:
            raise ValueError("empty diagram_ref")
        try:
            self.cone.validate_shell()
        except ValueError as e:
            raise ValueError(f"cone: {e}") from e



