"""Universe Anomalonica Deformation Theory — DGLA Subsystem.

Differential Graded Lie Algebras (DGLAs) provide the algebraic engine for deformation theory.
AuthorityEffect: None.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple
import numpy as np


def _scaled_atol(tol: float, *arrays: Any) -> float:
    """Absolute tolerance scaled to the magnitude of the operands.

    A fixed atol makes an algebraic law scale-dependent: a relative violation of
    1e-9 in operands of size 1e6 is absolutely 1e-3 and reads as a failure,
    while a relative violation of 1 in operands of size 1e-6 reads as holding.
    The laws below are the evidence for this module's claim that the DGLA
    satisfies graded Jacobi and Leibniz, so they must not depend on scale.
    Callers pass rtol=0.0 alongside this: numpy's default rtol is 1e-5,
    which accepted an algebra violating the Jacobi identity by a relative
    1e-6 -- the law was being checked to five significant figures.
    """
    scale = 1.0
    for a in arrays:
        arr = np.asarray(a, dtype=float)
        if arr.size:
            scale = max(scale, float(np.max(np.abs(arr))))
    return float(tol) * scale


@dataclass
class DGLA:
    r"""Differential Graded Lie Algebra L = \bigoplus_k L^k."""
    name: str
    dims: Dict[int, int]
    differentials: Dict[int, np.ndarray] = field(default_factory=dict)
    brackets: Dict[Tuple[int, int], np.ndarray] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for deg, mat in list(self.differentials.items()):
            self.differentials[deg] = np.asarray(mat, dtype=float)

    def d(self, deg: int, x: np.ndarray) -> np.ndarray:
        """Applies the differential d_k: L^k -> L^{k+1}."""
        x_arr = np.asarray(x, dtype=float)
        if deg not in self.differentials:
            next_dim = self.dims.get(deg + 1, 0)
            return np.zeros(next_dim)
        return self.differentials[deg] @ x_arr

    def lie_bracket(self, deg_x: int, x: np.ndarray, deg_y: int, y: np.ndarray) -> np.ndarray:
        """Computes the graded Lie bracket [x, y] in degree deg_x + deg_y."""
        deg_out = deg_x + deg_y
        out_dim = self.dims.get(deg_out, 0)
        x_arr = np.asarray(x, dtype=float)
        y_arr = np.asarray(y, dtype=float)
        key = (deg_x, deg_y)
        if key in self.brackets:
            B = self.brackets[key]
            return np.einsum('ijk,j,k->i', B, x_arr, y_arr)
        if deg_x == 0 and deg_y == 0 and x_arr.ndim == 2 and y_arr.ndim == 2:
            return x_arr @ y_arr - y_arr @ x_arr
        return np.zeros(out_dim)

    def check_nilpotency(self, deg: int, tol: float = 1e-10) -> bool:
        """Checks d_{k+1} . d_k = 0."""
        if deg not in self.differentials or (deg + 1) not in self.differentials:
            return True
        d_k = self.differentials[deg]
        d_k1 = self.differentials[deg + 1]
        prod = d_k1 @ d_k
        return bool(np.allclose(prod, 0.0, rtol=0.0, atol=_scaled_atol(tol, prod)))

    def check_graded_skew_symmetry(
        self, deg_x: int, x: np.ndarray, deg_y: int, y: np.ndarray, tol: float = 1e-10
    ) -> bool:
        """Checks [x, y] = -(-1)^{|x||y|} [y, x]."""
        b_xy = self.lie_bracket(deg_x, x, deg_y, y)
        b_yx = self.lie_bracket(deg_y, y, deg_x, x)
        koszul = -((-1.0) ** (deg_x * deg_y))
        return bool(np.allclose(b_xy, koszul * b_yx, rtol=0.0,
                                atol=_scaled_atol(tol, b_xy, b_yx)))

    def check_graded_jacobi(
        self,
        deg_x: int, x: np.ndarray,
        deg_y: int, y: np.ndarray,
        deg_z: int, z: np.ndarray,
        tol: float = 1e-10,
    ) -> bool:
        """Checks graded Jacobi identity: [x, [y, z]] = [[x, y], z] + (-1)^{|x||y|} [y, [x, z]]."""
        yz = self.lie_bracket(deg_y, y, deg_z, z)
        t1 = self.lie_bracket(deg_x, x, deg_y + deg_z, yz)

        xy = self.lie_bracket(deg_x, x, deg_y, y)
        t2 = self.lie_bracket(deg_x + deg_y, xy, deg_z, z)

        xz = self.lie_bracket(deg_x, x, deg_z, z)
        sign = (-1.0) ** (deg_x * deg_y)
        t3 = sign * self.lie_bracket(deg_y, y, deg_x + deg_z, xz)

        return bool(np.allclose(t1, t2 + t3, rtol=0.0,
                                atol=_scaled_atol(tol, t1, t2, t3)))

    def check_graded_leibniz(
        self, deg_x: int, x: np.ndarray, deg_y: int, y: np.ndarray, tol: float = 1e-10
    ) -> bool:
        """Checks graded Leibniz rule: d([x, y]) = [dx, y] + (-1)^{|x|} [x, dy]."""
        xy = self.lie_bracket(deg_x, x, deg_y, y)
        d_xy = self.d(deg_x + deg_y, xy)

        dx = self.d(deg_x, x)
        dx_y = self.lie_bracket(deg_x + 1, dx, deg_y, y)

        dy = self.d(deg_y, y)
        sign = (-1.0) ** deg_x
        x_dy = sign * self.lie_bracket(deg_x, x, deg_y + 1, dy)

        return bool(np.allclose(d_xy, dx_y + x_dy, rtol=0.0,
                                atol=_scaled_atol(tol, d_xy, dx_y, x_dy)))

    @classmethod
    def abelian(cls, dims: Dict[int, int]) -> DGLA:
        """Creates an abelian DGLA with zero differentials and zero brackets."""
        return cls(name="AbelianDGLA", dims=dims)

    @classmethod
    def standard_sl2(cls) -> DGLA:
        """Constructs sl_2 as a degree-0 DGLA with basis (e, f, h)."""
        dim = 3
        B = np.zeros((dim, dim, dim))
        B[0, 2, 0] = 2.0
        B[0, 0, 2] = -2.0
        B[1, 2, 1] = -2.0
        B[1, 1, 2] = 2.0
        B[2, 0, 1] = 1.0
        B[2, 1, 0] = -1.0
        return cls(
            name="sl2",
            dims={0: dim, 1: 0, 2: 0},
            differentials={},
            brackets={(0, 0): B}
        )
