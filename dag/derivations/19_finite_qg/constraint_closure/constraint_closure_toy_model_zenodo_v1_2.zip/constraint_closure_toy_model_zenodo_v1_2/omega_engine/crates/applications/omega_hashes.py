"""BLAKE3 content hashing for packet and receipt identities.

Universe-local narrow port of the rail's ``omega_hashes`` public surface
(only what this estate consumes), implemented directly over the ``blake3``
package this estate already depends on (see
``math/omega_homology/hashing.py``).

AuthorityEffect: None.
"""

from __future__ import annotations
try:
    import blake3 as _blake3
except ImportError:
    _blake3 = None

OUT_LEN = 32


def blake3_digest(
    data: bytes | bytearray | memoryview | str, length: int = OUT_LEN
) -> bytes:
    if _blake3 is None:
        raise RuntimeError("blake3 package is required for blake3_digest but not installed.")
    raw = data.encode("utf-8") if isinstance(data, str) else bytes(data)
    return _blake3.blake3(raw).digest(length=length)


def blake3_hex(
    data: bytes | bytearray | memoryview | str, length: int = OUT_LEN
) -> str:
    return blake3_digest(data, length).hex()


__all__ = ["OUT_LEN", "blake3_digest", "blake3_hex"]
