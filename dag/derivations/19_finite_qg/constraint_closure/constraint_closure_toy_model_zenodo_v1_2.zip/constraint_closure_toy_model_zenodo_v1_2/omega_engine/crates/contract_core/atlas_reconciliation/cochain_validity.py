from enum import Enum
from typing import List, Optional


class TriState(Enum):
    True_ = "True"
    False_ = "False"
    Unknown = "Unknown"


class CochainValidity:
    def __init__(
        self,
        chain: List[str],
        d0_declared: str,
        d1_declared: str,
        d1_d0_zero: TriState,
        failure_reason: str,
        d0: List[List[int]],
        d1: List[List[int]],
        terminal_if_failed: Optional[str] = None,
    ) -> None:
        self.chain = chain
        self.d0_declared = d0_declared
        self.d1_declared = d1_declared
        self.d1_d0_zero = d1_d0_zero
        self.failure_reason = failure_reason
        self.terminal_if_failed = terminal_if_failed
        self.d0 = d0
        self.d1 = d1

    def computed_d1_d0_zero(self) -> TriState:
        return check_d1_d0_zero_f2(self.d1, self.d0)


def check_d1_d0_zero_f2(d1: List[List[int]], d0: List[List[int]]) -> TriState:
    if not d1 or not d0:
        return TriState.Unknown
    cols = len(d0[0])
    for row in d0:
        if len(row) != cols:
            return TriState.Unknown
    for r in d1:
        if len(r) != len(d0):
            return TriState.Unknown
        for j in range(cols):
            acc = 0
            for k in range(len(d0)):
                acc ^= (r[k] & d0[k][j]) & 1
            if acc != 0:
                return TriState.False_
    return TriState.True_
