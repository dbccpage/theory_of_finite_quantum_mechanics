import math
from collections import defaultdict
from typing import Iterable, Mapping

from omega_engine.crates.evaluated_path_kernels_local_green_global_red.core import ComposedPath, PathSegment



# ---------------------------------------------------------------------------
# Input guards
# ---------------------------------------------------------------------------


def _require_bool(value: bool, name: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"{name} must be bool, got {type(value).__name__}")
    return value


def _require_finite_nonnegative(value: float, name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be numeric, not bool")
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    if value < 0.0:
        raise ValueError(f"{name} must be non-negative, got {value!r}")
    return value


def _require_nonempty_id(value: str, name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{name} must be a string")
    if not value:
        raise ValueError(f"{name} cannot be empty")
    return value


def _require_kernel_value(value: float, key: tuple) -> float:
    """Kernel values must be finite and non-negative."""
    if isinstance(value, bool):
        raise ValueError(f"kernel value at {key!r} must be numeric, not bool")
    v = float(value)
    if not math.isfinite(v):
        raise ValueError(f"kernel value at {key!r} must be finite, got {v!r}")
    if v < 0.0:
        raise ValueError(f"kernel value at {key!r} must be non-negative, got {v!r}")
    return v


# ---------------------------------------------------------------------------
# Core weight function
# ---------------------------------------------------------------------------


def path_weight(eval_pass: bool, cost: float, beta: float) -> float:
    """Compute the kernel weight for a single path.

    w_beta(gamma) = E(gamma) * exp(-beta * A[gamma])

    where E(gamma) in {0, 1} is the evaluator gate.

    Raises ValueError for:
    - eval_pass not bool
    - cost negative, NaN, or Inf
    - beta negative, NaN, or Inf
    """
    eval_pass = _require_bool(eval_pass, "eval_pass")
    cost = _require_finite_nonnegative(cost, "cost")
    beta = _require_finite_nonnegative(beta, "beta")
    return math.exp(-beta * cost) if eval_pass else 0.0


# ---------------------------------------------------------------------------
# Segment kernel
# ---------------------------------------------------------------------------


def segment_kernel(
    segments: Iterable[PathSegment],
    beta: float,
) -> dict[tuple[str, str], float]:
    """Accumulate path weights over segments sharing a source-target pair.

    Z(b | a) = sum_{gamma: a -> b} E(gamma) * exp(-beta * A[gamma])

    Empty input produces an empty dict.
    """
    beta = _require_finite_nonnegative(beta, "beta")
    z: dict[tuple[str, str], float] = defaultdict(float)

    for seg in segments:
        source_id = _require_nonempty_id(seg.source.id, "seg.source.id")
        target_id = _require_nonempty_id(seg.target.id, "seg.target.id")
        z[(source_id, target_id)] += path_weight(seg.eval_pass, seg.cost, beta)

    return dict(z)


# ---------------------------------------------------------------------------
# Composed kernel
# ---------------------------------------------------------------------------


def composed_kernel(
    paths: Iterable[ComposedPath],
    beta: float,
) -> dict[tuple[str, str], float]:
    """Compute the kernel over fully-composed two-segment paths.

    A[gamma2 * gamma1] = A[gamma1] + A[gamma2]  (additive, if composed_cost is None)

    or uses path.composed_cost when explicitly supplied.

    Raises ValueError if a path's boundary nodes do not match (unglued).
    Empty input produces an empty dict.
    """
    beta = _require_finite_nonnegative(beta, "beta")
    z: dict[tuple[str, str], float] = defaultdict(float)

    for path in paths:
        source_id = _require_nonempty_id(path.first.source.id, "path.first.source.id")
        boundary_left = _require_nonempty_id(
            path.first.target.id, "path.first.target.id"
        )
        boundary_right = _require_nonempty_id(
            path.second.source.id, "path.second.source.id"
        )
        target_id = _require_nonempty_id(path.second.target.id, "path.second.target.id")

        if boundary_left != boundary_right:
            raise ValueError(
                f"composed path is not glued: "
                f"first.target={boundary_left!r} != second.source={boundary_right!r}"
            )

        if path.composed_cost is None:
            cost = path.first.cost + path.second.cost
        else:
            cost = path.composed_cost

        cost = _require_finite_nonnegative(cost, "composed path cost")
        z[(source_id, target_id)] += path_weight(path.global_eval_pass, cost, beta)

    return dict(z)


# ---------------------------------------------------------------------------
# Kernel composition over boundary
# ---------------------------------------------------------------------------


def compose_kernels(
    left: Mapping[tuple[str, str], float],
    right: Mapping[tuple[str, str], float],
    boundary_ids: set[str],
) -> dict[tuple[str, str], float]:
    """Compose two kernel matrices over the declared boundary slice.

    Z_hat(c | a) = sum_{b in boundary_ids} Z(c | b) * Z(b | a)

    where *left* is Z(c | b)  (boundary -> target)
    and   *right* is Z(b | a) (source -> boundary).

    Rows in *left* / *right* whose boundary node is not in *boundary_ids* are
    silently skipped.  An empty *boundary_ids* always returns an empty dict.

    Raises ValueError for any NaN, Inf, or negative kernel value encountered.
    """
    if not isinstance(boundary_ids, set):
        raise ValueError("boundary_ids must be a set[str]")
    for bid in boundary_ids:
        _require_nonempty_id(bid, "boundary_id element")

    result: dict[tuple[str, str], float] = defaultdict(float)

    for (b1, c), z_cb_raw in left.items():
        b1 = _require_nonempty_id(b1, "left key source")
        c = _require_nonempty_id(c, "left key target")
        if b1 not in boundary_ids:
            continue
        z_cb = _require_kernel_value(z_cb_raw, (b1, c))

        for (a, b2), z_ba_raw in right.items():
            a = _require_nonempty_id(a, "right key source")
            b2 = _require_nonempty_id(b2, "right key target")
            if b1 != b2 or b2 not in boundary_ids:
                continue
            z_ba = _require_kernel_value(z_ba_raw, (a, b2))
            result[(a, c)] += z_cb * z_ba

    return dict(result)


def path_weight_generalized(
    eval_pass: bool,
    cost: float,
    risk: float,
    prob: float,
    lambda_: float = 1.0,
    mu_: float = 1.0,
) -> float:
    """Compute the generalized kernel weight for a single trace.

    w = E * P * exp(-lambda * C - mu * R)
    """
    eval_pass = _require_bool(eval_pass, "eval_pass")
    cost = _require_finite_nonnegative(cost, "cost")
    risk = _require_finite_nonnegative(risk, "risk")
    prob = _require_finite_nonnegative(prob, "prob")
    if prob > 1.0:
        raise ValueError("prob must be in [0.0, 1.0]")
    lambda_ = _require_finite_nonnegative(lambda_, "lambda_")
    mu_ = _require_finite_nonnegative(mu_, "mu_")

    if not eval_pass:
        return 0.0
    return prob * math.exp(-lambda_ * cost - mu_ * risk)


def composed_kernel_generalized(
    paths: Iterable[ComposedPath],
    lambda_: float = 1.0,
    mu_: float = 1.0,
) -> dict[tuple[str, str], float]:
    """Compute the generalized kernel over fully-composed paths using cost, risk, and probability."""
    lambda_ = _require_finite_nonnegative(lambda_, "lambda_")
    mu_ = _require_finite_nonnegative(mu_, "mu_")
    z: dict[tuple[str, str], float] = defaultdict(float)

    for path in paths:
        source_id = _require_nonempty_id(path.first.source.id, "path.first.source.id")
        boundary_left = _require_nonempty_id(
            path.first.target.id, "path.first.target.id"
        )
        boundary_right = _require_nonempty_id(
            path.second.source.id, "path.second.source.id"
        )
        target_id = _require_nonempty_id(path.second.target.id, "path.second.target.id")

        if boundary_left != boundary_right:
            raise ValueError(
                f"composed path is not glued: "
                f"first.target={boundary_left!r} != second.source={boundary_right!r}"
            )

        c1 = path.first.cost
        c2 = path.second.cost
        cost = path.composed_cost if path.composed_cost is not None else (c1 + c2)
        cost = _require_finite_nonnegative(cost, "composed path cost")

        # Extract risk and probability
        p1 = float(
            getattr(
                path.first,
                "prob",
                path.first.metadata.get(
                    "prob", path.first.metadata.get("proposal_prob", 1.0)
                ),
            )
        )
        p2 = float(
            getattr(
                path.second,
                "prob",
                path.second.metadata.get(
                    "prob", path.second.metadata.get("proposal_prob", 1.0)
                ),
            )
        )
        p_global_raw = getattr(
            path,
            "prob",
            path.metadata.get("prob", path.metadata.get("proposal_prob", None)),
        )
        prob = p1 * p2 if p_global_raw is None else float(p_global_raw)

        r1 = float(
            getattr(
                path.first,
                "risk",
                path.first.metadata.get(
                    "risk", path.first.metadata.get("residual_risk", 0.0)
                ),
            )
        )
        r2 = float(
            getattr(
                path.second,
                "risk",
                path.second.metadata.get(
                    "risk", path.second.metadata.get("residual_risk", 0.0)
                ),
            )
        )
        r_global_raw = getattr(
            path,
            "risk",
            path.metadata.get("risk", path.metadata.get("residual_risk", None)),
        )
        risk = r1 + r2 if r_global_raw is None else float(r_global_raw)

        w = path_weight_generalized(
            eval_pass=path.global_eval_pass,
            cost=cost,
            risk=risk,
            prob=prob,
            lambda_=lambda_,
            mu_=mu_,
        )
        z[(source_id, target_id)] += w

    return dict(z)


# BEGIN GENERATED RUST SURFACE
# Rust source: omega_engine/crates/omega_engine.crates.evaluated_path_kernels_local_green_global_red/src/kernels.rs
# Rust sha256: 3032b406962d23110ba7e5dd3660e0895bec4e16e7b00d7452da64a65e9b49ab
# Structural parity only; no behavioral or authority claim.
from typing import Any, TypeAlias  # noqa: E402


class _RustSurfaceMeta(type):
    def __getattr__(cls, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {cls.__name__}.{name} is not ported"
            )

        return unavailable


class _RustSurfaceObject(metaclass=_RustSurfaceMeta):
    def __getattr__(self, name: str) -> Any:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)

        def unavailable(*args: Any, **kwargs: Any) -> Any:
            raise NotImplementedError(
                f"Behavioral method {type(self).__name__}.{name} is not ported"
            )

        return unavailable


KernelKey: TypeAlias = Any


Kernel: TypeAlias = Any


def weighted_path_weight(*args: Any, **kwargs: Any) -> Any:
    """Structural mirror of Rust callable ``weighted_path_weight``."""

    raise NotImplementedError(
        "Behavioral port not implemented; Rust authority: omega_engine/crates/omega_engine.crates.evaluated_path_kernels_local_green_global_red/src/kernels.rs::weighted_path_weight"
    )


# END GENERATED RUST SURFACE



