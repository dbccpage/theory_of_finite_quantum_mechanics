"""eilenberg_moore shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class EilenbergMoore:
    """Best-effort shell for a labeled Eilenberg–Moore category of a monad."""

    label: str
    base_monad_ref: str = ""
    base_category_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "EilenbergMoore":
        return cls(label=label)

    @classmethod
    def for_monad(cls, label: str, base_monad_ref: str) -> "EilenbergMoore":
        return cls(label=label, base_monad_ref=base_monad_ref)

    def with_note(self, note: str) -> "EilenbergMoore":
        self.notes.append(note)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.base_monad_ref:
            raise ValueError("empty base_monad_ref")



