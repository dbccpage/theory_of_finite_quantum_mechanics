"""equivalence_of_categories shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class EquivalenceOfCategories:
    """Best-effort shell for an equivalence of categories claim."""

    label: str
    left_functor_ref: str = ""
    right_functor_ref: str = ""
    unit_nat_trans_ref: str = ""
    counit_nat_trans_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "EquivalenceOfCategories":
        return cls(label=label)

    @classmethod
    def between(
        cls, label: str, left_functor_ref: str, right_functor_ref: str
    ) -> "EquivalenceOfCategories":
        return cls(
            label=label,
            left_functor_ref=left_functor_ref,
            right_functor_ref=right_functor_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.left_functor_ref:
            raise ValueError("empty left_functor_ref")
        if not self.right_functor_ref:
            raise ValueError("empty right_functor_ref")



