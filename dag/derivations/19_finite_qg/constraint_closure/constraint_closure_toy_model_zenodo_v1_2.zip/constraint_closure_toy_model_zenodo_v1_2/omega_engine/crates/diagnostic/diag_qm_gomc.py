"""Executable diagnostics for the General Obstruction Management Calculus.

Faithful port of ``crates/omega_engine.crates.engine/src/quantum/gomc_diagnostics.rs``.
"""

from __future__ import annotations
import math
from typing import List, Optional, Tuple

from omega_engine_governance.contracts import AuthorityEffect
from omega_engine.crates.operator.transforms.trans_qm_residual_density import (
    branch_residual_search_report,
    coarse_grain_residual_density_report,
    edge_residual_density_report,
    incidence_residual_density_report,
    residual_channel_pushforward_report,
)
from omega_engine.crates.type.qm_density import (
    BranchResidualCandidate,
    BranchResidualSearchReport,
    GomcDiagnosticConfig,
    GomcDiagnosticReport,
    LocalGreenGlobalRedDiagnostic,
    ResidualDensityReport,
)


def edge_gomc_diagnostic_report(
    h1: List[float],
    config: GomcDiagnosticConfig,
) -> Optional[GomcDiagnosticReport]:
    validate_config(config)
    global_report = edge_residual_density_report(h1)
    if global_report is None:
        return None

    return build_gomc_diagnostic_report(global_report, config)


def incidence_gomc_diagnostic_report(
    n_nodes: int,
    edges: List[Tuple[int, int]],
    h1: List[float],
    config: GomcDiagnosticConfig,
) -> Optional[GomcDiagnosticReport]:
    validate_config(config)
    global_report = incidence_residual_density_report(n_nodes, edges, h1)
    if global_report is None:
        return None

    return build_gomc_diagnostic_report(global_report, config)


def build_gomc_diagnostic_report(
    global_report: ResidualDensityReport,
    config: GomcDiagnosticConfig,
) -> GomcDiagnosticReport:
    validate_config(config)

    observer = None
    if config.observer_labels is not None:
        observer = coarse_grain_residual_density_report(
            global_report, config.observer_labels
        )

    channel = None
    if config.channel_transition is not None:
        channel_source = observer if observer is not None else global_report
        channel = residual_channel_pushforward_report(
            channel_source, config.channel_transition
        )

    branch_search = None
    if config.branch_candidates:
        branch_search = branch_residual_search_report(config.branch_candidates)

    lggr = None
    if observer is not None:
        lggr = local_green_global_red_diagnostic(
            global_report,
            observer,
            config.local_green_purity_threshold,
            config.global_red_phi1_threshold,
        )

    return GomcDiagnosticReport(
        global_report=global_report,
        observer=observer,
        channel=channel,
        branch_search=branch_search,
        lggr=lggr,
        authority_effect=AuthorityEffect.None_,
    )


def local_green_global_red_diagnostic(
    global_report: ResidualDensityReport,
    local: ResidualDensityReport,
    local_green_purity_threshold: float,
    global_red_phi1_threshold: float,
) -> LocalGreenGlobalRedDiagnostic:
    local_green = (
        local.diagnostics.purity >= local_green_purity_threshold
        and abs(local.diagnostics.trace - 1.0) <= 1e-9
        and local.diagnostics.mass_error <= 1e-9
        and local.diagnostics.prob_error <= 1e-9
    )
    global_red = global_report.diagnostics.raw_l1_mass > global_red_phi1_threshold
    observer_forgets_support = local.diagnostics.dim < global_report.diagnostics.dim

    return LocalGreenGlobalRedDiagnostic(
        local_green=local_green,
        global_red=global_red,
        detected=local_green and global_red and observer_forgets_support,
        local_purity=local.diagnostics.purity,
        global_raw_l1_mass=global_report.diagnostics.raw_l1_mass,
        observer_dim=local.diagnostics.dim,
        global_dim=global_report.diagnostics.dim,
        authority_effect=AuthorityEffect.None_,
    )


def validate_config(config: GomcDiagnosticConfig) -> None:
    if not math.isfinite(config.local_green_purity_threshold) or not (
        0.0 <= config.local_green_purity_threshold <= 1.0
    ):
        raise ValueError("local green purity threshold must be finite and in [0, 1]")
    if (
        not math.isfinite(config.global_red_phi1_threshold)
        or config.global_red_phi1_threshold < 0.0
    ):
        raise ValueError("global red Phi1 threshold must be finite and nonnegative")





