"""Adjunction shells for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Mirrors ``omega_engine/crates/omega_category_theory/src/adjunction/``.
"""

from .adjunction import AdjunctionShell
from .unit import UnitShell
from .counit import CounitShell
from .hom_set_adjunction import HomSetAdjunctionShell, MatePair
from .galois_connection import GaloisConnectionShell, MonotonePair
from .adjoint_functor_theorem import AdjointFunctorTheoremShell
from .reflective_subcategory import ReflectiveSubcategoryShell
from .coreflective_subcategory import CoreflectiveSubcategoryShell

Adjunction = AdjunctionShell

__all__ = [
    "AdjunctionShell",
    "Adjunction",
    "UnitShell",
    "CounitShell",
    "HomSetAdjunctionShell",
    "MatePair",
    "GaloisConnectionShell",
    "MonotonePair",
    "AdjointFunctorTheoremShell",
    "ReflectiveSubcategoryShell",
    "CoreflectiveSubcategoryShell",
]

