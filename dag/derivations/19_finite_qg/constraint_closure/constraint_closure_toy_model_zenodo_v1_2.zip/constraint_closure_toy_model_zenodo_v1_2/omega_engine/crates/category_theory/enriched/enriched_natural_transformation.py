"""enriched_natural_transformation shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class EnrichedNaturalTransformation:
    """Best-effort enriched natural transformation shell."""

    label: str
    source_functor: str = ""
    target_functor: str = ""
    base_monoidal_v: str = ""
    components_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "EnrichedNaturalTransformation":
        return cls(label=label)

    @classmethod
    def between(
        cls,
        label: str,
        source_functor: str,
        target_functor: str,
        base_monoidal_v: str,
    ) -> "EnrichedNaturalTransformation":
        return cls(
            label=label,
            source_functor=source_functor,
            target_functor=target_functor,
            base_monoidal_v=base_monoidal_v,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.source_functor:
            raise ValueError("empty source_functor")
        if not self.target_functor:
            raise ValueError("empty target_functor")
        if not self.base_monoidal_v:
            raise ValueError("empty base_monoidal_v")



