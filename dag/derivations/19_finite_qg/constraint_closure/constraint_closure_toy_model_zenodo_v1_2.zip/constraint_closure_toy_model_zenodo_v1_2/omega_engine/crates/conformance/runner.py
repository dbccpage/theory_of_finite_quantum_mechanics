r"""
The conformance runner: check *this* implementation against the language-neutral vectors.

AuthorityEffect: None.

``vectors/*.json`` is the **specification**. It contains no Python and names no language, so
a Rust port is checked against the same file. That is the point: "port Phi_1 to Rust" stops
being a prose instruction and becomes a decidable question --- does the port reproduce
``vectors/phi1.json``?

This module supplies the Python binding. A Rust runner reading the same JSON would supply
the other. Nothing here is the spec; the JSON is.
"""

from __future__ import annotations
import json
import pathlib
from typing import Any, Callable, Dict, List

import numpy as np

VECTOR_DIR = pathlib.Path(__file__).parent / "vectors"

__all__ = ["load_vectors", "run_quantity", "run_all", "BINDINGS"]


def load_vectors(quantity: str) -> Dict[str, Any]:
    """Load one quantity's spec."""
    path = VECTOR_DIR / f"{quantity}.json"
    if not path.exists():
        raise FileNotFoundError(f"no conformance vectors for {quantity!r} at {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def available() -> List[str]:
    return sorted(p.stem for p in VECTOR_DIR.glob("*.json"))


# --------------------------------------------------------------------------- bindings
# Each binding maps ONE vector's `input` to a dict of observed values, keyed to match the
# vector's `expect`. Bindings contain no expectations of their own.


def _bind_phi1(inp: Dict[str, Any]) -> Dict[str, Any]:
    from omega_engine.crates.solver.phi1_lp import Phi1Uncertified, phi1, solve_phi1_dual_witness

    verts, edges = inp["vertices"], [tuple(e) for e in inp["edges"]]
    omega = np.asarray(inp["omega"], dtype=float)
    out: Dict[str, Any] = {"raw_l1": float(np.sum(np.abs(omega)))}

    if inp.get("simulate_primal_failure"):
        import scipy.optimize as opt

        real, calls = opt.linprog, {"n": 0}

        def fail_first(*a, **k):
            calls["n"] += 1
            if calls["n"] == 1:
                class Failed:
                    success, x, fun = False, None, None
                return Failed()
            return real(*a, **k)

        opt.linprog = fail_first
        try:
            out["is_certified"] = solve_phi1_dual_witness(verts, edges, omega)["is_certified"]
        finally:
            opt.linprog = real
        return out

    receipt = solve_phi1_dual_witness(verts, edges, omega)
    out["phi1"] = receipt["min_l1"]
    out["is_certified"] = receipt["is_certified"]
    out["dual_feasible"] = bool(
        np.all(np.abs(receipt["dual_phi"]) <= 1.0 + 1e-7)
        and float(np.max(np.abs(_d0(verts, edges).T @ receipt["dual_phi"]))) < 1e-7
    )
    out["duality_gap_below"] = abs(receipt["duality_gap"])

    if "gauge_shift" in inp:
        shifted = omega + _d0(verts, edges) @ np.asarray(inp["gauge_shift"], dtype=float)
        try:
            out["invariant_under_gauge_shift"] = bool(
                abs(phi1(verts, edges, shifted) - receipt["min_l1"]) < 1e-6
            )
        except Phi1Uncertified:
            out["invariant_under_gauge_shift"] = False
    return out


def _d0(vertices, edges) -> np.ndarray:
    idx = {v: i for i, v in enumerate(vertices)}
    m = np.zeros((len(edges), len(vertices)))
    for i, (u, v) in enumerate(edges):
        m[i, idx[u]] -= 1.0
        m[i, idx[v]] += 1.0
    return m


def _bind_betti(inp: Dict[str, Any]) -> Dict[str, Any]:
    from omega_engine.crates.homology_theory.finite_graph import FiniteGraph
    from omega_engine.crates.homology_theory.snf_betti import betti_numbers, smith_normal_form_diagonal

    if "matrix" in inp:
        mat = np.array(inp["matrix"], dtype=int)
        factors = smith_normal_form_diagonal(mat)
        return {
            "raises": False,
            "invariant_factors": factors,
            "det_abs": int(round(abs(float(np.linalg.det(mat))))),
        }

    g = FiniteGraph(
        vertices=inp["vertices"],
        edges=[tuple(e) for e in inp["edges"]],
        faces=[tuple(f) for f in inp.get("faces", [])],
    )
    r = betti_numbers(g)
    return {
        "b0": r["b0"],
        "b1": r["b1"],
        "b2": r["b2"],
        "euler_identity_holds": r["euler_identity_holds"],
    }


def _bind_interference(inp: Dict[str, Any]) -> Dict[str, Any]:
    from omega_engine.crates.quantum_physics import interference as itf

    if "c_a" in inp:
        ca = np.asarray(inp["c_a"], dtype=complex)
        cb = np.asarray(inp["c_b"], dtype=complex)
        da, db = itf.diagonal_data(ca), itf.diagonal_data(cb)
        ia, ib = itf.interfered_weight(ca), itf.interfered_weight(cb)
        return {
            "diagonal_a": da.tolist(),
            "diagonal_b": db.tolist(),
            "interfered_a": ia,
            "interfered_b": ib,
            "diagonal_identical": bool(np.allclose(da, db, atol=1e-15)),
            "interfered_differs": bool(not np.isclose(ia, ib, atol=1e-12)),
        }
    if "w1" in inp:
        s = itf.phase_sweep(inp["w1"], inp["w2"])
        return {
            "max_constructive": s["max_constructive"],
            "max_destructive": s["max_destructive"],
            "vanishes_somewhere": s["vanishes_somewhere"],
        }
    f = itf.superposition_quotient_fiber(inp["n_sectors"])
    return {
        "global_phase_invisible": f["global_phase_invisible"],
        "relative_phase_visible": f["relative_phase_visible"],
    }


def _bind_wigner_yanase(inp: Dict[str, Any]) -> Dict[str, Any]:
    from omega_engine.crates.quantum_physics.primitives import SIGMA_X, SIGMA_Y, SIGMA_Z
    from omega_engine.crates.quantum_physics import cptp_channel as cptp

    obs = {
        "Z": SIGMA_Z.astype(complex),
        "X": SIGMA_X.astype(complex),
        "X+Y": (SIGMA_X + SIGMA_Y).astype(complex),
    }[inp["observable"]]

    kraus = {
        "dephasing": lambda: cptp.dephasing_kraus(inp.get("p", 0.3)),
        "amplitude_damping": lambda: cptp.amplitude_damping_kraus(inp.get("gamma", 0.25)),
        "hadamard": cptp.hadamard_kraus,
        "half_identity": lambda: [0.5 * np.eye(2, dtype=complex)],
    }[inp["channel"]]()

    bx, by, bz = inp["rho_bloch"]
    rho = 0.5 * (np.eye(2, dtype=complex) + bx * SIGMA_X + by * SIGMA_Y + bz * SIGMA_Z)

    before = cptp.wigner_yanase_skew_information(rho, obs)
    after = cptp.wigner_yanase_skew_information(cptp.apply_channel(rho, kraus), obs)
    res = cptp.solve_covariant_wigner_yanase_monotonicity(rho, kraus, obs)

    return {
        "is_trace_preserving": res["is_trace_preserving"],
        "is_unital": res["is_unital"],
        "is_covariant": res["is_covariant"],
        "hypotheses_hold": res["hypotheses_hold"],
        "i_before": before,
        "i_after": after,
        "increases": bool(after > before + 1e-12),
        "delta_i": res["delta_i"],
        "delta_i_positive": bool(res["delta_i"] > 0.0),
        "certifies": bool("VERIFIED" in res["status"]),
        "state_is_fixed_point": bool(
            np.allclose(cptp.apply_channel(rho, kraus), rho, atol=1e-12)
        ),
    }


def _bind_dda_cascade(inp: Dict[str, Any]) -> Dict[str, Any]:
    """Binds the letter modules under anomalon/code.

    Loaded by explicit file path, not by ``import f`` -- single-letter module names are a
    collision waiting to happen on any sys.path.
    """
    import importlib.util

    # This runner moved with the qam consolidation: it now lives INSIDE
    # anomalon, and the letter files were de-lettered. The vector
    # inputs keep their frozen "module": "f"/"i"/"j" fields; the map below is
    # the letter -> recovered-module binding.
    code_dir = pathlib.Path(__file__).resolve().parents[2] / "coda"
    letter_modules = {
        "f": "projection_obstruction_engine.py",
        "i": "graph_coloring_cohomology.py",
        "j": "dda_cascade_router.py",
    }

    def _letter(name: str):
        spec = importlib.util.spec_from_file_location(
            f"_dda_{name}", code_dir / letter_modules[name]
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    if inp["module"] == "f":
        ProjectionObstructionEngine = _letter("f").ProjectionObstructionEngine

        v = np.asarray(inp["velocity"], dtype=float)
        dpi = np.zeros((v.size, v.size)) if inp["dpi"] == "zero" else np.eye(v.size)
        eng = ProjectionObstructionEngine(Pi=lambda x: x, DPi=lambda x: dpi, velocity=lambda x: v)
        verdict, mass = eng.evaluate(None)
        return {"obstruction_mass": mass, "verdict": verdict}

    if inp["module"] == "j":
        DdaCascadeRouter = _letter("j").DdaCascadeRouter

        if inp["carrier"] == "five_cycle":
            n, edges = 5, [(i, (i + 1) % 5) for i in range(5)]
            w = np.ones(5)
        else:  # b1_two_witness -- the measured worst separation
            n = 6
            edges = [(0, 1), (0, 2), (0, 4), (1, 3), (1, 4), (1, 5), (2, 3), (4, 5)]
            w = np.array([1.0, 2.0, 0.0, 0.0, 1.0, -1.0, -3.0, -2.0])
        d0 = np.zeros((len(edges), n))
        for i, (u, v_) in enumerate(edges):
            d0[i, u] = -1.0
            d0[i, v_] = 1.0
        r = DdaCascadeRouter(d0, np.zeros((0, len(edges))))
        return r.phi1_comparison(w)

    # module == "i"
    GraphColoringCohomology = _letter("i").GraphColoringCohomology

    import itertools

    g = GraphColoringCohomology(3, [(0, 2), (1, 2)], 2)
    gap = g.soundness_gap()
    raw_exact = all(
        g.has_conflict(list(c)) == any(list(c)[u] == list(c)[v] for u, v in g.edges)
        for c in itertools.product(range(g.k), repeat=g.n)
    )
    betti_1 = len(g.edges) - int(np.linalg.matrix_rank(g.d0))
    return {
        "raw_test_is_exact": bool(raw_exact),
        "cohomological_false_negatives_exist": bool(gap["false_negatives"] > 0),
        "false_negatives": gap["false_negatives"],
        "false_positives": gap["false_positives"],
        "betti_1": betti_1,
    }


def _bind_trace_norm_quotient(inp: Dict[str, Any]) -> Dict[str, Any]:
    """Every carrier, cochain and matrix below is DECODED from the vector, never held here."""
    from . import decode as dc
    from omega_engine.crates.quantum_physics.bipartite_carrier import BipartiteEdge
    from omega_engine.crates.quantum_physics.primitives import trace_norm
    from omega_engine.crates.functional.trace_norm_quotient import (
        dual_ball_diameter_identity,
        dual_ball_slack,
        trace_distance_dual_ball_slack,
        trace_norm_quotient,
    )

    where = "trace_norm_quotient"
    case = dc.pick_case(
        inp,
        (
            "phi_tr_from_carrier_and_cochain",
            "dual_ball_slack",
            "dual_ball_diameter_identity",
            "projection_on_bipartite_witness",
        ),
        where=where,
    )

    if case in ("dual_ball_slack", "dual_ball_diameter_identity"):
        dc.strict_keys(inp, ("case", "matrix"), where=where)
        m = dc.complex_matrix(inp["matrix"], where=f"{where}.matrix")
        if case == "dual_ball_slack":
            return {
                "op_norm_slack": dual_ball_slack(m),
                "trace_distance_slack": trace_distance_dual_ball_slack(m),
            }
        ident = dual_ball_diameter_identity(m)
        return {
            "diameter": ident["diameter"],
            "op_norm_at_optimal_shift": ident["op_norm_at_optimal_shift"],
            "identity_holds": ident["identity_holds"],
        }

    if case == "projection_on_bipartite_witness":
        dc.strict_keys(inp, ("case", "hamiltonian", "state"), where=where)
        h = dc.complex_matrix(inp["hamiltonian"], where=f"{where}.hamiltonian")
        psi = dc.complex_vector(inp["state"], where=f"{where}.state")
        e = BipartiteEdge(hamiltonian=h, rho0=np.outer(psi, psi.conj()))
        _, rddot = e.derivatives()
        raw, proj = trace_norm(rddot), trace_norm(e.Q_e(rddot))
        return {
            "raw_rho_ddot_trace_norm": raw,
            "projected_trace_norm": proj,
            "projection_raises_the_norm": bool(proj > raw + 1e-9),
        }

    # phi_tr_from_carrier_and_cochain
    dc.strict_keys(inp, ("case", "carrier", "cochain"), where=where)
    g = dc.graph(inp["carrier"], where=where)
    spec = inp["cochain"]
    construct = dc.pick_case(
        {"case": spec.get("construct")},
        ("coboundary_of_vertex_potentials", "explicit_edge_matrices"),
        where=f"{where}.cochain.construct",
    )
    if construct == "coboundary_of_vertex_potentials":
        dc.strict_keys(spec, ("construct", "vertex_potentials"), where=f"{where}.cochain")
        alphas = dc.decoded_matrices(
            spec["vertex_potentials"], where=f"{where}.cochain.vertex_potentials"
        )
        if len(alphas) != g.n_vertices:
            raise dc.VectorSpecError(
                f"{where}.cochain: {len(alphas)} potentials for {g.n_vertices} vertices"
            )
        d0 = g.d0_matrix()
        deltas = [
            sum(d0[e, v] * alphas[v] for v in range(g.n_vertices)) for e in range(g.n_edges)
        ]
    else:
        dc.strict_keys(spec, ("construct", "edge_matrices"), where=f"{where}.cochain")
        deltas = dc.decoded_matrices(spec["edge_matrices"], where=f"{where}.cochain.edge_matrices")
        if len(deltas) != g.n_edges:
            raise dc.VectorSpecError(
                f"{where}.cochain: {len(deltas)} matrices for {g.n_edges} edges"
            )

    r = trace_norm_quotient(g, deltas)
    return {
        "phi_tr": r["phi_tr"],
        "raw_trace_norm_sum": r["raw_trace_norm_sum"],
        "dual_value": r["dual_value"],
        "dual_feasible": r["dual_feasible"],
        "certified": r["certified"],
        "is_exact_repair": r["is_exact_repair"],
        # SIGNED, and reported alongside the violation flag. `abs(gap)` would certify a dual
        # ABOVE the primal, which is not a weak-duality certificate at all.
        "duality_gap_signed": r["duality_gap"],
        "weak_duality_violated": r["weak_duality_violated"],
        "dual_is_a_lower_bound": bool(r["duality_gap"] >= -1e-9),
    }


def _bind_holonomy(inp: Dict[str, Any]) -> Dict[str, Any]:
    """Carrier, connection, gauge and potentials are all DECODED from the vector."""
    from . import decode as dc
    from omega_engine.crates.holonomy_theory import holonomy_curvature as hc

    where = "holonomy"
    case = dc.pick_case(
        inp,
        (
            "gauge_invariance",
            "coboundary_flatness",
            "curvature_agreement",
            "connection_laplacian",
        ),
        where=where,
    )

    if case == "gauge_invariance":
        dc.strict_keys(inp, ("case", "carrier", "connection", "gauge", "cycle"), where=where)
        g = dc.graph(inp["carrier"], where=where)
        conn = dc.unit_phase_connection(inp["connection"], g.n_edges, where=f"{where}.connection")
        gauge = dc.unit_phase_connection(inp["gauge"], g.n_vertices, where=f"{where}.gauge")
        r = hc.holonomy_is_gauge_invariant(g, conn, tuple(inp["cycle"]), gauge)
        return {
            "invariant": r["invariant"],
            "curvature_phase": r["curvature_phase"],
            "is_flat": r["is_flat"],
            "gauge_actually_moves_the_connection": bool(
                not np.allclose(hc.gauge_transform(g, conn, gauge), conn)
            ),
        }

    if case == "coboundary_flatness":
        dc.strict_keys(inp, ("case", "carrier", "vertex_potentials"), where=where)
        g = dc.graph(inp["carrier"], where=where)
        theta = dc.real_vector(
            inp["vertex_potentials"], g.n_vertices, where=f"{where}.vertex_potentials"
        )
        r = hc.coboundary_loop_zero_holonomy(g, theta)
        return {
            "all_flat": r["all_flat"],
            "max_curvature_phase_below": r["max_curvature_phase"],
        }

    if case == "curvature_agreement":
        dc.strict_keys(inp, ("case", "carrier", "additive_potential"), where=where)
        g = dc.graph(inp["carrier"], where=where)
        pot = dc.real_vector(
            inp["additive_potential"], g.n_edges, where=f"{where}.additive_potential"
        )
        r = hc.curvature_agreement(g, pot)
        kf = [float(x) for x in r["K_f_additive"]]
        ph = [float(x) for x in r["holonomy_phase"]]
        return {
            "K_f": kf,
            "holonomy_phase": ph,
            "agree_mod_2pi": r["agree_mod_2pi"],
            "any_wrapping_occurred": r["any_wrapping_occurred"],
            "differ_directly": bool(any(abs(a - b) > 1e-6 for a, b in zip(kf, ph))),
        }

    # connection_laplacian
    dc.strict_keys(inp, ("case", "carrier", "connection"), where=where)
    g = dc.graph(inp["carrier"], where=where)
    conn = dc.unit_phase_connection(inp["connection"], g.n_edges, where=f"{where}.connection")
    r = hc.laplacian_is_hermitian_psd(g, conn)
    return {
        "is_hermitian": r["is_hermitian"],
        "is_psd": r["is_psd"],
        "min_eigenvalue": r["min_eigenvalue"],
    }


BINDINGS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    "phi1": _bind_phi1,
    "betti": _bind_betti,
    "interference": _bind_interference,
    "wigner_yanase": _bind_wigner_yanase,
    "dda_cascade": _bind_dda_cascade,
    "trace_norm_quotient": _bind_trace_norm_quotient,
    "holonomy": _bind_holonomy,
}


# ------------------------------------------------------------------------------ compare


def _matches(observed: Any, expected: Any, key: str, tol: float) -> bool:
    # An absent key is a MISMATCH, not a crash. A binding that omits a quantity the vector
    # asks for has failed that vector; it must not take the whole run down with a TypeError.
    if observed is None and expected is not None:
        return False
    if key in ("duality_gap_below", "max_curvature_phase_below"):
        return isinstance(observed, (int, float)) and float(observed) < float(expected)
    if isinstance(expected, bool):
        return bool(observed) is expected
    if isinstance(expected, (int, float)):
        return isinstance(observed, (int, float)) and abs(float(observed) - float(expected)) <= tol
    if isinstance(expected, list):
        try:
            return len(observed) == len(expected) and all(
                abs(float(a) - float(b)) <= tol for a, b in zip(observed, expected)
            )
        except (TypeError, ValueError):
            return list(observed) == list(expected)
    return observed == expected


def run_quantity(quantity: str) -> Dict[str, Any]:
    """Run every vector for one quantity. Residual = number of failing vectors."""
    spec = load_vectors(quantity)
    bind = BINDINGS.get(quantity)
    if bind is None:
        return {
            "quantity": quantity,
            "residual": len(spec["vectors"]),
            "failures": [{"id": v["id"], "reason": "no binding for this implementation"} for v in spec["vectors"]],
            "checked": len(spec["vectors"]),
            "authority_effect": "None",
        }

    failures: List[Dict[str, Any]] = []
    for vec in spec["vectors"]:
        tol = float(vec.get("tol", 1e-9))
        try:
            observed = bind(vec["input"])
        except Exception as exc:
            if vec["expect"].get("raises") is True:
                continue
            failures.append({"id": vec["id"], "reason": f"{type(exc).__name__}: {exc}", "why": vec["why"]})
            continue
        bad = {
            k: {"expected": e, "observed": observed.get(k, "<absent>")}
            for k, e in vec["expect"].items()
            if not _matches(observed.get(k), e, k, tol)
        }
        if bad:
            failures.append({"id": vec["id"], "mismatches": bad, "why": vec["why"]})

    return {
        "quantity": quantity,
        "source": spec.get("source", ""),
        "contract": spec.get("contract", ""),
        # Per-quantity lock. Surfaces converge at different rates, so enforcement is
        # per-quantity rather than one switch: freeze what has settled, leave the rest open.
        "enforcement": spec.get("enforcement", "report"),
        "checked": len(spec["vectors"]),
        "residual": len(failures),
        "terminal": "ExactConformance" if not failures else "ClosedResidual",
        "failures": failures,
        "authority_effect": "None",
    }


def run_all() -> Dict[str, Any]:
    """Run every quantity that has vectors."""
    results = {q: run_quantity(q) for q in available()}
    total = sum(r["residual"] for r in results.values())
    # Only LOCKED quantities contribute to the blocking residual.
    blocking = sum(
        r["residual"] for r in results.values() if r.get("enforcement") == "block"
    )
    locked = sorted(q for q, r in results.items() if r.get("enforcement") == "block")
    return {
        "total_residual": total,
        "blocking_residual": blocking,
        "locked_quantities": locked,
        "unlocked_quantities": sorted(set(results) - set(locked)),
        "terminal": "ExactConformance" if total == 0 else "ClosedResidual",
        "quantities": results,
        "vectors_checked": sum(r["checked"] for r in results.values()),
        "authority_effect": "None",
    }



