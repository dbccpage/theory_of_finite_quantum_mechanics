"""end shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class End:
    """Best-effort shell for an end ∫_c F(c,c) of a bifunctor."""

    label: str
    bifunctor_ref: str = ""
    indexing_category_ref: str = ""
    end_object: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "End":
        return cls(label=label)

    @classmethod
    def of_bifunctor(
        cls,
        label: str,
        bifunctor_ref: str,
        indexing_category_ref: str,
        end_object: str,
    ) -> "End":
        return cls(
            label=label,
            bifunctor_ref=bifunctor_ref,
            indexing_category_ref=indexing_category_ref,
            end_object=end_object,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.bifunctor_ref:
            raise ValueError("empty bifunctor_ref")
        if not self.indexing_category_ref:
            raise ValueError("empty indexing_category_ref")
        if not self.end_object:
            raise ValueError("empty end_object")



