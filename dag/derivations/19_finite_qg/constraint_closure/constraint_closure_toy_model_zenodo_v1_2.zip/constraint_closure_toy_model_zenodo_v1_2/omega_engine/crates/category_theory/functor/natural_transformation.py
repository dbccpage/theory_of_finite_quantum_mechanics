"""natural_transformation shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class NaturalTransformation:
    """Best-effort shell for a natural transformation between labeled functors."""

    label: str
    source_functor: str = ""
    target_functor: str = ""
    components: List[Tuple[str, str]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "NaturalTransformation":
        return cls(label=label)

    @classmethod
    def between(
        cls, label: str, source_functor: str, target_functor: str
    ) -> "NaturalTransformation":
        return cls(
            label=label,
            source_functor=source_functor,
            target_functor=target_functor,
        )

    def with_components(
        self, components: List[Tuple[str, str]]
    ) -> "NaturalTransformation":
        self.components = list(components)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.source_functor:
            raise ValueError("empty source_functor")
        if not self.target_functor:
            raise ValueError("empty target_functor")
        for i, (obj, mor) in enumerate(self.components):
            if not obj or not mor:
                raise ValueError(f"empty component tag at index {i}")



