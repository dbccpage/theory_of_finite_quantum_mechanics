from typing import List
from omega_engine.crates.contract_core.kinds import (
    AuthorityEffect,
    ComponentRole,
    ContractStatus,
    Capability,
)
from omega_engine.crates.contract_core.schema import (
    ConstitutionalBlock,
    ContractDescriptor,
    ArtifactFamily,
    AuthorityLayer,
    EffectLawDecl,
)


def expected_layer_for_family(family: ArtifactFamily) -> AuthorityLayer:
    if (
        family == ArtifactFamily.StructureArtifact
        or str(family) == "ArtifactFamily.StructureArtifact"
        or family.value == "StructureArtifact"
    ):
        return AuthorityLayer.Structure
    elif (
        family == ArtifactFamily.EvidenceEnvelope or family.value == "EvidenceEnvelope"
    ):
        return AuthorityLayer.Evidence
    elif family == ArtifactFamily.FactEnvelope or family.value == "FactEnvelope":
        return AuthorityLayer.Fact
    elif (
        family == ArtifactFamily.DecisionEnvelope or family.value == "DecisionEnvelope"
    ):
        return AuthorityLayer.Judgment
    elif family == ArtifactFamily.ActionLicense or family.value == "ActionLicense":
        return AuthorityLayer.Action
    elif family == ArtifactFamily.Action or family.value == "Action":
        return AuthorityLayer.Action
    elif family == ArtifactFamily.Record or family.value == "Record":
        return AuthorityLayer.Record
    raise ValueError(f"Unknown family: {family}")


def validate_constitutional_block(block: ConstitutionalBlock) -> None:
    if block.authority_layer in block.forbidden_later_layers:
        raise ValueError("constitution cannot forbid its own authority layer")

    expected = expected_layer_for_family(block.emits)
    if block.authority_layer != expected:
        raise ValueError(f"{block.emits.name} must use {expected.name} authority layer")

    if block.authority_layer in (AuthorityLayer.Structure, AuthorityLayer.Fact):
        if not block.contract_dependencies and not block.law_refs:
            raise ValueError(
                "Structure and Fact layers require at least one contract_dependency or law_ref"
            )

    if "schema_hash" not in block.replay_certificates:
        raise ValueError("constitution must require 'schema_hash' certificate")


def validate_contract_descriptor(desc: ContractDescriptor) -> None:
    # Validate common
    if not desc.id or not desc.id.strip():
        raise ValueError("contract id must not be empty")
    if not desc.name or not desc.name.strip():
        raise ValueError("contract name must not be empty")

    if desc.constitution is not None:
        desc.constitution.validate()

    role = desc.role
    if role == ComponentRole.DeclaredActionCandidate:
        validate_declared_action_candidate(desc)
    elif role == ComponentRole.CheckedPacket:
        validate_checked_packet(desc)
    elif role == ComponentRole.Certificate:
        validate_certificate_artifact(desc)
    elif role == ComponentRole.CertificateStore:
        validate_certificate_store(desc)
    elif role == ComponentRole.CertificateApiInterface:
        validate_certificate_api_interface(desc)
    elif role == ComponentRole.Evaluator:
        validate_evaluator(desc)
    elif role == ComponentRole.Validator:
        validate_validator(desc)
    elif role == ComponentRole.Diagnostic:
        validate_diagnostic(desc)
    elif role == ComponentRole.HealthModel:
        validate_health_model(desc)
    elif role == ComponentRole.Observable:
        validate_observable(desc)
    elif role == ComponentRole.Measurement:
        validate_measurement(desc)
    elif role == ComponentRole.Engine:
        validate_engine(desc)
    elif role == ComponentRole.Witness:
        validate_witness(desc)
    elif role == ComponentRole.Policy:
        if desc.id == "anomalon.policy":
            validate_policy(desc)
    elif role == ComponentRole.Replay:
        validate_replay(desc)
    elif role == ComponentRole.Pipeline:
        validate_pipeline(desc)
    elif role == ComponentRole.LiftLicense:
        validate_lift_license(desc)
    elif role == ComponentRole.Trace:
        validate_trace(desc)
    elif role == ComponentRole.Search:
        validate_search(desc)
    elif role == ComponentRole.Solver:
        validate_solver(desc)
    elif role == ComponentRole.Kernel:
        validate_kernel(desc)
    elif role == ComponentRole.LlmAdapter:
        validate_llm_adapter(desc)
    elif role == ComponentRole.SymbolGame:
        validate_symbol_game(desc)
    elif role == ComponentRole.TerminalMapper:
        validate_terminal_mapper(desc)
    elif role == ComponentRole.Terminalizer:
        validate_terminalizer(desc)
    elif role == ComponentRole.AuthInterface:
        validate_auth_interface(desc)
    elif role == ComponentRole.Packetization:
        validate_packetization(desc)
    elif role == ComponentRole.MathObject:
        validate_math_object(desc)
    elif role == ComponentRole.MathComputation:
        validate_math_computation(desc)


def forbid_capability(desc: ContractDescriptor, cap: Capability, message: str) -> None:
    if not desc.capabilities.forbids(cap):
        raise ValueError(message)


def require_constitution(
    desc: ContractDescriptor, family: ArtifactFamily, layer: AuthorityLayer
) -> None:
    if desc.constitution is None:
        raise ValueError("contract requires constitution block")
    if desc.constitution.emits != family:
        raise ValueError(f"contract must emit {family.name}")
    if desc.constitution.authority_layer != layer:
        raise ValueError(f"contract must use {layer.name} authority layer")


def validate_declared_action_candidate(desc: ContractDescriptor) -> None:
    if desc.domain_type is None:
        raise ValueError("DeclaredActionCandidate requires domain_type")
    if desc.codomain_type is None:
        raise ValueError("DeclaredActionCandidate requires codomain_type")
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError(
            "DeclaredActionCandidate must have authority_effect = EvidenceOnly"
        )
    if desc.laws is None:
        raise ValueError("DeclaredActionCandidate requires laws declared as claims")

    if desc.constraints.search_forbidden is not True:
        has_license = desc.requires is not None and "search" in desc.requires.licenses
        if not has_license:
            raise ValueError("search must be forbidden unless explicitly licensed")

    if desc.constraints.hidden_state_forbidden is not True:
        has_license = (
            desc.requires is not None and "hidden_state" in desc.requires.licenses
        )
        if not has_license:
            raise ValueError(
                "hidden state must be forbidden unless explicitly licensed"
            )

    if desc.constraints.mutation_forbidden is not True:
        has_license = desc.requires is not None and "mutation" in desc.requires.licenses
        if not has_license:
            raise ValueError("mutation must be forbidden unless explicitly licensed")

    if desc.operator_class is not None:
        raise ValueError(
            "DeclaredActionCandidate must not declare accepted operator_class; classifier owns E/I/C/R/M"
        )


def validate_certificate_artifact(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.EvidenceEnvelope, AuthorityLayer.Evidence)
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("certificate must have authority_effect = EvidenceOnly")
    if desc.constraints.immutable_after_emit is not True:
        raise ValueError("certificate must be immutable after emit")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("certificate must forbid mutation")
    if desc.constraints.typed_output_required is not True:
        raise ValueError("certificate must require typed output")
    if desc.constraints.signature_required is not True:
        raise ValueError("certificate must require signature")
    if desc.constraints.certificate_hash_required is not True:
        raise ValueError("certificate must require certificate hash")
    if desc.constraints.policy_hash_required is not True:
        raise ValueError("certificate must require policy hash")
    if desc.constraints.policy_version_required is not True:
        raise ValueError("certificate must bind policy version")
    if desc.constraints.request_hash_required is not True:
        raise ValueError("certificate must require request hash")
    if desc.constraints.replay_required is not True:
        raise ValueError("certificate must require replay")
    if desc.replay is None or not desc.replay.required:
        raise ValueError("certificate must declare replay block")
    if desc.witnesses is None or not desc.witnesses.required:
        raise ValueError("certificate must declare witness requirements")

    forbid_capability(
        desc, Capability.Terminalization, "certificate must not terminalize"
    )
    forbid_capability(desc, Capability.SolverExecution, "certificate must not execute")
    forbid_capability(
        desc, Capability.PolicyInterpretation, "certificate must not interpret policy"
    )


def validate_evaluator(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.DecisionEnvelope, AuthorityLayer.Judgment)
    if desc.authority_effect != AuthorityEffect.RequestsDecision:
        raise ValueError("evaluator must have authority_effect = RequestsDecision")
    if desc.subject_type is None:
        raise ValueError("evaluator requires subject_type")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("evaluator must forbid mutation")
    if desc.constraints.typed_output_required is not True:
        raise ValueError("evaluator must emit typed evaluation result")
    if desc.constraints.runtime_orchestration_forbidden is not True:
        raise ValueError("evaluator must not orchestrate runtime")
    if desc.evaluates_outputs_of is not None:
        raise ValueError(
            "evaluator must not declare evaluates_outputs_of; policy owns admissibility"
        )

    forbid_capability(desc, Capability.ComputePhi, "evaluator must not recompute phi")
    forbid_capability(
        desc, Capability.ComputeGamma, "evaluator must not recompute gamma"
    )


def validate_validator(desc: ContractDescriptor) -> None:
    if (
        desc.authority_effect == AuthorityEffect.FactOnly
        and desc.constraints.checker_boundary_required is not True
    ):
        raise ValueError("FactOnly validator requires checker boundary")
    if desc.authority_effect not in (
        AuthorityEffect.EvidenceOnly,
        AuthorityEffect.FactOnly,
    ):
        raise ValueError("validator must be EvidenceOnly or scoped FactOnly")
    if desc.subject_type is None:
        raise ValueError("validator unit requires subject_type")
    if desc.constraints.read_only is not True:
        raise ValueError("validator must be read-only")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("validator must forbid mutation")
    if desc.constraints.typed_output_required is not True:
        raise ValueError("validator must require typed output")


def validate_checked_packet(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.FactEnvelope, AuthorityLayer.Fact)
    if desc.authority_effect != AuthorityEffect.FactOnly:
        raise ValueError("checked packet must have authority_effect = FactOnly")
    if desc.constraints.checker_boundary_required is not True:
        raise ValueError("checked packet requires checker boundary")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("checked packet must forbid mutation")
    if desc.constraints.typed_output_required is not True:
        raise ValueError("checked packet must require typed output")


def validate_diagnostic(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.EvidenceEnvelope, AuthorityLayer.Evidence)
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("diagnostic must have authority_effect = EvidenceOnly")


def validate_observable(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.EvidenceEnvelope, AuthorityLayer.Evidence)
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("observable must have authority_effect = EvidenceOnly")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("observable must forbid mutation")
    if desc.constraints.typed_output_required is not True:
        raise ValueError("observable must require typed output")
    if desc.constraints.runtime_orchestration_forbidden is not True:
        raise ValueError("observable must not orchestrate runtime")


def validate_measurement(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.EvidenceEnvelope, AuthorityLayer.Evidence)
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("measurement must have authority_effect = EvidenceOnly")
    if desc.subject_type is None:
        raise ValueError("measurement requires subject_type")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("measurement must forbid mutation")
    if desc.constraints.typed_output_required is not True:
        raise ValueError("measurement must require typed output")
    if desc.constraints.operator_execution_forbidden is not True:
        raise ValueError("measurement must forbid operator execution")
    if desc.constraints.runtime_orchestration_forbidden is not True:
        raise ValueError("measurement must not orchestrate runtime")


def validate_health_model(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("health model must have authority_effect = EvidenceOnly")


def validate_engine(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.Action, AuthorityLayer.Action)
    if desc.authority_effect != AuthorityEffect.StateTransition:
        raise ValueError("engine must have authority_effect = StateTransition")
    if desc.laws is None or desc.laws.effect != EffectLawDecl.Stateful:
        raise ValueError("engine must have effect=Stateful")
    if desc.runtime_state_type is None:
        raise ValueError("engine requires runtime_state_type")
    if desc.constraints.iteration_forbidden is True:
        raise ValueError("engine must allow iteration")
    if desc.constraints.action_license_required is not True:
        raise ValueError(
            "engine must require action license (ActionLicense) before StateTransition"
        )

    forbid_capability(desc, Capability.ComputePhi, "engine must not compute phi")
    forbid_capability(desc, Capability.ComputeGamma, "engine must not compute gamma")
    forbid_capability(
        desc,
        Capability.PolicyInterpretation,
        "engine must not run policy interpreter or evaluate policy internally",
    )
    forbid_capability(desc, Capability.Evaluation, "engine must not evaluate")
    forbid_capability(
        desc, Capability.CertificateSigning, "engine must not sign certificates"
    )
    forbid_capability(
        desc, Capability.EmitCertificate, "engine must not emit certificates"
    )


def validate_certificate_store(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.None_:
        raise ValueError("certificate store must have authority_effect = None")
    if desc.constraints.immutable_after_emit is not True:
        raise ValueError("certificate store must be immutable after emit")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("certificate store must forbid mutation")
    if desc.constraints.raw_payload_forbidden is not True:
        raise ValueError("certificate store must forbid raw payload exposure")

    forbid_capability(
        desc,
        Capability.RuntimeMutation,
        "certificate store must not overwrite certificates",
    )
    forbid_capability(
        desc,
        Capability.CertificateSigning,
        "certificate store must not sign certificates",
    )


def validate_witness(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.EvidenceEnvelope, AuthorityLayer.Evidence)
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("witness must have authority_effect = EvidenceOnly")

    forbid_capability(desc, Capability.CertificateSigning, "witness must not authorize")
    forbid_capability(
        desc,
        Capability.PolicyInterpretation,
        "witness must not make admissibility decisions",
    )
    forbid_capability(desc, Capability.Terminalization, "witness must not terminalize")


def validate_policy(desc: ContractDescriptor) -> None:
    if desc.id == "anomalon.policy":
        require_constitution(
            desc, ArtifactFamily.DecisionEnvelope, AuthorityLayer.Judgment
        )
    if desc.authority_effect != AuthorityEffect.RequestsDecision:
        raise ValueError("policy must have authority_effect = RequestsDecision")
    if desc.constraints.deterministic is not True:
        raise ValueError("policy must be deterministic")
    if desc.constraints.hidden_state_forbidden is not True:
        raise ValueError("policy must forbid hidden state")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("policy must forbid mutation")
    if desc.constraints.runtime_orchestration_forbidden is not True:
        raise ValueError("policy must not orchestrate runtime")
    if desc.constraints.typed_output_required is not True:
        raise ValueError("policy must require typed output")
    if desc.constraints.policy_version_required is not True:
        raise ValueError("policy must require policy version")

    forbid_capability(desc, Capability.ComputePhi, "policy must not compute metrics")
    forbid_capability(desc, Capability.ComputeGamma, "policy must not compute gamma")
    forbid_capability(
        desc, Capability.ComputeRefusalSignal, "policy must not compute refusal signal"
    )
    forbid_capability(desc, Capability.SolverExecution, "policy must not call solvers")
    forbid_capability(desc, Capability.Terminalization, "policy must not terminalize")


def validate_replay(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.EvidenceEnvelope, AuthorityLayer.Evidence)
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("replay must have authority_effect = EvidenceOnly")

    forbid_capability(
        desc, Capability.RuntimeMutation, "replay must not mutate trace bundle"
    )
    forbid_capability(desc, Capability.Terminalization, "replay must not terminalize")


def validate_pipeline(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.None_:
        raise ValueError("pipeline must have authority_effect = None")

    forbid_capability(
        desc, Capability.CertificateSigning, "pipeline must not sign certificates"
    )
    forbid_capability(
        desc, Capability.RuntimeMutation, "pipeline must not mutate store"
    )


def validate_lift_license(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.ActionLicense, AuthorityLayer.Action)
    if desc.authority_effect != AuthorityEffect.AuthorizesTransition:
        raise ValueError(
            "lift license must have authority_effect = AuthorizesTransition"
        )
    if desc.constraints.scope_bound is not True:
        raise ValueError("lift license must be scope bound")
    if desc.constraints.non_transferable is not True:
        raise ValueError("lift license must be non-transferable")
    if desc.constraints.authority_does_not_exceed_evidence is not True:
        raise ValueError("lift license authority must not exceed evidence")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("lift license must forbid mutation")
    if desc.replay is None or not desc.replay.required:
        raise ValueError("lift license must declare replay block")
    if desc.witnesses is None or not desc.witnesses.required:
        raise ValueError("lift license must declare witness requirements")

    forbid_capability(
        desc,
        Capability.ExecuteStateTransition,
        "lift license must not execute state transitions",
    )
    forbid_capability(
        desc, Capability.RuntimeMutation, "lift license must not mutate runtime"
    )


def validate_trace(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.EvidenceEnvelope, AuthorityLayer.Evidence)
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("trace must have authority_effect = EvidenceOnly")
    if desc.constraints.immutable_after_emit is not True:
        raise ValueError("trace must be immutable after emit")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("trace must forbid mutation")


def validate_search(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("search must have authority_effect = EvidenceOnly")

    forbid_capability(desc, Capability.Terminalization, "search must not terminalize")
    forbid_capability(
        desc, Capability.CertificateSigning, "search must not sign certificates"
    )
    forbid_capability(desc, Capability.Evaluation, "search must not evaluate")


def validate_solver(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("solver must have authority_effect = EvidenceOnly")

    forbid_capability(desc, Capability.Terminalization, "solver must not terminalize")
    forbid_capability(
        desc, Capability.CertificateSigning, "solver must not sign certificates"
    )
    forbid_capability(desc, Capability.Evaluation, "solver must not evaluate")


def validate_kernel(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.None_:
        raise ValueError("kernel must have authority_effect = None")

    forbid_capability(
        desc, Capability.CertificateSigning, "kernel must not sign certificates"
    )


def validate_llm_adapter(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("llm adapter must have authority_effect = EvidenceOnly")

    forbid_capability(
        desc, Capability.CertificateSigning, "llm adapter must not sign certificates"
    )
    forbid_capability(
        desc, Capability.Terminalization, "llm adapter must not terminalize"
    )
    forbid_capability(desc, Capability.Evaluation, "llm adapter must not evaluate")
    forbid_capability(desc, Capability.Validation, "llm adapter must not validate")


def validate_symbol_game(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("symbol game must have authority_effect = EvidenceOnly")

    forbid_capability(
        desc, Capability.CertificateSigning, "symbol game must not sign certificates"
    )
    forbid_capability(
        desc, Capability.Terminalization, "symbol game must not terminalize"
    )


def validate_terminal_mapper(desc: ContractDescriptor) -> None:
    require_constitution(desc, ArtifactFamily.DecisionEnvelope, AuthorityLayer.Judgment)
    if desc.authority_effect != AuthorityEffect.RequestsDecision:
        raise ValueError(
            "terminal mapper must have authority_effect = RequestsDecision"
        )
    if desc.constraints.typed_output_required is not True:
        raise ValueError("terminal mapper must require typed output")

    forbid_capability(
        desc, Capability.ExecuteStateTransition, "terminal mapper must not execute"
    )
    forbid_capability(
        desc, Capability.ActionLicensing, "terminal mapper must not license actions"
    )
    forbid_capability(
        desc,
        Capability.MeasurementComputation,
        "terminal mapper must not compute measurements",
    )
    forbid_capability(
        desc, Capability.CertificateSigning, "terminal mapper must not certify"
    )
    forbid_capability(
        desc, Capability.RuntimeMutation, "terminal mapper must not mutate"
    )
    forbid_capability(
        desc, Capability.ComputePhi, "terminal mapper must not compute phi"
    )
    forbid_capability(
        desc, Capability.ComputeGamma, "terminal mapper must not compute gamma"
    )


def validate_terminalizer(desc: ContractDescriptor) -> None:
    if desc.status == ContractStatus.Deprecated:
        return
    raise ValueError("Terminalizer is deprecated; use TerminalMapper")


def validate_certificate_api_interface(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.None_:
        raise ValueError("certificate api interface must have authority_effect = None")
    if desc.constraints.read_only is not True:
        raise ValueError("certificate api interface must be read-only")
    if desc.constraints.mutation_forbidden is not True:
        raise ValueError("certificate api interface must forbid mutation")
    if desc.constraints.raw_payload_forbidden is not True:
        raise ValueError("certificate api interface must forbid raw payload exposure")
    if desc.constraints.public_signing_forbidden is not True:
        raise ValueError("certificate api interface must forbid public signing")

    forbid_capability(
        desc,
        Capability.CertificateSigning,
        "certificate api interface must not sign certificates",
    )
    forbid_capability(
        desc,
        Capability.EmitCertificate,
        "certificate api interface must not emit certificates",
    )
    forbid_capability(
        desc, Capability.Evaluation, "certificate api interface must not evaluate"
    )
    forbid_capability(
        desc,
        Capability.Terminalization,
        "certificate api interface must not terminalize",
    )
    forbid_capability(
        desc,
        Capability.AuthorityPromotion,
        "certificate api interface must not promote authority",
    )
    forbid_capability(
        desc,
        Capability.RuntimeMutation,
        "certificate api interface must not mutate store",
    )


def validate_packetization(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.EvidenceOnly:
        raise ValueError("packetization must have authority_effect = EvidenceOnly")

    forbid_capability(
        desc,
        Capability.SemanticTruthClaim,
        "packetization must not certify semantic truth",
    )


def validate_math_object(desc: ContractDescriptor) -> None:
    if desc.authority_effect not in (
        AuthorityEffect.None_,
        AuthorityEffect.EvidenceOnly,
    ):
        raise ValueError("math object must be None or EvidenceOnly")

    forbid_capability(desc, Capability.EmitDecision, "math object must not decide")
    forbid_capability(
        desc, Capability.EmitCertificate, "math object must not emit certificates"
    )
    forbid_capability(desc, Capability.EmitAction, "math object must not emit actions")


def validate_math_computation(desc: ContractDescriptor) -> None:
    if desc.authority_effect not in (
        AuthorityEffect.EvidenceOnly,
        AuthorityEffect.FactOnly,
    ):
        raise ValueError("math computation must be EvidenceOnly or scoped FactOnly")

    forbid_capability(desc, Capability.EmitDecision, "math computation must not decide")
    forbid_capability(
        desc, Capability.EmitCertificate, "math computation must not emit certificates"
    )
    forbid_capability(
        desc, Capability.EmitAction, "math computation must not emit actions"
    )


def validate_auth_interface(desc: ContractDescriptor) -> None:
    if desc.authority_effect != AuthorityEffect.None_:
        raise ValueError("auth interface must have authority_effect = None")

    forbid_capability(
        desc, Capability.CertificateSigning, "auth interface must not sign certificates"
    )
    forbid_capability(
        desc, Capability.Terminalization, "auth interface must not terminalize"
    )


def validate_registry(contracts: List[ContractDescriptor]) -> None:
    ids = set()
    for c in contracts:
        try:
            c.validate()
        except Exception as e:
            raise ValueError(f"contract '{c.id}' failed validation: {e}")

        if c.id in ids:
            raise ValueError(f"duplicate contract id: {c.id}")
        ids.add(c.id)



