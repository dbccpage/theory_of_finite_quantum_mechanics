r"""Universe Anomalonica Deformation Theory — Maurer-Cartan Elements & Deformation Complexes.

Governs solutions to the Maurer-Cartan equation:
    d(\tau) + 1/2 [\tau, \tau] = 0
and associated deformation complexes with twisted differential d_\tau = d + [\tau, \cdot].

AuthorityEffect: None.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
from .dgla import DGLA


@dataclass
class MaurerCartanElement:
    r"""Degree 1 element \tau \in L^1."""
    tau: np.ndarray

    def curvature(self, dgla: DGLA) -> np.ndarray:
        r"""Computes curvature F(\tau) = d(\tau) + 1/2 [\tau, \tau] in L^2."""
        tau_arr = np.asarray(self.tau, dtype=float)
        d_tau = dgla.d(1, tau_arr)
        bracket = dgla.lie_bracket(1, tau_arr, 1, tau_arr)
        return d_tau + 0.5 * bracket

    def curvature_norm(self, dgla: DGLA) -> float:
        """L1 norm of curvature."""
        return float(np.sum(np.abs(self.curvature(dgla))))

    def is_maurer_cartan(self, dgla: DGLA, tol: float = 1e-7) -> bool:
        r"""Checks whether F(\tau) = 0 within numerical tolerance."""
        return self.curvature_norm(dgla) <= tol

    def gauge_transform(self, dgla: DGLA, lambda_elem: np.ndarray) -> MaurerCartanElement:
        r"""Infinitesimal gauge transformation: \tau' = \tau + d(\lambda) + [\tau, \lambda] for \lambda \in L^0."""
        lam = np.asarray(lambda_elem, dtype=float)
        d_lam = dgla.d(0, lam)
        tau_lam = dgla.lie_bracket(1, self.tau, 0, lam)
        new_tau = np.asarray(self.tau, dtype=float) + d_lam + tau_lam
        return MaurerCartanElement(tau=new_tau)


@dataclass
class DeformationComplex:
    r"""Deformation complex (L, d_\tau) twisted by a Maurer-Cartan element \tau.

    The twisted differential is defined as:
        d_\tau(x) = d(x) + [\tau, x].
    A fundamental theorem states: (d_\tau)^2 = 0 if and only if \tau is Maurer-Cartan!
    """
    dgla: DGLA
    mc_element: MaurerCartanElement

    def twisted_d(self, deg: int, x: np.ndarray) -> np.ndarray:
        r"""Computes d_\tau(x) = d(x) + [\tau, x] in degree deg + 1."""
        x_arr = np.asarray(x, dtype=float)
        dx = self.dgla.d(deg, x_arr)
        tau_x = self.dgla.lie_bracket(1, self.mc_element.tau, deg, x_arr)
        return dx + tau_x

    def verify_twisted_d_squared(self, deg: int, x: np.ndarray, tol: float = 1e-7) -> Tuple[bool, float]:
        r"""Verifies (d_\tau)^2(x) = 0.

        Returns (is_nilpotent, defect_norm).
        """
        dx = self.twisted_d(deg, x)
        ddx = self.twisted_d(deg + 1, dx)
        defect = float(np.sum(np.abs(ddx)))
        return (defect <= tol, defect)


@dataclass
class ObstructionClass:
    """Obstruction to lifting an n-th order deformation to order n+1."""
    order: int
    obstruction_cocycle: np.ndarray
    is_obstructed: bool

    @classmethod
    def evaluate(cls, dgla: DGLA, tau_order_n: np.ndarray, order: int, tol: float = 1e-7) -> ObstructionClass:
        mc = MaurerCartanElement(tau=tau_order_n)
        curv = mc.curvature(dgla)
        norm = float(np.sum(np.abs(curv)))
        return cls(
            order=order,
            obstruction_cocycle=curv,
            is_obstructed=norm > tol
        )
