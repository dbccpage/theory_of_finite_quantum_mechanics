"""The LGGR(EPK) <-> OE Prime 000/001/002 seam — Python mirror of ``omega_engine.crates.evaluated_path_kernels_local_green_global_red::prime_seam``.

Two Prime implementations exist in this repository and neither was connected to
EPK:

* the **live rail** ``omega_engine.crates.engine.omega_engine_algo_prime_0_engine.AlgoPrimeDdaEngine``
  (phases ``P-1 . P001I . P000 . DDA . P001T . P002 . T``), and
* the **published paper** ``PrimeTriadEngine`` in
  ``research/published/008_engine_runtime/000_oe_prime_algorithms/code/oe_prime_algorithms.py``
  (with the newer contract source at ``ooutwire_docs/universe_coda/universe_coda.py``).

Both are reachable here through :class:`PrimeIntakePort`, :class:`PrimeDescentPort`
and :class:`PrimeContinuationPort`. They are not equivalent, and the difference
matters: the live rail's ``run_prime002_control()`` is a stub that always returns
``PASS``, with no budget and no ``CanContinue_n`` predicate, so it cannot refuse.
:class:`LiveRailPrimeAdapter` therefore does **not** derive continuation from it.

AuthorityEffect: None. Continuation is a predicate a host consults; satisfying it
is not an authorization.
"""

from __future__ import annotations
import importlib.util
import sys
from dataclasses import field
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from omega_engine.crates.evaluated_path_kernels_local_green_global_red.adequacy import AdequacyKind, DetectorAdequacyVerdict
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.verdict import classify, EvaluatorProvenance, LggrVerdict, VerdictKind

__all__ = [
    "LGGR_EPK_OBSERVATION_SCHEMA",
    "PRIME_DESCENT_RECEIPT_SCHEMA",
    "PrimeIntakeOutcome",
    "PrimeDeclarationOutcome",
    "CandidateDeclaration",
    "PrimeDeclarationOrder",
    "LggrEpkObservation",
    "PrimeDescentReceipt",
    "PrimeBudget",
    "ContinuationBlocker",
    "PrimeContinuationInputs",
    "V1_SCHEMA_DISPOSITION",
    "V1_QUARANTINE_REASON",
    "ContinuationEvidence",
    "VerifiedDescentReceipt",
    "PrimeContinuation",
    "PrimeIntakePort",
    "PrimeDescentPort",
    "PrimeContinuationPort",
    "ReferencePrimePorts",
    "LiveRailPrimeAdapter",
    "PublishedPrimeTriadAdapter",
    "PrimeAdapterUnavailable",
]

_MINT_SEAL = object()

V1_SCHEMA_DISPOSITION = "REJECTED_UNSOUND"

V1_QUARANTINE_REASON = (
    "v1 Python evidence is forgeable in-process (duck typing, dataclasses.replace, "
    "reachable mint helpers) and the Rust v1 digest omits the adequacy report. "
    "Python proposes; an external verifier decides."
)

LGGR_EPK_OBSERVATION_SCHEMA = "omega.epk.lggr-observation.v1"
PRIME_DESCENT_RECEIPT_SCHEMA = "omega.epk.prime-descent-receipt.v1"


class PrimeIntakeOutcome(str, Enum):
    """Prime 001 intake. Values are the exact upstream literals, reused not invented."""

    AcceptDeclaration = "ACCEPT_DECLARATION"
    RefusedMissingCarrier = "REFUSED_MISSING_CARRIER"
    RefusedMissingObserver = "REFUSED_MISSING_OBSERVER"
    RefusedMissingWitness = "REFUSED_MISSING_WITNESS"
    AdapterInadequate = "ADAPTER_INADEQUATE"

    def is_refusal(self) -> bool:
        return self is not PrimeIntakeOutcome.AcceptDeclaration


class PrimeDeclarationOutcome(str, Enum):
    """Prime 000 seven-step declaration order (OE001-02).

    Note the ``REFUSE_`` prefix. Upstream ``validate_declaration_order`` uses it
    while ``evaluate_intake`` uses ``REFUSED_``; the difference is preserved rather
    than normalized away.
    """

    AcceptDeclaration = "ACCEPT_DECLARATION"
    RefuseMissingGrounding = "REFUSE_MISSING_GROUNDING"
    RefuseMissingCarrier = "REFUSE_MISSING_CARRIER"
    RefuseMissingObserver = "REFUSE_MISSING_OBSERVER"
    RefuseMissingPrimitiveDifference = "REFUSE_MISSING_PRIMITIVE_DIFFERENCE"
    RefuseMissingZeroRel = "REFUSE_MISSING_ZERO_REL"
    RefuseMissingWitness = "REFUSE_MISSING_WITNESS"

    def is_refusal(self) -> bool:
        return self is not PrimeDeclarationOutcome.AcceptDeclaration


@dataclass(frozen=True, slots=True)
class CandidateDeclaration:
    """Mirrors ``CandidatePacket``."""

    artifact_id: str
    locus_id: str
    problem_family: str
    primitive_difference_proposal: str
    carrier_proposal: str
    zero_rel_proposal: str
    observer_proposal: str
    witness_available: bool = True
    quotient_or_refusal: str = "E"
    adapter_confidence: str = "high"
    status: str = "proposed_only"
    authority_effect: str = field(default="None")

    def evaluate_intake(self) -> PrimeIntakeOutcome:
        """Upstream order: carrier, observer, witness, adapter confidence."""
        if not self.carrier_proposal:
            return PrimeIntakeOutcome.RefusedMissingCarrier
        if not self.observer_proposal:
            return PrimeIntakeOutcome.RefusedMissingObserver
        if not self.witness_available:
            return PrimeIntakeOutcome.RefusedMissingWitness
        if self.adapter_confidence == "inadequate":
            return PrimeIntakeOutcome.AdapterInadequate
        return PrimeIntakeOutcome.AcceptDeclaration


@dataclass(frozen=True, slots=True)
class PrimeDeclarationOrder:
    """The seven declared steps, in order."""

    step0_grounding_hash: str = ""
    step1_carrier_declared: bool = False
    step2_observer_id: str = ""
    step3_primitive_difference_declared: bool = False
    step4_zero_rel_rule: str = ""
    step5_witness_certificate: str | None = None
    step6_quotient_policy: str = "Q1_SEPARATED"

    def validate(self) -> PrimeDeclarationOutcome:
        """Short-circuit on the first gap: the order is the contract, so a later
        step never excuses an earlier one."""
        if not self.step0_grounding_hash:
            return PrimeDeclarationOutcome.RefuseMissingGrounding
        if not self.step1_carrier_declared:
            return PrimeDeclarationOutcome.RefuseMissingCarrier
        if not self.step2_observer_id:
            return PrimeDeclarationOutcome.RefuseMissingObserver
        if not self.step3_primitive_difference_declared:
            return PrimeDeclarationOutcome.RefuseMissingPrimitiveDifference
        if not self.step4_zero_rel_rule:
            return PrimeDeclarationOutcome.RefuseMissingZeroRel
        if not self.step5_witness_certificate:
            return PrimeDeclarationOutcome.RefuseMissingWitness
        return PrimeDeclarationOutcome.AcceptDeclaration


@dataclass(frozen=True, slots=True)
class LggrEpkObservation:
    """One LGGR(EPK) reading packaged for the Prime seam.

    A **sidecar**: it holds the residual signals rather than extending any existing
    ledger type, following the rule two Rust consumers state explicitly about
    ``EpkResidualLedger``.
    """

    verdict: LggrVerdict
    adequacy_kind: AdequacyKind
    ngd: float = 0.0
    nrke: float | None = None
    observed_corpus_digest: str | None = None
    record_id: str | None = None
    schema: str = field(default=LGGR_EPK_OBSERVATION_SCHEMA)
    authority_effect: str = field(default="None")

    @classmethod
    def measure(
        cls,
        delta_eval: int,
        local_product: bool,
        global_pass: bool,
        adequacy: DetectorAdequacyVerdict | None = None,
        provenance: EvaluatorProvenance = EvaluatorProvenance.Exhibited,
        ngd: float = 0.0,
        nrke: float | None = None,
    ) -> "LggrEpkObservation":
        """Build an observation whose verdict and adequacy projection are **derived
        from the same adequacy verdict**, so they cannot disagree.

        Takes the raw defect rather than a pre-classified verdict: a caller handing
        in a verdict is a caller who can hand in one classified against a
        *different* adequacy verdict. An earlier revision accepted a verdict, and
        this package's own test helper then paired a ``GreenOracleNeeded`` verdict
        with a ``NumericallySupported`` kind — a state the production path cannot
        produce.
        """
        verdict = classify(
            delta_eval,
            local_product=local_product,
            global_pass=global_pass,
            adequacy=adequacy,
            provenance=provenance,
        )
        return cls(
            verdict=verdict,
            adequacy_kind=(
                adequacy.kind if adequacy is not None else AdequacyKind.NotEvaluated
            ),
            ngd=ngd,
            nrke=nrke,
            observed_corpus_digest=(
                adequacy.observed_corpus_digest if adequacy is not None else None
            ),
        )

    def detector_adequate(self) -> bool:
        """The wire that makes an inadequate detector actually block continuation.

        Requires **both** that the adequacy projection permits it and that the
        verdict itself is not an unsound reading. :meth:`measure` derives both from
        one verdict so they agree by construction; Python cannot make dataclass
        fields private, so this conjunction is the enforcement — a hand-assembled
        incoherent pair still reads as inadequate.
        """
        return (
            self.adequacy_kind is AdequacyKind.NumericallySupported
            and self.verdict.kind
            not in (VerdictKind.GreenOracleNeeded, VerdictKind.OracleExtractedUnsound)
        )

    def evidence_ceiling(self) -> str:
        return self.verdict.evidence_ceiling()


@dataclass(frozen=True, slots=True)
class PrimeDescentReceipt:
    """Plain transport data. Round-trips; proves nothing on its own."""

    source_carrier: str
    target_carrier: str
    observed_corpus_digest: str
    residual_preservation_verified: bool
    loss_ledger: tuple[str, ...]
    receipt_hash: str
    schema: str = field(default=PRIME_DESCENT_RECEIPT_SCHEMA)
    authority_effect: str = field(default="None")


@dataclass(frozen=True, slots=True)
class VerifiedDescentReceipt:
    """A receipt whose canonical hash has been independently recomputed.

    Constructed only via :meth:`BoundEpkMeasurement.descend` or
    :meth:`BoundEpkMeasurement.verify_receipt`. Direct construction raises, so a
    receipt parsed from JSON cannot satisfy a gate until it is verified.
    """

    _receipt: PrimeDescentReceipt
    _seal: object = None

    def __post_init__(self) -> None:
        if self._seal is not _MINT_SEAL:
            raise PrimeAdapterUnavailable(
                "VerifiedDescentReceipt must be minted by BoundEpkMeasurement; a "
                "deserialized receipt must go through verify_receipt() first"
            )

    @classmethod
    def _seal_receipt(cls, receipt: PrimeDescentReceipt) -> "VerifiedDescentReceipt":
        return cls(_receipt=receipt, _seal=_MINT_SEAL)

    def receipt(self) -> PrimeDescentReceipt:
        return self._receipt

    def residual_preservation_verified(self) -> bool:
        return self._receipt.residual_preservation_verified

    def observed_corpus_digest(self) -> str:
        return self._receipt.observed_corpus_digest

    def receipt_hash(self) -> str:
        return self._receipt.receipt_hash


@dataclass(frozen=True, slots=True)
class PrimeBudget:
    """Bounded step budget. Mirrors ``PrimeTriadEngine.__init__(budget, delta_control)``."""

    budget: float
    delta_control: float

    def has_budget(self) -> bool:
        """Upstream predicate, preserved exactly: ``budget - delta_control >= 0``.

        Non-finite inputs are refused rather than compared: ``NaN`` fails every
        comparison, which would read as "no budget" by accident rather than by
        decision.
        """
        for v in (self.budget, self.delta_control):
            if v != v or v in (float("inf"), float("-inf")):
                return False
        return self.budget - self.delta_control >= 0.0


class ContinuationBlocker(str, Enum):
    """One per failed conjunct of ``CanContinue_n``."""

    V1SchemaQuarantined = "V1SchemaQuarantined"
    ObligationMissing = "ObligationMissing"
    WitnessMissing = "WitnessMissing"
    NextCarrierUndeclared = "NextCarrierUndeclared"
    AdapterUnsound = "AdapterUnsound"
    DetectorInadequate = "DetectorInadequate"
    MinimalLiftMissing = "MinimalLiftMissing"
    SkeletonNotPreserved = "SkeletonNotPreserved"
    BudgetExhausted = "BudgetExhausted"
    GtlaRefusal = "GtlaRefusal"


@dataclass(frozen=True, slots=True)
class ContinuationEvidence:
    """Sealed evidence that Prime 002 may be consulted.

    ``detector_adequate`` comes from the measurement's adequacy verdict;
    ``adapter_sound`` comes from the descent receipt. Neither is a caller
    parameter — that is what makes a lossy descent actually block continuation.

    Python cannot make fields private, so construction is guarded by a
    module-private sentinel only :meth:`BoundEpkMeasurement.continuation_evidence`
    holds. Direct construction raises.
    """

    corpus_digest: str
    receipt_hash: str
    detector_adequate: bool
    adapter_sound: bool
    _seal: object = None
    authority_effect: str = field(default="None")

    def __post_init__(self) -> None:
        if self._seal is not _MINT_SEAL:
            raise PrimeAdapterUnavailable(
                "ContinuationEvidence must be minted by "
                "BoundEpkMeasurement.continuation_evidence — it cannot be asserted"
            )


@dataclass(frozen=True, slots=True)
class PrimeContinuationInputs:
    """The conjuncts of Prime 002 ``CanContinue_n``, plus the budget.

    ``detector_adequate`` and ``adapter_sound`` are **not** parameters. An earlier
    revision took them as ordinary keywords, so
    ``PrimeContinuationInputs(budget=..., detector_adequate=True).evaluate()``
    returned ``may_continue`` with no observation, adequacy verdict, or receipt
    anywhere in sight.
    """

    evidence: ContinuationEvidence
    budget: PrimeBudget
    has_obligation: bool = True
    has_witness: bool = True
    next_carrier_declared: bool = True
    minimal_lift: bool = True
    skeleton_preserved: bool = True
    gtla_refusal: bool = False

    @classmethod
    def from_evidence(
        cls,
        evidence: ContinuationEvidence,
        budget: PrimeBudget,
        *,
        has_obligation: bool = True,
        has_witness: bool = True,
        next_carrier_declared: bool = True,
        minimal_lift: bool = True,
        skeleton_preserved: bool = True,
        gtla_refusal: bool = False,
    ) -> "PrimeContinuationInputs":
        if not isinstance(evidence, ContinuationEvidence):
            raise PrimeAdapterUnavailable("sealed ContinuationEvidence is required")
        return cls(
            evidence=evidence,
            budget=budget,
            has_obligation=has_obligation,
            has_witness=has_witness,
            next_carrier_declared=next_carrier_declared,
            minimal_lift=minimal_lift,
            skeleton_preserved=skeleton_preserved,
            gtla_refusal=gtla_refusal,
        )

    def evaluate(self) -> "PrimeContinuation":
        """Collect **every** failed conjunct rather than short-circuiting."""
        blockers: list[ContinuationBlocker] = []
        blockers.append(ContinuationBlocker.V1SchemaQuarantined)
        if not self.has_obligation:
            blockers.append(ContinuationBlocker.ObligationMissing)
        if not self.has_witness:
            blockers.append(ContinuationBlocker.WitnessMissing)
        if not self.next_carrier_declared:
            blockers.append(ContinuationBlocker.NextCarrierUndeclared)
        if not self.evidence.adapter_sound:
            blockers.append(ContinuationBlocker.AdapterUnsound)
        if not self.evidence.detector_adequate:
            blockers.append(ContinuationBlocker.DetectorInadequate)
        if not self.minimal_lift:
            blockers.append(ContinuationBlocker.MinimalLiftMissing)
        if not self.skeleton_preserved:
            blockers.append(ContinuationBlocker.SkeletonNotPreserved)
        if not self.budget.has_budget():
            blockers.append(ContinuationBlocker.BudgetExhausted)
        if self.gtla_refusal:
            blockers.append(ContinuationBlocker.GtlaRefusal)
        return PrimeContinuation(
            proposed_may_continue=not blockers, blockers=tuple(blockers)
        )


@dataclass(frozen=True, slots=True)
class PrimeContinuation:
    """The Prime 002 decision, with its reasons."""

    proposed_may_continue: bool = False
    blockers: tuple[ContinuationBlocker, ...] = ()
    authority_effect: str = field(default="None")

    @property
    def may_continue(self) -> bool:
        """**Unconditionally ``False``.**

        Python never returns an executable continuation. The computed proposal is
        :attr:`proposed_may_continue`; crossing proposal into execution requires
        the external verifier.
        """
        return False

    def disposition(self) -> str:
        """What a host may actually do with this decision.

        Python never returns an executable continuation. It returns
        ``"ExternalVerifierRequired"``.
        """
        return "ExternalVerifierRequired"

    def is_quarantined(self) -> bool:
        return ContinuationBlocker.V1SchemaQuarantined in self.blockers

    TERMINAL_WITH_DEBT = "TERMINAL_WITH_DEBT"
    LOCAL_GREEN_FOR_SCOPE = "LOCAL_GREEN_FOR_SCOPE"

    def step_terminal(self) -> str:
        """``LOCAL_GREEN_FOR_SCOPE`` is scope-local by name and by contract — it is
        not a global green."""
        return PrimeContinuation.TERMINAL_WITH_DEBT


@runtime_checkable
class PrimeIntakePort(Protocol):
    def evaluate_intake(
        self, candidate: CandidateDeclaration
    ) -> PrimeIntakeOutcome: ...
    def validate_declaration_order(
        self, order: PrimeDeclarationOrder
    ) -> PrimeDeclarationOutcome: ...


@runtime_checkable
class PrimeDescentPort(Protocol):
    def descend(self, observation: LggrEpkObservation) -> PrimeDescentReceipt: ...


@runtime_checkable
class PrimeContinuationPort(Protocol):
    def can_continue(self, inputs: PrimeContinuationInputs) -> PrimeContinuation: ...


class ReferencePrimePorts:
    """In-module reference implementation: performs the declared checks, nothing else."""

    def evaluate_intake(self, candidate: CandidateDeclaration) -> PrimeIntakeOutcome:
        return candidate.evaluate_intake()

    def validate_declaration_order(
        self, order: PrimeDeclarationOrder
    ) -> PrimeDeclarationOutcome:
        return order.validate()

    def descend(self, observation: LggrEpkObservation) -> PrimeDescentReceipt:
        raise PrimeAdapterUnavailable(
            "descent receipts are minted by BoundEpkMeasurement.descend, which "
            "binds them to a measured corpus; this port cannot mint one from a "
            "bare observation"
        )

    def can_continue(self, inputs: PrimeContinuationInputs) -> PrimeContinuation:
        return inputs.evaluate()


class PrimeAdapterUnavailable(RuntimeError):
    """A Prime implementation could not be bound. Raised rather than silently
    degrading to a permissive default."""


class LiveRailPrimeAdapter:
    """Adapter A — the live rail ``AlgoPrimeDdaEngine``.

    Intake and descent are delegated. **Continuation is not**: the live rail's
    ``run_prime002_control()`` returns ``PASS`` unconditionally, with no budget and
    no ``CanContinue_n`` predicate, so deriving a decision from it would launder a
    stub into a gate. :meth:`can_continue` evaluates the real predicate locally and
    records the live-rail phase receipt as evidence only.
    """

    def __init__(
        self, engine: Any | None = None, prompt_text: str | None = None
    ) -> None:
        if engine is None:
            from omega_engine.crates.engine.omega_engine_algo_prime_0_engine import (
                AlgoPrimeDdaEngine,
                DEFAULT_RABBIT_PROMPT,
            )

            engine = AlgoPrimeDdaEngine(prompt_text or DEFAULT_RABBIT_PROMPT)
        self.engine = engine

    def evaluate_intake(self, candidate: CandidateDeclaration) -> PrimeIntakeOutcome:
        return candidate.evaluate_intake()

    def validate_declaration_order(
        self, order: PrimeDeclarationOrder
    ) -> PrimeDeclarationOutcome:
        return order.validate()

    def descend(self, observation: LggrEpkObservation) -> PrimeDescentReceipt:
        """Refuse **before** performing transport.

        An earlier revision called ``run_prime001_transport()`` -- which mutates
        ``phase_tape`` and ``phase_receipts`` -- and only then raised. That is
        fail-late: the run was advanced by a call that could never succeed. The
        live rail cannot mint a corpus-bound receipt, so it refuses first and
        leaves engine state untouched.
        """
        raise PrimeAdapterUnavailable(
            "LiveRailPrimeAdapter cannot mint a corpus-bound descent receipt; use "
            "BoundEpkMeasurement.descend. Refused before running P001T so engine "
            "state is not advanced by a call that cannot succeed."
        )

    def can_continue(self, inputs: PrimeContinuationInputs) -> PrimeContinuation:
        return inputs.evaluate()


class PublishedPrimeTriadAdapter:
    """Adapter B — the published ``PrimeTriadEngine``, loaded by injected path.

    This is the only adapter that reaches the real ``CanContinue_n`` with its
    budget, so it is what the budget-boundary tests exercise.

    The module is loaded from an explicitly supplied path rather than imported: the
    published paper directories are Zenodo reproducibility artifacts on a separate
    rail, and the live rail must not acquire an import dependency on them.
    """

    MODULE_NAME = "oe_prime_algorithms_published"

    def __init__(self, paper_code_dir: str | Path) -> None:
        path = Path(paper_code_dir) / "oe_prime_algorithms.py"
        if not path.is_file():
            raise PrimeAdapterUnavailable(f"published Prime engine not found at {path}")
        spec = importlib.util.spec_from_file_location(self.MODULE_NAME, path)
        if spec is None or spec.loader is None:
            raise PrimeAdapterUnavailable(f"could not load a module spec from {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[self.MODULE_NAME] = module
        try:
            spec.loader.exec_module(module)
        except NameError as exc:
            sys.modules.pop(self.MODULE_NAME, None)
            raise PrimeAdapterUnavailable(
                f"published Prime engine failed to import on Python "
                f"{sys.version_info.major}.{sys.version_info.minor}: {exc}. "
                "The module forward-references PrimeTriadEngine without "
                "``, so it requires 3.14+."
            ) from exc
        self.module = module
        self.engine = module.PrimeTriadEngine()

    def evaluate_intake(self, candidate: CandidateDeclaration) -> PrimeIntakeOutcome:
        """Delegate to the published engine and map its literal back."""
        packet = self.module.CandidatePacket(
            artifact_id=candidate.artifact_id,
            locus_id=candidate.locus_id,
            problem_family=candidate.problem_family,
            primitive_difference_proposal=candidate.primitive_difference_proposal,
            carrier_proposal=candidate.carrier_proposal,
            zero_rel_proposal=candidate.zero_rel_proposal,
            observer_proposal=candidate.observer_proposal,
            witness_available=candidate.witness_available,
            quotient_or_refusal=candidate.quotient_or_refusal,
            adapter_confidence=candidate.adapter_confidence,
        )
        trace = self.module.IntakeTrace(
            raw_artifact_hash="sha256:seam",
            candidate_locus=candidate.locus_id,
            candidate_packet=packet,
        )
        return PrimeIntakeOutcome(self.engine.evaluate_intake(trace))

    def validate_declaration_order(
        self, order: PrimeDeclarationOrder
    ) -> PrimeDeclarationOutcome:
        return order.validate()

    def can_continue(self, inputs: PrimeContinuationInputs) -> PrimeContinuation:
        """Cross-check the published predicate against ours.

        The published ``can_continue`` returns a bare ``bool`` and takes budget from
        engine state, so it is configured here from the supplied budget. If the two
        disagree, that is a real contract divergence and is raised rather than
        silently resolved in either direction.
        """
        engine = self.module.PrimeTriadEngine(
            budget=inputs.budget.budget, delta_control=inputs.budget.delta_control
        )
        upstream = engine.can_continue(
            stage=0,
            has_obligation=inputs.has_obligation,
            has_witness=inputs.has_witness,
            next_carrier_declared=inputs.next_carrier_declared,
            adapter_sound=inputs.evidence.adapter_sound,
            detector_adequate=inputs.evidence.detector_adequate,
            minimal_lift=inputs.minimal_lift,
            skeleton_preserved=inputs.skeleton_preserved,
            budget_remains=inputs.budget.has_budget(),
            gtla_refusal=inputs.gtla_refusal,
        )
        local = inputs.evaluate()
        without_quarantine = not [
            b
            for b in local.blockers
            if b is not ContinuationBlocker.V1SchemaQuarantined
        ]
        if bool(upstream) != without_quarantine:
            raise PrimeAdapterUnavailable(
                "published CanContinue_n disagrees with the seam predicate: "
                f"upstream={upstream}, seam={local.may_continue}, "
                f"blockers={[b.value for b in local.blockers]}"
            )
        return local





