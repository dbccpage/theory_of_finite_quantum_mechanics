"""traced_monoidal shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class TracedMonoidal:
    """Best-effort traced monoidal category shell."""

    label: str
    monoidal_ref: str = ""
    trace_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "TracedMonoidal":
        return cls(label=label)

    @classmethod
    def with_trace(
        cls, label: str, monoidal_ref: str, trace_ref: str
    ) -> "TracedMonoidal":
        return cls(label=label, monoidal_ref=monoidal_ref, trace_ref=trace_ref)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.monoidal_ref:
            raise ValueError("empty monoidal_ref")
        if not self.trace_ref:
            raise ValueError("empty trace_ref")



