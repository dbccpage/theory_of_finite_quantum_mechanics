"""cokernel_pair shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class CokernelPair:
    """Best-effort shell for a cokernel pair of a morphism f : A → B."""

    label: str
    pair_object: str = ""
    source: str = ""
    target: str = ""
    morphism_f: str = ""
    injection_left: str = ""
    injection_right: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "CokernelPair":
        return cls(label=label)

    @classmethod
    def of_morphism(
        cls,
        label: str,
        pair_object: str,
        source: str,
        target: str,
        morphism_f: str,
        injection_left: str,
        injection_right: str,
    ) -> "CokernelPair":
        return cls(
            label=label,
            pair_object=pair_object,
            source=source,
            target=target,
            morphism_f=morphism_f,
            injection_left=injection_left,
            injection_right=injection_right,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.pair_object:
            raise ValueError("empty pair_object")
        if not self.source:
            raise ValueError("empty source")
        if not self.target:
            raise ValueError("empty target")
        if not self.morphism_f:
            raise ValueError("empty morphism_f")
        if not self.injection_left:
            raise ValueError("empty injection_left")
        if not self.injection_right:
            raise ValueError("empty injection_right")



