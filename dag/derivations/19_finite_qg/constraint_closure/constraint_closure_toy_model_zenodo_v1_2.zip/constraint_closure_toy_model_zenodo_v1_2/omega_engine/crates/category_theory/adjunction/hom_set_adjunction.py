"""hom-set adjunction shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Hom_D(L(A), B) ≅ Hom_C(A, R(B)) — mate-pair tags only.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class MatePair:
    """A single mate pair tag: f : L(A)→B  ↔  f̄ : A→R(B)."""

    base_object: str
    lifted_object: str
    left_hom: str
    right_hom: str

    @classmethod
    def new(
        cls,
        base_object: str,
        lifted_object: str,
        left_hom: str,
        right_hom: str,
    ) -> "MatePair":
        return cls(
            base_object=base_object,
            lifted_object=lifted_object,
            left_hom=left_hom,
            right_hom=right_hom,
        )


@dataclass
class HomSetAdjunctionShell:
    """Best-effort shell for a hom-set adjunction declaration."""

    label: str
    left_functor: str = ""
    right_functor: str = ""
    adjunction_ref: str = ""
    mate_pairs: List[MatePair] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "HomSetAdjunctionShell":
        return cls(label=label)

    @classmethod
    def between(
        cls, label: str, left_functor: str, right_functor: str
    ) -> "HomSetAdjunctionShell":
        return cls(
            label=label,
            left_functor=left_functor,
            right_functor=right_functor,
        )

    def with_mate(self, pair: MatePair) -> "HomSetAdjunctionShell":
        self.mate_pairs.append(pair)
        return self

    def add_mate(self, pair: MatePair) -> None:
        self.mate_pairs.append(pair)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.left_functor:
            raise ValueError("empty left_functor")
        if not self.right_functor:
            raise ValueError("empty right_functor")
        for i, p in enumerate(self.mate_pairs):
            if (
                not p.base_object
                or not p.lifted_object
                or not p.left_hom
                or not p.right_hom
            ):
                raise ValueError(f"empty mate pair field at index {i}")



