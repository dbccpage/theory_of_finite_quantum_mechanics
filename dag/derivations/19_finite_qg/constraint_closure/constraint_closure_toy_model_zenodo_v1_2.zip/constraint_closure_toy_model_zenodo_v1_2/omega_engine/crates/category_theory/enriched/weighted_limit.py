"""weighted_limit shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class WeightedLimit:
    """Best-effort weighted limit shell."""

    label: str
    weight_ref: str = ""
    diagram_ref: str = ""
    ambient_enriched: str = ""
    base_monoidal_v: str = ""
    apex: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "WeightedLimit":
        return cls(label=label)

    @classmethod
    def of(
        cls,
        label: str,
        weight_ref: str,
        diagram_ref: str,
        ambient_enriched: str,
        base_monoidal_v: str,
    ) -> "WeightedLimit":
        return cls(
            label=label,
            weight_ref=weight_ref,
            diagram_ref=diagram_ref,
            ambient_enriched=ambient_enriched,
            base_monoidal_v=base_monoidal_v,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.weight_ref:
            raise ValueError("empty weight_ref")
        if not self.diagram_ref:
            raise ValueError("empty diagram_ref")
        if not self.ambient_enriched:
            raise ValueError("empty ambient_enriched")
        if not self.base_monoidal_v:
            raise ValueError("empty base_monoidal_v")



