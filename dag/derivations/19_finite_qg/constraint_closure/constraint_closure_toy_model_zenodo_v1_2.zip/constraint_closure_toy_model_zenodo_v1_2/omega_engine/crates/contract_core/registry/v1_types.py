from pydantic import ConfigDict
from enum import Enum
from typing import List, Optional, Any, Dict
from dataclasses import field
from pydantic.dataclasses import dataclass
from omega_engine.crates.contract_core.kinds import (
    AuthorityEffect,
    ComponentRole,
    ContractCategory,
    ContractStatus,
    Capability,
    CapabilityPolicy,
)
from omega_engine.crates.contract_core.schema import (
    ConstitutionalBlock,
    ConstraintBlock,
    ReplayBlock,
    WitnessesBlock,
    LawBlock,
    ProofObligationRef,
    TerminalPolicy,
    RefusalPolicy,
    OperatorClassPolicy,
    RustBinding,
    ContractDescriptor,
    ArtifactFamily,
    AuthorityLayer,
    PhiLawDecl,
    StructureLawDecl,
    EffectLawDecl,
    OperatorClass,
)
from omega_engine.crates.type import EvidenceCeiling


class OmegaContractV1Status(Enum):
    Active = "active"
    Draft = "draft"
    Deprecated = "deprecated"
    Experimental = "experimental"
    MathematicalWip = "mathematical_wip"
    ExactRationalClassifierImplemented = "exact_rational_classifier_implemented"

    def normalized(self) -> "OmegaContractV1Status":
        if self == OmegaContractV1Status.ExactRationalClassifierImplemented:
            return OmegaContractV1Status.Active
        if self == OmegaContractV1Status.MathematicalWip:
            return OmegaContractV1Status.Experimental
        return self

    def to_contract_status(self) -> ContractStatus:
        norm = self.normalized()
        if norm == OmegaContractV1Status.Active:
            return ContractStatus.Canonical
        if norm in (OmegaContractV1Status.Draft, OmegaContractV1Status.Experimental):
            return ContractStatus.Staged
        if norm == OmegaContractV1Status.Deprecated:
            return ContractStatus.Deprecated
        raise ValueError(f"Unknown status: {self}")


class ContractKind(Enum):
    MathContract = "math_contract"
    ConstitutionContract = "constitution_contract"
    StateContract = "state_contract"
    EvidenceContract = "evidence_contract"
    ObstructionContract = "obstruction_contract"
    GovernanceContract = "governance_contract"
    ExecutionContract = "execution_contract"
    ProductContract = "product_contract"
    LiftContract = "lift_contract"

    def category(self) -> ContractCategory:
        if self == ContractKind.MathContract:
            return ContractCategory.Math
        elif self == ContractKind.ConstitutionContract:
            return ContractCategory.Constitution
        elif self == ContractKind.StateContract:
            return ContractCategory.State
        elif self == ContractKind.EvidenceContract:
            return ContractCategory.Evidence
        elif self == ContractKind.ObstructionContract:
            return ContractCategory.Obstruction
        elif self == ContractKind.GovernanceContract:
            return ContractCategory.Governance
        elif self == ContractKind.ExecutionContract:
            return ContractCategory.Execution
        elif self == ContractKind.ProductContract:
            return ContractCategory.Product
        elif self == ContractKind.LiftContract:
            return ContractCategory.Lifts
        raise ValueError(f"Unknown kind: {self}")

    def default_role(self) -> Optional[ComponentRole]:
        if self == ContractKind.MathContract:
            return ComponentRole.MathObject
        return None

    def is_math(self) -> bool:
        return self == ContractKind.MathContract

    def forbidden_capabilities(self) -> List[Capability]:
        if self == ContractKind.MathContract:
            return [
                Capability.EmitDecision,
                Capability.EmitCertificate,
                Capability.EmitAction,
            ]
        if self == ContractKind.LiftContract:
            return [
                Capability.ExecuteStateTransition,
                Capability.RuntimeMutation,
            ]
        return []


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class Dependencies:
    contracts: List[str] = field(default_factory=list)
    proof_obligations: List[ProofObligationRef] = field(default_factory=list)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class DescriptorBlock:
    authority_effect: AuthorityEffect
    evidence_ceiling: EvidenceCeiling
    runtime_enforcement: bool = False
    customer_claim_allowed: bool = False
    dependencies: Dependencies = field(default_factory=Dependencies)
    terminals: TerminalPolicy = field(default_factory=TerminalPolicy)
    refusals: RefusalPolicy = field(default_factory=RefusalPolicy)
    operator_classes: OperatorClassPolicy = field(default_factory=OperatorClassPolicy)
    constitution: Optional[ConstitutionalBlock] = None
    constraints: Optional[ConstraintBlock] = None
    replay: Optional[ReplayBlock] = None
    witnesses: Optional[WitnessesBlock] = None
    subject_type: Optional[str] = None
    capabilities: Optional[CapabilityPolicy] = None
    laws: Optional[LawBlock] = None
    runtime_state_type: Optional[str] = None


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class OmegaContractV1:
    schema_version: str
    contract_id: str
    title: str
    kind: ContractKind
    status: OmegaContractV1Status
    descriptor: DescriptorBlock
    layer: Optional[str] = None
    role: Optional[ComponentRole] = None
    math: Optional[Any] = None
    requirements: Optional[Any] = None
    definition: Optional[Any] = None
    laws: Optional[Any] = None
    equivalence: Optional[Any] = None
    replay: Optional[Any] = None
    relationships: Optional[Any] = None
    rust_binding: Optional[RustBinding] = None
    negative_tests: Optional[List[str]] = None
    doctrine: Optional[Any] = None
    wip: Optional[Any] = None

    def to_descriptor(self) -> ContractDescriptor:
        role_val = self.role
        if role_val is None:
            role_val = self.kind.default_role()
        if role_val is None:
            role_val = ComponentRole.MathObject

        caps = self.descriptor.capabilities
        if caps is None:
            caps = CapabilityPolicy(
                forbidden=self.kind.forbidden_capabilities(), required=[]
            )

        return ContractDescriptor(
            id=self.contract_id,
            name=self.title,
            category=self.kind.category(),
            role=role_val,
            status=self.status.to_contract_status(),
            authority_effect=self.descriptor.authority_effect,
            domain_type=None,
            codomain_type=None,
            subject_type=self.descriptor.subject_type,
            runtime_state_type=self.descriptor.runtime_state_type,
            laws=self.descriptor.laws,
            constraints=self.descriptor.constraints or ConstraintBlock(),
            capabilities=caps,
            requires=None,
            validation=None,
            witnesses=self.descriptor.witnesses,
            replay=self.descriptor.replay,
            constitution=self.descriptor.constitution,
            schema_hash=None,
            algebra_laws=None,
            governed_algebra_layer=None,
            operator_class=None,
            signature=None,
            uros=None,
            evaluates_outputs_of=None,
            decision_scope=None,
            evidence_ceiling=self.descriptor.evidence_ceiling,
            runtime_enforcement=self.descriptor.runtime_enforcement,
            proof_obligations=self.descriptor.dependencies.proof_obligations,
            terminals=self.descriptor.terminals,
            refusals=self.descriptor.refusals,
            operator_classes=self.descriptor.operator_classes,
            rust_binding=self.rust_binding,
        )


def _get_enum_val(enum_cls: Any, val: Any) -> Any:
    if val is None:
        return None
    if isinstance(val, enum_cls):
        return val
    try:
        return enum_cls(val)
    except ValueError:
        # Check casing variants
        for item in enum_cls:
            if str(item.value).lower() == str(val).lower():
                return item
        raise


def from_dict(d: Dict[str, Any]) -> OmegaContractV1:
    # Top-level keys check for deny_unknown_fields
    allowed_keys = {
        "schema_version",
        "contract_id",
        "title",
        "kind",
        "status",
        "layer",
        "role",
        "descriptor",
        "math",
        "requirements",
        "definition",
        "laws",
        "equivalence",
        "replay",
        "relationships",
        "rust_binding",
        "negative_tests",
        "doctrine",
        "wip",
    }
    for k in d.keys():
        if k not in allowed_keys:
            raise ValueError(f"Unknown top-level field: {k}")

    kind = _get_enum_val(ContractKind, d["kind"])
    status = _get_enum_val(OmegaContractV1Status, d["status"])
    role = _get_enum_val(ComponentRole, d.get("role"))

    desc_data = d["descriptor"]
    # check unknown fields in descriptor
    allowed_desc_keys = {
        "authority_effect",
        "evidence_ceiling",
        "runtime_enforcement",
        "customer_claim_allowed",
        "dependencies",
        "terminals",
        "refusals",
        "operator_classes",
        "constitution",
        "constraints",
        "replay",
        "witnesses",
        "subject_type",
        "capabilities",
        "laws",
        "runtime_state_type",
    }
    for k in desc_data.keys():
        if k not in allowed_desc_keys:
            raise ValueError(f"Unknown field in descriptor: {k}")

    auth_effect = _get_enum_val(AuthorityEffect, desc_data["authority_effect"])
    evidence_ceiling = EvidenceCeiling(desc_data["evidence_ceiling"])

    dep_data = desc_data.get("dependencies", {})
    allowed_dep_keys = {"contracts", "proof_obligations"}
    for k in dep_data.keys():
        if k not in allowed_dep_keys:
            raise ValueError(f"Unknown field in dependencies: {k}")
    deps = Dependencies(
        contracts=dep_data.get("contracts", []),
        proof_obligations=[
            ProofObligationRef(po) for po in dep_data.get("proof_obligations", [])
        ],
    )

    term_data = desc_data.get("terminals", {})
    allowed_term_keys = {"may_emit", "may_support"}
    for k in term_data.keys():
        if k not in allowed_term_keys:
            raise ValueError(f"Unknown field in terminals: {k}")
    terminals = TerminalPolicy(
        may_emit=term_data.get("may_emit", []),
        may_support=term_data.get("may_support", []),
    )

    ref_data = desc_data.get("refusals", {})
    allowed_ref_keys = {"may_emit"}
    for k in ref_data.keys():
        if k not in allowed_ref_keys:
            raise ValueError(f"Unknown field in refusals: {k}")
    refusals = RefusalPolicy(may_emit=ref_data.get("may_emit", []))

    op_data = desc_data.get("operator_classes", {})
    allowed_op_keys = {"may_support", "must_not_self_assign"}
    for k in op_data.keys():
        if k not in allowed_op_keys:
            raise ValueError(f"Unknown field in operator_classes: {k}")
    operator_classes = OperatorClassPolicy(
        may_support=[
            _get_enum_val(OperatorClass, oc) for oc in op_data.get("may_support", [])
        ],
        must_not_self_assign=op_data.get("must_not_self_assign", False),
    )

    const_data = desc_data.get("constitution")
    constitution = None
    if const_data is not None:
        allowed_const_keys = {
            "emits",
            "authority_layer",
            "contract_dependencies",
            "law_refs",
            "forbidden_later_layers",
            "replay_certificates",
        }
        for k in const_data.keys():
            if k not in allowed_const_keys:
                raise ValueError(f"Unknown field in constitution: {k}")
        constitution = ConstitutionalBlock(
            emits=_get_enum_val(ArtifactFamily, const_data["emits"]),
            authority_layer=_get_enum_val(
                AuthorityLayer, const_data["authority_layer"]
            ),
            contract_dependencies=const_data.get("contract_dependencies", []),
            law_refs=const_data.get("law_refs", []),
            forbidden_later_layers=[
                _get_enum_val(AuthorityLayer, al)
                for al in const_data.get("forbidden_later_layers", [])
            ],
            replay_certificates=const_data.get("replay_certificates", []),
        )

    constraint_data = desc_data.get("constraints")
    constraints = None
    if constraint_data is not None:
        constraints = ConstraintBlock(**constraint_data)

    rep_data = desc_data.get("replay")
    replay = None
    if rep_data is not None:
        allowed_rep_keys = {"required"}
        for k in rep_data.keys():
            if k not in allowed_rep_keys:
                raise ValueError(f"Unknown field in replay: {k}")
        replay = ReplayBlock(required=rep_data.get("required", []))

    wit_data = desc_data.get("witnesses")
    witnesses = None
    if wit_data is not None:
        allowed_wit_keys = {"required"}
        for k in wit_data.keys():
            if k not in allowed_wit_keys:
                raise ValueError(f"Unknown field in witnesses: {k}")
        witnesses = WitnessesBlock(required=wit_data.get("required", []))

    cap_data = desc_data.get("capabilities")
    capabilities = None
    if cap_data is not None:
        allowed_cap_keys = {"forbidden", "required"}
        for k in cap_data.keys():
            if k not in allowed_cap_keys:
                raise ValueError(f"Unknown field in capabilities: {k}")
        capabilities = CapabilityPolicy(
            forbidden=[
                _get_enum_val(Capability, cap) for cap in cap_data.get("forbidden", [])
            ],
            required=[
                _get_enum_val(Capability, cap) for cap in cap_data.get("required", [])
            ],
        )

    laws_data = desc_data.get("laws")
    laws = None
    if laws_data is not None:
        allowed_laws_keys = {"phi", "structure", "effect", "required"}
        for k in laws_data.keys():
            if k not in allowed_laws_keys:
                raise ValueError(f"Unknown field in laws: {k}")
        # Note: In Rust, phi/structure/effect are LawPresence. Since they are untagged, we check if they are present.
        phi_val = _get_enum_val(PhiLawDecl, laws_data.get("phi"))
        struct_val = _get_enum_val(StructureLawDecl, laws_data.get("structure"))
        eff_val = _get_enum_val(EffectLawDecl, laws_data.get("effect"))
        laws = LawBlock(
            phi=phi_val,
            structure=struct_val,
            effect=eff_val,
            required=laws_data.get("required", []),
        )

    descriptor = DescriptorBlock(
        authority_effect=auth_effect,
        evidence_ceiling=evidence_ceiling,
        runtime_enforcement=desc_data.get("runtime_enforcement", False),
        customer_claim_allowed=desc_data.get("customer_claim_allowed", False),
        dependencies=deps,
        terminals=terminals,
        refusals=refusals,
        operator_classes=operator_classes,
        constitution=constitution,
        constraints=constraints,
        replay=replay,
        witnesses=witnesses,
        subject_type=desc_data.get("subject_type"),
        capabilities=capabilities,
        laws=laws,
        runtime_state_type=desc_data.get("runtime_state_type"),
    )

    rust_binding_data = d.get("rust_binding")
    rust_binding = None
    if rust_binding_data is not None:
        allowed_rb_keys = {"crate", "module", "symbols"}
        for k in rust_binding_data.keys():
            if k not in allowed_rb_keys:
                raise ValueError(f"Unknown field in rust_binding: {k}")
        rust_binding = RustBinding(
            krate=rust_binding_data["crate"],
            module=rust_binding_data["module"],
            symbols=rust_binding_data.get("symbols", []),
        )

    return OmegaContractV1(
        schema_version=d["schema_version"],
        contract_id=d["contract_id"],
        title=d["title"],
        kind=kind,
        status=status,
        layer=d.get("layer"),
        role=role,
        descriptor=descriptor,
        math=d.get("math"),
        requirements=d.get("requirements"),
        definition=d.get("definition"),
        laws=d.get("laws"),
        equivalence=d.get("equivalence"),
        replay=d.get("replay"),
        relationships=d.get("relationships"),
        rust_binding=rust_binding,
        negative_tests=d.get("negative_tests"),
        doctrine=d.get("doctrine"),
        wip=d.get("wip"),
    )





