"""Dual Witness Subdifferential Optimality & Weak Duality Certifier.

Mechanized mirror of Lean 4 kernel theorem:
    `UniverseAnomalonica.DualPairing.exact_minimizer_certificate`
    (omega_engine/lean4/anomalon/dual_witness_duality.lean)

Doctrine:
- Computes exact weak duality lower bound: <y, omega> <= ||omega - d0*alpha||_1.
- Certifies exact L1 repair minimality via zero duality gap.
- AuthorityEffect: None.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
import numpy as np

CONTRACT_ID = "urn:omega:math:dual_witness_solver:v1.0.0"


@dataclass(frozen=True)
class DualWitnessCert:
    """Certified evidence envelope for L1 cochain repair minimality."""

    omega: List[float]
    alpha_opt: List[float]
    dual_witness: List[float]
    primal_l1_norm: float
    dual_bound: float
    duality_gap: float
    is_certified: bool
    authority_effect: str = "None"


class DualWitnessCertifier:
    """Verifies dual witness weak duality and exact L1 repair minimality."""

    def __init__(self, d0: np.ndarray, tol: float = 1e-8):
        self.d0 = np.asarray(d0, dtype=float)
        self.tol = float(tol)

    def certify_repair(
        self,
        omega: List[float],
        alpha_opt: List[float],
        dual_witness: List[float],
    ) -> DualWitnessCert:
        """Verify dual witness orthogonality, subgradient bound, and zero duality gap."""
        w = np.asarray(omega, dtype=float)
        a = np.asarray(alpha_opt, dtype=float)
        y = np.asarray(dual_witness, dtype=float)

        # 1. Primal residual omega - d0*alpha
        res = w - self.d0 @ a
        primal_l1 = float(np.sum(np.abs(res)))

        # 2. Dual bound <y, omega - d0*alpha>
        dual_bound = float(np.dot(y, res))

        # 3. Orthogonality check: d0^T * y == 0
        d0_t_y = self.d0.T @ y
        orth_err = float(np.max(np.abs(d0_t_y))) if len(d0_t_y) > 0 else 0.0

        # 4. Subgradient norm check: ||y||_inf <= 1
        subgrad_err = float(np.max(np.abs(y))) if len(y) > 0 else 0.0

        # 5. Duality gap
        gap = abs(primal_l1 - dual_bound)

        is_certified = (
            orth_err <= self.tol
            and subgrad_err <= 1.0 + self.tol
            and gap <= self.tol
        )

        return DualWitnessCert(
            omega=list(w),
            alpha_opt=list(a),
            dual_witness=list(y),
            primal_l1_norm=primal_l1,
            dual_bound=dual_bound,
            duality_gap=gap,
            is_certified=is_certified,
            authority_effect="None",
        )


def verify_dual_witness_weak_duality(
    d0: np.ndarray,
    omega: np.ndarray,
    alpha_var: np.ndarray,
    dual_witness: np.ndarray,
) -> bool:
    """Verify weak duality inequality: <y, omega> <= ||omega - d0*alpha_var||_1."""
    d0 = np.asarray(d0, dtype=float)
    w = np.asarray(omega, dtype=float)
    a = np.asarray(alpha_var, dtype=float)
    y = np.asarray(dual_witness, dtype=float)

    # Cochain d0 is (N_edges, N_vertices); alpha_var is N_vertices
    res = w - (d0 @ a if d0.shape[1] == len(a) else d0.T @ a)
    dual_val = float(np.dot(y, res))
    primal_val = float(np.sum(np.abs(res)))

    return dual_val <= primal_val + 1e-8


__all__ = [
    "DualWitnessCert",
    "DualWitnessCertifier",
    "verify_dual_witness_weak_duality",
    "CONTRACT_ID",
]
