"""Density matrix diagnostics snapshot with strict L1 invariants.

Faithful port of ``crates/omega_engine.crates.engine/src/quantum/density_diagnostics.rs``.

Tracks observables (purity, von Neumann entropy in bits, spectrum, coherence)
and validates internal consistency. ``validate()`` raises on violation;
``try_validate()`` returns the violation (or ``None`` on success).
"""

from __future__ import annotations
import math
from typing import Optional

from omega_engine.crates.type.qm_density import DensityDiagnostics


class DensityDiagnosticViolation(Exception):
    pass


class ZeroDimensionV(DensityDiagnosticViolation):
    pass


class EigenvaluesLengthMismatch(DensityDiagnosticViolation):
    pass


class DiagonalProbsLengthMismatch(DensityDiagnosticViolation):
    pass


class NonFinite(DensityDiagnosticViolation):
    pass


class NegativeProbability(DensityDiagnosticViolation):
    pass


class TraceMismatch(DensityDiagnosticViolation):
    pass


class NonPSD(DensityDiagnosticViolation):
    pass


class EntropyMismatch(DensityDiagnosticViolation):
    pass


class CoherenceViolation(DensityDiagnosticViolation):
    pass


class PurityMismatch(DensityDiagnosticViolation):
    pass


def try_validate_density(
    diagnostics: DensityDiagnostics,
) -> Optional[DensityDiagnosticViolation]:
    if diagnostics.dim == 0:
        return ZeroDimensionV()
    if len(diagnostics.eigenvalues) != diagnostics.dim:
        return EigenvaluesLengthMismatch()
    if len(diagnostics.diagonal_probs) != diagnostics.dim:
        return DiagonalProbsLengthMismatch()
    if not all(math.isfinite(x) for x in diagnostics.eigenvalues):
        return NonFinite()
    if not all(math.isfinite(p) for _, p in diagnostics.diagonal_probs):
        return NonFinite()
    if not all(p >= -1e-10 for _, p in diagnostics.diagonal_probs):
        return NegativeProbability()
    if not all(
        math.isfinite(value)
        for value in (
            diagnostics.total_trace,
            diagnostics.purity,
            diagnostics.entropy_bits,
            diagnostics.l1_coherence,
        )
    ):
        return NonFinite()
    if abs(sum(diagnostics.eigenvalues) - diagnostics.total_trace) > 1e-10:
        return TraceMismatch()
    if min(diagnostics.eigenvalues) < -1e-10:
        return NonPSD()
    if abs(sum(p for _, p in diagnostics.diagonal_probs) - diagnostics.total_trace) > 1e-10:
        return TraceMismatch()
    entropy = sum(
        -value * math.log2(value) for value in diagnostics.eigenvalues if value > 0.0
    )
    if abs(entropy - diagnostics.entropy_bits) > 1e-8:
        return EntropyMismatch()
    if diagnostics.l1_coherence < -1e-10 or diagnostics.l1_coherence > diagnostics.dim - 1.0 + 1e-10:
        return CoherenceViolation()
    if diagnostics.entropy_bits < -1e-12 or diagnostics.entropy_bits > math.log2(diagnostics.dim) + 1e-12:
        return EntropyMismatch()
    purity_min = 1.0 / diagnostics.dim
    if diagnostics.purity < purity_min - 1e-10 or diagnostics.purity > 1.0 + 1e-10:
        return PurityMismatch()
    spectral_purity = sum(value * value for value in diagnostics.eigenvalues)
    if abs(spectral_purity - diagnostics.purity) > 1e-8:
        return PurityMismatch()
    return None


def validate_density(diagnostics: DensityDiagnostics) -> None:
    violation = try_validate_density(diagnostics)
    if violation is not None:
        raise violation
