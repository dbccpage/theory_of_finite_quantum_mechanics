"""Typed morphisms and executable morphism equations.

This module supplies the arrow-level primitives used by the Omega Engine's
finite category test system.  A :class:`Morphism` is an explicitly typed arrow
``source -> target``.  Composition is defined only when the middle objects
agree, and equations between callable arrows are checked on declared finite
samples rather than inferred from Python function identity.

The sample-based checks are finite evidence.  They do not claim equality of
arbitrary functions outside the supplied proof window.
"""

from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from operator import eq
from typing import (
    Any,
    Callable,
    Generic,
    Hashable,
    Iterable,
    Mapping,
    Optional,
    Tuple,
    TypeVar,
)


Domain = TypeVar("Domain")
Codomain = TypeVar("Codomain")
Third = TypeVar("Third")


class MorphismError(ValueError):
    """Base class for invalid arrow operations."""


class CompositionError(MorphismError):
    """Raised when two morphisms are not composable."""


class ParallelismError(MorphismError):
    """Raised when an equation is formed from non-parallel morphisms."""


def object_name(obj: Any) -> str:
    """Return a stable human-readable label for a category object."""

    name = getattr(obj, "name", None)
    if name:
        return str(name)
    if hasattr(obj, "layer") and hasattr(obj, "carrier"):
        return f"Packet({obj.layer},{obj.carrier})"
    return str(obj)


class Morphism(Generic[Domain, Codomain]):
    """A typed callable arrow.

    ``arrow_id`` is the symbolic identity of the arrow inside a finite
    presentation.  It is deliberately separate from extensional equality of
    the underlying callable.  If omitted, a named arrow uses its name as its
    symbolic identifier; an unnamed arrow uses the identity of its callable.

    Two arrows compare equal only when their source, target, and symbolic
    identifiers agree.  Use :class:`MorphismEquation` for finite extensional
    checks.
    """

    __slots__ = (
        "source",
        "target",
        "mapping",
        "name",
        "metadata",
        "_arrow_id",
        "_factors",
        "_is_identity",
        "_sealed",
    )

    def __init__(
        self,
        source: Any,
        target: Any,
        mapping: Callable[[Domain], Codomain],
        name: str = "",
        *,
        arrow_id: Optional[Hashable] = None,
        metadata: Optional[Mapping[str, Any]] = None,
        _factors: Optional[Tuple[Hashable, ...]] = None,
        _is_identity: bool = False,
    ) -> None:
        if not callable(mapping):
            raise TypeError("A morphism mapping must be callable")

        self.source = source
        self.target = target
        self.mapping = mapping
        self.name = name or f"{object_name(source)}->{object_name(target)}"
        self.metadata = dict(metadata or {})

        if arrow_id is None:
            if name:
                arrow_id = ("named", name)
            else:
                arrow_id = ("callable", id(mapping))
        try:
            hash(arrow_id)
        except TypeError as exc:
            raise TypeError("arrow_id must be hashable") from exc

        self._arrow_id = arrow_id
        self._factors = _factors if _factors is not None else (arrow_id,)
        self._is_identity = _is_identity
        self._sealed = True

    def __setattr__(self, name: str, value: Any) -> None:
        if getattr(self, "_sealed", False):
            raise AttributeError("Morphism instances are immutable")
        object.__setattr__(self, name, value)

    @property
    def arrow_id(self) -> Hashable:
        """Return the arrow's symbolic identifier."""

        return self._arrow_id

    @property
    def is_identity(self) -> bool:
        """Whether this arrow was constructed as an identity."""

        return self._is_identity

    def apply(self, value: Domain) -> Codomain:
        """Apply the underlying callable."""

        return self.mapping(value)

    def __call__(self, value: Domain) -> Codomain:
        return self.apply(value)

    def is_parallel_to(self, other: "Morphism[Any, Any]") -> bool:
        """Return whether two arrows have the same source and target."""

        return self.source == other.source and self.target == other.target

    def then(self, after: "Morphism[Codomain, Third]") -> "Morphism[Domain, Third]":
        """Return ``after o self``."""

        return compose(after, self)

    def after(self, before: "Morphism[Third, Domain]") -> "Morphism[Third, Codomain]":
        """Return ``self o before``."""

        return compose(self, before)

    def equation_with(self, other: "Morphism[Any, Any]") -> "MorphismEquation":
        """Construct a typed equation between parallel arrows."""

        return MorphismEquation(self, other)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Morphism):
            return NotImplemented
        return (
            self.source == other.source
            and self.target == other.target
            and self.arrow_id == other.arrow_id
        )

    def __hash__(self) -> int:
        return hash((self.source, self.target, self.arrow_id))

    def __repr__(self) -> str:
        return (
            f"Morphism({self.name}: "
            f"{object_name(self.source)} -> {object_name(self.target)})"
        )


def identity(obj: Any, *, name: Optional[str] = None) -> Morphism[Any, Any]:
    """Return the canonical symbolic identity arrow on ``obj``."""

    return Morphism(
        source=obj,
        target=obj,
        mapping=lambda value: value,
        name=name or f"id_{object_name(obj)}",
        arrow_id=("identity", obj),
        _factors=(),
        _is_identity=True,
    )


def compose(
    outer: Morphism[Codomain, Third],
    inner: Morphism[Domain, Codomain],
    *,
    name: Optional[str] = None,
) -> Morphism[Domain, Third]:
    """Return ``outer o inner`` (apply ``inner``, then ``outer``).

    Identity factors are simplified, and non-identity factor sequences are
    flattened.  Consequently, differently parenthesized symbolic composites
    have the same ``arrow_id``.
    """

    if outer.source != inner.target:
        raise CompositionError(
            "Cannot compose "
            f"{outer.name}: {object_name(outer.source)} -> {object_name(outer.target)} "
            "after "
            f"{inner.name}: {object_name(inner.source)} -> {object_name(inner.target)}"
        )

    if outer.is_identity:
        return inner
    if inner.is_identity:
        return outer

    factors = inner._factors + outer._factors
    return Morphism(
        source=inner.source,
        target=outer.target,
        mapping=lambda value: outer.apply(inner.apply(value)),
        name=name or f"({outer.name} o {inner.name})",
        arrow_id=("composite", factors),
        metadata={"composite_of": (inner.arrow_id, outer.arrow_id)},
        _factors=factors,
    )


def compose_many(*arrows: Morphism[Any, Any]) -> Morphism[Any, Any]:
    """Compose arrows listed in application order.

    ``compose_many(f, g, h)`` returns ``h o g o f``.
    """

    if not arrows:
        raise ValueError("compose_many requires at least one morphism")
    result = arrows[0]
    for arrow in arrows[1:]:
        result = compose(arrow, result)
    return result


class EquationStatus(Enum):
    """Outcome of a finite morphism-equation check."""

    PASS = "pass"
    FAIL = "fail"
    INCONCLUSIVE = "inconclusive"


@dataclass(frozen=True)
class EquationCounterexample:
    """A finite input on which two parallel arrows disagree."""

    input_value: Any
    left_value: Any = None
    right_value: Any = None
    error: Optional[str] = None


@dataclass(frozen=True)
class EquationResult:
    """Finite evidence for a morphism equation."""

    status: EquationStatus
    checked_inputs: int
    counterexample: Optional[EquationCounterexample] = None
    reason: str = ""

    @property
    def passed(self) -> bool:
        return self.status is EquationStatus.PASS

    def __bool__(self) -> bool:
        return self.passed


@dataclass(frozen=True)
class MorphismEquation:
    """An equation between two parallel morphisms."""

    left: Morphism[Any, Any]
    right: Morphism[Any, Any]

    def __post_init__(self) -> None:
        if not self.left.is_parallel_to(self.right):
            raise ParallelismError(
                "Morphism equation requires parallel arrows, got "
                f"{object_name(self.left.source)} -> {object_name(self.left.target)} "
                "and "
                f"{object_name(self.right.source)} -> {object_name(self.right.target)}"
            )

    def check(
        self,
        inputs: Iterable[Any],
        *,
        value_equal: Callable[[Any, Any], bool] = eq,
        require_samples: bool = True,
    ) -> EquationResult:
        """Check the equation on a declared finite proof window.

        Symbolically identical arrows pass immediately.  Otherwise an empty
        proof window is inconclusive by default, preventing vacuous law checks.
        """

        if self.left == self.right:
            return EquationResult(
                EquationStatus.PASS,
                checked_inputs=0,
                reason="symbolically identical arrows",
            )

        checked = 0
        for value in inputs:
            checked += 1
            try:
                left_value = self.left.apply(value)
                right_value = self.right.apply(value)
            except Exception as exc:  
                return EquationResult(
                    EquationStatus.FAIL,
                    checked_inputs=checked,
                    counterexample=EquationCounterexample(
                        input_value=value,
                        error=f"{type(exc).__name__}: {exc}",
                    ),
                    reason="arrow evaluation raised an exception",
                )
            if not value_equal(left_value, right_value):
                return EquationResult(
                    EquationStatus.FAIL,
                    checked_inputs=checked,
                    counterexample=EquationCounterexample(
                        input_value=value,
                        left_value=left_value,
                        right_value=right_value,
                    ),
                    reason="parallel arrows disagree on a supplied input",
                )

        if checked == 0 and require_samples:
            return EquationResult(
                EquationStatus.INCONCLUSIVE,
                checked_inputs=0,
                reason="no samples supplied for a non-symbolic equation",
            )
        return EquationResult(EquationStatus.PASS, checked_inputs=checked)


@dataclass(frozen=True)
class IsomorphismCheck:
    """Finite validation report for a candidate isomorphism."""

    left_inverse: EquationResult
    right_inverse: EquationResult

    @property
    def passed(self) -> bool:
        return self.left_inverse.passed and self.right_inverse.passed

    def __bool__(self) -> bool:
        return self.passed


@dataclass(frozen=True)
class Isomorphism:
    """A candidate isomorphism with explicitly supplied forward and inverse arrows."""

    forward: Morphism[Any, Any]
    inverse: Morphism[Any, Any]

    def __post_init__(self) -> None:
        if (
            self.forward.source != self.inverse.target
            or self.forward.target != self.inverse.source
        ):
            raise CompositionError(
                "Isomorphism arrows must have opposite source and target objects"
            )

    @property
    def source(self) -> Any:
        return self.forward.source

    @property
    def target(self) -> Any:
        return self.forward.target

    def check(
        self,
        source_inputs: Iterable[Any],
        target_inputs: Iterable[Any],
        *,
        value_equal: Callable[[Any, Any], bool] = eq,
        require_samples: bool = True,
    ) -> IsomorphismCheck:
        """Check both inverse equations on declared finite samples."""

        left = MorphismEquation(
            compose(self.inverse, self.forward),
            identity(self.source),
        ).check(
            source_inputs,
            value_equal=value_equal,
            require_samples=require_samples,
        )
        right = MorphismEquation(
            compose(self.forward, self.inverse),
            identity(self.target),
        ).check(
            target_inputs,
            value_equal=value_equal,
            require_samples=require_samples,
        )
        return IsomorphismCheck(left_inverse=left, right_inverse=right)


