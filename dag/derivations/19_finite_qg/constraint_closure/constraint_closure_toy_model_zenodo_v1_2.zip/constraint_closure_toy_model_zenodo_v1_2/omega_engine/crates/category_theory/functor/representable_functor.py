"""representable_functor shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class RepresentableFunctor:
    """Best-effort shell for a representable functor on a category reference."""

    label: str
    category_ref: str = ""
    representing_object: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "RepresentableFunctor":
        return cls(label=label)

    @classmethod
    def on_category(cls, label: str, category_ref: str) -> "RepresentableFunctor":
        return cls(label=label, category_ref=category_ref)

    @classmethod
    def represented_by(
        cls, label: str, category_ref: str, representing_object: str
    ) -> "RepresentableFunctor":
        return cls(
            label=label,
            category_ref=category_ref,
            representing_object=representing_object,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.category_ref:
            raise ValueError("empty category_ref")



