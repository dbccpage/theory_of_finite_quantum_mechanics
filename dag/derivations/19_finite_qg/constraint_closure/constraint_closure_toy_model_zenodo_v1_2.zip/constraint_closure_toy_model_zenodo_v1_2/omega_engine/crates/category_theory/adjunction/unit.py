"""unit (η) shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Natural-transformation-style record: η : Id_C ⇒ R ∘ L.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class UnitShell:
    """Best-effort shell for an adjunction unit η : Id ⇒ R∘L."""

    label: str
    source_functor: str = ""
    target_functor: str = ""
    components: Dict[str, str] = field(default_factory=dict)
    adjunction_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "UnitShell":
        return cls(label=label)

    @classmethod
    def between(
        cls, label: str, source_functor: str, target_functor: str
    ) -> "UnitShell":
        return cls(
            label=label,
            source_functor=source_functor,
            target_functor=target_functor,
        )

    def with_component(self, object: str, morphism: str) -> "UnitShell":
        self.components[object] = morphism
        return self

    def set_component(self, object: str, morphism: str) -> None:
        self.components[object] = morphism

    def with_adjunction_ref(self, adjunction_ref: str) -> "UnitShell":
        self.adjunction_ref = adjunction_ref
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.source_functor:
            raise ValueError("empty source_functor")
        if not self.target_functor:
            raise ValueError("empty target_functor")
        for obj, mor in self.components.items():
            if not obj or not mor:
                raise ValueError("empty unit component key or value")



