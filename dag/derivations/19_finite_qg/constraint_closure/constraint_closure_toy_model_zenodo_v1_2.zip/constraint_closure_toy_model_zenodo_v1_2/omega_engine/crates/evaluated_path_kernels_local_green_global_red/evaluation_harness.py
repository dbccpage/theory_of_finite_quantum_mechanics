"""
Execution-driven evaluation harness for EPK.

Structure score is declaration-based in this version. It is suitable for
internal gating only when `declared_structure_flags` are supplied by trusted
review code. It is not a non-fuzzable structural verifier.
"""

from __future__ import annotations
import math
import time
from dataclasses import field
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Callable, Mapping, Sequence

MANDATORY_EPK_INVARIANTS: tuple[str, ...] = (
    "identity_gpr_minus_lpr_equals_avg_delta",
    "identity_partition_unity",
    "identity_egd_equals_ngd_plus_pgd",
)


@dataclass(frozen=True, slots=True)
class FailureRecord:
    name: str
    error_type: str
    message: str

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("failure record name must be a non-empty string")
        if not isinstance(self.error_type, str) or not self.error_type:
            raise ValueError("failure record error_type must be a non-empty string")
        if not isinstance(self.message, str):
            raise ValueError("failure record message must be a string")


@dataclass(frozen=True, slots=True)
class ExecutionReport:
    passed: int
    failed: int
    failures: tuple[FailureRecord, ...]
    passed_names: tuple[str, ...]

    def __post_init__(self) -> None:
        if isinstance(self.passed, bool) or not isinstance(self.passed, int):
            raise ValueError("passed must be an integer")
        if isinstance(self.failed, bool) or not isinstance(self.failed, int):
            raise ValueError("failed must be an integer")
        if self.passed < 0 or self.failed < 0:
            raise ValueError("passed/failed must be non-negative")
        if self.failed != len(self.failures):
            raise ValueError("failed must match number of failure records")
        if self.passed != len(self.passed_names):
            raise ValueError("passed must match number of passed names")


@dataclass(frozen=True, slots=True)
class DeterminismReport:
    deterministic: bool
    runtime_ms: float
    failure: FailureRecord | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.deterministic, bool):
            raise ValueError("deterministic must be bool")
        if isinstance(self.runtime_ms, bool):
            raise ValueError("runtime_ms must be numeric, not bool")
        value = float(self.runtime_ms)
        if not math.isfinite(value) or value < 0.0:
            raise ValueError("runtime_ms must be a finite non-negative float")
        object.__setattr__(self, "runtime_ms", value)
        if self.failure is not None and not isinstance(self.failure, FailureRecord):
            raise ValueError("failure must be a FailureRecord or None")


@dataclass(frozen=True, slots=True)
class EvaluationResult:
    tests_passed: int
    tests_failed: int
    invariants_passed: int
    invariants_failed: int
    deterministic: bool
    runtime_ms: float
    score_L: int
    score_E: str
    final_score: float
    failed_tests: tuple[FailureRecord, ...] = field(default_factory=tuple)
    failed_invariants: tuple[FailureRecord, ...] = field(default_factory=tuple)
    notes: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for field_name in (
            "tests_passed",
            "tests_failed",
            "invariants_passed",
            "invariants_failed",
        ):
            value = getattr(self, field_name)
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"{field_name} must be an integer")
            if value < 0:
                raise ValueError(f"{field_name} must be non-negative")

        if self.tests_failed != len(self.failed_tests):
            raise ValueError("tests_failed must match number of failed_tests records")
        if self.invariants_failed != len(self.failed_invariants):
            raise ValueError(
                "invariants_failed must match number of failed_invariants records"
            )

        if not isinstance(self.deterministic, bool):
            raise ValueError("deterministic must be bool")

        if isinstance(self.runtime_ms, bool):
            raise ValueError("runtime_ms must be numeric, not bool")
        runtime = float(self.runtime_ms)
        if not math.isfinite(runtime) or runtime < 0.0:
            raise ValueError("runtime_ms must be finite and non-negative")
        object.__setattr__(self, "runtime_ms", runtime)

        if isinstance(self.score_L, bool) or not isinstance(self.score_L, int):
            raise ValueError("score_L must be an integer")
        if self.score_L < 0 or self.score_L > 6:
            raise ValueError("score_L must be in [0, 6]")

        if self.score_E not in {"LF", "E", "D", "C", "B", "A", "A+"}:
            raise ValueError("score_E must be one of LF/E/D/C/B/A/A+")

        if isinstance(self.final_score, bool):
            raise ValueError("final_score must be numeric, not bool")
        final_score = float(self.final_score)
        if not math.isfinite(final_score) or final_score < 0.0:
            raise ValueError("final_score must be finite and non-negative")
        object.__setattr__(self, "final_score", final_score)

        object.__setattr__(self, "notes", _freeze_notes(self.notes))


def _callable_name(fn: Callable[..., Any]) -> str:
    name = getattr(fn, "__name__", "")
    if isinstance(name, str) and name:
        return name
    return fn.__class__.__name__


def _freeze_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType(
            {key: _freeze_value(item) for key, item in value.items()}
        )
    if isinstance(value, list | tuple):
        return tuple(_freeze_value(item) for item in value)
    if isinstance(value, set | frozenset):
        return frozenset(_freeze_value(item) for item in value)
    return value


def _freeze_notes(notes: Mapping[str, Any]) -> Mapping[str, Any]:
    if not isinstance(notes, Mapping):
        raise ValueError("notes must be a mapping")
    return MappingProxyType({key: _freeze_value(value) for key, value in notes.items()})


def _require_int(value: int, name: str, *, minimum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} must be an integer")
    if minimum is not None and value < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    return value


def _require_declared_structure_flags(
    declared_structure_flags: Mapping[str, bool],
) -> Mapping[str, bool]:
    if not isinstance(declared_structure_flags, Mapping):
        raise ValueError("declared_structure_flags must be a mapping")
    out: dict[str, bool] = {}
    for key, value in declared_structure_flags.items():
        if not isinstance(key, str) or not key:
            raise ValueError("declared_structure_flags keys must be non-empty strings")
        if not isinstance(value, bool):
            raise ValueError(f"declared_structure_flags[{key!r}] must be bool")
        out[key] = value
    return MappingProxyType(out)


def _deterministic_eq(a: Any, b: Any) -> bool:
    if type(a) is not type(b):
        return False
    if isinstance(a, Mapping):
        if set(a.keys()) != set(b.keys()):
            return False
        return all(_deterministic_eq(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)):
        if len(a) != len(b):
            return False
        return all(_deterministic_eq(x, y) for x, y in zip(a, b))

    import sys

    if "numpy" in sys.modules:
        np = sys.modules["numpy"]
        if isinstance(a, np.ndarray):
            return np.array_equal(a, b)

    try:
        res = a == b
        if isinstance(res, bool):
            return res
        import sys

        if "numpy" in sys.modules:
            np = sys.modules["numpy"]
            if isinstance(res, np.ndarray):
                return bool(np.all(res))
        return False
    except Exception:
        return False


def measure_determinism(
    f: Callable[..., Any],
    args: tuple[Any, ...],
    runs: int = 5,
) -> DeterminismReport:
    runs = _require_int(runs, "runs", minimum=2)
    if not isinstance(args, tuple):
        raise ValueError("args must be a tuple")

    outputs: list[Any] = []
    elapsed_ms = 0.0
    for _ in range(runs):
        start = time.perf_counter()
        try:
            outputs.append(f(*args))
        except Exception as exc:
            elapsed_ms += (time.perf_counter() - start) * 1000.0
            return DeterminismReport(
                deterministic=False,
                runtime_ms=elapsed_ms / runs,
                failure=FailureRecord(
                    name=_callable_name(f),
                    error_type=type(exc).__name__,
                    message=str(exc),
                ),
            )
        elapsed_ms += (time.perf_counter() - start) * 1000.0

    deterministic = all(_deterministic_eq(outputs[0], item) for item in outputs[1:])
    return DeterminismReport(
        deterministic=deterministic,
        runtime_ms=elapsed_ms / runs,
    )


def measure_runtime(f: Callable[..., Any], args: tuple[Any, ...]) -> float:
    if not isinstance(args, tuple):
        raise ValueError("args must be a tuple")
    start = time.perf_counter()
    f(*args)
    return (time.perf_counter() - start) * 1000.0


def _run_named_callables(callables: Sequence[Callable[[], None]]) -> ExecutionReport:
    """Execute callables and record pass/fail outcomes for diagnostics only.

    The broad ``except Exception`` below is intentional diagnostic capture: each
    caught exception becomes a ``FailureRecord``, which is a plain execution log
    entry, NOT a typed mathematical refusal. This harness (run_tests,
    run_invariants, and evaluate_system_launch_gate) is strictly diagnostic and
    emits no authority terminals; it never imports from omega_engine.crates.type.terminal.
    """
    passed = 0
    failed = 0
    failures: list[FailureRecord] = []
    passed_names: list[str] = []

    for fn in callables:
        name = _callable_name(fn)
        try:
            fn()
            passed += 1
            passed_names.append(name)
        except Exception as exc:
            failed += 1
            failures.append(
                FailureRecord(
                    name=name,
                    error_type=type(exc).__name__,
                    message=str(exc),
                )
            )

    return ExecutionReport(
        passed=passed,
        failed=failed,
        failures=tuple(failures),
        passed_names=tuple(passed_names),
    )


def run_tests(tests: Sequence[Callable[[], None]]) -> ExecutionReport:
    return _run_named_callables(tests)


def run_invariants(invariants: Sequence[Callable[[], None]]) -> ExecutionReport:
    return _run_named_callables(invariants)


def score_L(declared_structure_flags: Mapping[str, bool]) -> int:
    """
    Structural score from caller-declared flags.
    This is declaration-based, not AST-derived.
    """
    flags = _require_declared_structure_flags(declared_structure_flags)
    score = 1

    if flags.get("uses_functions"):
        score = max(score, 2)
    if flags.get("typed") and flags.get("modular"):
        score = max(score, 3)
    if flags.get("advanced_constructs"):
        score = max(score, 4)
    if flags.get("functional_core") and flags.get("immutability"):
        score = max(score, 5)

    return score


def score_E(
    tests: ExecutionReport,
    invariants: ExecutionReport,
    deterministic: bool,
    mandatory_invariant_names: Sequence[str] = MANDATORY_EPK_INVARIANTS,
) -> str:
    if tests.failed > 0:
        if tests.passed > 0:
            return "C"
        return "D"

    if invariants.failed > 0:
        return "C"

    if not deterministic:
        return "B"

    mandatory = tuple(mandatory_invariant_names)
    if any(not isinstance(name, str) or not name for name in mandatory):
        raise ValueError("mandatory invariant names must be non-empty strings")
    passed = set(invariants.passed_names)
    mandatory_passed = all(name in passed for name in mandatory)

    if tests.passed > 0 and invariants.passed > 0 and mandatory_passed:
        return "A+"
    if tests.passed > 0 and invariants.passed > 0:
        return "A"
    return "B"


def numeric_E(grade: str) -> float:
    scale = {
        "LF": 0.0,
        "E": 0.5,
        "D": 1.0,
        "C": 2.0,
        "B": 3.0,
        "A": 4.0,
        "A+": 5.0,
    }
    if grade not in scale:
        raise ValueError(f"unknown grade: {grade!r}")
    return scale[grade]


def anti_cheat(result: EvaluationResult) -> None:
    if result.tests_failed != 0:
        raise ValueError("tests failing")
    if result.invariants_failed != 0:
        raise ValueError("invariants failing")
    if not result.deterministic:
        raise ValueError("non-deterministic system")


def evaluate_system(
    target_function: Callable[..., Any],
    args: tuple[Any, ...],
    tests: Sequence[Callable[[], None]],
    invariants: Sequence[Callable[[], None]],
    declared_structure_flags: Mapping[str, bool],
    *,
    determinism_runs: int = 5,
    mandatory_invariant_names: Sequence[str] = MANDATORY_EPK_INVARIANTS,
) -> EvaluationResult:
    if not isinstance(args, tuple):
        raise ValueError("args must be a tuple")

    test_report = run_tests(tests)
    invariant_report = run_invariants(invariants)
    det_report = measure_determinism(target_function, args, runs=determinism_runs)

    l_score = score_L(declared_structure_flags)
    e_score = score_E(
        tests=test_report,
        invariants=invariant_report,
        deterministic=det_report.deterministic,
        mandatory_invariant_names=mandatory_invariant_names,
    )

    final_score = 0.6 * l_score + 0.4 * numeric_E(e_score)
    notes: dict[str, Any] = {
        "structure_flags_mode": "declared",
        "mandatory_invariants_required_for_a_plus": tuple(mandatory_invariant_names),
    }
    if det_report.failure is not None:
        notes["determinism_failure"] = {
            "name": det_report.failure.name,
            "error_type": det_report.failure.error_type,
            "message": det_report.failure.message,
        }

    return EvaluationResult(
        tests_passed=test_report.passed,
        tests_failed=test_report.failed,
        invariants_passed=invariant_report.passed,
        invariants_failed=invariant_report.failed,
        deterministic=det_report.deterministic,
        runtime_ms=round(det_report.runtime_ms, 3),
        score_L=l_score,
        score_E=e_score,
        final_score=round(final_score, 3),
        failed_tests=test_report.failures,
        failed_invariants=invariant_report.failures,
        notes=notes,
    )


def evaluate_system_launch_gate(
    target_function: Callable[..., Any],
    args: tuple[Any, ...],
    tests: Sequence[Callable[[], None]],
    invariants: Sequence[Callable[[], None]],
    declared_structure_flags: Mapping[str, bool],
    *,
    determinism_runs: int = 5,
    mandatory_invariant_names: Sequence[str] = MANDATORY_EPK_INVARIANTS,
) -> EvaluationResult:
    result = evaluate_system(
        target_function=target_function,
        args=args,
        tests=tests,
        invariants=invariants,
        declared_structure_flags=declared_structure_flags,
        determinism_runs=determinism_runs,
        mandatory_invariant_names=mandatory_invariant_names,
    )
    anti_cheat(result)

    if result.score_E != "A+":
        raise ValueError(f"Launch gate requires A+ behavior, got {result.score_E}")

    return result





