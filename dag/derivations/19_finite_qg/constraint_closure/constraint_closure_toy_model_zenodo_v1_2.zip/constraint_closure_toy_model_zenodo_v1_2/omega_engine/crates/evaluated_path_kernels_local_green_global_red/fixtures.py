from omega_engine.crates.evaluated_path_kernels_local_green_global_red.core import (
    State,
    PathSegment,
    ComposedPath,
)


def canonical_hidden_failure_fixture() -> list[ComposedPath]:
    """Returns the canonical single-path failure: E1=1, E2=1, Eg=0."""
    s_a = State(id="S_a")
    s_b = State(id="S_b")
    s_c = State(id="S_c")

    seg1 = PathSegment(id="demo_seg1", source=s_a, target=s_b, cost=1.0, eval_pass=True)
    seg2 = PathSegment(id="demo_seg2", source=s_b, target=s_c, cost=1.0, eval_pass=True)
    cp = ComposedPath(id="demo_cp", first=seg1, second=seg2, global_eval_pass=False)
    return [cp]


def exact_composition_fixture() -> tuple[
    list[PathSegment], list[PathSegment], list[ComposedPath], set[str]
]:
    """
    Return segments_a_to_b, segments_b_to_c, composed paths, and boundary IDs.

    This constructs the exact glued fiber product:
    Omega(S_a, B) x_B Omega(B, S_c).
    """
    s_a = State(id="S_a")
    s_b1 = State(id="S_b1")
    s_b2 = State(id="S_b2")
    s_c = State(id="S_c")

    seg_l1 = PathSegment(id="seg_l1", source=s_a, target=s_b1, cost=1.0, eval_pass=True)
    seg_l2 = PathSegment(
        id="seg_l2", source=s_a, target=s_b2, cost=1.5, eval_pass=False
    )
    segments_a_to_b = [seg_l1, seg_l2]

    seg_r1 = PathSegment(id="seg_r1", source=s_b1, target=s_c, cost=2.0, eval_pass=True)
    seg_r2 = PathSegment(id="seg_r2", source=s_b2, target=s_c, cost=1.0, eval_pass=True)
    segments_b_to_c = [seg_r1, seg_r2]

    cp1 = ComposedPath(
        id="cp1",
        first=seg_l1,
        second=seg_r1,
        global_eval_pass=True,
        composed_cost=seg_l1.cost + seg_r1.cost,
    )
    cp2 = ComposedPath(
        id="cp2",
        first=seg_l2,
        second=seg_r2,
        global_eval_pass=False,
        composed_cost=seg_l2.cost + seg_r2.cost,
    )
    composed_paths = [cp1, cp2]

    boundary_states = {"S_b1", "S_b2"}
    return segments_a_to_b, segments_b_to_c, composed_paths, boundary_states


def poe_moe_reference_table_fixture() -> dict[str, object]:
    """Returns static reference data from paper tables for PoE vs MoE comparison."""
    return {
        "source": "paper_reference_table",
        "evidence_class": "ReferenceTable",
        "moe": {
            "success_rate": 0.759,
            "hallucination_rate": 0.062,
            "refusal_rate": 0.0,
        },
        "poe": {
            "success_rate": 0.700,
            "hallucination_rate": 0.003,
            "refusal_rate": 0.300,
        },
    }



