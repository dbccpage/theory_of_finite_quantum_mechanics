"""sum_category (coproduct) shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class SumCategoryShell:
    """Best-effort sum (coproduct) category shell C + D."""

    label: str
    left_summand_label: str = ""
    right_summand_label: str = ""
    left_objects: List[str] = field(default_factory=list)
    right_objects: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "SumCategoryShell":
        return cls(label=label)

    @classmethod
    def of(
        cls, label: str, left_summand_label: str, right_summand_label: str
    ) -> "SumCategoryShell":
        return cls(
            label=label,
            left_summand_label=left_summand_label,
            right_summand_label=right_summand_label,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.left_summand_label:
            raise ValueError("empty left_summand_label")
        if not self.right_summand_label:
            raise ValueError("empty right_summand_label")
        for i, o in enumerate(self.left_objects):
            if not o:
                raise ValueError(f"empty left_objects tag at index {i}")
        for i, o in enumerate(self.right_objects):
            if not o:
                raise ValueError(f"empty right_objects tag at index {i}")



