"""finite_set shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Related contract (if present): ``urn:omega:math:finite_set:v0.1.0``.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class FiniteSet:
    """Best-effort shell for a finite set with explicit element inventory."""

    label: str
    elements: List[str] = field(default_factory=list)
    declared_cardinality: Optional[int] = 0
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "FiniteSet":
        return cls(label=label, declared_cardinality=0)

    @classmethod
    def with_elements(cls, label: str, elements: List[str]) -> "FiniteSet":
        els = list(elements)
        return cls(label=label, elements=els, declared_cardinality=len(els))

    def cardinality(self) -> int:
        return len(self.elements)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        for i, e in enumerate(self.elements):
            if not e:
                raise ValueError(f"empty element tag at index {i}")
        if self.declared_cardinality is not None and self.declared_cardinality != len(
            self.elements
        ):
            raise ValueError(
                f"declared_cardinality {self.declared_cardinality} != "
                f"elements.len() {len(self.elements)}"
            )



