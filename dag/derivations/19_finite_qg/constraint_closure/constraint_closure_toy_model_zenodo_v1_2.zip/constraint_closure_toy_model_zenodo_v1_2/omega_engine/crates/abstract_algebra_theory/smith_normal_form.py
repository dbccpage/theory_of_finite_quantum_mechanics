from dataclasses import dataclass
from enum import Enum
from typing import Any, List, Tuple
import numpy as np


class SmithError(Enum):
    Matrix = "Matrix"
    EmptyMatrixUnsupported = "EmptyMatrixUnsupported"
    Overflow = "Overflow"
    NonIntegerEntry = "NonIntegerEntry"
    InvalidInvariant = "InvalidInvariant"
    DivisibilityViolation = "DivisibilityViolation"
    VerificationFailed = "VerificationFailed"
    AlgorithmIncomplete = "AlgorithmIncomplete"


def _egcd(a: int, b: int) -> Tuple[int, int, int]:
    """Extended Euclidean Algorithm: returns (g, x, y) such that a*x + b*y = g."""
    if b == 0:
        return (abs(a), 1 if a >= 0 else -1, 0)
    g, x1, y1 = _egcd(b, a % b)
    x = y1
    y = x1 - (a // b) * y1
    return (g, x, y)


class SmithDiagonal:
    """Certified diagonal invariants of Smith normal form over Z."""

    def __init__(self, invariants: List[int]):
        self._invariants = [int(x) for x in invariants]

    @classmethod
    def new_checked(cls, invariants: List[int]) -> "SmithDiagonal":
        invs = [int(x) for x in invariants]
        for d in invs:
            if d <= 0:
                raise ValueError("invalid Smith invariant; invariants must be positive")
        for p1, p2 in zip(invs[:-1], invs[1:]):
            if p2 % p1 != 0:
                raise ValueError(f"Smith divisibility violation: {p1} does not divide {p2}")
        return cls(invs)

    def invariants(self) -> List[int]:
        return list(self._invariants)

    def rank(self) -> int:
        return len(self._invariants)


class SmithNormalForm:
    """Result of Smith normal form computation certifying U * A * V = D."""

    def __init__(self, diagonal: SmithDiagonal, diagonal_matrix: np.ndarray, u: np.ndarray, v: np.ndarray):
        self._diagonal = diagonal
        self._diagonal_matrix = np.asarray(diagonal_matrix, dtype=int)
        self._u = np.asarray(u, dtype=int)
        self._v = np.asarray(v, dtype=int)

    def diagonal(self) -> SmithDiagonal:
        return self._diagonal

    def diagonal_matrix(self) -> np.ndarray:
        return self._diagonal_matrix

    def u(self) -> np.ndarray:
        return self._u

    def v(self) -> np.ndarray:
        return self._v


def smith_normal_form_checked(matrix: Any) -> SmithNormalForm:
    """Computes exact integer Smith Normal Form U * A * V = D matching Rust smith_normal_form_checked."""
    arr = np.asarray(matrix, dtype=int)
    m, n = arr.shape
    if m == 0 or n == 0:
        diag = SmithDiagonal([])
        d_mat = np.zeros((m, n), dtype=int)
        u_mat = np.eye(m, dtype=int)
        v_mat = np.eye(n, dtype=int)
        return SmithNormalForm(diagonal=diag, diagonal_matrix=d_mat, u=u_mat, v=v_mat)

    d = [[int(arr[i, j]) for j in range(n)] for i in range(m)]
    u = [[1 if i == j else 0 for j in range(m)] for i in range(m)]
    v = [[1 if i == j else 0 for j in range(n)] for i in range(n)]

    r = min(m, n)

    for k in range(r):
        while True:
            pivot = None
            pivot_abs = None
            for i in range(k, m):
                for j in range(k, n):
                    if d[i][j] != 0:
                        val_abs = abs(d[i][j])
                        if pivot_abs is None or val_abs < pivot_abs:
                            pivot = (i, j)
                            pivot_abs = val_abs

            if pivot is None:
                break

            pi, pj = pivot
            if pi != k:
                d[pi], d[k] = d[k], d[pi]
                u[pi], u[k] = u[k], u[pi]
            if pj != k:
                for row in d:
                    row[pj], row[k] = row[k], row[pj]
                for row in v:
                    row[pj], row[k] = row[k], row[pj]

            if d[k][k] < 0:
                for j in range(n):
                    d[k][j] = -d[k][j]
                for j in range(m):
                    u[k][j] = -u[k][j]

            changed = False

            for i in range(k + 1, m):
                if d[i][k] != 0:
                    g, x, y = _egcd(d[k][k], d[i][k])
                    q1 = d[k][k] // g
                    q2 = d[i][k] // g

                    row_k = list(d[k])
                    row_i = list(d[i])
                    for j in range(n):
                        d[k][j] = x * row_k[j] + y * row_i[j]
                        d[i][j] = -q2 * row_k[j] + q1 * row_i[j]

                    u_k = list(u[k])
                    u_i = list(u[i])
                    for j in range(m):
                        u[k][j] = x * u_k[j] + y * u_i[j]
                        u[i][j] = -q2 * u_k[j] + q1 * u_i[j]
                    changed = True

            for j in range(k + 1, n):
                if d[k][j] != 0:
                    g, x, y = _egcd(d[k][k], d[k][j])
                    q1 = d[k][k] // g
                    q2 = d[k][j] // g

                    for i in range(m):
                        val_k = d[i][k]
                        val_j = d[i][j]
                        d[i][k] = x * val_k + y * val_j
                        d[i][j] = -q2 * val_k + q1 * val_j

                    for i in range(n):
                        val_k = v[i][k]
                        val_j = v[i][j]
                        v[i][k] = x * val_k + y * val_j
                        v[i][j] = -q2 * val_k + q1 * val_j
                    changed = True

            if not changed:
                divides_all = True
                bad_pos = None
                for i in range(k + 1, m):
                    for j in range(k + 1, n):
                        if d[i][j] % d[k][k] != 0:
                            divides_all = False
                            bad_pos = (i, j)
                            break
                    if not divides_all:
                        break

                if not divides_all and bad_pos is not None:
                    bi, bj = bad_pos
                    for j in range(n):
                        d[k][j] += d[bi][j]
                    for j in range(m):
                        u[k][j] += u[bi][j]
                    changed = True
                else:
                    break

    invs = []
    for i in range(min(m, n)):
        if d[i][i] != 0:
            invs.append(abs(d[i][i]))

    diag = SmithDiagonal.new_checked(invs)
    d_mat = np.array(d, dtype=int)
    u_mat = np.array(u, dtype=int)
    v_mat = np.array(v, dtype=int)

    return SmithNormalForm(diagonal=diag, diagonal_matrix=d_mat, u=u_mat, v=v_mat)


def from_rational64_integer_matrix(matrix: Any) -> SmithNormalForm:
    return smith_normal_form_checked(matrix)



