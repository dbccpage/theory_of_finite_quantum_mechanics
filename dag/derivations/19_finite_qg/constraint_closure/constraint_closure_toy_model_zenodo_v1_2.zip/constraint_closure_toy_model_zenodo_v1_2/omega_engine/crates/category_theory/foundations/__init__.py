"""Foundations shells for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Mirrors ``omega_engine/crates/omega_category_theory/src/foundations/``.
"""

from .set import Set
from .finite_set import FiniteSet
from .function import Function, MappingPair
from .universe import Universe
from .hlevel import HLevel
from .truncation import Truncation

__all__ = [
    "Set",
    "FiniteSet",
    "Function",
    "MappingPair",
    "Universe",
    "HLevel",
    "Truncation",
]

