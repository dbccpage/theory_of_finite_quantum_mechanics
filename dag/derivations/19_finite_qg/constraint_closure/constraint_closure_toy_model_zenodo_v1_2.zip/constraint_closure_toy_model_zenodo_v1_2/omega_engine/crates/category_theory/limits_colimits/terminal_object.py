"""terminal_object shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class TerminalObject:
    """Best-effort shell for a terminal object (limit of the empty diagram)."""

    label: str
    object: str = ""
    category_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "TerminalObject":
        return cls(label=label)

    @classmethod
    def in_category(
        cls, label: str, object: str, category_ref: str
    ) -> "TerminalObject":
        return cls(label=label, object=object, category_ref=category_ref)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.object:
            raise ValueError("empty object")
        if not self.category_ref:
            raise ValueError("empty category_ref")



