"""``BoundEpkMeasurement`` — Python mirror of ``omega_engine.crates.evaluated_path_kernels_local_green_global_red::bound_measurement``.

Review of PR
sufficient: ``PrimeContinuationInputs`` took ``detector_adequate`` as an ordinary
keyword, so

.. code-block:: python

    PrimeContinuationInputs(budget=PrimeBudget(100.0, 10.0),
                            detector_adequate=True).evaluate().may_continue

bypassed every gate with no observation, adequacy verdict, or receipt in sight.
And ``DetectorAdequacyVerdict`` is a plain dataclass, so one could simply be
constructed as ``NumericallySupported``.

**RETRACTED / REJECTED_UNSOUND.** An earlier revision of this docstring called the
mint sentinel "a genuine runtime refusal ... which only
:meth:`BoundEpkMeasurement.continuation_evidence` holds". **That is false**, and all
three defeats were reproduced by execution:

* ``SimpleNamespace(detector_adequate=True, adapter_sound=True)`` -- duck typing;
* ``dataclasses.replace(ev, detector_adequate=True)`` -- copies the valid sentinel;
* ``_MINT_SEAL`` is importable and ``_seal_receipt`` publicly callable.

A same-process Python sentinel is **not** an unforgeable capability and cannot be
made into one by another sentinel. Python is therefore ADVISORY: it proposes; an
external verifier decides. The forgeries are harmless only because the continuation
gate is quarantined closed -- see
``crates/omega_engine.crates.evaluated_path_kernels_local_green_global_red/docs/lggr_prime_seam/residual_ledger.md`` § Q-3.

AuthorityEffect: None.
"""

from __future__ import annotations
import hashlib
import struct
from dataclasses import field
from dataclasses import dataclass
from typing import Sequence

from omega_engine.crates.evaluated_path_kernels_local_green_global_red.adequacy import (
    AdequacyKind,
    CompositionObservation,
    DetectorAdequacyVerdict,
    DetectorDeploymentDeclaration,
    evaluate_detector_adequacy,
)
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.verdict import EvaluatorProvenance, LggrVerdict, classify

__all__ = [
    "BOUND_MEASUREMENT_SCHEMA",
    "CanonicalHasher",
    "BoundMeasurementError",
    "ProvenanceNotExhibitedError",
    "CorpusMismatchError",
    "ReceiptHashMismatchError",
    "BoundEpkMeasurement",
]

BOUND_MEASUREMENT_SCHEMA = "omega.epk.bound-measurement.v1"


class BoundMeasurementError(ValueError):
    """Refusal to produce or accept bound evidence."""


class ProvenanceNotExhibitedError(BoundMeasurementError):
    """``Exhibited`` was claimed but the corpus is not ledger-backed."""


class CorpusMismatchError(BoundMeasurementError):
    """Evidence from one corpus was presented to another."""


class ReceiptHashMismatchError(BoundMeasurementError):
    """A receipt's claimed hash does not survive recomputation."""


class CanonicalHasher:
    """Length-prefixed, tagged canonical hasher.

    Every field contributes ``len(tag) || tag || len(value) || value`` with
    big-endian 8-byte lengths. Because both tag and value are length-prefixed, no
    choice of contents can be re-partitioned into a different field sequence — the
    delimiter-collision surface of a NUL-separated encoding does not exist.
    """

    def __init__(self, schema: str) -> None:
        self._h = hashlib.sha256()
        self.bytes_field("schema", schema.encode("utf-8"))

    def bytes_field(self, tag: str, value: bytes) -> "CanonicalHasher":
        t = tag.encode("utf-8")
        self._h.update(struct.pack(">Q", len(t)))
        self._h.update(t)
        self._h.update(struct.pack(">Q", len(value)))
        self._h.update(value)
        return self

    def str_field(self, tag: str, value: str) -> "CanonicalHasher":
        return self.bytes_field(tag, value.encode("utf-8"))

    def int_field(self, tag: str, value: int) -> "CanonicalHasher":
        return self.bytes_field(tag, struct.pack(">q", value))

    def bool_field(self, tag: str, value: bool) -> "CanonicalHasher":
        return self.bytes_field(tag, bytes((int(value),)))

    def float_field(self, tag: str, value: float) -> "CanonicalHasher":
        return self.bytes_field(tag, struct.pack(">d", value))

    def opt_float(self, tag: str, value: float | None) -> "CanonicalHasher":
        if value is None:
            return self.bytes_field(tag, b"\x00")
        self.bytes_field(tag, b"\x01")
        return self.float_field(tag, value)

    def finish(self) -> str:
        return "sha256:" + self._h.hexdigest()


@dataclass(frozen=True, slots=True)
class BoundEpkMeasurement:
    """One measurement over one corpus. Everything downstream is minted from it."""

    corpus_digest: str
    rows: tuple[CompositionObservation, ...]
    adequacy: DetectorAdequacyVerdict
    provenance: EvaluatorProvenance
    ngd: float
    schema: str = field(default=BOUND_MEASUREMENT_SCHEMA)
    authority_effect: str = field(default="None")

    @classmethod
    def measure(
        cls,
        corpus: Sequence[CompositionObservation],
        *,
        declaration: DetectorDeploymentDeclaration | None = None,
        capacity_value: float | None = None,
        provenance: EvaluatorProvenance = EvaluatorProvenance.Exhibited,
        ledger_backed: bool = True,
    ) -> "BoundEpkMeasurement":
        """The only way to obtain bound EPK evidence.

        ``ledger_backed`` is the Python stand-in for the Rust ledger-consistency
        check: ``Exhibited`` is admissible only when the caller can attest the
        evaluator values came from an observation ledger. Claiming ``Exhibited``
        with ``ledger_backed=False`` is a **typed refusal**, not a downgrade.
        """
        if not corpus:
            raise BoundMeasurementError("cannot measure an empty corpus")
        if provenance is EvaluatorProvenance.Exhibited and not ledger_backed:
            raise ProvenanceNotExhibitedError(
                "provenance Exhibited refused: the corpus is not ledger-backed, so "
                "the evaluator values were not observed"
            )

        adequacy = evaluate_detector_adequacy(
            corpus, declaration=declaration, capacity_value=capacity_value
        )
        rows = tuple(corpus)
        ngd = sum(1 for r in rows if r.delta_eval == -1) / len(rows)

        h = CanonicalHasher(BOUND_MEASUREMENT_SCHEMA)
        h.str_field("observed_corpus", adequacy.observed_corpus_digest)
        h.str_field("provenance", provenance.value)
        for r in rows:
            h.str_field("row_id", r.composed_id)
            h.int_field("row_delta", r.delta_eval)
            h.bool_field("row_local_product", r.local_product)
            h.bool_field("row_global_pass", r.global_pass)
        h.float_field("ngd", ngd)

        return cls(
            corpus_digest=h.finish(),
            rows=rows,
            adequacy=adequacy,
            provenance=provenance,
            ngd=ngd,
        )

    def row_count(self) -> int:
        return len(self.rows)

    def verdict(self, index: int) -> LggrVerdict:
        row = self._row(index)
        return classify(
            row.delta_eval,
            local_product=row.local_product,
            global_pass=row.global_pass,
            adequacy=self.adequacy,
            provenance=self.provenance,
        )

    def observe(self, index: int):
        """Mint an observation for one row of **this** corpus."""
        from omega_engine.crates.evaluated_path_kernels_local_green_global_red.prime_seam import LggrEpkObservation

        row = self._row(index)
        return LggrEpkObservation(
            verdict=self.verdict(index),
            adequacy_kind=self.adequacy.kind,
            ngd=self.ngd,
            observed_corpus_digest=self.corpus_digest,
            record_id=row.composed_id,
        )

    def descend(
        self,
        source_carrier: str,
        target_carrier: str,
        observation,
        residual_preservation_verified: bool = True,
        loss_ledger: Sequence[str] = (),
    ):
        """Mint a verified descent receipt for an observation from this corpus."""
        from omega_engine.crates.evaluated_path_kernels_local_green_global_red.prime_seam import PrimeDescentReceipt, VerifiedDescentReceipt

        self._require_same_corpus(observation.observed_corpus_digest)
        receipt = PrimeDescentReceipt(
            source_carrier=source_carrier,
            target_carrier=target_carrier,
            observed_corpus_digest=self.corpus_digest,
            residual_preservation_verified=residual_preservation_verified,
            loss_ledger=tuple(loss_ledger),
            receipt_hash=descent_receipt_hash(
                source_carrier,
                target_carrier,
                self.corpus_digest,
                residual_preservation_verified,
                tuple(loss_ledger),
                observation,
            ),
        )
        return VerifiedDescentReceipt._seal_receipt(receipt)

    def verify_receipt(self, receipt, observation):
        """Promote a transport receipt by recomputing its canonical hash."""
        from omega_engine.crates.evaluated_path_kernels_local_green_global_red.prime_seam import VerifiedDescentReceipt

        self._require_same_corpus(receipt.observed_corpus_digest)
        self._require_same_corpus(observation.observed_corpus_digest)
        recomputed = descent_receipt_hash(
            receipt.source_carrier,
            receipt.target_carrier,
            receipt.observed_corpus_digest,
            receipt.residual_preservation_verified,
            tuple(receipt.loss_ledger),
            observation,
        )
        if recomputed != receipt.receipt_hash:
            raise ReceiptHashMismatchError(
                f"receipt hash mismatch: claimed {receipt.receipt_hash}, "
                f"recomputed {recomputed}"
            )
        return VerifiedDescentReceipt._seal_receipt(receipt)

    def continuation_evidence(self, receipt):
        """Mint sealed continuation evidence.

        ``detector_adequate`` comes from this measurement's adequacy verdict;
        ``adapter_sound`` comes from the receipt. Neither is a caller parameter.
        """
        from omega_engine.crates.evaluated_path_kernels_local_green_global_red.prime_seam import ContinuationEvidence, _MINT_SEAL

        self._require_same_corpus(receipt.observed_corpus_digest())
        return ContinuationEvidence(
            corpus_digest=self.corpus_digest,
            receipt_hash=receipt.receipt_hash(),
            detector_adequate=self.adequacy.kind is AdequacyKind.NumericallySupported,
            adapter_sound=receipt.residual_preservation_verified(),
            _seal=_MINT_SEAL,
        )

    def _row(self, index: int) -> CompositionObservation:
        if not 0 <= index < len(self.rows):
            raise BoundMeasurementError(
                f"row {index} is out of range for a corpus of {len(self.rows)} records"
            )
        return self.rows[index]

    def _require_same_corpus(self, digest: str | None) -> None:
        if digest != self.corpus_digest:
            raise CorpusMismatchError(
                f"evidence is bound to corpus {digest}, this measurement is "
                f"{self.corpus_digest}"
            )


def descent_receipt_hash(
    source_carrier: str,
    target_carrier: str,
    observed_corpus_digest: str,
    residual_preservation_verified: bool,
    loss_ledger: tuple[str, ...],
    observation,
) -> str:
    """Canonical receipt identity binding every semantic field.

    An earlier encoding omitted the corpus digest and the defect triple, so
    distinct observations could share a receipt identity.
    """
    from omega_engine.crates.evaluated_path_kernels_local_green_global_red.prime_seam import PRIME_DESCENT_RECEIPT_SCHEMA

    h = CanonicalHasher(PRIME_DESCENT_RECEIPT_SCHEMA)
    h.str_field("source_carrier", source_carrier)
    h.str_field("target_carrier", target_carrier)
    h.str_field("observed_corpus_digest", observed_corpus_digest)
    h.bool_field("residual_preservation_verified", residual_preservation_verified)
    h.str_field("record_id", observation.record_id or "")
    v: LggrVerdict = observation.verdict
    h.int_field("delta_eval", v.delta_eval)
    h.bool_field("local_product", v.local_product)
    h.bool_field("global_pass", v.global_pass)
    h.str_field("verdict", v.kind.value)
    h.str_field("adequacy_kind", observation.adequacy_kind.value)
    h.float_field("ngd", observation.ngd)
    h.opt_float("nrke", observation.nrke)
    h.bytes_field("loss_ledger_len", struct.pack(">Q", len(loss_ledger)))
    for line in loss_ledger:
        h.str_field("loss", line)
    return h.finish()





