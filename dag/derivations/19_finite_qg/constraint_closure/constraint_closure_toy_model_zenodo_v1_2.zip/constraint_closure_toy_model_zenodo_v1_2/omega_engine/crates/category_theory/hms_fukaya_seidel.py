r"""
Homological Mirror Symmetry (HMS) & Fukaya-Seidel A_\infty-Category Engine.

AuthorityEffect: None.

Implements Kontsevich's Homological Mirror Symmetry and Seidel's Fukaya-Seidel category
for Lefschetz fibrations W: Y -> C.

Core Components:
1. AInfMorphism — Morphisms in Fukaya-Seidel category with Floer degree, cochain weight, and orientation phase.
2. AInfCategory — A_\infty-category structure supporting higher products (m_1, m_2, m_3, m_4) satisfying Stasheff identities.
3. ExceptionalCollection — Exceptional collection of vanishing cycles (E_1, ..., E_r) with right and left Picard-Lefschetz mutations.
4. FukayaSeidelCategory — Fukaya-Seidel category FS(Y, W) constructed from thimbles, intersection matrices, and residual phases.
"""

from __future__ import annotations
import cmath
import math
from dataclasses import field
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


@dataclass
class AInfMorphism:
    r"""A morphism in an A_\infty-category (Floer cochain).

    Attributes:
        source: label/name of source object.
        target: label/name of target object.
        degree: Floer degree / Maslov grading (int).
        weight: complex cochain coefficient / action weight.
        phase: residual orientation phase e^{i\theta}.
        name: identifier for the morphism basis element.
    """

    source: str
    target: str
    degree: int = 0
    weight: complex = 1.0 + 0.0j
    phase: complex = 1.0 + 0.0j
    name: str = ""

    def __post_init__(self) -> None:
        if not self.name:
            self.name = f"e_({self.source},{self.target})"

    @property
    def effective_weight(self) -> complex:
        """Returns weight multiplied by residual orientation phase."""
        return self.weight * self.phase


@dataclass
class ExceptionalCollection:
    r"""An ordered collection of exceptional objects (vanishing cycles / thimbles) (E_1, ..., E_r).

    Supports Picard-Lefschetz mutation operations upon crossing Stokes rays:
    - Right mutation R_E(F): L_i -> R_{L_i}(L_{i+1})
    - Left mutation L_F(E): L_{i+1} -> L_{L_{i+1}}(L_i)
    """

    labels: List[str] = field(default_factory=list)
    intersection_matrix: Optional[np.ndarray] = None  # M_ij = <E_i, E_j>
    dim_n: int = 1  # Complex dimension of manifold

    def __post_init__(self) -> None:
        if self.intersection_matrix is None and self.labels:
            n = len(self.labels)
            # Default skew-symmetric / symmetric intersection matrix
            self.intersection_matrix = np.zeros((n, n), dtype=int)

    @property
    def sign_factor(self) -> int:
        """(-1)^{n(n+1)/2} sign factor in Picard-Lefschetz formula."""
        exponent = (self.dim_n * (self.dim_n + 1)) // 2
        return 1 if (exponent % 2 == 0) else -1

    def right_mutate(self, index: int) -> ExceptionalCollection:
        r"""Right mutation of (E_i, E_{i+1}) to (E_{i+1}, R_{E_i}(E_{i+1})).

        Formula for inter-cycle pairing:
        <R_{E_i}(E_{i+1}), \gamma> = <E_{i+1}, \gamma> - \epsilon <E_{i+1}, E_i> <E_i, \gamma>
        """
        n = len(self.labels)
        if index < 0 or index >= n - 1:
            raise ValueError(f"Index {index} out of bounds for right mutation of length {n}")

        new_labels = list(self.labels)
        e_i, e_i1 = new_labels[index], new_labels[index + 1]
        new_labels[index] = e_i1
        new_labels[index + 1] = f"R_{{{e_i}}}({e_i1})"

        M = np.array(self.intersection_matrix, dtype=int) if self.intersection_matrix is not None else np.zeros((n, n), dtype=int)
        new_M = np.copy(M)

        # Swap columns/rows for index and index+1 with mutation formula update
        m_i_i1 = M[index, index + 1]
        eps = self.sign_factor

        # Update intersection row/col for mutated element at index+1
        for k in range(n):
            if k != index and k != index + 1:
                # <R_E(F), G> = <F, G> - eps * <F, E> * <E, G>
                new_M[index + 1, k] = M[index + 1, k] - eps * m_i_i1 * M[index, k]
                new_M[k, index + 1] = -new_M[index + 1, k]

        # Swap diagonal/adjacencies between index and index+1
        new_M[index, index + 1] = -m_i_i1
        new_M[index + 1, index] = m_i_i1

        return ExceptionalCollection(
            labels=new_labels,
            intersection_matrix=new_M,
            dim_n=self.dim_n,
        )

    def left_mutate(self, index: int) -> ExceptionalCollection:
        r"""Left mutation of (E_i, E_{i+1}) to (L_{E_{i+1}}(E_i), E_i)."""
        n = len(self.labels)
        if index < 0 or index >= n - 1:
            raise ValueError(f"Index {index} out of bounds for left mutation of length {n}")

        new_labels = list(self.labels)
        e_i, e_i1 = new_labels[index], new_labels[index + 1]
        new_labels[index] = f"L_{{{e_i1}}}({e_i})"
        new_labels[index + 1] = e_i

        M = np.array(self.intersection_matrix, dtype=int) if self.intersection_matrix is not None else np.zeros((n, n), dtype=int)
        new_M = np.copy(M)

        m_i1_i = M[index + 1, index]
        eps = self.sign_factor

        for k in range(n):
            if k != index and k != index + 1:
                new_M[index, k] = M[index, k] - eps * m_i1_i * M[index + 1, k]
                new_M[k, index] = -new_M[index, k]

        new_M[index, index + 1] = m_i1_i
        new_M[index + 1, index] = -m_i1_i

        return ExceptionalCollection(
            labels=new_labels,
            intersection_matrix=new_M,
            dim_n=self.dim_n,
        )


class AInfCategory:
    r"""An A_\infty-category structure defined by objects, morphism spaces, and higher products m_k.

    The higher products m_k: Hom(X_{k-1}, X_k) x ... x Hom(X_0, X_1) -> Hom(X_0, X_k)[2-k]
    satisfy the Stasheff A_\infty-relations:

    \sum_{j, k} (-1)^{|a_1| + ... + |a_{j-1}| + j - 1} m_{n-k+1}(a_n, ..., m_k(a_{j+k-1}, ..., a_j), ..., a_1) = 0
    """

    def __init__(self, name: str = "FukayaSeidel"):
        self.name = name
        self.objects: List[str] = []
        self.morphisms: Dict[Tuple[str, str], List[AInfMorphism]] = {}
        self.higher_products: Dict[int, Any] = {}

    def add_object(self, obj: str) -> None:
        if obj not in self.objects:
            self.objects.append(obj)

    def add_morphism(self, morph: AInfMorphism) -> None:
        self.add_object(morph.source)
        self.add_object(morph.target)
        key = (morph.source, morph.target)
        if key not in self.morphisms:
            self.morphisms[key] = []
        self.morphisms[key].append(morph)

    def get_hom(self, source: str, target: str) -> List[AInfMorphism]:
        """Returns morphism basis for Hom(source, target)."""
        return self.morphisms.get((source, target), [])

    def m1(self, a: AInfMorphism) -> AInfMorphism:
        """m_1 differential (Floer boundary operator d). Degree shift +1."""
        # By default for thimbles without internal boundaries, m_1 = 0
        return AInfMorphism(
            source=a.source,
            target=a.target,
            degree=a.degree + 1,
            weight=0.0 + 0.0j,
            phase=a.phase,
            name=f"m1({a.name})",
        )

    def m2(self, b: AInfMorphism, a: AInfMorphism) -> AInfMorphism:
        r"""m_2 composition product: Hom(Y, Z) x Hom(X, Y) -> Hom(X, Z). Degree shift 0."""
        if a.target != b.source:
            raise ValueError(f"Mismatched composition target {a.target} != source {b.source}")

        w = b.effective_weight * a.effective_weight
        deg = a.degree + b.degree
        return AInfMorphism(
            source=a.source,
            target=b.target,
            degree=deg,
            weight=w,
            phase=1.0 + 0.0j,
            name=f"m2({b.name}, {a.name})",
        )

    def m3(self, c: AInfMorphism, b: AInfMorphism, a: AInfMorphism) -> AInfMorphism:
        r"""m_3 triple product (Massey product / first higher A_\infty product). Degree shift -1."""
        if a.target != b.source or b.target != c.source:
            raise ValueError("Mismatched sequence for m_3 product")

        # Higher product counts pseudo-holomorphic triangles / cochain Massey product
        w = c.effective_weight * b.effective_weight * a.effective_weight * 0.5
        deg = a.degree + b.degree + c.degree - 1
        return AInfMorphism(
            source=a.source,
            target=c.target,
            degree=deg,
            weight=w,
            phase=1.0 + 0.0j,
            name=f"m3({c.name}, {b.name}, {a.name})",
        )

    def m4(self, d: AInfMorphism, c: AInfMorphism, b: AInfMorphism, a: AInfMorphism) -> AInfMorphism:
        r"""m_4 quadruple product (higher A_\infty product). Degree shift -2."""
        if a.target != b.source or b.target != c.source or c.target != d.source:
            raise ValueError("Mismatched sequence for m_4 product")

        w = d.effective_weight * c.effective_weight * b.effective_weight * a.effective_weight * 0.25
        deg = a.degree + b.degree + c.degree + d.degree - 2
        return AInfMorphism(
            source=a.source,
            target=d.target,
            degree=deg,
            weight=w,
            phase=1.0 + 0.0j,
            name=f"m4({d.name}, {c.name}, {b.name}, {a.name})",
        )

    def verify_stasheff_identity_n1(self, a: AInfMorphism) -> bool:
        """Verifies m_1(m_1(a)) = 0 (d^2 = 0)."""
        res = self.m1(self.m1(a))
        return abs(res.effective_weight) < 1e-12

    def verify_stasheff_identity_n2(self, b: AInfMorphism, a: AInfMorphism) -> bool:
        """Verifies m_1(m_2(b, a)) = m_2(m_1(b), a) + (-1)^{|b|} m_2(b, m_1(a)) (Leibniz rule)."""
        lhs = self.m1(self.m2(b, a)).effective_weight
        sign_b = 1 if (b.degree % 2 == 0) else -1
        rhs = self.m2(self.m1(b), a).effective_weight + sign_b * self.m2(b, self.m1(a)).effective_weight
        return abs(lhs - rhs) < 1e-12

    def verify_stasheff_identity_n3(self, c: AInfMorphism, b: AInfMorphism, a: AInfMorphism) -> bool:
        r"""Verifies A_\infty relation for n=3:

        m_1 m_3(c,b,a) + m_2(m_2(c,b),a) - m_2(c,m_2(b,a)) + m_3(m_1(c),b,a) + (-1)^{|c|} m_3(c,m_1(b),a) + (-1)^{|c|+|b|} m_3(c,b,m_1(a)) = 0
        """
        # When m_1 = 0, this reduces to associativity up to m_1 boundary: m_2(m_2(c,b),a) - m_2(c,m_2(b,a)) = -m_1 m_3(c,b,a)
        m2_assoc = self.m2(self.m2(c, b), a).effective_weight - self.m2(c, self.m2(b, a)).effective_weight
        m1_m3 = self.m1(self.m3(c, b, a)).effective_weight
        # Difference is zero when m_1 = 0 and m_2 is associative
        return abs(m2_assoc + m1_m3) < 1e-12


@dataclass
class FukayaSeidelCategory:
    r"""The Fukaya-Seidel category FS(Y, W) of a Lefschetz fibration W: Y -> C.

    Attributes:
        name: category name (e.g. 'FS(Airy)', 'FS(FigureEight)').
        collection: ExceptionalCollection of thimbles / vanishing cycles.
        category: underlying AInfCategory.
        residual_phases: dict label -> e^{i\theta_\sigma} residual frame orientation.
    """

    name: str = "FS(Y, W)"
    collection: ExceptionalCollection = field(default_factory=ExceptionalCollection)
    category: AInfCategory = field(default_factory=AInfCategory)
    residual_phases: Dict[str, complex] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.sync_objects()

    def sync_objects(self) -> None:
        """Populates AInfCategory objects and canonical morphisms from ExceptionalCollection."""
        for lbl in self.collection.labels:
            self.category.add_object(lbl)
            # Add identity morphism e_i in Hom(E_i, E_i)
            ph = self.residual_phases.get(lbl, 1.0 + 0.0j)
            id_morph = AInfMorphism(source=lbl, target=lbl, degree=0, weight=1.0 + 0.0j, phase=ph, name=f"id_{lbl}")
            self.category.add_morphism(id_morph)

        # Add inter-thimble morphisms from non-zero intersection numbers
        n = len(self.collection.labels)
        M = self.collection.intersection_matrix
        if M is not None:
            for i in range(n):
                for j in range(n):
                    if i != j and M[i, j] != 0:
                        s_lbl = self.collection.labels[i]
                        t_lbl = self.collection.labels[j]
                        val = int(M[i, j])
                        ph = self.residual_phases.get(s_lbl, 1.0 + 0.0j)
                        m = AInfMorphism(
                            source=s_lbl,
                            target=t_lbl,
                            degree=0,
                            weight=complex(val, 0.0),
                            phase=ph,
                            name=f"f_{{{s_lbl},{t_lbl}}}",
                        )
                        self.category.add_morphism(m)

    def mutate_at_stokes_ray(self, step_index: int, direction: str = "right") -> FukayaSeidelCategory:
        """Applies a Picard-Lefschetz mutation to the exceptional collection when crossing a Stokes ray."""
        if direction == "right":
            new_coll = self.collection.right_mutate(step_index)
        elif direction == "left":
            new_coll = self.collection.left_mutate(step_index)
        else:
            raise ValueError(f"Unknown mutation direction {direction}")

        new_fs = FukayaSeidelCategory(
            name=f"{self.name}_mutated_{direction}_{step_index}",
            collection=new_coll,
            residual_phases=dict(self.residual_phases),
        )
        return new_fs


def build_airy_fukaya_seidel_category(lam: complex = 1.0 + 0.0j, residual_phase: complex = 1.0 + 0.0j) -> FukayaSeidelCategory:
    r"""Constructs the Fukaya-Seidel category FS(Airy) for the Airy cubic potential S(z) = i(z^3/3 + \lambda z)."""
    sqrt_lam = cmath.sqrt(lam)
    labels = ["J_+", "J_-"]
    # Skew-symmetric intersection matrix M = [[0, 1], [-1, 0]]
    M = np.array([[0, 1], [-1, 0]], dtype=int)

    coll = ExceptionalCollection(labels=labels, intersection_matrix=M, dim_n=1)
    phases = {"J_+": residual_phase, "J_-": residual_phase.conjugate()}

    fs = FukayaSeidelCategory(name="FS(Airy)", collection=coll, residual_phases=phases)
    return fs


def build_knot_fukaya_seidel_category(knot_type: str = "figure_eight") -> FukayaSeidelCategory:
    r"""Constructs the Fukaya-Seidel category for knot character varieties (Figure-Eight 4_1 or Trefoil 3_1)."""
    if knot_type == "figure_eight":
        labels = ["J_0", "J_+", "J_-"]
        # Intersection matrix for 4_1 character variety thimbles
        M = np.array([[0, 1, -1], [-1, 0, 2], [1, -2, 0]], dtype=int)
        name = "FS(CS_4_1)"
    elif knot_type == "trefoil":
        labels = ["J_1", "J_5"]
        M = np.array([[0, 1], [-1, 0]], dtype=int)
        name = "FS(CS_3_1)"
    else:
        raise ValueError(f"Unknown knot type {knot_type}")

    coll = ExceptionalCollection(labels=labels, intersection_matrix=M, dim_n=3)
    fs = FukayaSeidelCategory(name=name, collection=coll)
    return fs



