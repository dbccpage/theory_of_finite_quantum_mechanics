"""monad_transformer shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class MonadTransformer:
    """Best-effort shell for a labeled monad transformer."""

    label: str
    outer_ref: str = ""
    inner_monad_ref: str = ""
    result_monad_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "MonadTransformer":
        return cls(label=label)

    @classmethod
    def with_structure(
        cls,
        label: str,
        outer_ref: str,
        inner_monad_ref: str,
    ) -> "MonadTransformer":
        return cls(
            label=label,
            outer_ref=outer_ref,
            inner_monad_ref=inner_monad_ref,
        )

    def with_note(self, note: str) -> "MonadTransformer":
        self.notes.append(note)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.outer_ref:
            raise ValueError("empty outer_ref")
        if not self.inner_monad_ref:
            raise ValueError("empty inner_monad_ref")



