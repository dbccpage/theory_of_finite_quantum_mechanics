"""omega_engine.abstract_algebra_theory package root.

Re-exports finite carriers, quotient witnesses, Phi1, F29 Galois representations,
Lie algebra generators, Smith normal form over Z, and Lawvere diagonal obstruction.
"""

from .finite_carrier import (
    FiniteSet as FiniteSet,
    FiniteVectorSpace as FiniteVectorSpace,
    FiniteMap as FiniteMap,
    MatrixMap as MatrixMap,
    Vector as Vector,
)
from .cochain_complex import CochainComplex as CochainComplex
from .quotient import (
    QuotientWitness as QuotientWitness,
    CertQ1 as CertQ1,
    equivalent as equivalent,
    projection_to_Q1 as projection_to_Q1,
)
from .phi1 import (
    Phi1Witness,
    PrimalCertificate,
    DualCertificate,
    compute_phi1_lp_float,
    compute_phi1_exact,
)
from .f29 import (
    F29Element,
    F29GaloisRepresentationPacket,
    verify_f29_representation,
)
from .lie_algebras import (
    MultiChannelSymmetry,
)
from .smith_normal_form import (
    SmithDiagonal,
    SmithError,
)
from .lawvere_impossibility import (
    LawvereImpossibility,
)
from .algebraic_field import (
    AlgebraicField as AlgebraicField,
    make_rational_field as make_rational_field,
    make_quadratic_field as make_quadratic_field,
)
from .algebraic_k_theory import (
    AlgebraicKTheory as AlgebraicKTheory,
    KGroup as KGroup,
    make_k_theory_integers as make_k_theory_integers,
    make_k_theory_field as make_k_theory_field,
)

__all__ = [
    "FiniteSet",
    "FiniteVectorSpace",
    "FiniteMap",
    "MatrixMap",
    "Vector",
    "CochainComplex",
    "QuotientWitness",
    "CertQ1",
    "equivalent",
    "projection_to_Q1",
    "Phi1Witness",
    "PrimalCertificate",
    "DualCertificate",
    "compute_phi1_lp_float",
    "compute_phi1_exact",
    "F29Element",
    "F29GaloisRepresentationPacket",
    "verify_f29_representation",
    "MultiChannelSymmetry",
    "SmithDiagonal",
    "SmithError",
    "LawvereImpossibility",
    "AlgebraicField",
    "make_rational_field",
    "make_quadratic_field",
    "AlgebraicKTheory",
    "KGroup",
    "make_k_theory_integers",
    "make_k_theory_field",
]
