"""additivity shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Additive-category shape flags (zero object, biproducts). Not a proof of
enrichment over Ab or of biproduct existence.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Additivity:
    """Best-effort shell for an additive-category claim."""

    label: str
    has_biproducts: bool = False
    zero_object: bool = False
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Additivity":
        return cls(label=label)

    @classmethod
    def with_flags(
        cls, label: str, has_biproducts: bool, zero_object: bool
    ) -> "Additivity":
        return cls(
            label=label,
            has_biproducts=has_biproducts,
            zero_object=zero_object,
        )

    def with_note(self, note: str) -> "Additivity":
        self.notes.append(note)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")



