"""reflective subcategory shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Subcategory + reflector labels; inclusion may admit left adjoint r ⊣ i.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class ReflectiveSubcategoryShell:
    """Best-effort shell for a reflective subcategory declaration."""

    label: str
    ambient_category: str = ""
    subcategory: str = ""
    inclusion: str = ""
    reflector: str = ""
    unit_ref: str = ""
    counit_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "ReflectiveSubcategoryShell":
        return cls(label=label)

    @classmethod
    def with_labels(
        cls,
        label: str,
        ambient_category: str,
        subcategory: str,
        reflector: str,
    ) -> "ReflectiveSubcategoryShell":
        return cls(
            label=label,
            ambient_category=ambient_category,
            subcategory=subcategory,
            reflector=reflector,
        )

    def with_inclusion(self, inclusion: str) -> "ReflectiveSubcategoryShell":
        self.inclusion = inclusion
        return self

    def with_unit_counit(
        self, unit_ref: str, counit_ref: str
    ) -> "ReflectiveSubcategoryShell":
        self.unit_ref = unit_ref
        self.counit_ref = counit_ref
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.ambient_category:
            raise ValueError("empty ambient_category")
        if not self.subcategory:
            raise ValueError("empty subcategory")
        if not self.reflector:
            raise ValueError("empty reflector")



