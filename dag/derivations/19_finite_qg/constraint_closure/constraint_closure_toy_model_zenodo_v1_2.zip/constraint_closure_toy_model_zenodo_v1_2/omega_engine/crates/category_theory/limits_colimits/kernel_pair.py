"""kernel_pair shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class KernelPair:
    """Best-effort shell for a kernel pair of a morphism f : A → B."""

    label: str
    pair_object: str = ""
    source: str = ""
    target: str = ""
    morphism_f: str = ""
    projection_left: str = ""
    projection_right: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "KernelPair":
        return cls(label=label)

    @classmethod
    def of_morphism(
        cls,
        label: str,
        pair_object: str,
        source: str,
        target: str,
        morphism_f: str,
        projection_left: str,
        projection_right: str,
    ) -> "KernelPair":
        return cls(
            label=label,
            pair_object=pair_object,
            source=source,
            target=target,
            morphism_f=morphism_f,
            projection_left=projection_left,
            projection_right=projection_right,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.pair_object:
            raise ValueError("empty pair_object")
        if not self.source:
            raise ValueError("empty source")
        if not self.target:
            raise ValueError("empty target")
        if not self.morphism_f:
            raise ValueError("empty morphism_f")
        if not self.projection_left:
            raise ValueError("empty projection_left")
        if not self.projection_right:
            raise ValueError("empty projection_right")



