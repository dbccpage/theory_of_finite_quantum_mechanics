"""rigid_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class RigidCategory:
    """Best-effort rigid monoidal category shell."""

    label: str
    monoidal_ref: str = ""
    left_dual_ref: str = ""
    right_dual_ref: str = ""
    left_unit_ref: str = ""
    left_counit_ref: str = ""
    right_unit_ref: str = ""
    right_counit_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "RigidCategory":
        return cls(label=label)

    @classmethod
    def with_duals(
        cls,
        label: str,
        monoidal_ref: str,
        left_dual_ref: str,
        right_dual_ref: str,
    ) -> "RigidCategory":
        return cls(
            label=label,
            monoidal_ref=monoidal_ref,
            left_dual_ref=left_dual_ref,
            right_dual_ref=right_dual_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.monoidal_ref:
            raise ValueError("empty monoidal_ref")
        if not self.left_dual_ref:
            raise ValueError("empty left_dual_ref")
        if not self.right_dual_ref:
            raise ValueError("empty right_dual_ref")



