"""coequalizer shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Coequalizer:
    """Best-effort shell for a coequalizer of a parallel pair."""

    label: str
    coequalizer_object: str = ""
    source: str = ""
    target: str = ""
    morphism_f: str = ""
    morphism_g: str = ""
    coequalizer_morphism: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Coequalizer":
        return cls(label=label)

    @classmethod
    def of_pair(
        cls,
        label: str,
        coequalizer_object: str,
        source: str,
        target: str,
        morphism_f: str,
        morphism_g: str,
        coequalizer_morphism: str,
    ) -> "Coequalizer":
        return cls(
            label=label,
            coequalizer_object=coequalizer_object,
            source=source,
            target=target,
            morphism_f=morphism_f,
            morphism_g=morphism_g,
            coequalizer_morphism=coequalizer_morphism,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.coequalizer_object:
            raise ValueError("empty coequalizer_object")
        if not self.source:
            raise ValueError("empty source")
        if not self.target:
            raise ValueError("empty target")
        if not self.morphism_f:
            raise ValueError("empty morphism_f")
        if not self.morphism_g:
            raise ValueError("empty morphism_g")
        if not self.coequalizer_morphism:
            raise ValueError("empty coequalizer_morphism")



