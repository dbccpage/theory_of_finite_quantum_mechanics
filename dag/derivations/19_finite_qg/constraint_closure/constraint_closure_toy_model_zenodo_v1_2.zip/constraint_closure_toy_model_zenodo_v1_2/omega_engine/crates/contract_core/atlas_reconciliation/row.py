from pydantic import ConfigDict
from enum import Enum
from typing import List
from dataclasses import field
from pydantic.dataclasses import dataclass

from omega_engine.crates.contract_core.kinds import AuthorityEffect, ComponentRole
from omega_engine.crates.type.evidence import EvidenceCeiling

from .cochain_validity import CochainValidity, TriState
from .identity_witness import IdentityWitness
from .primitive_difference import PrimitiveDifferenceJudgment


def authority_rank(e: AuthorityEffect) -> int:
    # Match the Rust ranking
    # AuthorityEffect is an enum in omega_contract_core.kinds.
    # In Rust: None => 0, EvidenceOnly => 1, FactOnly => 2, RequiresEvaluator => 3,
    # RequestsDecision => 4, AuthorizesTransition => 5, StateTransition => 6.
    mapping = {
        AuthorityEffect.None_: 0,
        AuthorityEffect.EvidenceOnly: 1,
        AuthorityEffect.FactOnly: 2,
        AuthorityEffect.RequiresEvaluator: 3,
        AuthorityEffect.RequestsDecision: 4,
        AuthorityEffect.AuthorizesTransition: 5,
        AuthorityEffect.StateTransition: 6,
    }
    return mapping.get(e, 0)


class ClaimDelta(Enum):
    Undersold = "Undersold"
    Accurate = "Accurate"
    Oversold = "Oversold"
    Missing = "Missing"


class ReconVerdict(Enum):
    Aligned = "Aligned"
    Drifted = "Drifted"
    ClaimWithoutCode = "ClaimWithoutCode"
    CodeWithoutProduct = "CodeWithoutProduct"
    Overclaim = "Overclaim"
    UnverifiableAbstain = "UnverifiableAbstain"


class Surface(Enum):
    Public = "Public"
    Private = "Private"
    Research = "Research"


class BuildStatus(Enum):
    Builds = "Builds"
    UnbuiltUnwired = "UnbuiltUnwired"
    NotApplicable = "NotApplicable"


class TestsState(Enum):
    __test__ = False
    None_ = "None"
    WrittenUnrun = "WrittenUnrun"
    Run = "Run"
    Green = "Green"
    CiGated = "CiGated"


class AuthorityBasis(Enum):
    Test = "Test"
    Lean = "Lean"
    Golden = "Golden"
    Replay = "Replay"
    None_ = "None"


class TerminalStatus(Enum):
    ExactRepair = "ExactRepair"
    StabilizedSurvivor = "StabilizedSurvivor"
    LicensedLift = "LicensedLift"
    OpenObstruction = "OpenObstruction"
    BudgetUnknown = "BudgetUnknown"
    NoRule = "NoRule"
    Refused = "Refused"
    RepresentationMalformed = "RepresentationMalformed"
    CochainInvalid = "CochainInvalid"
    GovernanceDrift = "GovernanceDrift"


class Route(Enum):
    Sprint = "Sprint"
    MathDev = "MathDev"
    PaperHygiene = "PaperHygiene"
    Doctrine = "Doctrine"
    None_ = "None"


class VerifyResult(Enum):
    Confirmed = "Confirmed"
    Downgraded = "Downgraded"
    Refuted = "Refuted"


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class AuthClaim:
    claim: str
    basis: AuthorityBasis


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class ProofStatus:
    enc_refs: List[str]
    status: str
    lean_status: str
    relative_axioms: List[str] = field(default_factory=list)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class Terminal:
    status: TerminalStatus
    reason: str


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class VerifyVerdict:
    result: VerifyResult
    refutation: str


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class RoutedItem:
    item: str
    route: Route


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class ReconciliationRow:
    row_id: str
    asset_id: str
    claimed: str
    observed: str
    claim_delta: ClaimDelta
    recon_verdict: ReconVerdict
    surface: Surface
    build_status: BuildStatus
    tests_state: TestsState
    proof_status: ProofStatus
    evidence_ceiling: EvidenceCeiling
    declared_authority_effect: AuthorityEffect
    role: ComponentRole
    role_pinned_ceiling: AuthorityEffect
    authority_basis: List[AuthClaim]
    primitive_difference: PrimitiveDifferenceJudgment
    cochain_validity: CochainValidity
    identity_witness: IdentityWitness
    terminal_status: Terminal
    verify_verdict: VerifyVerdict
    routed_work: List[RoutedItem]
    doctrine_version: str

    @classmethod
    def sample_good(cls) -> "ReconciliationRow":
        # Tigers objects
        iw = IdentityWitness.tiger()
        iw.object_kind = "crate"

        return cls(
            row_id="ROW-0001",
            asset_id="omega_types::authority",
            claimed="stub",
            observed="HARDENED machine-checked",
            claim_delta=ClaimDelta.Undersold,
            recon_verdict=ReconVerdict.Drifted,
            surface=Surface.Private,
            build_status=BuildStatus.Builds,
            tests_state=TestsState.Green,
            proof_status=ProofStatus(
                enc_refs=["ENC-0001"],
                status="PROVED-PROSE",
                lean_status="MECHANIZED",
                relative_axioms=[],
            ),
            evidence_ceiling=EvidenceCeiling.LOCAL_REPLAY,
            declared_authority_effect=AuthorityEffect.None_,
            role=ComponentRole.MathObject,
            role_pinned_ceiling=AuthorityEffect.None_,
            authority_basis=[AuthClaim("sealed authority type", AuthorityBasis.Lean)],
            primitive_difference=PrimitiveDifferenceJudgment(
                left_presentation="atlas:stub",
                right_presentation="code:HARDENED",
                zero_difference_relation="path off-by-one + rename",
                licensed_equivalences=["crates/ prefix"],
                quotient_residual="maturity mismatch",
                residual_class="UNDERSOLD",
                factors_through_quotient=True,
            ),
            cochain_validity=CochainValidity(
                chain=["product", "crate", "proof", "contract"],
                d0_declared="atlas->crate",
                d1_declared="crate->proof",
                d1_d0_zero=TriState.True_,
                failure_reason="",
                d0=[[1], [1]],
                d1=[[1, 1]],
            ),
            identity_witness=iw,
            terminal_status=Terminal(
                status=TerminalStatus.OpenObstruction,
                reason="undersold; product wrapper missing",
            ),
            verify_verdict=VerifyVerdict(
                result=VerifyResult.Confirmed,
                refutation="tried to show stub; found sealed + tests",
            ),
            routed_work=[RoutedItem("wrap authority surface", Route.Sprint)],
            doctrine_version="000",
        )





