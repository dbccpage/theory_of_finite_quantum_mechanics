"""Certificate Kernel Contract Subsystem Implementation.

Conforms strictly to contract specification:
    urn:omega:evidence:certificate_kernel:v1.0.0
    (omega_engine/crates/omega_contracts/src/contract_canonical_definitions/02_core_evidence/certificate_kernel.contract.yaml)

Doctrine:
- Binds typed claims to attached evidence under a declared verifier capability.
- Unchecked certificates and proof witnesses are EvidenceOnly.
- Verified certificates support FactOnly claims within authority bounds.
- Never self-certifies or creates authority beyond evidence.
"""

from __future__ import annotations
import hashlib
import json
from dataclasses import field
from pydantic.dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Union

CONTRACT_ID = "urn:omega:evidence:certificate_kernel:v1.0.0"
SCHEMA_VERSION = "omega.contract.v1"


class CertificateKind(str, Enum):
    """Canonical certificate kind enumeration."""

    ANALYSIS_CERTIFICATE = "AnalysisCertificate"
    REPLAY_CERTIFICATE = "ReplayCertificate"
    WITNESS_CERTIFICATE = "WitnessCertificate"
    LIFT_LICENSE_EVIDENCE = "LiftLicenseEvidence"
    TRACE_CERTIFICATE = "TraceCertificate"


@dataclass(frozen=True)
class CertificateEnvelope:
    """Raw certificate envelope conforming to urn:omega:evidence:certificate_kernel:v1.0.0."""

    certificate_id: str
    kind: CertificateKind
    claim: Dict[str, Any]
    evidence_refs: List[str] = field(default_factory=list)
    witness_refs: List[str] = field(default_factory=list)
    measurement_refs: List[str] = field(default_factory=list)
    replay_refs: List[str] = field(default_factory=list)
    certificate_hash: str = field(default_factory=str)
    authority_effect: str = "EvidenceOnly"

    def compute_hash(self) -> str:
        payload = {
            "certificate_id": self.certificate_id,
            "kind": self.kind.value if isinstance(self.kind, Enum) else str(self.kind),
            "claim": self.claim,
            "evidence_refs": [str(e) for e in self.evidence_refs],
            "witness_refs": [str(w) for w in self.witness_refs],
            "measurement_refs": [str(m) for m in self.measurement_refs],
            "replay_refs": [str(r) for r in self.replay_refs],
            "authority_effect": self.authority_effect,
        }
        raw_bytes = json.dumps(payload, sort_keys=True).encode("utf-8")
        return hashlib.sha256(raw_bytes).hexdigest()


@dataclass(frozen=True)
class VerifiedCertificateClaim:
    """Verified certificate claim envelope (FactOnly)."""

    certificate_ref: str
    verifier_ref: str
    evidence_authority_bound: str
    verified_claim_hash: str
    authority_effect: str = "FactOnly"


@dataclass(frozen=True)
class RefusedCertificateClaim:
    """Refused certificate claim (AuthorityEffect: Refused)."""

    certificate_ref: str
    verifier_ref: str
    refusal_reason: str
    authority_effect: str = "Refused"


class CertificateKernel:
    """Kernel for managing certificate creation, evidence reference tracking, and verification."""

    def __init__(
        self,
        kernel_id: str = "omega_cert_kernel_001",
        kernel_version: str = "v1.0.0",
    ):
        self.kernel_id = kernel_id
        self.kernel_version = kernel_version
        self.schema_hash = self.compute_schema_hash()

    def compute_schema_hash(self) -> str:
        raw = f"{CONTRACT_ID}:{SCHEMA_VERSION}:{self.kernel_id}:{self.kernel_version}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def create_envelope(
        self,
        certificate_id: str,
        kind: CertificateKind,
        claim: Dict[str, Any],
        evidence_refs: Optional[List[str]] = None,
        witness_refs: Optional[List[str]] = None,
        measurement_refs: Optional[List[str]] = None,
        replay_refs: Optional[List[str]] = None,
    ) -> CertificateEnvelope:
        """Create a typed CertificateEnvelope."""
        env = CertificateEnvelope(
            certificate_id=certificate_id,
            kind=kind,
            claim=claim,
            evidence_refs=evidence_refs or [],
            witness_refs=witness_refs or [],
            measurement_refs=measurement_refs or [],
            replay_refs=replay_refs or [],
            authority_effect="EvidenceOnly",
        )
        c_hash = env.compute_hash()
        return CertificateEnvelope(
            certificate_id=env.certificate_id,
            kind=env.kind,
            claim=env.claim,
            evidence_refs=env.evidence_refs,
            witness_refs=env.witness_refs,
            measurement_refs=env.measurement_refs,
            replay_refs=env.replay_refs,
            certificate_hash=c_hash,
            authority_effect="EvidenceOnly",
        )

    def verify_envelope(
        self,
        envelope: CertificateEnvelope,
        verifier_ref: str = "cert_verifier_001",
    ) -> Union[VerifiedCertificateClaim, RefusedCertificateClaim]:
        """Verify certificate claim and return VerifiedCertificateClaim or RefusedCertificateClaim."""
        expected_hash = envelope.compute_hash()
        if not envelope.certificate_hash or envelope.certificate_hash != expected_hash:
            return RefusedCertificateClaim(
                certificate_ref=envelope.certificate_id,
                verifier_ref=verifier_ref,
                refusal_reason=f"Certificate hash mismatch: expected {expected_hash}, got {envelope.certificate_hash}",
            )

        v_hash = hashlib.sha256(f"{envelope.certificate_hash}:{verifier_ref}".encode("utf-8")).hexdigest()
        return VerifiedCertificateClaim(
            certificate_ref=envelope.certificate_id,
            verifier_ref=verifier_ref,
            evidence_authority_bound=envelope.authority_effect,
            verified_claim_hash=v_hash,
            authority_effect="FactOnly",
        )


def verify_certificate_contract(kernel_instance: CertificateKernel) -> bool:
    """Verify that a certificate kernel instance conforms to urn:omega:evidence:certificate_kernel:v1.0.0."""
    return (
        isinstance(kernel_instance, CertificateKernel)
        and hasattr(kernel_instance, "kernel_id")
        and hasattr(kernel_instance, "create_envelope")
    )


@dataclass(frozen=True)
class FOCRealCert:
    packet: Any
    witness: Any
    authority_effect: str = "None"

    def __post_init__(self) -> None:
        from omega_engine.crates.replay import ReplayTracePacket
        if not isinstance(self.packet, ReplayTracePacket):
            raise TypeError("requires a ReplayTracePacket")
        packet_hash = getattr(self.packet, "replay_hash", None)
        witness_hash = getattr(self.witness, "replay_hash", None)
        if packet_hash is not None and witness_hash is not None and packet_hash != witness_hash:
            raise ValueError("witness not bound to packet")


from omega_engine.crates.packet.packet import CheckedPacket


__all__ = [
    "CONTRACT_ID",
    "SCHEMA_VERSION",
    "CertificateKind",
    "CertificateEnvelope",
    "VerifiedCertificateClaim",
    "RefusedCertificateClaim",
    "FOCRealCert",
    "CertificateKernel",
    "verify_certificate_contract",
    "CheckedPacket",
]




