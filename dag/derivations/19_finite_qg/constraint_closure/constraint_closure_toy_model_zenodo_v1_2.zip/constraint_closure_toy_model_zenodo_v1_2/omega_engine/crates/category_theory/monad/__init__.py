"""Monad shells for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Mirrors ``omega_engine/crates/omega_category_theory/src/monad/``.
"""

from .monad import Monad
from .comonad import Comonad
from .kleisli_category import KleisliCategory
from .eilenberg_moore import EilenbergMoore
from .algebra_for_monad import AlgebraForMonad
from .coalgebra_for_comonad import CoalgebraForComonad
from .monad_transformer import MonadTransformer
from .distributive_law import DistributiveLaw

__all__ = [
    "Monad",
    "Comonad",
    "KleisliCategory",
    "EilenbergMoore",
    "AlgebraForMonad",
    "CoalgebraForComonad",
    "MonadTransformer",
    "DistributiveLaw",
]

