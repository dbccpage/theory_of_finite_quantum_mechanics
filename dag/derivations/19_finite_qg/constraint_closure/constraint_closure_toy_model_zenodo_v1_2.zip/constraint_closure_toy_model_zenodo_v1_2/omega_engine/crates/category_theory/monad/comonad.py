"""comonad shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Comonad:
    """Best-effort shell for a labeled comonad (W, ε, δ). Dual of Monad."""

    label: str
    endofunctor_ref: str = ""
    counit_ref: str = ""
    comultiply_ref: str = ""
    category_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Comonad":
        return cls(label=label)

    @classmethod
    def with_structure(
        cls,
        label: str,
        endofunctor_ref: str,
        counit_ref: str,
        comultiply_ref: str,
    ) -> "Comonad":
        return cls(
            label=label,
            endofunctor_ref=endofunctor_ref,
            counit_ref=counit_ref,
            comultiply_ref=comultiply_ref,
        )

    def with_note(self, note: str) -> "Comonad":
        self.notes.append(note)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.endofunctor_ref:
            raise ValueError("empty endofunctor_ref")
        if not self.counit_ref:
            raise ValueError("empty counit_ref")
        if not self.comultiply_ref:
            raise ValueError("empty comultiply_ref")



