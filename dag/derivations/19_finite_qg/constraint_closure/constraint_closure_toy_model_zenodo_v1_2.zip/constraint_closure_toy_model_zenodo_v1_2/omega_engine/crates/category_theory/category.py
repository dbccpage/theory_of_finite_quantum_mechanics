"""Executable category presentations for finite Omega test windows.

The objects and declared arrows form a finite presentation.  Composition and
identity are supplied by :mod:`morphism`; law checks are evaluated on explicit
finite samples and report inconclusive evidence instead of passing vacuously.

``Morphism``, ``compose``, and ``identity`` are re-exported here to preserve the
original public import surface.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Iterator, List, Mapping, Set, Tuple

from .morphism import (
    EquationResult,
    EquationStatus,
    Morphism,
    MorphismEquation,
    compose,
    identity,
)


class DuplicateMorphismError(ValueError):
    """Raised when one symbolic arrow id is assigned conflicting callables."""


@dataclass(frozen=True)
class Object:
    """A named object in a category.

    Object identity is its name.  ``value`` is optional carrier metadata and is
    intentionally excluded from equality and hashing.
    """

    name: str
    value: Any = field(default=None, compare=False, hash=False)

    def __post_init__(self) -> None:
        if self.value is None:
            object.__setattr__(self, "value", self.name)

    def __repr__(self) -> str:
        return f"Object({self.name})"


@dataclass(frozen=True)
class CategoryLawFailure:
    """One failed or inconclusive category-law check."""

    law: str
    message: str
    equation: EquationResult | None = None


@dataclass(frozen=True)
class CategoryLawReport:
    """Finite validation report for a category presentation."""

    checked_equations: int
    failures: Tuple[CategoryLawFailure, ...] = ()
    inconclusive: Tuple[CategoryLawFailure, ...] = ()

    @property
    def passed(self) -> bool:
        return not self.failures and not self.inconclusive

    def __bool__(self) -> bool:
        return self.passed


class Category:
    """A finite executable presentation of a concrete category.

    Declared morphisms are kept in finite hom-set inventories.  Composites can
    be synthesized for law checks without mutating that inventory.
    """

    def __init__(self, name: str) -> None:
        self.name = name
        self.objects: Set[Any] = set()
        self.morphisms: Dict[Tuple[Any, Any], List[Morphism]] = {}
        self._identities: Dict[Any, Morphism] = {}

    def add_object(self, obj: Any) -> None:
        """Register an object and exactly one canonical identity arrow."""

        if obj in self.objects:
            return
        if len(self.objects) >= 512:
            raise RuntimeError(
                "OperationLimits breach: category objects exceed max_category_objects 512"
            )
        self.objects.add(obj)
        identity_morphism = identity(obj)
        self._identities[obj] = identity_morphism
        self._insert_morphism(identity_morphism)

    def _insert_morphism(self, morph: Morphism) -> None:
        pair = (morph.source, morph.target)
        hom_set = self.morphisms.setdefault(pair, [])
        for existing in hom_set:
            if existing != morph:
                continue
            if (
                existing is morph
                or existing.mapping is morph.mapping
                or (existing.is_identity and morph.is_identity)
            ):
                return
            raise DuplicateMorphismError(
                f"Symbolic arrow {morph.arrow_id!r} already exists in "
                f"Hom({morph.source!r}, {morph.target!r}) with a different "
                "callable; supply a distinct arrow_id or reuse the same arrow"
            )
        hom_set.append(morph)

    def add_morphism(self, morph: Morphism) -> None:
        """Register a typed arrow and ensure both endpoint identities exist."""

        if not isinstance(morph, Morphism):
            raise TypeError("Category arrows must be Morphism instances")
        self.add_object(morph.source)
        self.add_object(morph.target)
        self._insert_morphism(morph)

    def hom(self, source: Any, target: Any) -> List[Morphism]:
        """Return a copy of the declared hom-set inventory."""

        return list(self.morphisms.get((source, target), ()))

    def identity(self, obj: Any) -> Morphism:
        """Return the category's canonical identity for ``obj``."""

        try:
            return self._identities[obj]
        except KeyError as exc:
            raise KeyError(f"{obj!r} is not an object of category {self.name}") from exc

    def contains_morphism(self, morph: Morphism) -> bool:
        """Return whether the arrow is present in the declared hom-set."""

        return morph in self.morphisms.get((morph.source, morph.target), ())

    def iter_morphisms(self) -> Iterator[Morphism]:
        """Iterate over all declared arrows exactly once."""

        for hom_set in self.morphisms.values():
            yield from hom_set

    def composable_pairs(self) -> Iterator[Tuple[Morphism, Morphism]]:
        """Yield ``(outer, inner)`` for every declared composable pair."""

        for middle in self.objects:
            incoming = (
                morph
                for (source, target), hom_set in self.morphisms.items()
                if target == middle
                for morph in hom_set
            )
            outgoing = [
                morph
                for (source, target), hom_set in self.morphisms.items()
                if source == middle
                for morph in hom_set
            ]
            for inner in incoming:
                for outer in outgoing:
                    yield outer, inner

    def compose(
        self,
        outer: Morphism,
        inner: Morphism,
        *,
        require_declared: bool = True,
    ) -> Morphism:
        """Compose two category arrows without silently accepting foreign arrows."""

        if require_declared:
            for morph in (outer, inner):
                if not self.contains_morphism(morph):
                    raise ValueError(
                        f"Arrow {morph.name!r} is not declared in category {self.name}"
                    )
        return compose(outer, inner)

    def validate(
        self,
        test_inputs: Mapping[Any, Iterable[Any]],
        *,
        require_samples: bool = True,
    ) -> CategoryLawReport:
        """Check left/right identity and associativity on a finite proof window."""

        failures: List[CategoryLawFailure] = []
        inconclusive: List[CategoryLawFailure] = []
        checked = 0

        def record(law: str, equation: EquationResult, message: str) -> None:
            nonlocal checked
            checked += 1
            finding = CategoryLawFailure(law, message, equation)
            if equation.status is EquationStatus.FAIL:
                failures.append(finding)
            elif equation.status is EquationStatus.INCONCLUSIVE:
                inconclusive.append(finding)

        for morph in self.iter_morphisms():
            samples = test_inputs.get(morph.source, ())
            left = MorphismEquation(
                compose(self.identity(morph.target), morph),
                morph,
            ).check(samples, require_samples=require_samples)
            record("left_identity", left, f"id o {morph.name} = {morph.name}")

            right = MorphismEquation(
                compose(morph, self.identity(morph.source)),
                morph,
            ).check(samples, require_samples=require_samples)
            record("right_identity", right, f"{morph.name} o id = {morph.name}")

        for obj_a in self.objects:
            for obj_b in self.objects:
                for obj_c in self.objects:
                    for obj_d in self.objects:
                        for first in self.hom(obj_a, obj_b):
                            for second in self.hom(obj_b, obj_c):
                                for third in self.hom(obj_c, obj_d):
                                    lhs = compose(compose(third, second), first)
                                    rhs = compose(third, compose(second, first))
                                    result = MorphismEquation(lhs, rhs).check(
                                        test_inputs.get(obj_a, ()),
                                        require_samples=require_samples,
                                    )
                                    record(
                                        "associativity",
                                        result,
                                        (
                                            f"({third.name} o {second.name}) o "
                                            f"{first.name} = {third.name} o "
                                            f"({second.name} o {first.name})"
                                        ),
                                    )

        return CategoryLawReport(
            checked_equations=checked,
            failures=tuple(failures),
            inconclusive=tuple(inconclusive),
        )

    def __contains__(self, value: Any) -> bool:
        if isinstance(value, Morphism):
            return self.contains_morphism(value)
        return value in self.objects

    def __repr__(self) -> str:
        return (
            f"Category({self.name!r}, objects={len(self.objects)}, "
            f"morphisms={sum(len(hom_set) for hom_set in self.morphisms.values())})"
        )


def check_associativity_finite(
    cat: Category,
    test_inputs: Dict[Object, List[Any]],
    *,
    require_samples: bool = True,
) -> bool:
    """Backward-compatible finite associativity predicate.

    Empty non-symbolic proof windows fail by default.
    """

    for obj_a in cat.objects:
        for obj_b in cat.objects:
            for obj_c in cat.objects:
                for obj_d in cat.objects:
                    for first in cat.hom(obj_a, obj_b):
                        for second in cat.hom(obj_b, obj_c):
                            for third in cat.hom(obj_c, obj_d):
                                lhs = compose(compose(third, second), first)
                                rhs = compose(third, compose(second, first))
                                result = MorphismEquation(lhs, rhs).check(
                                    test_inputs.get(obj_a, ()),
                                    require_samples=require_samples,
                                )
                                if not result:
                                    return False
    return True



