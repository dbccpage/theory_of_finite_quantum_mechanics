"""distributive_law shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class DistributiveLaw:
    """Best-effort shell for a labeled distributive law λ : TG ⇒ GT."""

    label: str
    monad_t_ref: str = ""
    monad_g_ref: str = ""
    transformation_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "DistributiveLaw":
        return cls(label=label)

    @classmethod
    def with_structure(
        cls,
        label: str,
        monad_t_ref: str,
        monad_g_ref: str,
        transformation_ref: str,
    ) -> "DistributiveLaw":
        return cls(
            label=label,
            monad_t_ref=monad_t_ref,
            monad_g_ref=monad_g_ref,
            transformation_ref=transformation_ref,
        )

    def with_note(self, note: str) -> "DistributiveLaw":
        self.notes.append(note)
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.monad_t_ref:
            raise ValueError("empty monad_t_ref")
        if not self.monad_g_ref:
            raise ValueError("empty monad_g_ref")
        if not self.transformation_ref:
            raise ValueError("empty transformation_ref")



