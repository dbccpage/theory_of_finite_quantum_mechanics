"""Conformance harness tests. AuthorityEffect: None."""
