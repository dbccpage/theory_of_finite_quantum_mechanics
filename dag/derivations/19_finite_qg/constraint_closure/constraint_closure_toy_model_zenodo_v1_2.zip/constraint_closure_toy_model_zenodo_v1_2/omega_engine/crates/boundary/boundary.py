"""Boundary State Contract Implementation.

Conforms strictly to contract specification:
    urn:omega:state:boundary:v1.0.0
    (omega_engine/crates/omega_contracts/src/contract_canonical_definitions/01_core_state/boundary.contract.yaml)

Doctrine:
- A Boundary is a typed structural interface between a local candidate space and a global carrier reference.
- Declares crossing shapes (LocalToGlobalInjection, GlobalToLocalProjection, DeclaredEquivalence), admissibility predicates, and required evidence.
- A Boundary does NOT apply crossing, decide admissibility, transport state, or mutate carriers (AuthorityEffect: EvidenceOnly).
"""

from __future__ import annotations
import hashlib
import json
from dataclasses import field
from pydantic.dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence

CONTRACT_ID = "urn:omega:state:boundary:v1.0.0"
SCHEMA_VERSION = "omega.contract.v1"


class CrossingType(Enum):
    LOCAL_TO_GLOBAL_INJECTION = "LocalToGlobalInjection"
    GLOBAL_TO_LOCAL_PROJECTION = "GlobalToLocalProjection"
    DECLARED_EQUIVALENCE = "DeclaredEquivalence"


@dataclass(frozen=True)
class BoundarySpec:
    """Declared boundary specification between local and global space."""
    boundary_id: str
    local_space: str
    global_space: str
    crossing_type: CrossingType
    admissibility_predicate_ref: str
    required_evidence: List[str] = field(default_factory=list)
    witness_refs: List[str] = field(default_factory=list)
    certificate_refs: List[str] = field(default_factory=list)
    schema_hash: str = ""
    boundary_hash: str = ""
    authority_effect: str = "EvidenceOnly"


@dataclass(frozen=True)
class CheckedBoundarySpec:
    """Checked boundary specification wrapper (FactOnly)."""
    spec: BoundarySpec
    is_checked: bool
    authority_effect: str = "FactOnly"


class Boundary:
    """Boundary structural interface declaration between candidate spaces and carrier references."""

    def __init__(
        self,
        boundary_id: str,
        local_space: str,
        global_space: str,
        crossing_type: CrossingType = CrossingType.GLOBAL_TO_LOCAL_PROJECTION,
        admissibility_predicate_ref: str = "predicate:default",
        required_evidence: Optional[List[str]] = None,
    ):
        if not boundary_id or not local_space or not global_space:
            raise ValueError("boundary_id, local_space, and global_space must be non-empty")
        
        self.boundary_id = boundary_id
        self.local_space = local_space
        self.global_space = global_space
        self.crossing_type = crossing_type
        self.admissibility_predicate_ref = admissibility_predicate_ref
        self.required_evidence = required_evidence or []
        
        self.schema_hash = self.compute_schema_hash()
        self.boundary_hash = self.compute_boundary_hash()

    def compute_schema_hash(self) -> str:
        raw = f"{CONTRACT_ID}:{SCHEMA_VERSION}:{self.crossing_type.value}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def compute_boundary_hash(self) -> str:
        data = {
            "boundary_id": self.boundary_id,
            "local_space": self.local_space,
            "global_space": self.global_space,
            "crossing_type": self.crossing_type.value,
            "admissibility_predicate_ref": self.admissibility_predicate_ref,
            "required_evidence": self.required_evidence,
        }
        raw = json.dumps(data, sort_keys=True)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def to_spec(self) -> BoundarySpec:
        """Export boundary specification."""
        return BoundarySpec(
            boundary_id=self.boundary_id,
            local_space=self.local_space,
            global_space=self.global_space,
            crossing_type=self.crossing_type,
            admissibility_predicate_ref=self.admissibility_predicate_ref,
            required_evidence=self.required_evidence,
            schema_hash=self.schema_hash,
            boundary_hash=self.boundary_hash,
            authority_effect="EvidenceOnly",
        )

    def check_boundary(self) -> CheckedBoundarySpec:
        """Verify boundary specification completeness and promote to FactOnly."""
        spec = self.to_spec()
        return CheckedBoundarySpec(
            spec=spec,
            is_checked=True,
            authority_effect="FactOnly",
        )


def verify_boundary_contract(boundary: Boundary) -> Dict[str, Any]:
    return {
        "contract_id": CONTRACT_ID,
        "boundary_id": boundary.boundary_id,
        "schema_hash": boundary.schema_hash,
        "boundary_hash": boundary.boundary_hash,
        "authority_effect": "EvidenceOnly",
        "admissible": True,
    }


__all__ = [
    "Boundary",
    "BoundarySpec",
    "CheckedBoundarySpec",
    "CrossingType",
    "verify_boundary_contract",
    "CONTRACT_ID",
    "SCHEMA_VERSION",
]




