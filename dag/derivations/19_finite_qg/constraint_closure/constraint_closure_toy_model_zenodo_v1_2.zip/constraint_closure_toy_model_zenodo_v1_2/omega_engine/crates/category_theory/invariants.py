"""Invariant packets and fiberwise invariant categories.

Implements the fiberwise invariant category Inv(L) and certified transport
functors described in the canonical math spine.
"""

from typing import Any, Callable, Optional, Set
from .category import Category, Morphism
from omega_engine.crates.homotopy_type_theory.types import Result, Success, Refusal


class WitnessProtocol:
    """Validator protocol for replaying an invariant claim under a witness.

    Wraps a check function ``(claim, witness) -> Result`` so that a packet's
    witness protocol can be replayed during verification.
    """

    def __init__(self, check_func: Callable[[Any, Any], Result]) -> None:
        self.check_func = check_func

    def check(self, claim: Any, witness: Any) -> Result:
        return self.check_func(claim, witness)


class InvariantPacket:
    """Invariant packet (X, I, V, Preserve, WitnessProtocol).

    Represents a specific mathematical invariant on a carrier.
    """

    def __init__(
        self,
        layer: str,
        carrier: Any,
        value_object: Any,
        invariant_map: Callable[[Any], Any],
        preserve: Set[str],
        witness_protocol: Callable[[Any, Any], Result],
    ) -> None:
        self.layer = layer
        self.carrier = carrier
        self.value_object = value_object
        self.invariant_map = invariant_map
        self.preserve = preserve
        self.witness_protocol = witness_protocol

    def compute(self) -> Any:
        """Evaluate the invariant map on the carrier."""
        return self.invariant_map(self.carrier)

    def replay_witness(self, claim: Any, witness: Any) -> Result:
        """Validate a claimed invariant value using the witness protocol."""
        return self.witness_protocol(claim, witness)

    def __repr__(self) -> str:
        return f"InvariantPacket(layer={self.layer}, val={self.compute()!r})"


class CertifiedInvariantMorphism:
    """Certified morphism between invariant packets (f, g, certificate).

    Requires that: J o f == g o I, where I, J are the invariant maps.
    """

    def __init__(
        self,
        source: InvariantPacket,
        target: InvariantPacket,
        carrier_map: Callable[[Any], Any],
        value_map: Callable[[Any], Any],
        certificate: Any,
    ) -> None:
        self.source = source
        self.target = target
        self.carrier_map = carrier_map
        self.value_map = value_map
        self.certificate = certificate

    def verify(self) -> Result:
        """Verify the commuting square J(f(x)) == g(I(x)) under the certificate."""
        fx = self.carrier_map(self.source.carrier)
        j_fx = self.target.invariant_map(fx)

        ix = self.source.compute()
        g_ix = self.value_map(ix)

        if j_fx != g_ix:
            return Refusal(
                reason="CommutingSquareViolation",
                details=f"J(f(x)) = {j_fx} but g(I(x)) = {g_ix}",
            )

        src_check = self.source.replay_witness(ix, self.certificate)
        if isinstance(src_check, Refusal):
            return Refusal(
                reason="SourceWitnessProtocolFailed", details=src_check.reason
            )

        tgt_check = self.target.replay_witness(j_fx, self.certificate)
        if isinstance(tgt_check, Refusal):
            return Refusal(
                reason="TargetWitnessProtocolFailed", details=tgt_check.reason
            )

        return Success(True)


class BoundedDefectMorphism:
    """An approximate morphism checking d_W(J o f, g o I) <= epsilon.

    Unlike :class:`CertifiedInvariantMorphism`, the commuting square is allowed
    to fail up to a metric tolerance ``epsilon``. To remain a *certified*
    diagnostic rather than a bare numeric bound, a bounded-defect morphism must
    also carry a certificate and a defect witness protocol that is replayed at
    verification time; verification refuses when the protocol is absent.
    """

    def __init__(
        self,
        source: InvariantPacket,
        target: InvariantPacket,
        carrier_map: Callable[[Any], Any],
        value_map: Callable[[Any], Any],
        epsilon: float,
        metric: Callable[[Any, Any], float],
        certificate: Any = None,
        defect_protocol: Optional[WitnessProtocol] = None,
    ) -> None:
        self.source = source
        self.target = target
        self.carrier_map = carrier_map
        self.value_map = value_map
        self.epsilon = epsilon
        self.metric = metric
        self.certificate = certificate
        self.defect_protocol = defect_protocol

    def verify(self) -> Result:
        """Check the approximate commuting square and replay the defect protocol.

        Returns ``Success(True)`` when the metric defect is within ``epsilon``
        and the defect protocol replays successfully; otherwise returns a typed
        ``Refusal``. Refuses outright if no defect protocol is supplied.
        """
        if self.defect_protocol is None:
            return Refusal(
                reason="MissingDefectProtocol",
                details="BoundedDefectMorphism requires a defect witness protocol",
            )

        fx = self.carrier_map(self.source.carrier)
        j_fx = self.target.invariant_map(fx)

        ix = self.source.compute()
        g_ix = self.value_map(ix)

        defect = self.metric(j_fx, g_ix)
        if defect > self.epsilon:
            return Refusal(
                reason="EpsilonBoundExceeded",
                details=f"d_W(J(f(x)), g(I(x))) = {defect} > {self.epsilon}",
            )

        protocol_check = self.defect_protocol.check(defect, self.certificate)
        if isinstance(protocol_check, Refusal):
            return Refusal(
                reason="DefectProtocolFailed",
                details=protocol_check.reason,
            )

        return Success(True)


class InvariantCategory(Category):
    """Fiberwise invariant category Inv(L) for a layer L."""

    def __init__(self, layer: str) -> None:
        super().__init__(name=f"Inv({layer})")
        self.layer = layer

    def add_packet(self, packet: InvariantPacket) -> None:
        if packet.layer != self.layer:
            raise ValueError(
                f"Packet layer {packet.layer} does not match category layer {self.layer}"
            )
        self.add_object(packet)

    def add_certified_morphism(self, morph: CertifiedInvariantMorphism) -> None:
        verification = morph.verify()
        if isinstance(verification, Refusal):
            raise ValueError(f"Morphism verification failed: {verification.reason}")
        cat_morph = Morphism(
            source=morph.source,
            target=morph.target,
            mapping=lambda x: morph.carrier_map(x.carrier),
            name=f"CertifiedMap({morph.certificate})",
        )
        self.add_morphism(cat_morph)



