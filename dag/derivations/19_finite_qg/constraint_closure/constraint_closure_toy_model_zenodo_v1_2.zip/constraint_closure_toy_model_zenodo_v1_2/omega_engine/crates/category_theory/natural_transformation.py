"""Natural transformations and natural isomorphisms.

These structures sit one categorical level above :class:`Functor`.  Naturality
and componentwise invertibility are checked on explicit finite target-carrier
samples, so the result is a bounded executable certificate rather than a claim
of unrestricted function equality.
"""

from __future__ import annotations
from dataclasses import dataclass
from operator import eq
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Tuple

from .functor import Functor, FunctorError
from .morphism import (
    EquationResult,
    EquationStatus,
    Isomorphism,
    IsomorphismCheck,
    Morphism,
    MorphismEquation,
    compose,
)


class NaturalTransformationError(ValueError):
    """Raised for malformed transformations or invalid composition."""


@dataclass(frozen=True)
class NaturalityFailure:
    """One failed or inconclusive naturality square."""

    message: str
    source_morphism: Optional[Morphism] = None
    equation: Optional[EquationResult] = None


@dataclass(frozen=True)
class NaturalityReport:
    """Finite validation report for a natural transformation."""

    component_checks: int
    naturality_checks: int
    failures: Tuple[NaturalityFailure, ...] = ()
    inconclusive: Tuple[NaturalityFailure, ...] = ()

    @property
    def passed(self) -> bool:
        return not self.failures and not self.inconclusive

    def __bool__(self) -> bool:
        return self.passed


class NaturalTransformation:
    """A candidate natural transformation ``eta: F => G``."""

    def __init__(
        self,
        name: str,
        source_functor: Functor,
        target_functor: Functor,
        components: Callable[[Any], Morphism] | Mapping[Any, Morphism],
    ) -> None:
        if source_functor.source is not target_functor.source:
            raise NaturalTransformationError(
                "Parallel functors must have the same source category"
            )
        if source_functor.target is not target_functor.target:
            raise NaturalTransformationError(
                "Parallel functors must have the same target category"
            )
        if not callable(components) and not isinstance(components, Mapping):
            raise TypeError("components must be a callable or mapping")

        self.name = name
        self.source_functor = source_functor
        self.target_functor = target_functor
        self._components = components
        self._component_cache: Dict[Any, Morphism] = {}

    @property
    def source_category(self):
        return self.source_functor.source

    @property
    def target_category(self):
        return self.source_functor.target

    def component(self, obj: Any) -> Morphism:
        """Return and type-check ``eta_obj: F(obj) -> G(obj)``."""

        if obj not in self.source_category.objects:
            raise NaturalTransformationError(
                f"{obj!r} is not an object of {self.source_category.name}"
            )
        if obj not in self._component_cache:
            if callable(self._components):
                component = self._components(obj)
            else:
                try:
                    component = self._components[obj]
                except KeyError as exc:
                    raise NaturalTransformationError(
                        f"Missing component of {self.name} at {obj!r}"
                    ) from exc

            if not isinstance(component, Morphism):
                raise NaturalTransformationError(
                    f"Component of {self.name} at {obj!r} is not a Morphism"
                )
            expected_source = self.source_functor.maps_object(obj)
            expected_target = self.target_functor.maps_object(obj)
            if (
                component.source != expected_source
                or component.target != expected_target
            ):
                raise NaturalTransformationError(
                    f"Component {component.name!r} at {obj!r} has type "
                    f"{component.source!r} -> {component.target!r}; expected "
                    f"{expected_source!r} -> {expected_target!r}"
                )
            self._component_cache[obj] = component
        return self._component_cache[obj]

    def validate(
        self,
        target_test_inputs: Mapping[Any, Iterable[Any]],
        *,
        value_equal: Callable[[Any, Any], bool] = eq,
        require_samples: bool = True,
        require_registered_components: bool = True,
    ) -> NaturalityReport:
        """Check component typing and every declared naturality square.

        For ``f: A -> B``, the checked equation is
        ``G(f) o eta_A = eta_B o F(f)`` on samples of ``F(A)``.
        """

        failures: List[NaturalityFailure] = []
        inconclusive: List[NaturalityFailure] = []
        component_checks = 0
        naturality_checks = 0

        for obj in self.source_category.objects:
            component_checks += 1
            try:
                component = self.component(obj)
                if (
                    require_registered_components
                    and not self.target_category.contains_morphism(component)
                ):
                    failures.append(
                        NaturalityFailure(
                            message=(
                                f"Component {component.name!r} at {obj!r} is not "
                                f"a declared arrow of {self.target_category.name}"
                            )
                        )
                    )
            except (FunctorError, NaturalTransformationError, TypeError) as exc:
                failures.append(NaturalityFailure(message=str(exc)))

        for source_morphism in self.source_category.iter_morphisms():
            naturality_checks += 1
            try:
                eta_source = self.component(source_morphism.source)
                eta_target = self.component(source_morphism.target)
                left = compose(
                    self.target_functor.maps_morphism(source_morphism),
                    eta_source,
                )
                right = compose(
                    eta_target,
                    self.source_functor.maps_morphism(source_morphism),
                )
                source_image = self.source_functor.maps_object(source_morphism.source)
                equation = MorphismEquation(left, right).check(
                    target_test_inputs.get(source_image, ()),
                    value_equal=value_equal,
                    require_samples=require_samples,
                )
                finding = NaturalityFailure(
                    message=(
                        f"Naturality failed for source arrow {source_morphism.name!r}"
                    ),
                    source_morphism=source_morphism,
                    equation=equation,
                )
                if equation.status is EquationStatus.FAIL:
                    failures.append(finding)
                elif equation.status is EquationStatus.INCONCLUSIVE:
                    inconclusive.append(finding)
            except (
                FunctorError,
                NaturalTransformationError,
                TypeError,
                ValueError,
            ) as exc:
                failures.append(
                    NaturalityFailure(
                        message=str(exc),
                        source_morphism=source_morphism,
                    )
                )

        return NaturalityReport(
            component_checks=component_checks,
            naturality_checks=naturality_checks,
            failures=tuple(failures),
            inconclusive=tuple(inconclusive),
        )

    def __repr__(self) -> str:
        return (
            f"NaturalTransformation({self.name}: "
            f"{self.source_functor.name} => {self.target_functor.name})"
        )


def identity_natural_transformation(
    functor: Functor,
    *,
    name: Optional[str] = None,
) -> NaturalTransformation:
    """Return the identity natural transformation on ``functor``."""

    return NaturalTransformation(
        name=name or f"id_{functor.name}",
        source_functor=functor,
        target_functor=functor,
        components=lambda obj: functor.target.identity(functor.maps_object(obj)),
    )


def vertical_compose(
    upper: NaturalTransformation,
    lower: NaturalTransformation,
    *,
    name: Optional[str] = None,
) -> NaturalTransformation:
    """Return the vertical composite ``upper o lower``."""

    if lower.target_functor is not upper.source_functor:
        raise NaturalTransformationError(
            "Vertical composition requires lower.target_functor to be "
            "upper.source_functor"
        )
    return NaturalTransformation(
        name=name or f"({upper.name} o {lower.name})",
        source_functor=lower.source_functor,
        target_functor=upper.target_functor,
        components=lambda obj: compose(
            upper.component(obj),
            lower.component(obj),
        ),
    )


@dataclass(frozen=True)
class NaturalIsomorphismReport:
    """Finite validation report for a natural isomorphism."""

    forward_naturality: NaturalityReport
    inverse_naturality: NaturalityReport
    component_checks: Tuple[Tuple[Any, IsomorphismCheck], ...]

    @property
    def passed(self) -> bool:
        return (
            self.forward_naturality.passed
            and self.inverse_naturality.passed
            and all(check.passed for _, check in self.component_checks)
        )

    def __bool__(self) -> bool:
        return self.passed


@dataclass(frozen=True)
class NaturalIsomorphism:
    """Opposite natural transformations whose components are finite isomorphisms."""

    forward: NaturalTransformation
    inverse: NaturalTransformation

    def __post_init__(self) -> None:
        if (
            self.forward.source_functor is not self.inverse.target_functor
            or self.forward.target_functor is not self.inverse.source_functor
        ):
            raise NaturalTransformationError(
                "Natural-isomorphism transformations must have opposite directions"
            )

    def validate(
        self,
        target_test_inputs: Mapping[Any, Iterable[Any]],
        *,
        value_equal: Callable[[Any, Any], bool] = eq,
        require_samples: bool = True,
        require_registered_components: bool = True,
    ) -> NaturalIsomorphismReport:
        """Validate both transformations and every component inverse pair."""

        forward_report = self.forward.validate(
            target_test_inputs,
            value_equal=value_equal,
            require_samples=require_samples,
            require_registered_components=require_registered_components,
        )
        inverse_report = self.inverse.validate(
            target_test_inputs,
            value_equal=value_equal,
            require_samples=require_samples,
            require_registered_components=require_registered_components,
        )

        checks: List[Tuple[Any, IsomorphismCheck]] = []
        for obj in self.forward.source_category.objects:
            forward_component = self.forward.component(obj)
            inverse_component = self.inverse.component(obj)
            source_obj = forward_component.source
            target_obj = forward_component.target
            checks.append(
                (
                    obj,
                    Isomorphism(
                        forward_component,
                        inverse_component,
                    ).check(
                        target_test_inputs.get(source_obj, ()),
                        target_test_inputs.get(target_obj, ()),
                        value_equal=value_equal,
                        require_samples=require_samples,
                    ),
                )
            )

        return NaturalIsomorphismReport(
            forward_naturality=forward_report,
            inverse_naturality=inverse_report,
            component_checks=tuple(checks),
        )


