from pydantic import ConfigDict
from enum import Enum
from typing import List, Optional, Any
from dataclasses import field
from pydantic.dataclasses import dataclass
from omega_engine.crates.contract_core.kinds import (
    ContractCategory,
    ComponentRole,
    ContractStatus,
    AuthorityEffect,
    CapabilityPolicy,
    ArtifactKind,
)
from omega_engine.crates.type import EvidenceCeiling


class ArtifactFamily(Enum):
    StructureArtifact = "StructureArtifact"
    EvidenceEnvelope = "EvidenceEnvelope"
    FactEnvelope = "FactEnvelope"
    DecisionEnvelope = "DecisionEnvelope"
    ActionLicense = "ActionLicense"
    Action = "Action"
    Record = "Record"


class OperatorClass(Enum):
    E = "E"
    I = "I"  # noqa: E741
    C = "C"
    R = "R"
    M = "M"


class UrosSystem(Enum):
    GeneralTheory = "GeneralTheory"
    Kernel = "Kernel"
    ArtifactFamilies = "ArtifactFamilies"
    Runtime = "Runtime"
    Codex = "Codex"
    Encyclopedia = "Encyclopedia"
    LevelSystem = "LevelSystem"
    Tiers = "Tiers"
    OperatorLevels = "OperatorLevels"


class RegistryKind(Enum):
    Codex = "Codex"
    Encyclopedia = "Encyclopedia"


class AuthorityLayer(Enum):
    Structure = "Structure"
    Evidence = "Evidence"
    Fact = "Fact"
    Judgment = "Judgment"
    Action = "Action"
    Record = "Record"
    Runtime = "Runtime"


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class ExpressivityCoordinate:
    domain: str
    operator_height: Optional[int] = None
    meta_height: Optional[int] = None


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class UrosBlock:
    system: UrosSystem
    subsystem: str
    artifact_family: ArtifactFamily
    registry: RegistryKind
    domain: str
    tier: int
    artifact_kind: Optional[ArtifactKind] = None
    operator_height: Optional[int] = None
    meta_height: Optional[int] = None


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class ConstitutionalBlock:
    emits: ArtifactFamily
    authority_layer: AuthorityLayer
    contract_dependencies: List[str] = field(default_factory=list)
    law_refs: List[str] = field(default_factory=list)
    forbidden_later_layers: List[AuthorityLayer] = field(default_factory=list)
    replay_certificates: List[str] = field(default_factory=list)

    def validate(self) -> None:
        from omega_engine.crates.contract_core.validate import validate_constitutional_block

        validate_constitutional_block(self)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class SignatureBlock:
    input: Optional[str] = None
    output: Optional[str] = None


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class RequiresBlock:
    licenses: List[str] = field(default_factory=list)
    declarations: List[str] = field(default_factory=list)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class ValidationBlock:
    validators: List[str] = field(default_factory=list)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class WitnessesBlock:
    required: List[str] = field(default_factory=list)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class ReplayBlock:
    required: List[str] = field(default_factory=list)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class LawRequirementsBlock:
    required: List[str] = field(default_factory=list)


class PhiLawDecl(Enum):
    NonIncreasing = "NonIncreasing"
    Reducing = "Reducing"
    Unrestricted = "Unrestricted"


class StructureLawDecl(Enum):
    Preserving = "Preserving"
    Reductive = "Reductive"
    Transforming = "Transforming"


class EffectLawDecl(Enum):
    Pure = "Pure"
    ReadOnly = "ReadOnly"
    Stateful = "Stateful"


class LawPresence:
    """Helper representing presence or absence of a law requirement."""

    def __init__(self, required_val: Optional[Any] = None) -> None:
        self.required_val = required_val

    def is_required(self) -> bool:
        return self.required_val is not None

    def as_option(self) -> Optional[Any]:
        return self.required_val

    def __repr__(self) -> str:
        if self.is_required():
            return f"Required({self.required_val})"
        return "Forbidden"


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class LawBlock:
    phi: Optional[PhiLawDecl] = None
    structure: Optional[StructureLawDecl] = None
    effect: Optional[EffectLawDecl] = None
    required: List[str] = field(default_factory=list)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class ConstraintBlock:
    total_over_domain: Optional[bool] = None
    deterministic: Optional[bool] = None
    search_forbidden: Optional[bool] = None
    hidden_state_forbidden: Optional[bool] = None
    iteration_forbidden: Optional[bool] = None
    mutation_forbidden: Optional[bool] = None
    read_only: Optional[bool] = None
    typed_output_required: Optional[bool] = None
    operator_execution_forbidden: Optional[bool] = None
    runtime_orchestration_forbidden: Optional[bool] = None
    immutable_after_emit: Optional[bool] = None
    policy_version_required: Optional[bool] = None
    certificate_required: Optional[bool] = None
    action_license_required: Optional[bool] = None
    checker_boundary_required: Optional[bool] = None
    authority_does_not_exceed_evidence: Optional[bool] = None
    scope_bound: Optional[bool] = None
    non_transferable: Optional[bool] = None
    self_certification_forbidden: Optional[bool] = None
    admissibility_decision_forbidden: Optional[bool] = None
    measurement_computation_forbidden: Optional[bool] = None
    action_emission_forbidden: Optional[bool] = None
    candidate_generation_forbidden: Optional[bool] = None
    signature_required: Optional[bool] = None
    certificate_hash_required: Optional[bool] = None
    policy_hash_required: Optional[bool] = None
    request_hash_required: Optional[bool] = None
    replay_required: Optional[bool] = None
    public_signing_forbidden: Optional[bool] = None
    raw_payload_forbidden: Optional[bool] = None
    authority_effect_must_be_none: Optional[bool] = None


class ProofObligationRef(str):
    def as_str(self) -> str:
        return str(self)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class TerminalPolicy:
    may_emit: List[str] = field(default_factory=list)
    may_support: List[str] = field(default_factory=list)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class RefusalPolicy:
    may_emit: List[str] = field(default_factory=list)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class OperatorClassPolicy:
    may_support: List[OperatorClass] = field(default_factory=list)
    must_not_self_assign: bool = False


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class RustBinding:
    krate: str
    module: str
    symbols: List[str] = field(default_factory=list)


@dataclass(config=ConfigDict(arbitrary_types_allowed=True))
class ContractDescriptor:
    id: str
    name: str
    category: ContractCategory
    role: ComponentRole
    status: ContractStatus
    authority_effect: AuthorityEffect
    domain_type: Optional[str] = None
    codomain_type: Optional[str] = None
    subject_type: Optional[str] = None
    runtime_state_type: Optional[str] = None
    laws: Optional[LawBlock] = None
    constraints: ConstraintBlock = field(default_factory=ConstraintBlock)
    capabilities: CapabilityPolicy = field(default_factory=CapabilityPolicy)
    requires: Optional[RequiresBlock] = None
    validation: Optional[ValidationBlock] = None
    witnesses: Optional[WitnessesBlock] = None
    replay: Optional[ReplayBlock] = None
    constitution: Optional[ConstitutionalBlock] = None
    schema_hash: Optional[str] = None
    algebra_laws: Optional[List[str]] = None
    governed_algebra_layer: Optional[str] = None
    operator_class: Optional[OperatorClass] = None
    signature: Optional[SignatureBlock] = None
    uros: Optional[UrosBlock] = None
    evaluates_outputs_of: Optional[ComponentRole] = None
    decision_scope: Optional[List[str]] = None
    evidence_ceiling: Optional[EvidenceCeiling] = None
    runtime_enforcement: bool = False
    proof_obligations: List[ProofObligationRef] = field(default_factory=list)
    terminals: TerminalPolicy = field(default_factory=TerminalPolicy)
    refusals: RefusalPolicy = field(default_factory=RefusalPolicy)
    operator_classes: OperatorClassPolicy = field(default_factory=OperatorClassPolicy)
    rust_binding: Optional[RustBinding] = None

    def validate(self) -> None:
        from omega_engine.crates.contract_core.validate import validate_contract_descriptor

        validate_contract_descriptor(self)





