import os
import sys

root_dir = os.path.dirname(os.path.abspath(__file__))
math_dir = os.path.join(root_dir, "math")
engine_dir = os.path.join(root_dir, "omega_engine")
ooutwire_dir = os.path.dirname(root_dir)
# Repo root: required by the cross-rail parity tests that bind
# anomalon mirrors to the omega_engine_py rail. First in the
# list so it lands with the lowest precedence of the inserted paths.
repo_root = os.path.dirname(os.path.dirname(os.path.dirname(ooutwire_dir)))

for p in [repo_root, root_dir, math_dir, engine_dir, ooutwire_dir]:
    if p not in sys.path:
        sys.path.insert(0, p)


