"""galois connection shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Poset labels + monotone maps as list of pairs.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class MonotonePair:
    """A single ordered pair tag (x, y) used as a monotone-map edge."""

    domain_element: str
    codomain_element: str

    @classmethod
    def new(cls, domain_element: str, codomain_element: str) -> "MonotonePair":
        return cls(
            domain_element=domain_element,
            codomain_element=codomain_element,
        )


@dataclass
class GaloisConnectionShell:
    """Best-effort shell for a Galois connection between posets."""

    label: str
    poset_left: str = ""
    poset_right: str = ""
    lower: List[MonotonePair] = field(default_factory=list)
    upper: List[MonotonePair] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "GaloisConnectionShell":
        return cls(label=label)

    @classmethod
    def between(
        cls, label: str, poset_left: str, poset_right: str
    ) -> "GaloisConnectionShell":
        return cls(
            label=label,
            poset_left=poset_left,
            poset_right=poset_right,
        )

    def with_lower_pair(
        self, domain_element: str, codomain_element: str
    ) -> "GaloisConnectionShell":
        self.lower.append(MonotonePair.new(domain_element, codomain_element))
        return self

    def with_upper_pair(
        self, domain_element: str, codomain_element: str
    ) -> "GaloisConnectionShell":
        self.upper.append(MonotonePair.new(domain_element, codomain_element))
        return self

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.poset_left:
            raise ValueError("empty poset_left")
        if not self.poset_right:
            raise ValueError("empty poset_right")
        for i, p in enumerate(self.lower):
            if not p.domain_element or not p.codomain_element:
                raise ValueError(f"empty lower pair tag at index {i}")
        for i, p in enumerate(self.upper):
            if not p.domain_element or not p.codomain_element:
                raise ValueError(f"empty upper pair tag at index {i}")



