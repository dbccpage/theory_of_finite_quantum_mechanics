"""hom_functor shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class HomFunctor:
    """Best-effort shell for a Hom-functor on a category reference."""

    label: str
    category_ref: str = ""
    fixed_object: str = ""
    variance: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "HomFunctor":
        return cls(label=label)

    @classmethod
    def covariant(
        cls, label: str, category_ref: str, fixed_object: str
    ) -> "HomFunctor":
        return cls(
            label=label,
            category_ref=category_ref,
            fixed_object=fixed_object,
            variance="covariant",
        )

    @classmethod
    def contravariant(
        cls, label: str, category_ref: str, fixed_object: str
    ) -> "HomFunctor":
        return cls(
            label=label,
            category_ref=category_ref,
            fixed_object=fixed_object,
            variance="contravariant",
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.category_ref:
            raise ValueError("empty category_ref")
        if not self.fixed_object:
            raise ValueError("empty fixed_object")
        if not self.variance:
            raise ValueError("empty variance")
        if self.variance not in ("covariant", "contravariant"):
            raise ValueError(f"unknown variance tag: {self.variance}")



