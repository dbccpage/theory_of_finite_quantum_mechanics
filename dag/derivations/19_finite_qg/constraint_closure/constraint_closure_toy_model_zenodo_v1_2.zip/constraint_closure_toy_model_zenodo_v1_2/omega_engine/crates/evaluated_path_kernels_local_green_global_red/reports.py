import csv
import io
import json
import math
from typing import Any

from omega_engine.crates.evaluated_path_kernels_local_green_global_red.metrics import (
    MetricReport,
    validate_metric_identity,
)




def _require_example_name(example_name: str) -> str:
    if not isinstance(example_name, str):
        raise ValueError("example_name must be a string")
    value = example_name.strip()
    if not value:
        raise ValueError("example_name cannot be empty")
    return value


def _require_beta(beta: float) -> float:
    if isinstance(beta, bool):
        raise ValueError("beta must be a finite non-negative float, not bool")
    value = float(beta)
    if not math.isfinite(value):
        raise ValueError("beta must be finite")
    if value < 0.0:
        raise ValueError("beta must be non-negative")
    return value


def _require_seed(seed: int) -> int:
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ValueError("seed must be an integer")
    return seed


def _validated_inputs(
    report: MetricReport,
    example_name: str,
    beta: float,
    seed: int,
) -> tuple[str, float, int]:
    validate_metric_identity(report)
    return (
        _require_example_name(example_name),
        _require_beta(beta),
        _require_seed(seed),
    )




def _metrics_dict(
    report: MetricReport, *, rounded: bool
) -> dict[str, float | int | None]:
    """Return all metrics as a dict.

    When *rounded* is True values are rounded to 5 decimal places (suitable
    for human-readable CSV/Markdown).  When False, full float precision is
    kept (suitable for machine-readable JSON).

    Raises ValueError for any non-finite metric value so that NaN/Inf can
    never escape into a serialised output.
    """

    def maybe_round(value: float | None) -> float | None:
        if value is None:
            return None
        if not math.isfinite(value):
            raise ValueError(f"metric value is not finite: {value!r}")
        return round(value, 5) if rounded else value

    return {
        "lpr": maybe_round(report.lpr),
        "gpr": maybe_round(report.gpr),
        "avg_delta_eval": maybe_round(report.avg_delta_eval),
        "ngd": maybe_round(report.ngd),
        "positive_defect_rate": maybe_round(report.positive_defect_rate),
        "zero_defect_rate": maybe_round(report.zero_defect_rate),
        "egd": maybe_round(report.egd),
        "rke": maybe_round(report.rke),
        "nrke": maybe_round(report.nrke),
        "avg_action_defect": maybe_round(report.avg_action_defect),
    }




def generate_json_report(
    report: MetricReport,
    example_name: str,
    beta: float,
    seed: int,
    *,
    rounded: bool = False,
) -> str:
    """Serialise *report* to a JSON string.

    Uses ``allow_nan=False`` so that any non-finite metric value raises
    ``ValueError`` rather than silently emitting invalid JSON.  Keys are
    sorted for deterministic output.
    """
    example_name, beta, seed = _validated_inputs(report, example_name, beta, seed)

    data: dict[str, Any] = {
        "example": example_name,
        "n": report.n,
        "beta": beta,
        "seed": seed,
        "metrics": _metrics_dict(report, rounded=rounded),
        "notes": dict(report.notes),
    }
    return json.dumps(data, indent=2, sort_keys=True, allow_nan=False)



_CSV_HEADERS = [
    "example",
    "n",
    "beta",
    "seed",
    "lpr",
    "gpr",
    "avg_delta_eval",
    "ngd",
    "positive_defect_rate",
    "zero_defect_rate",
    "egd",
    "rke",
    "nrke",
    "avg_action_defect",
]


def _csv_safe_cell(value: str) -> str:
    """Neutralize spreadsheet formula prefixes in CSV cells."""
    if value and value[0] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + value
    return value


def generate_csv_report(
    report: MetricReport,
    example_name: str,
    beta: float,
    seed: int,
) -> str:
    """Serialise *report* to a CSV string using the ``csv`` module.

    The ``csv`` module handles quoting/escaping of commas, double-quotes, and
    newlines. Formula-like prefixes are neutralized for spreadsheet safety.
    """
    example_name, beta, seed = _validated_inputs(report, example_name, beta, seed)

    metrics = _metrics_dict(report, rounded=True)
    row = {
        "example": _csv_safe_cell(example_name),
        "n": report.n,
        "beta": beta,
        "seed": seed,
        **metrics,
    }

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=_CSV_HEADERS, lineterminator="\n")
    writer.writeheader()
    writer.writerow(row)
    return output.getvalue()




def _md_escape(value: str) -> str:
    """Escape characters that can break Markdown table or heading structure."""
    return value.replace("\\", "\\\\").replace("|", "\\|").replace("\n", " ")


def _fmt(value: float | None) -> str:
    """Format a nullable metric value for Markdown display."""
    if value is None:
        return "N/A"
    if not math.isfinite(value):
        raise ValueError(f"metric value is not finite: {value!r}")
    return f"{value:.5f}"


def generate_markdown_report(
    report: MetricReport,
    example_name: str,
    beta: float,
    seed: int,
) -> str:
    """Serialise *report* to a Markdown string.

    ``example_name`` is escaped so that pipe characters, backslashes, and
    embedded newlines cannot break the Markdown table or heading structure.
    """
    example_name, beta, seed = _validated_inputs(report, example_name, beta, seed)
    safe_name = _md_escape(example_name)

    identity_lhs = report.gpr - report.lpr
    partition_sum = report.ngd + report.positive_defect_rate + report.zero_defect_rate
    egd_sum = report.ngd + report.positive_defect_rate

    return f"""# Evaluated Path Kernels Report - {safe_name.upper()}

- **Trajectories (N)**: {report.n}
- **Inference Temperature (Beta)**: {beta}
- **Random Seed**: {seed}

| Metric | Value | Description |
| :--- | :--- | :--- |
| **LPR** (Joint Local Pass Rate) | {_fmt(report.lpr)} | Percentage of paths passing all local validators |
| **GPR** (Global Pass Rate) | {_fmt(report.gpr)} | Percentage of paths passing the global validator |
| **Avg $\\Delta_{{\\mathrm{{Eval}}}}$** (Evaluator Defect Mass) | {_fmt(report.avg_delta_eval)} | Difference between global and local verification rate |
| **NGD** (Negative Gluing Defect Rate) | {_fmt(report.ngd)} | Rate of safety-critical hidden failures |
| **PGD** (Positive Gluing Defect Rate) | {_fmt(report.positive_defect_rate)} | Rate of rescue/global-only success effects |
| **ZDR** (Zero Defect Rate) | {_fmt(report.zero_defect_rate)} | Rate of local/global compositor agreement |
| **EGD** (Absolute Evaluator Defect Rate) | {_fmt(report.egd)} | Absolute rate of non-compositional failures |
| **RKE** (Residual Kernel Error) | {_fmt(report.rke)} | Discrepancy between actual and estimated path kernel |
| **nRKE** (Normalized Residual Error) | {_fmt(report.nrke)} | Residual kernel error relative to actual kernel mass |
| **Avg Action Defect** | {_fmt(report.avg_action_defect)} | Cumulative cost composition deviation |

- **Evaluator Defect Identity** (GPR - LPR = Avg $\\Delta_{{\\mathrm{{Eval}}}}$): **PASSED** ({identity_lhs:.5f} = {report.avg_delta_eval:.5f})
- **Unity Partition Check** (NGD + PGD + ZDR = 1.0): **PASSED** ({partition_sum:.5f} = 1.00000)
- **EGD Consistency Check** (EGD = NGD + PGD): **PASSED** ({report.egd:.5f} = {egd_sum:.5f})

> [!NOTE]
> Synthetic simulation results are for mathematical correctness checking of the path calculus only and do not represent empirical verification on real LLM trajectories.
"""



