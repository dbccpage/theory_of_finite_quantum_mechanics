"""Python package mirror for Rust module ``examples``."""

