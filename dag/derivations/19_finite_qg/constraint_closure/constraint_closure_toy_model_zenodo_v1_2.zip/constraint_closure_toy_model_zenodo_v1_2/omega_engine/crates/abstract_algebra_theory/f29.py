"""F29 Finite Field Algebra and Galois Representation examples (spine §6)."""

import math
from typing import Any, Dict
from omega_engine.crates.type.refusal import Refusal, Result


class F29Element:
    """An element in the finite field F29 (integers modulo 29)."""

    def __init__(self, value: int) -> None:
        self.value = int(value) % 29

    def __add__(self, other: Any) -> "F29Element":
        o_val = other.value if isinstance(other, F29Element) else int(other)
        return F29Element(self.value + o_val)

    def __sub__(self, other: Any) -> "F29Element":
        o_val = other.value if isinstance(other, F29Element) else int(other)
        return F29Element(self.value - o_val)

    def __mul__(self, other: Any) -> "F29Element":
        o_val = other.value if isinstance(other, F29Element) else int(other)
        return F29Element(self.value * o_val)

    def __truediv__(self, other: Any) -> "F29Element":
        o_val = other.value if isinstance(other, F29Element) else int(other)
        if o_val % 29 == 0:
            raise ZeroDivisionError("Division by zero in F29")
        inv = pow(o_val, 27, 29)
        return F29Element(self.value * inv)

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, F29Element):
            return self.value == other.value
        return self.value == int(other) % 29

    def __repr__(self) -> str:
        return f"F29Element({self.value})"


class F29GaloisRepresentationPacket:
    """A mock Galois representation packet with coefficient field F29."""

    def __init__(self, trace_values: Dict[int, int]) -> None:
        self.traces = {p: F29Element(v) for p, v in trace_values.items()}

    def __repr__(self) -> str:
        return f"F29GaloisRepresentationPacket(traces={self.traces!r})"


def verify_f29_representation(packet: F29GaloisRepresentationPacket) -> Result[bool]:
    """Verification function for F29 Galois representations."""
    for p, trace in packet.traces.items():
        bound = 2.0 * math.sqrt(p)
        val = trace.value
        signed_val = val if val <= 14 else val - 29
        if abs(signed_val) > bound + 1.0:
            return Refusal(
                "WeilBoundViolation",
                f"Frobenius trace at p={p} has value {signed_val}, exceeding Weil bound {bound}",
            )
    return True



