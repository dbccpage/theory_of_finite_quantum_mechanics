"""Quotient spaces and equivalence witnesses modulo exact repair.

Represents Q^1 = C^1 / im(d0). Two elements x, y are equivalent iff
x - y = d0(alpha).

EXACTNESS (audit U3 / spine L123-125): the certificate relation

    Cert_{Q^1}(omega, omega') := Sigma (alpha : C^0) (omega - omega' = d0 alpha)

is checked over EXACT rationals (``fractions.Fraction``), never over the float
shadow. ``Vector`` keeps float storage so existing numeric consumers (phi1.py,
numpy LP) are untouched, but the equality ``x - y == d0(alpha)`` is computed in
Fraction space (``exact_difference`` / ``MatrixMap.apply_exact``). A float-shadow
near-miss (e.g. ``alpha`` coeff ``0.1`` against an integer ``d0`` that would
collapse to ``1.0`` under float ``==``) is therefore REFUSED.

Sameness in Q^1 is an *inhabited certificate*, never definitional ``==``.
"""

from .finite_carrier import (
    Vector,
    exact_difference,
    exact_dicts_equal,
)
from omega_engine.crates.homology_theory.cochain_complex import CochainComplex


class QuotientWitness:
    """Witness that x is equivalent to y modulo im(d0) via alpha."""

    def __init__(self, alpha: Vector) -> None:
        self.alpha = alpha

    def __repr__(self) -> str:
        return f"QuotientWitness(alpha={self.alpha!r})"


class CertQ1:
    """An (unverified) Q^1 certificate carrier: the data (omega, omega', alpha).

    This is the explicit inhabitant of ``Cert_{Q^1}(omega, omega')`` from the
    HoTT lens (spine L123): a candidate witness ``alpha : C^0`` together with the
    two 1-cochains it claims to relate. Construction does NOT verify the relation
    ``omega - omega' = d0 alpha``; verification is ``verify`` / ``equivalent``
    over exact arithmetic. Holding the carrier separately from its proof is the
    "unwired" gap the audit (A7, glue) names.
    """

    def __init__(self, omega: Vector, omega_prime: Vector, alpha: Vector) -> None:
        self.omega = omega
        self.omega_prime = omega_prime
        self.alpha = alpha

    @property
    def witness(self) -> QuotientWitness:
        return QuotientWitness(self.alpha)

    def verify(self, cochain: CochainComplex) -> bool:
        """Exact check that ``omega - omega' = d0 alpha``."""
        return equivalent(cochain, self.omega, self.omega_prime, self.witness)

    def __repr__(self) -> str:
        return (
            f"CertQ1(omega={self.omega!r}, omega_prime={self.omega_prime!r}, "
            f"alpha={self.alpha!r})"
        )


def equivalent(
    cochain: CochainComplex, x: Vector, y: Vector, witness: QuotientWitness
) -> bool:
    """Check if x and y are equivalent in C^1 modulo im(d0) under the witness.

    EXACT: ``x - y`` and ``d0(alpha)`` are both computed in ``Fraction`` space
    and compared exactly. A float-shadow near-miss is refused (returns ``False``)
    even though it would pass under float ``==``.
    """
    diff = exact_difference(x, y)
    d0_alpha = cochain.d0.apply_exact(witness.alpha)
    return exact_dicts_equal(diff, d0_alpha)


def projection_to_Q1(cochain: CochainComplex, x: Vector) -> Vector:
    """Representative-wrapper placeholder for the class of x in Q^1.

    This is NOT a quotient projection: it does not canonicalize x or pick a
    minimal-norm representative. It simply returns x unchanged as a stand-in
    representative of its class in Q^1 = C^1 / im(d0). Two elements must NOT be
    compared for equality on the returned vectors directly; equivalence modulo
    im(d0) goes through ``equivalent(cochain, x, y, witness)``.
    """
    return x



