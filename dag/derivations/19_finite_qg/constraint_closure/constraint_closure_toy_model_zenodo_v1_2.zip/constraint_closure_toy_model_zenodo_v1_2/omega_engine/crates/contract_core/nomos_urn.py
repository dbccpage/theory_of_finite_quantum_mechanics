from __future__ import annotations
from pydantic import ConfigDict
"""Nomos URN schema for Omega contract identifiers (Python twin).

Canonical grammar (012 contracts + live corpus)::

    Form A: urn:omega:{domain}:{name}:v{MAJOR.MINOR.PATCH}
    Form B: urn:omega:rust:{crate}:{name}:v{MAJOR.MINOR.PATCH}
    Form C: urn:omega:{domain}:{name}:file:v{MAJOR.MINOR.PATCH}

Segment charset: domain/crate = ``[a-z0-9_]+``; name = ``[a-z0-9_.\\-]+``.
Prefix-only checks are insufficient for Nomos parity.

AuthorityEffect: None. Diagnostic + validation only.
Twin of ``omega_contract_core::nomos_urn`` (Rust PROD).
"""


from pydantic.dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

PREFIX = "urn:omega:"

SCHEMA_RECEIPT = "omega.contract.nomos_urn_sample_receipt.v1"
STORY_ID = "STORY-ORT-CONTRACTS-001"

# Stable error tokens — must match Rust NomosUrnError Display-independent enum names
# used for behavioral parity (error *kind*, not Display string).
ERR_EMPTY = "Empty"
ERR_MISSING_PREFIX = "MissingPrefix"
ERR_WRONG_SEGMENT_COUNT = "WrongSegmentCount"
ERR_EMPTY_SEGMENT = "EmptySegment"
ERR_BAD_DOMAIN = "BadDomainCharset"
ERR_BAD_NAME = "BadNameCharset"
ERR_BAD_CRATE = "BadCrateCharset"
ERR_BAD_VERSION = "BadVersion"
ERR_UNEXPECTED_FILE = "UnexpectedFileMarker"


class NomosUrnError(ValueError):
    """Structured Nomos URN parse failure."""

    def __init__(self, kind: str, message: str) -> None:
        super().__init__(message)
        self.kind = kind


@dataclass(config=ConfigDict(arbitrary_types_allowed=True, frozen=True))
class NomosUrn:
    domain: str
    name: str
    version: str
    crate_name: Optional[str] = None
    file_locus: bool = False


CRITICAL_URN_SAMPLE: Tuple[str, ...] = (
    "urn:omega:math:cech_cochain:v1.0.0",
    "urn:omega:state:packet:v1.0.0",
    "urn:omega:obstruction:obstruction:v1.0.0",
    "urn:omega:evidence:phi1_certificate:v1.0.0",
    "urn:omega:governance:council_decision:v1.0.0",
    "urn:omega:execution:fsr_retrieval:v1.0.0",
    "urn:omega:constitution:contract_constitution:v1.0.0",
    "urn:omega:products:llm_adapter:v1.0.0",
    "urn:omega:lifts:lift_license:v1.0.0",
    "urn:omega:rust:omega_discrete_deformation_algebra:discrete_deformation_algebra:v1.13.0",
    "urn:omega:rust:omega_functional:contract_descriptors:v1.1.0",
    "urn:omega:rust:omega_q:admission:v0.2.0",
    "urn:omega:engine:cycle_aware_engine:file:v1.0.0",
    "urn:omega:qm:quantum_density_engine:file:v1.0.0",
    "urn:omega:math:demo:v0.1.0",
    "urn:omega:obstruction:demo:v0.1.0",
)

CRITICAL_URN_NEGATIVE_SAMPLE: Tuple[str, ...] = (
    "",
    "urn:omega:",
    "urn:omega:math",
    "urn:foo:math:x:v1.0.0",
    "urn:omega:Math:x:v1.0.0",
    "urn:omega:math::v1.0.0",
    "urn:omega:math:x:1.0.0",
    "urn:omega:math:x:v1.0",
    "urn:omega:math:x:v01.0.0",
    "urn:omega:math:x:v1.0.0:extra",
    "urn:omega:rust:BadCrate:name:v1.0.0",
    "urn:omega:engine:foo:notfile:v1.0.0",
    "not-a-urn",
)


def _is_domain_seg(s: str) -> bool:
    return bool(s) and all(c.islower() or c.isdigit() or c == "_" for c in s)


def _is_name_seg(s: str) -> bool:
    return bool(s) and all(c.islower() or c.isdigit() or c in "_.-" for c in s)


def _parse_version(seg: str) -> str:
    if not seg.startswith("v"):
        raise NomosUrnError(ERR_BAD_VERSION, "version must be vMAJOR.MINOR.PATCH")
    rest = seg[1:]
    parts = rest.split(".")
    if len(parts) != 3:
        raise NomosUrnError(ERR_BAD_VERSION, "version must be vMAJOR.MINOR.PATCH")
    for p in parts:
        if not p or not p.isdigit():
            raise NomosUrnError(ERR_BAD_VERSION, "version must be vMAJOR.MINOR.PATCH")
        if len(p) > 1 and p.startswith("0"):
            raise NomosUrnError(ERR_BAD_VERSION, "version must be vMAJOR.MINOR.PATCH")
    return rest


def parse_nomos_urn(raw: str) -> NomosUrn:
    """Parse a Nomos contract URN into structured parts."""
    s = raw.strip() if raw is not None else ""
    if not s:
        raise NomosUrnError(ERR_EMPTY, "empty URN")
    if not s.startswith(PREFIX):
        raise NomosUrnError(
            ERR_MISSING_PREFIX, "contract_id must start with urn:omega:"
        )
    body = s[len(PREFIX) :]
    if not body:
        raise NomosUrnError(
            ERR_WRONG_SEGMENT_COUNT, "wrong segment count for Nomos URN"
        )
    segs = body.split(":")
    if any(g == "" for g in segs):
        raise NomosUrnError(ERR_EMPTY_SEGMENT, "empty URN segment")

    if len(segs) == 3:
        domain, name, ver = segs
        if not _is_domain_seg(domain):
            raise NomosUrnError(ERR_BAD_DOMAIN, "domain must match [a-z0-9_]+")
        if not _is_name_seg(name):
            raise NomosUrnError(ERR_BAD_NAME, "name must match [a-z0-9_.\\-]+")
        version = _parse_version(ver)
        return NomosUrn(domain=domain, name=name, version=version)

    if len(segs) == 4:
        domain = segs[0]
        if not _is_domain_seg(domain):
            raise NomosUrnError(ERR_BAD_DOMAIN, "domain must match [a-z0-9_]+")
        if domain == "rust":
            crate_name, name, ver = segs[1], segs[2], segs[3]
            if not _is_domain_seg(crate_name):
                raise NomosUrnError(ERR_BAD_CRATE, "crate must match [a-z0-9_]+")
            if not _is_name_seg(name):
                raise NomosUrnError(ERR_BAD_NAME, "name must match [a-z0-9_.\\-]+")
            version = _parse_version(ver)
            return NomosUrn(
                domain=domain,
                crate_name=crate_name,
                name=name,
                version=version,
                file_locus=False,
            )
        if segs[2] == "file":
            name, ver = segs[1], segs[3]
            if not _is_name_seg(name):
                raise NomosUrnError(ERR_BAD_NAME, "name must match [a-z0-9_.\\-]+")
            version = _parse_version(ver)
            return NomosUrn(domain=domain, name=name, version=version, file_locus=True)
        raise NomosUrnError(ERR_UNEXPECTED_FILE, "unexpected file locus marker")

    raise NomosUrnError(ERR_WRONG_SEGMENT_COUNT, "wrong segment count for Nomos URN")


def is_well_formed_nomos_urn(raw: str) -> bool:
    try:
        parse_nomos_urn(raw)
        return True
    except NomosUrnError:
        return False


def format_nomos_urn(u: NomosUrn) -> str:
    if u.crate_name is not None and not u.file_locus:
        return f"urn:omega:{u.domain}:{u.crate_name}:{u.name}:v{u.version}"
    if u.file_locus:
        return f"urn:omega:{u.domain}:{u.name}:file:v{u.version}"
    return f"urn:omega:{u.domain}:{u.name}:v{u.version}"


def _form_label(u: NomosUrn) -> str:
    if u.crate_name is not None:
        return "B_rust"
    if u.file_locus:
        return "C_file"
    return "A_domain"


def audit_critical_urn_sample() -> Dict[str, Any]:
    """Audit the critical-crate URN sample (positive + negative vectors)."""
    rows: List[Dict[str, Any]] = []
    pass_count = 0
    for urn in CRITICAL_URN_SAMPLE:
        try:
            u = parse_nomos_urn(urn)
            assert format_nomos_urn(u) == urn
            pass_count += 1
            rows.append(
                {
                    "urn": urn,
                    "well_formed": True,
                    "domain": u.domain,
                    "form": _form_label(u),
                }
            )
        except NomosUrnError:
            rows.append(
                {
                    "urn": urn,
                    "well_formed": False,
                    "domain": None,
                    "form": None,
                }
            )
    fail_count = len(CRITICAL_URN_SAMPLE) - pass_count
    negative_reject_count = sum(
        1 for urn in CRITICAL_URN_NEGATIVE_SAMPLE if not is_well_formed_nomos_urn(urn)
    )
    negative_expected = len(CRITICAL_URN_NEGATIVE_SAMPLE)
    return {
        "schema_id": SCHEMA_RECEIPT,
        "story_id": STORY_ID,
        "authority_effect": "None",
        "sample_size": len(CRITICAL_URN_SAMPLE),
        "pass_count": pass_count,
        "fail_count": fail_count,
        "negative_reject_count": negative_reject_count,
        "negative_expected": negative_expected,
        "all_positive_pass": fail_count == 0,
        "all_negative_reject": negative_reject_count == negative_expected,
        "rows": rows,
    }


