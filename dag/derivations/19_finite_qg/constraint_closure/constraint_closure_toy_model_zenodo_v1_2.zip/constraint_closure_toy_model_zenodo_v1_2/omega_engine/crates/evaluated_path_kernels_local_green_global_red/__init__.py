"""Kernel implementations owned above pipelines."""

from dataclasses import field
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Optional

from . import evaluated_path as evaluated_path


class StepRealization(str, Enum):
    MECHANICAL = "MECHANICAL"
    PROPOSAL = "PROPOSAL"


@dataclass(frozen=True)
class ResearchStepPacket:
    carrier_sha256: str
    proposal_sha256: str
    round_index: int
    step_index: int
    realization: StepRealization
    verifier_ref: str = ""
    evidence_ref: str = ""
    authority_effect: str = "None"

    def __post_init__(self) -> None:
        if self.realization == StepRealization.MECHANICAL and (not self.verifier_ref or not self.evidence_ref):
            raise ValueError("mechanical realization requires verifier and evidence")


__all__ = ["evaluated_path", "ResearchStepPacket", "StepRealization"]



