r"""Universe Anomalonica Coboundary Subsystem Package.

Provides graded cochains, coboundary operators, cochain complexes with exact nilpotency d^2 = 0,
cohomology computation (Z^k / B^k), Betti numbers, and graded cup products.
AuthorityEffect: None.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Dict, List, Optional, Sequence, Tuple
import numpy as np

from omega_engine.crates.homology_theory.qmatrix import QMatrix
from omega_engine.crates.homology_theory.exact_solve import solve as exact_solve


def _as_qmatrix(mat: Any) -> QMatrix:
    """Exact rational view of a numeric matrix.

    Every IEEE double is exactly a dyadic rational, so `Fraction(float(x))` is
    a faithful reading of the stored value rather than an approximation of it.
    A coboundary operator is exact data; its rank is an exact integer and does
    not need a tolerance.
    """
    arr = np.asarray(mat, dtype=float)
    if arr.ndim == 1:
        arr = arr[:, np.newaxis]
    rows, cols = arr.shape
    data = [[Fraction(float(arr[i, j])) for j in range(cols)] for i in range(rows)]
    return QMatrix(rows, cols, data)


def exact_rank(mat: Any) -> int:
    """Exact rank over Q of the matrix as stored, via QMatrix.rank()."""
    arr = np.asarray(mat, dtype=float)
    if arr.size == 0:
        return 0
    return int(_as_qmatrix(arr).rank())


def compute_coboundary(B: np.ndarray, f: np.ndarray) -> np.ndarray:
    """Computes cochain coboundary delta = B @ f (backward-compatible entrypoint)."""
    return np.asarray(B, dtype=float) @ np.asarray(f, dtype=float)


@dataclass
class Cochain:
    """A cochain of degree k in C^k."""
    degree: int
    values: np.ndarray

    def __post_init__(self) -> None:
        self.values = np.asarray(self.values, dtype=float)

    @property
    def dim(self) -> int:
        return len(self.values)

    def __add__(self, other: Cochain) -> Cochain:
        if self.degree != other.degree:
            raise ValueError(f"Degree mismatch: {self.degree} != {other.degree}")
        return Cochain(self.degree, self.values + other.values)

    def __sub__(self, other: Cochain) -> Cochain:
        if self.degree != other.degree:
            raise ValueError(f"Degree mismatch: {self.degree} != {other.degree}")
        return Cochain(self.degree, self.values - other.values)

    def __mul__(self, scalar: float) -> Cochain:
        return Cochain(self.degree, self.values * scalar)

    def __rmul__(self, scalar: float) -> Cochain:
        return self.__mul__(scalar)

    def norm_l1(self) -> float:
        return float(np.sum(np.abs(self.values)))

    def norm_l2(self) -> float:
        return float(np.linalg.norm(self.values))


@dataclass
class CochainComplex:
    r"""Graded cochain complex C^0 --d0--> C^1 --d1--> C^2 ... with d^{k+1} . d^k = 0."""
    dims: Dict[int, int]
    operators: Dict[int, np.ndarray] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for deg, mat in list(self.operators.items()):
            self.operators[deg] = np.asarray(mat, dtype=float)

    def d(self, cochain: Cochain) -> Cochain:
        r"""Applies the coboundary operator d^k: C^k -> C^{k+1}."""
        k = cochain.degree
        if k not in self.operators:
            next_dim = self.dims.get(k + 1, 0)
            return Cochain(k + 1, np.zeros(next_dim))
        mat = self.operators[k]
        val = mat @ cochain.values
        return Cochain(k + 1, val)

    def check_nilpotency(self, k: int, tol: float = 1e-10) -> bool:
        r"""Checks d^{k+1} . d^k = 0."""
        if k not in self.operators or (k + 1) not in self.operators:
            return True
        d_k = self.operators[k]
        d_k1 = self.operators[k + 1]
        prod = d_k1 @ d_k
        return bool(np.allclose(prod, 0.0, atol=tol))

    def cocycle_space(self, k: int, tol: Optional[float] = None) -> np.ndarray:
        r"""Computes basis of Z^k = ker(d^k).

        The DIMENSION of the kernel comes from the exact rank over Q; the SVD
        supplies well-conditioned basis vectors spanning it. `tol` is accepted
        for backward compatibility and, when given, selects the old threshold
        behaviour -- which is scale-dependent and can report the wrong
        dimension. Leave it None.
        """
        dim_k = self.dims.get(k, 0)
        if dim_k == 0:
            return np.zeros((0, 0))
        if k not in self.operators:
            return np.eye(dim_k)
        mat = self.operators[k]
        _, s, vh = np.linalg.svd(mat)
        rank = int(np.sum(s > tol)) if tol is not None else exact_rank(mat)
        null_basis = vh[rank:].T
        return null_basis

    def coboundary_space(self, k: int, tol: Optional[float] = None) -> np.ndarray:
        r"""Computes basis of B^k = im(d^{k-1}).

        Dimension from the exact rank over Q; basis vectors from the SVD.
        """
        dim_k = self.dims.get(k, 0)
        if dim_k == 0 or (k - 1) not in self.operators:
            return np.zeros((dim_k, 0))
        prev_mat = self.operators[k - 1]
        u, s, _ = np.linalg.svd(prev_mat)
        rank = int(np.sum(s > tol)) if tol is not None else exact_rank(prev_mat)
        return u[:, :rank]

    def cohomology_dimension(self, k: int, tol: Optional[float] = None) -> int:
        r"""Computes k-th Betti number b^k = dim H^k = dim Z^k - dim B^k.

        Exact by default: both dimensions come from ranks over Q, so the answer
        does not move when the complex is rescaled. With a fixed absolute
        threshold this returned 2 for a complex with d0 = [[1],[1]] and
        d1 = [[1,-1]] scaled by 1e-8, whose true H^1 is 0.
        """
        dim_k = self.dims.get(k, 0)
        if dim_k == 0:
            return 0
        if tol is None:
            rank_k = exact_rank(self.operators[k]) if k in self.operators else 0
            dim_z = dim_k - rank_k
            dim_b = (exact_rank(self.operators[k - 1])
                     if (k - 1) in self.operators else 0)
            return max(0, dim_z - dim_b)

        z_basis = self.cocycle_space(k, tol=tol)
        dim_z = z_basis.shape[1] if z_basis.ndim == 2 else 0

        b_basis = self.coboundary_space(k, tol=tol)
        dim_b = b_basis.shape[1] if b_basis.ndim == 2 else 0

        return max(0, dim_z - dim_b)

    def is_cocycle(self, cochain: Cochain, tol: Optional[float] = None) -> bool:
        """Checks d^k(c) = 0, exactly by default."""
        dc = self.d(cochain)
        if tol is None:
            return bool(np.all(np.asarray(dc.values) == 0.0))
        return dc.norm_l1() <= tol

    def is_coboundary(self, cochain: Cochain, tol: Optional[float] = None) -> Tuple[bool, Optional[Cochain]]:
        r"""Checks if c = d^{k-1}(b) for some b, and returns the witness.

        Exact by default, through `homology_theory.exact_solve.solve` over Q.
        The previous implementation used `lstsq` plus `allclose`, which reports
        a least-squares approximation as a witness whenever the residual
        happens to fall under an absolute threshold -- so a cochain that is not
        a coboundary at all is accepted once the data is small enough.
        """
        k = cochain.degree
        if (k - 1) not in self.operators:
            zero = Cochain(k - 1, np.zeros(self.dims.get(k - 1, 0)))
            if tol is None:
                return (bool(np.all(np.asarray(cochain.values) == 0.0)), zero)
            return (cochain.norm_l1() <= tol, zero)

        mat = self.operators[k - 1]
        if tol is None:
            witness = exact_solve(
                _as_qmatrix(mat),
                [Fraction(float(v)) for v in np.asarray(cochain.values, dtype=float)],
            )
            if witness is None:
                return (False, None)
            return (True, Cochain(k - 1, np.array([float(w) for w in witness])))

        try:
            b, _, _, _ = np.linalg.lstsq(mat, cochain.values, rcond=None)
            diff = mat @ b - cochain.values
            if np.allclose(diff, 0.0, atol=tol):
                return (True, Cochain(k - 1, b))
            return (False, None)
        except Exception:
            return (False, None)

    def is_exact_at(self, k: int, tol: Optional[float] = None) -> bool:
        """Checks exactness at degree k: H^k = 0."""
        return self.cohomology_dimension(k, tol=tol) == 0


def cup_product(c1: Cochain, c2: Cochain) -> Cochain:
    """Computes standard graded cup product of cochains (represented as polynomial convolution)."""
    deg = c1.degree + c2.degree
    prod_vals = np.convolve(c1.values, c2.values)
    return Cochain(degree=deg, values=prod_vals)


__all__ = [
    "compute_coboundary",
    "Cochain",
    "CochainComplex",
    "cup_product",
]
