"""pullback shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class Pullback:
    """Best-effort shell for a pullback of a cospan A → C ← B."""

    label: str
    pullback_object: str = ""
    left_source: str = ""
    right_source: str = ""
    cospan_apex: str = ""
    morphism_f: str = ""
    morphism_g: str = ""
    projection_left: str = ""
    projection_right: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Pullback":
        return cls(label=label)

    @classmethod
    def of_cospan(
        cls,
        label: str,
        pullback_object: str,
        left_source: str,
        right_source: str,
        cospan_apex: str,
        morphism_f: str,
        morphism_g: str,
        projection_left: str,
        projection_right: str,
    ) -> "Pullback":
        return cls(
            label=label,
            pullback_object=pullback_object,
            left_source=left_source,
            right_source=right_source,
            cospan_apex=cospan_apex,
            morphism_f=morphism_f,
            morphism_g=morphism_g,
            projection_left=projection_left,
            projection_right=projection_right,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.pullback_object:
            raise ValueError("empty pullback_object")
        if not self.left_source:
            raise ValueError("empty left_source")
        if not self.right_source:
            raise ValueError("empty right_source")
        if not self.cospan_apex:
            raise ValueError("empty cospan_apex")
        if not self.morphism_f:
            raise ValueError("empty morphism_f")
        if not self.morphism_g:
            raise ValueError("empty morphism_g")
        if not self.projection_left:
            raise ValueError("empty projection_left")
        if not self.projection_right:
            raise ValueError("empty projection_right")



