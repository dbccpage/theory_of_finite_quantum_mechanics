import math
from typing import Any
from omega_engine.crates.evaluated_path_kernels_local_green_global_red.core import (
    State,
    PathSegment,
    ComposedPath,
)

UINT32_MOD = 2**32


class LCG:
    """A deterministic Linear Congruential Generator to ensure platform-independent reproducibility."""

    def __init__(self, seed: int):
        self.state = require_int(seed, "seed") % UINT32_MOD

    def next_float(self) -> float:
        self.state = (self.state * 1664525 + 1013904223) % UINT32_MOD
        return self.state / UINT32_MOD

    def uniform(self, a: float, b: float) -> float:
        if isinstance(a, bool) or isinstance(b, bool):
            raise ValueError("uniform bounds must be numeric, not boolean")
        a = float(a)
        b = float(b)
        if not math.isfinite(a) or not math.isfinite(b):
            raise ValueError("uniform bounds must be finite")
        if b < a:
            raise ValueError("uniform upper bound must be >= lower bound")
        return a + (b - a) * self.next_float()

    def choice(self, seq: list[Any]) -> Any:
        if not seq:
            raise ValueError("cannot choose from an empty sequence")
        idx = int(self.next_float() * len(seq))
        return seq[idx]


def require_probability(x: float, name: str) -> float:
    if isinstance(x, bool):
        raise ValueError(f"{name} must be a probability, not boolean")
    try:
        val = float(x)
    except (TypeError, ValueError) as e:
        raise ValueError(f"{name} must be a float") from e
    if not math.isfinite(val) or val < 0.0 or val > 1.0:
        raise ValueError(f"{name} must be in [0, 1]")
    return val


def require_int(value: int, name: str, *, positive: bool = False) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} must be an integer")
    if positive and value <= 0:
        raise ValueError(f"{name} must be positive")
    return value


def require_alpha(alpha: float) -> float:
    if isinstance(alpha, bool):
        raise ValueError("alpha must be numeric, not boolean")
    try:
        value = float(alpha)
    except (TypeError, ValueError) as exc:
        raise ValueError("alpha must be numeric") from exc
    if not math.isfinite(value) or value < 0.0 or value > 1.0:
        raise ValueError("alpha must be in [0, 1]")
    return value


def generate_synthetic_paths(
    n: int,
    p_first: float,
    p_second: float,
    p_conflict: float,
    p_rescue: float,
    seed: int,
    example_type: str,
) -> list[ComposedPath]:
    n = require_int(n, "n", positive=True)
    seed = require_int(seed, "seed")
    if example_type not in {"swe", "hwe", "tau"}:
        raise ValueError(f"unknown example_type: {example_type}")

    p_first = require_probability(p_first, "p_first")
    p_second = require_probability(p_second, "p_second")
    p_conflict = require_probability(p_conflict, "p_conflict")
    p_rescue = require_probability(p_rescue, "p_rescue")

    lcg = LCG(seed)
    paths = []

    if example_type == "swe":
        label = "cross_module_dependency"
    elif example_type == "hwe":
        label = "bus_width_mismatch"
    else:
        label = "wrong_state_transition"

    s_a = State(id="S_a")
    s_b = State(id="S_b")
    s_c = State(id="S_c")

    for i in range(n):
        task_id = f"{example_type}_{i}"
        path_metadata = {
            "label": label,
            "evidence_class": "SyntheticSimulation",
            "source": "synthetic_parameter_simulation",
            "example_type": example_type,
        }

        first_pass = lcg.next_float() < p_first
        second_pass = lcg.next_float() < p_second

        if first_pass and second_pass:
            global_pass = lcg.next_float() >= p_conflict
        else:
            global_pass = lcg.next_float() < p_rescue

        first_cost = round(lcg.uniform(0.5, 2.0), 2)
        second_cost = round(lcg.uniform(0.5, 2.0), 2)

        seg1 = PathSegment(
            id=f"{task_id}_seg1",
            source=s_a,
            target=s_b,
            cost=first_cost,
            eval_pass=first_pass,
            metadata=dict(path_metadata),
        )

        seg2 = PathSegment(
            id=f"{task_id}_seg2",
            source=s_b,
            target=s_c,
            cost=second_cost,
            eval_pass=second_pass,
            metadata=dict(path_metadata),
        )

        cp = ComposedPath(
            id=task_id,
            first=seg1,
            second=seg2,
            global_eval_pass=global_pass,
            metadata=dict(path_metadata),
        )
        paths.append(cp)

    return paths


def simulate_swe_paths(n: int, seed: int) -> list[ComposedPath]:
    return generate_synthetic_paths(
        n=n,
        p_first=0.9192,
        p_second=0.9192,
        p_conflict=0.15857,
        p_rescue=0.0,
        seed=seed,
        example_type="swe",
    )


def simulate_hwe_paths(n: int, seed: int) -> list[ComposedPath]:
    return generate_synthetic_paths(
        n=n,
        p_first=0.92,
        p_second=0.92,
        p_conflict=0.15,
        p_rescue=0.0,
        seed=seed,
        example_type="hwe",
    )


def simulate_tau_paths(n: int, seed: int) -> list[ComposedPath]:
    return generate_synthetic_paths(
        n=n,
        p_first=0.90,
        p_second=0.90,
        p_conflict=0.20,
        p_rescue=0.0,
        seed=seed,
        example_type="tau",
    )


def base_capability(alpha: float) -> float:
    alpha = require_alpha(alpha)
    if alpha == 0.0:
        return 0.65
    return 0.65 + 0.252 * (1.0 - math.exp(-3.8 * alpha))


def coupling_defect(alpha: float) -> float:
    alpha = require_alpha(alpha)
    if alpha == 0.0:
        return 0.0
    standards: dict[float, float] = {
        0.1: 0.139,
        0.2: 0.259,
        0.4: 0.451,
        0.6: 0.593,
        1.0: 0.777,
    }
    for std_a, val in standards.items():
        if abs(alpha - std_a) < 1e-5:
            return float(val)
    val = 0.777 * (alpha**0.83)
    return val if val < 1.0 else 1.0


def activation_density_curve() -> list[dict[str, Any]]:
    """Generate deterministic POC0 activation-density curve values."""
    max_experts = 10
    results = []
    for m in [1, 2, 4, 6, 10]:
        alpha = m / max_experts
        cap = base_capability(alpha)
        def_val = coupling_defect(alpha)
        success = cap * (1.0 - def_val)
        calculated_defect = -1.0 * def_val * cap

        results.append(
            {
                "active_experts": m,
                "max_experts": max_experts,
                "alpha": round(alpha, 4),
                "capability": round(cap, 4),
                "defect": round(def_val, 4),
                "success": round(success, 4),
                "calculated_defect": round(calculated_defect, 4),
            }
        )
    return results


def simulate_poe_moe_paths(n: int, seed: int) -> dict[str, Any]:
    """Sample aggregate PoE/MoE outcome counts/rates from fixed reference-table parameters."""
    n = require_int(n, "n", positive=True)
    seed = require_int(seed, "seed")
    lcg = LCG(seed)

    moe_success = 0
    moe_hallucination = 0
    moe_refusal = 0

    poe_success = 0
    poe_hallucination = 0
    poe_refusal = 0

    for _ in range(n):
        r_moe = lcg.next_float()
        if r_moe < 0.759:
            moe_success += 1
        elif r_moe < 0.759 + 0.062:
            moe_hallucination += 1
        else:
            moe_refusal += 1

        r_poe = lcg.next_float()
        if r_poe < 0.700:
            poe_success += 1
        elif r_poe < 0.700 + 0.003:
            poe_hallucination += 1
        else:
            poe_refusal += 1

    return {
        "n": n,
        "source": "reference_parameter_simulation",
        "evidence_class": "SyntheticSimulation",
        "moe_counts": {
            "success": moe_success,
            "hallucination": moe_hallucination,
            "refusal": moe_refusal,
        },
        "poe_counts": {
            "success": poe_success,
            "hallucination": poe_hallucination,
            "refusal": poe_refusal,
        },
        "moe": {
            "success_rate": round(moe_success / n, 4),
            "hallucination_rate": round(moe_hallucination / n, 4),
            "refusal_rate": round(moe_refusal / n, 4),
        },
        "poe": {
            "success_rate": round(poe_success / n, 4),
            "hallucination_rate": round(poe_hallucination / n, 4),
            "refusal_rate": round(poe_refusal / n, 4),
        },
    }



