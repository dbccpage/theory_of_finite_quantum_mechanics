"""truncation shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
Related contract (if present): ``urn:omega:math:truncation_level:v0.1.0``.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Truncation:
    """Best-effort shell for an n-truncation claim / level tag.

    Does not implement the truncation HIT; shape / inventory only.
    ``level`` is None for untruncated.
    """

    label: str
    level: Optional[int] = 0
    type_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "Truncation":
        return cls(label=label, level=0)

    @classmethod
    def at_level(cls, label: str, level: int) -> "Truncation":
        return cls(label=label, level=level)

    @classmethod
    def untruncated(cls, label: str) -> "Truncation":
        return cls(label=label, level=None)

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if self.level is not None and self.level < -2:
            raise ValueError(f"truncation level {self.level} < -2")



