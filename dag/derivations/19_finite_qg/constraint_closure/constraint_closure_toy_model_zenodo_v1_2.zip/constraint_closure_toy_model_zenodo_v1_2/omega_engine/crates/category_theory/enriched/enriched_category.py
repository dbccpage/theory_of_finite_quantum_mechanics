"""enriched_category shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class HomObjectEntry:
    domain: str
    codomain: str
    hom_object: str


@dataclass
class EnrichedCategory:
    """Best-effort V-enriched category shell (base monoidal V + hom-objects)."""

    label: str
    base_monoidal_v: str = ""
    objects: List[str] = field(default_factory=list)
    hom_objects: List[HomObjectEntry] = field(default_factory=list)
    composition_ref: str = ""
    identity_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "EnrichedCategory":
        return cls(label=label)

    @classmethod
    def over_v(cls, label: str, base_monoidal_v: str) -> "EnrichedCategory":
        return cls(label=label, base_monoidal_v=base_monoidal_v)

    def with_hom(self, domain: str, codomain: str, hom_object: str) -> None:
        self.hom_objects.append(
            HomObjectEntry(domain=domain, codomain=codomain, hom_object=hom_object)
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.base_monoidal_v:
            raise ValueError("empty base_monoidal_v")
        for i, o in enumerate(self.objects):
            if not o:
                raise ValueError(f"empty object tag at index {i}")
        for i, h in enumerate(self.hom_objects):
            if not h.domain or not h.codomain or not h.hom_object:
                raise ValueError(f"empty hom_objects entry at index {i}")



