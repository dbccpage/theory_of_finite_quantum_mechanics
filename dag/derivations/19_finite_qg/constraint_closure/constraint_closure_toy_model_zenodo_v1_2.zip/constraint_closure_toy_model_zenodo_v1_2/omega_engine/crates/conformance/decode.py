r"""
Strict decoding of conformance-vector inputs.

AuthorityEffect: None.

``vectors/*.json`` is the specification. A binding that holds data the JSON does not declare
is not checking the spec --- it is checking itself, and the JSON becomes decoration. That was
a real defect in the first cut of the trace-norm and holonomy bindings: the vectors carried
``"connection": "exp_i_0.3_0.4_0.5"`` and ``"gauge": "exp_i_0.2_1.4_2.6"`` as strings the
binding never read, while the actual arrays were hard-coded next to the call. Editing the JSON
to declare a *trivial* connection would have left the nontrivial fixture running, and the
vector would still have passed.

Two rules follow, and this module exists to enforce both mechanically:

1. **Every array of numbers a binding uses comes from the JSON.** Carriers, matrices,
   connections, gauges, states and potentials are decoded here, never constructed in a
   binding.
2. **Every discriminator is exhaustive, and unknown input is an error.** A ``case`` the
   decoder does not know raises :class:`VectorSpecError`; it never falls through to a default
   branch. Silent fall-through is how ``delta: "anything_at_all"`` used to select the
   ``X_Z_XplusZ`` fixture.

Unknown *keys* are rejected too. A typo'd field that is quietly ignored is the same failure
mode as an ignored value: the file says one thing and the run does another.
"""

from __future__ import annotations
from typing import Any, Dict, Mapping, Sequence

import numpy as np

__all__ = [
    "VectorSpecError",
    "strict_keys",
    "pick_case",
    "graph",
    "unit_phase_connection",
    "complex_matrix",
    "complex_vector",
    "real_vector",
]


class VectorSpecError(ValueError):
    """A vector's ``input`` block is not a well-formed spec.

    Raised rather than defaulted. A conformance harness that guesses what you meant cannot
    tell you that you wrote it wrong.
    """


def strict_keys(inp: Mapping[str, Any], allowed: Sequence[str], *, where: str) -> None:
    """Reject any field the decoder does not consume."""
    unknown = sorted(set(inp) - set(allowed))
    if unknown:
        raise VectorSpecError(
            f"{where}: unknown field(s) {unknown}; allowed are {sorted(allowed)}. "
            "An ignored field is an ignored specification."
        )


def _require(inp: Mapping[str, Any], key: str, *, where: str) -> Any:
    if key not in inp:
        raise VectorSpecError(f"{where}: missing required field {key!r}")
    return inp[key]


def pick_case(inp: Mapping[str, Any], known: Sequence[str], *, where: str) -> str:
    """Read the ``case`` discriminator, exhaustively.

    Dispatching on *key presence* (``if "gauge" in inp``) cannot distinguish "this vector
    selects the gauge check" from "this vector has a stray gauge field", and it silently
    reorders when two keys are present. An explicit ``case`` can do neither.
    """
    case = _require(inp, "case", where=where)
    if case not in known:
        raise VectorSpecError(
            f"{where}: unknown case {case!r}; known cases are {sorted(known)}. "
            "Unknown cases are rejected, never defaulted."
        )
    return str(case)


def graph(spec: Any, *, where: str):
    """Decode an explicit finite carrier: vertices, edges, and optional faces."""
    from omega_engine.crates.homology_theory.finite_graph import FiniteGraph

    if not isinstance(spec, Mapping):
        raise VectorSpecError(f"{where}: carrier must be an object with 'vertices' and 'edges'")
    strict_keys(spec, ("vertices", "edges", "faces", "note"), where=f"{where}.carrier")
    vertices = list(_require(spec, "vertices", where=f"{where}.carrier"))
    edges = [tuple(e) for e in _require(spec, "edges", where=f"{where}.carrier")]
    for e in edges:
        if len(e) != 2:
            raise VectorSpecError(f"{where}.carrier: edge {e} is not a pair")
        for endpoint in e:
            if endpoint not in vertices:
                raise VectorSpecError(f"{where}.carrier: edge {e} leaves the vertex set")
    faces = [tuple(f) for f in spec.get("faces", [])]
    return FiniteGraph(vertices=vertices, edges=edges, faces=faces)


def unit_phase_connection(spec: Any, n: int, *, where: str) -> np.ndarray:
    r"""Decode :math:`A = e^{i\theta}` from ``{"unit_phases": [...]}``.

    Unit modulus is the whole content of a U(1) connection, so the encoding names phases and
    the modulus is not a free parameter that a typo can break.
    """
    if not isinstance(spec, Mapping):
        raise VectorSpecError(f"{where}: expected an object with 'unit_phases'")
    strict_keys(spec, ("unit_phases",), where=where)
    theta = np.asarray(_require(spec, "unit_phases", where=where), dtype=float)
    if theta.shape != (n,):
        raise VectorSpecError(f"{where}: expected {n} phases, got {theta.shape}")
    return np.exp(1j * theta)


def complex_matrix(spec: Any, *, where: str) -> np.ndarray:
    """Decode ``{"real": [[...]], "imag": [[...]]}`` into a complex matrix.

    ``imag`` is optional and defaults to zero, because most witnesses here are real and a
    required block of zeros is noise that invites copy-paste error.
    """
    if not isinstance(spec, Mapping):
        raise VectorSpecError(f"{where}: expected an object with 'real' (and optional 'imag')")
    strict_keys(spec, ("real", "imag", "note"), where=where)
    re = np.asarray(_require(spec, "real", where=where), dtype=float)
    if re.ndim != 2:
        raise VectorSpecError(f"{where}: 'real' must be a matrix, got ndim={re.ndim}")
    im = np.asarray(spec.get("imag", np.zeros_like(re)), dtype=float)
    if im.shape != re.shape:
        raise VectorSpecError(f"{where}: 'imag' shape {im.shape} != 'real' shape {re.shape}")
    return (re + 1j * im).astype(complex)


def complex_vector(spec: Any, *, where: str) -> np.ndarray:
    """Decode ``{"real": [...], "imag": [...]}`` into a complex vector."""
    if not isinstance(spec, Mapping):
        raise VectorSpecError(f"{where}: expected an object with 'real' (and optional 'imag')")
    strict_keys(spec, ("real", "imag", "note"), where=where)
    re = np.asarray(_require(spec, "real", where=where), dtype=float)
    if re.ndim != 1:
        raise VectorSpecError(f"{where}: 'real' must be a vector, got ndim={re.ndim}")
    im = np.asarray(spec.get("imag", np.zeros_like(re)), dtype=float)
    if im.shape != re.shape:
        raise VectorSpecError(f"{where}: 'imag' shape {im.shape} != 'real' shape {re.shape}")
    return (re + 1j * im).astype(complex)


def real_vector(spec: Any, n: int, *, where: str) -> np.ndarray:
    """Decode a plain list of reals of declared length."""
    arr = np.asarray(spec, dtype=float)
    if arr.shape != (n,):
        raise VectorSpecError(f"{where}: expected {n} reals, got shape {arr.shape}")
    return arr


def decoded_matrices(spec: Any, *, where: str) -> list:
    """Decode a list of complex matrices."""
    if not isinstance(spec, Sequence) or isinstance(spec, (str, bytes)):
        raise VectorSpecError(f"{where}: expected a list of matrices")
    return [complex_matrix(m, where=f"{where}[{i}]") for i, m in enumerate(spec)]




