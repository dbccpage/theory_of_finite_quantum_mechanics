"""cartesian_closed shell for omega_category_theory.

AuthorityEffect: None. Not PROVED / GlobalGreen.
"""

from __future__ import annotations
from dataclasses import field
from dataclasses import dataclass
from typing import List


@dataclass
class CartesianClosed:
    """Best-effort cartesian closed category shell."""

    label: str
    underlying_category: str = ""
    product_ref: str = ""
    terminal_object: str = ""
    exponential_ref: str = ""
    notes: List[str] = field(default_factory=list)

    @classmethod
    def new(cls, label: str) -> "CartesianClosed":
        return cls(label=label)

    @classmethod
    def with_structure(
        cls,
        label: str,
        underlying_category: str,
        product_ref: str,
        terminal_object: str,
        exponential_ref: str,
    ) -> "CartesianClosed":
        return cls(
            label=label,
            underlying_category=underlying_category,
            product_ref=product_ref,
            terminal_object=terminal_object,
            exponential_ref=exponential_ref,
        )

    def validate_shell(self) -> None:
        if not self.label:
            raise ValueError("empty label")
        if not self.underlying_category:
            raise ValueError("empty underlying_category")
        if not self.product_ref:
            raise ValueError("empty product_ref")
        if not self.terminal_object:
            raise ValueError("empty terminal_object")
        if not self.exponential_ref:
            raise ValueError("empty exponential_ref")



