"""Omega Engine Core Package."""
