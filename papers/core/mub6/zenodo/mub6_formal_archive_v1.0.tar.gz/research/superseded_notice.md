# Superseded research statements

**AuthorityEffect:** None.

The files listed below are byte-pinned members of the historical archive
`zenodo/mub6_formal_archive_v1.0.tar.gz` (see `zenodo/release_manifest.sha256`).
They are kept unchanged so the archive digests still replay. Some of their
status lines are withdrawn. Read [the paper](../papers/paper.md) and
[the gap registry](mub6_gap_registry.json) for the current scope.

## Withdrawn statements

| File | Lines | Withdrawn statement | Current scope |
| --- | --- | --- | --- |
| `research/mub6_frontier_synthesis.md` | 5, 7 | `NoCompleteMUB6` "unconditionally mechanized" or "unconditionally derived" via Route C. | `no_complete_mub6_via_route_c` takes the landing hypothesis `h_landing` as a premise (paper section 3, claim MUB6-C04). Gap G1 is OPEN. |
| `research/mub6.md` | 5, 91, 93, 97 | Complete MUB(6) "unconditionally resolved in the negative" via Route C. | The same Route C theorem is conditional (MUB6-C04, MUB6-C05). The existence of seven MUBs in dimension six is open. |
| `research/mub6_roadmap.md` | 4, 8, 214, 226 | `NoCompleteMUB6` "unconditionally established" or "unconditionally mechanized". | Same as above. The roadmap's Target C3 remains an open target, not a result. |

## What this notice does not do

- It does not change any archived byte or any digest.
- It does not re-seal the archive. A new archive version would have to drop or
  amend these files and be re-sealed with `scripts/build_zenodo_release.py`.
