<div align="center"># Exact reductions and quantitative bounds for mutually unbiased bases in dimension six</div>
<div align="center">Jeremy H. Carroll</div>
<div align="center">2026-10-16</div>
<div align="center">Version 1.1.1</div>

## Abstract

This technical checkpoint separates finite exact calculations, reported Lean implications,
and unresolved links to concrete mutually unbiased bases. A pinned replay of
the finite-corner classification, together with concrete normalization and
transport, now reduces actual quartet existence to completion of a retained
reconstruction. A separate exact Cauchy--Binet calculation gives a minor with
squared determinant at least $54/5$ and inverse-entry squared moduli at most
$10/27$ in every raw Hadamard. Whether nonextension holds for every raw Hadamard remains open.
The bounded minor now also supplies a complete block reconstruction chart.
Clearing its nonzero determinant denominator yields explicit division-free
matrix equations equivalent to actual quartet existence, with both additional
bases retained. A checked affine completion of the balanced transition matrices
gives an equivalent system of 648 rational polynomial equations of degree at
most two in 320 bounded real coordinates. Its infeasibility is not established.
The code also contains
cyclotomic fixtures, rational interval routines, conditional atlas and gluing
interfaces, and finite parity calculations. The Route C obstruction still needs
a certified Fourier-triple landing premise. The declared 56-cell cover still
needs analytic curvature certificates. The operator interface admits a zero-action
countermodel and therefore needs stronger mathematical definitions before it can
express the intended exclusion theorem. Separate concrete constructions now
supply the continuous two-circulant family, variable-basis equations, and an
actual fourth-basis candidate from normalized positive flat compatible moments.
The needed empty varieties and full analytic cover remain open. No unconditional dimension-wide MUB
bound follows from this package at this checkpoint.

## 1. Mathematical problem and normalization

This article presents reductions and quantitative bounds, rather than a solution
of the dimension-six MUB problem. Its contribution is a separation of concrete
matrix reductions, finite calculations, conditional interfaces and remaining
exclusion obligations. Section 2.1 compares the reductions with existing family
results and the finite-corner classification.

Formal-verification statements below describe the source reports identified in
Section 6. The standalone preprint archive contains the manuscript and rendering
machinery; it contains no Lean project or computational research supplement.
Those formal statements have not received a complete fresh replay for this
release candidate and are not certified by its checksum verifier.


Let $B_a$ be a unitary $6\times6$ matrix whose columns form an orthonormal basis
of $\mathbb C^6$. Mutual unbiasedness means

$$
|(B_a^*B_b)_{ij}|^2=\frac16\qquad(a\ne b).
$$

The unnormalized transition $H_{ab}=\sqrt6 B_a^*B_b$ then has unit-modulus entries
and $H_{ab}^*H_{ab}=6I$. All computational checks must retain this normalization;
testing an unnormalized product against the normalized condition changes the
problem. A complete family would have seven bases and $\binom72=21$ unordered
transitions. A fourth-basis obstruction and a seven-basis obstruction are distinct
statements.

`MubQuartetTransportBridge.lean` now derives this normalization for every
actual quartet. `exists_quartet_iff_exists_rawQuartet` connects the existing
normalized matrix predicate to three raw Hadamard matrices with all three MU
conditions. `MubMonomialTransport.lean` derives preservation under a common
left row-permutation/phase action and independent right column actions.
Thus standard Hadamard equivalence preserves the entire completion problem.
`no_quartet_of_concrete_representatives` still requires both complete
representative coverage and nonextension for every representative.
The separate pinned `MubFiniteCornerReduction.lean` now consumes the verified
external coverage theorem and derives an equivalence between actual quartet
existence and raw quartet completion of some retained finite-corner output.
Its nonexistence equivalence leaves the exclusion of every retained output
as the remaining mathematical statement, rather than assuming coverage.

The Lean type `MUB6.Gluing.Basis` and its MU relation are opaque interfaces.
Their names do not supply coordinates, unitary matrices, or the above equations.
A theorem over those interfaces needs a separate concrete interpretation before
it can be applied to the Hilbert-space problem.

### 1.1. Gauge coordinates for a fixed first Hadamard matrix

Apply the same left unitary $B_0^*$ to every basis. Then $B_0=I$ and
$H_a=\sqrt6 B_a$, for $a=1,2,3$, have unit entries in modulus and
$H_a^*H_a=6I$. A common left diagonal phase action, followed by independent
column phases, dephases $H_1$. The common left action must be applied to all
bases; independently changing rows of just one basis need not preserve MU.

For a fixed $H_1$, right multiplication of $H_2,H_3$ by diagonal matrices with
entries $\overline{(H_a)_{0j}}$ fixes their first rows to one. Entry moduli,
unitarity and all transition moduli are preserved. The acting column-phase
group is $\mathbb T^{12}$, of real dimension **12**. The prescription fixes
24 ambient real coordinates: twelve phases and twelve already-constrained
radial coordinates. Thus $144-24=120$ real coordinates remain for the two
additional raw matrices. This is an ambient coordinate count, not a dimension
theorem for the solution set, a smoothness assertion, or a Jacobian rank claim.
There are still sixty circle equations before imposing orthogonality and MU.
If $H_1$ also varies, its dephased $5\times5$ block contributes another fifty
ambient real coordinates; the fixed-$H_1$ count must not be used globally.

The matrix-level preservation statements are
`SzollosiColumnGauge.columnRephase_gram`, `columnRephase_unitary`,
`columnRephase_rawPairMU` and `rawCandidates_firstRowDephase`.
The family-specific existence equivalence is
`exists_gauged_solution_with_parameters_iff`; it keeps the family parameters
fixed and both additional bases variable.

**Scope.** This supports the stated gauge reduction. It does not classify
$H_1$, establish a 120-dimensional manifold, or exclude a quartet. The narrow
claim is preservation of the completion problem under column phases. The next
required evidence is a complete obstruction for the remaining equations over
a declared domain, including the parameters when they vary.

### 1.2. Explicit transition-balance identities

Write $A=H_2$, $B=H_3$, $W=A^*B$ and define polynomial residuals

$$
g_{Aj}=A_{0j}-1,\quad g_{Bj}=B_{0j}-1,\qquad
R_{Bm}=\sum_k B_{mk}\overline{B_{0k}}-6\delta_{m0}.
$$

For arbitrary complex matrices $A,B$, without assuming any residual vanishes,
the following identity holds:

$$
\sum_k W_{jk}-6
=\sum_m\overline{A_{mj}}R_{Bm}
-\sum_{m,k}\overline{A_{mj}}B_{mk}\overline{g_{Bk}}
+6\overline{g_{Aj}}. \tag{1}
$$

Indeed, substituting $\overline{B_{0k}}=1+\overline{g_{Bk}}$ cancels the
double sums on the right, leaving
$\sum_{m,k}\overline{A_{mj}}B_{mk}-6\overline{A_{0j}}
+6(\overline{A_{0j}}-1)$. Interchanging $A,B$ and conjugating gives the
column identity. On the first-row gauge and row-unitarity equations both
residuals vanish, so all six row sums and six column sums of $W$ are six.
These are twelve complex, or twenty-four real, equations.

Equation (1), split into real and imaginary parts, is an explicit polynomial
ideal-membership identity for the row-unitarity and gauge residuals. Its
coefficients depend on matrix entries. For a square matrix, column unitarity
also implies row unitarity, as formalized by `SzollosiGaugeBalance.raw_right_gram`.
The solution-level conclusions are `transition_row_sum`,
`transition_column_sum` and `solution_balance_equations`. No additional
solution-set restriction follows by adding these consequences, although they
can strengthen an interval contractor on boxes containing nonsolutions.

**Scope.** `MubGaugeSyzygy.lean` now checks the row identity and its conjugate
column counterpart over every commutative star ring. Its two ideal-membership
corollaries apply to any ideal containing the displayed generators, including
polynomial ideals. They support exact algebraic redundancy, without supplying
a Jacobian rank or nonextension result. All six displayed theorem endpoints
were replayed on 2026-10-11 with only standard Lean axioms. The next step is
to bind these generator identities to the executable contractor's coordinates.

### 1.3. A quantitative invertible minor

For any $A\in\mathbb C^{3\times6}$ with $AA^*=6I_3$, the finite
Cauchy--Binet identity gives

$$
\sum_{S\subset\{0,\ldots,5\},\ |S|=3}|\det A_{[:,S]}|^2
=\det(AA^*)=216.
$$

There are twenty summands. Hence one selected minor $B=A_{[:,S]}$ satisfies
$|\det B|^2\ge216/20=54/5$, in particular $\det B\ne0$.
If all entries of $A$ have unit modulus, each entry of $\operatorname{adj}B$
is a difference of two unit-modulus products. Its squared modulus is at most
four, and therefore

$$
|(B^{-1})_{ij}|^2\le\frac4{|\det B|^2}\le\frac{10}{27}.
$$

`MubMinorChart.lean` checks the twenty-minor identity as an exact polynomial
identity and derives the two rational bounds. It also applies them to the
first three rows of every raw Hadamard matrix satisfying $HH^*=6I_6$.
All ten displayed endpoints passed the canonical Lean 4.33.1 replay with
only standard axioms. The next subsection supplies placement and complete
reconstruction coverage. Neither result establishes finite fibres or
excludes any quartet. The selected well-conditioned minor need not be the
minor chosen by the external finite-corner theorem.

### 1.4. A complete bounded chart and division-free quartet equations

`MubBoundedBlockChart.lean` extends each selected triple to a complete column
permutation, then dephases the entire matrix while preserving determinant
moduli and quartet extendability. On the block index set
$\operatorname{Fin}(3)+\operatorname{Fin}(3)$ the resulting matrix is

$$
H=\begin{pmatrix}E&B\\C&D\end{pmatrix},\qquad
q=|\det B|^2\ge54/5,\qquad D=-CE^*(B^{-1})^*.
$$

`Admissible E B C` requires unit entries in all four blocks, first row and
column one in $E$, first row one in $B$, first column one in $C$, and the
two diagonal row-Gram equations $EE^*+BB^*=6I_3$ and $CC^*+DD^*=6I_3$.
The forced formula makes the mixed Gram blocks zero. The module checks
soundness, coverage and actual quartet transport. It does not use the
external classification or a finite-fibre premise.

`MubBoundedQuartetEquations.lean` defines

$$
d=\overline{\det B},\qquad N=-CE^*(\operatorname{adj}B)^*,\qquad
S=\begin{pmatrix}dE&dB\\dC&N\end{pmatrix}.
$$

It shows in this model $dD=N$ and $dH=S$ under the positive determinant bound. The
forced-block constraints become $|N_{ij}|^2=q$ and
$qCC^*+NN^*=6qI_3$, without division. Retain the top Gram equation, the
unit entries of $E,B,C$, their gauge constants and $q\ge54/5$.
For two further raw matrices $U,V$, retain unit entries and
$U^*U=V^*V=6I_6$. Independent column phases fix their first rows to one.
The three MU conditions are exactly

$$
|(S^*U)_{ij}|^2=6q,\qquad |(S^*V)_{ij}|^2=6q,\qquad
|(U^*V)_{ij}|^2=6.
$$

The checked endpoint `exists_quartet_iff_equations` identifies actual
quartet existence with a solution of these equations and the determinant
inequality. The matching nonexistence equivalence is checked too.
There are 76 free complex entries after the gauge constants are substituted,
or 152 ambient real coordinates. Unit entries bound each real and imaginary
part by one; this is not a solution-dimension or independence claim.
The scalar bound and all 34 displayed endpoints across these two modules
passed targeted canonical replay with only standard axioms.

`MubBoundedCoordinates.lean` checks both directions of the 152-real-coordinate
codec and retains the full box $[-1,1]^{152}$, including its boundary.
`MubBoundedPolynomials.lean` represents complex arithmetic in the quadratic
algebra over $\mathbb Q[x_1,\ldots,x_{152}]$ with generator squared equal to
$-1$. Its real and imaginary components give 396 indexed rational polynomial
equalities. Together with $q\ge54/5$, their real solutions are equivalent to
actual quartet existence (`exists_quartet_iff_polynomials`). The 13 coordinate
and 26 polynomial endpoints passed scoped replay with only standard axioms.

`MubBoundedExpressions.lean` identifies each executable arithmetic expression
with its polynomial, including determinant and adjugate evaluation. The
polynomials have total degree at most 8, and $q$ has degree at most 4.
`MubBoundedCoefficientExpansion.lean` identifies finite rational term-list
expansion with those same polynomials. These degree and expansion statements
passed scoped kernel replay; they do not assert sharp degree or independence.

`MubBoundedExportIndices.lean` checks complete, unique coordinate and equation
numbering. `MubBoundedTermCollection.lean` checks polynomial preservation
under sorting, coefficient collection and exact-zero removal.
`MubBoundedCodedSystem.exists_quartet_iff_coded` retains actual quartet
existence on `Fin 152` with all 396 equations and the determinant inequality.
The 28 displayed endpoints passed scoped replay with only standard axioms.
The native export contains 3,760,338 collected monomials across the 396
constraints and $q$; all 1,588 exact rational expression/list comparisons pass.
The export receipt binds the compressed artifact and its decompressed bytes.

`MubBoundedMUFactor.lean` checks a further cancellation: 36 MU residuals
factor as $q$ times polynomials of degree at most four. Since $q\ge54/5$,
replacing those residuals preserves the complete quartet existence equivalence.
Their coefficient lists shrink from 371,520 to 3,096 monomials; with every
other row retained, the total becomes 3,391,914. The 36-row replacement table
is bound to the original archive by its receipt. Eighteen endpoints passed
scoped replay. A checked singular-point counterexample shows why the
positive determinant condition is required for this cancellation.

`MubQuadraticLift.lean` supplies a separate full-matrix formulation. Keeping
the nine complex entries of $D$ and three complex transition matrices gives
386 ambient real coordinates. `MubQuadraticLiftPolynomials.lean` checks
648 rational polynomial equalities: 108 unit-entry equations, 216 Gram
components, 216 transition graph components and 108 transition norm equations.
The graph equations are $W_0=H^*U$, $W_1=H^*V$, $W_2=U^*V$; each transition
entry has squared norm six. Actual quartet existence is equivalent to a
common zero in $[-1,1]^{170}\times[-3,3]^{216}$, with coordinates grouped by
their matrix-entry and transition slots. `MubQuadraticLiftDegree.lean` bounds
the total degree of every actual polynomial by two. The three modules' 28
displayed endpoints passed scoped replay with only standard axioms.

This full-matrix model uses no determinant division. Its reverse implication
checks the three full Hadamard matrices and all pairwise MU equations directly,
so it does not need invertibility of $B$. The positive determinant condition
remains necessary in the earlier reconstruction and factor-cancellation models.
The new coordinate and equation counts are not independence or dimension claims.

`MubQuadraticLiftIndices.lean` checks complete coordinate and equation
numbering and the bounds assigned to coordinate IDs. The coefficient and
coded-system modules identify the complete collected lists with these same
polynomials and preserve quartet existence on `Fin 386`. The native export
contains 4,920 monomials, at most 12 per row, in 169,800 bytes. All 2,592
comparisons with direct rational matrix arithmetic pass, and two exports are
byte-identical. Forty-two zero rows remain in the complete indexing.

`MubQuadraticLiftTable.lean` contains literal rows generated from that file.
Its `rows_match` checks every literal row against the defining coefficient
lists by kernel reduction; `bounds_match` checks the literal bounds.
`exists_quartet_iff_table` preserves actual quartet existence for common zeros
of these literal rows in the coded box. JSON parsing and file hashing remain
external steps recorded in the coefficient receipt. This does not identify an
arbitrary external file with the checked literals.

The native Rust loader now binds that exact file and checks its schema,
indexing, monomials and recorded probe values. One exact interval sweep
retains the first 170 coordinate bounds and narrows all 216 transition bounds
to $[-10035/4096,10035/4096]$. Every final equation range contains zero;
the result is `CONTRACTED_UNRESOLVED_BOX`. Three targeted Rust tests check
this result, invalid-input rejection, square enclosure, known-root retention
and closed boundary contact. These are native execution checks.

Independently, `MubQuadraticLiftNarrowBox.lean` derives the same bound from
the transition norm equations. Its `exists_quartet_iff_narrow_table` retains
actual quartet existence on the smaller box. All seven displayed endpoints
passed scoped replay with only standard axioms. This checks the specific
mathematical narrowing without treating the runtime parser or general
contractor as kernel-reflected proofs.

`MubQuadraticLiftCompatibility.lean` derives both transition Gram matrices
as $36I$, the three cycle identities $W_0W_2=6W_1$,
$W_0^*W_1=6W_2$, $W_1W_2^*=6W_0$, and row and column sums equal to six.
The polynomial companion adds 504 consequences: 216 column-Gram components,
216 cycle components and 72 linear balance components. Their degrees are
checked, and adding them preserves actual quartet existence. These new
polynomials have not yet been exported as another literal table.

The separation module checks, for every pair of columns,

$$
\sum_k |(W_0)_{ki}-(W_1)_{kj}|^2
=72-12\operatorname{Re}(W_2)_{ij}\ge\frac{43623}{1024}.
$$

The native inspector uses exact component interval bounds to exclude a box
when its squared-distance upper bound is strictly smaller. A closed example
with all coordinate intervals of positive width is excluded by this test
while the original 648 polynomial ranges still contain zero. In each of two
selected columns, real components lie in $[9/10,11/10]$ and imaginary
components lie within $1/20$ of common alternating centers $9/4,-9/4$.
The distance upper bound before contraction is $3/10$.
`close_columns_box_excluded` checks this family of regions directly in Lean.
Across the three new modules, 37 endpoints passed scoped replay with only
standard axioms. Five targeted native tests passed, including the new regional
regression and strict-threshold contact. This supplies a regional exclusion;
the full box remains unresolved and no complete cover is claimed.

**Scope.** Infeasibility over the retained domain and a complete exclusion
cover remain open. The contraction and coefficient checks do not
establish emptiness or solver complexity; $q\ge54/5$ remains part of the older
152-coordinate system. The earlier large serialized archive is separate from
this newly reflected literal table.

The transition balances also permit a global affine reduction.
`MubBalancedCompletion.lean` reconstructs a transition from its leading
$5\times5$ block $A$: the last column is $6-\sum_j A_{ij}$, the last row
is $6-\sum_i A_{ij}$, and the corner is $\sum_{i,j}A_{ij}-24$.
Both reconstruction directions are checked without division.
`MubBalancedQuadraticLift.lean` uses these formulas for all three transitions,
reducing 386 ambient real coordinates to 320 while preserving actual quartet
existence. The retained box is
$[-1,1]^{170}\times[-10035/4096,10035/4096]^{150}$.

The polynomial companion substitutes these affine formulas into all 648
original equations and checks that every resulting degree is at most two.
`exists_quartet_iff_balanced_polynomials` is the resulting global existence
equivalence. The recovered coordinate bounds hold on solutions; an arbitrary
reduced-box point need not expand into the old box. A checked counterexample
uses the all-zero free assignment, whose completed transition corner is $-24$.
All 27 displayed endpoints across the three modules passed scoped replay with
standard axioms. Fewer coordinates do not establish a speedup or constraint
independence.

The balanced coordinate codec and coefficient substitution now have a complete
exact export. The 18 displayed endpoints in `MubBalancedIndices.lean`,
`MubBalancedCoefficients.lean` and `MubBalancedCodedSystem.lean` passed scoped
replay with standard axioms, including `exists_quartet_iff_coded`.
The generated `MubBalancedTable.lean` contains literal equality checks in
blocks of 18 equations and a proposed `exists_quartet_iff_table` theorem.
Its full build has not completed. Its six displayed endpoints remain
unverified; this checkpoint does not claim a checked literal table. The exporter checks
2,592 rational values against direct completed-matrix arithmetic, and two full
exports have identical bytes. JSON parsing and byte custody remain external
to the kernel.

The balanced table contains 8,313 monomials, compared with 4,920 in the
386-coordinate table. Its largest row contains 676 terms rather than 12;
transition-norm equations account for most of the increase. The first 324
rows are unchanged. A corrupted corner row is rejected by the direct matrix
check, and the kernel separately checks that its true coefficient list is
nonempty. These are implementation and coefficient checks, not exclusion
certificates. The existing native inspector still uses 386 coordinates.
Factored completion should be compared with expanded substitution before
choosing a reduced search representation; no runtime or contraction-strength
advantage has been established. Global infeasibility remains open.

An independent Rust transcription in `omega_mub` regenerates all 648 rows of
the balanced table from the same definitions and compares them with the
exported table term by term over the rationals; every row agrees. This is a
check of the export against its definitions, not a replay of
`exists_quartet_iff_table`. Two negative controls set the third basis equal to
the first or to the second at the product triple. In each case exactly the 36
transition-norm rows of the repeated pair are nonzero, with values -6 and 30,
and five core coordinates leave the box. The Jacobian of the system at the
centre of the box has 1,045 linear terms in 269 rows and exact rank 184 of
320. It is neither zero nor of full column rank, so a containment test whose
premise is a vanishing Jacobian at the centre does not apply to this table,
and a Moore–Penrose preconditioner is not defined there. The receipt is
`artifacts/mub6_prompt05_campaign_receipt.json`.

## 2. Exact arithmetic and finite evidence

The computational fixtures use exact rational or cyclotomic arithmetic over
$\mathbb Q(\zeta_{24})$. This coefficient field supports those fixtures; it does
not restrict arbitrary complex phases in the original problem to 24th roots.
Rational interval bounds can support continuum statements only when they enclose
the actual matrix-dependent functions on a complete declared domain.

`Conjecture2GeneralMechanization.lean` contains the finite identities

$$
\alpha_2(m)=6m-9\in\{-9,-3,3,9\},\qquad m\in\{0,1,2,3\},
$$

$$
1+\operatorname{paritySign}(\alpha_2(m))=0,
$$

and paired integer cancellations. Its Tao phase-table calculation gives the
Eisenstein norm $9$. The new `balanced_mask_count` and
`tao_all_balanced_masks` check all twenty three-positive/three-negative sign
patterns among the 64 six-bit masks. For each column the signed exponent is
reduced modulo three, and counts $(n_0,n_1,n_2)$ give
$x=n_0-n_2$, $y=n_1-n_2$, with exact norm $x^2-xy+y^2=9$.
`tao_distinct_positive_rows` also checks every triple of distinct positive
row indices directly, without a bit-mask decoding premise. These four theorems
were replayed using Lean
4.33.1 on 2026-10-11; `#print axioms` reported no axioms for them.
`MubTaoLaurent.lean` now supplies the complex interpretation with
$\omega=-1/2+i\sqrt3/2$. It checks addition, multiplication, conjugation and
norm under the integer-pair evaluator, identifies inverse entries with their
conjugates, and derives

$$
\left|\sum_{j=0}^5\prod_{r=0}^5 S_{rj}^{\gamma_r}\right|^2=9
$$

for every balanced bit-mask sign vector $\gamma$. The eight displayed
endpoints passed fresh replay using only standard Lean axioms; the integer
pair/exponent norm comparison uses none. This is a complex matrix evaluation,
not a necessary condition for arbitrary triples.
The original module's `ModuliClass` table is a declared finite table, rather
than a classification of complex matrices. Its analytic-certificate structure
supplies row-count bounds and table compatibility as assumptions. The later
odd-parity polynomial lemmas remain integer identities until a matrix monomial
interpretation has been constructed.

The SymPy 2-circulant calculations and Rust non-tensor surveys are separate
family evidence. They do not make every complex Hadamard matrix a member of a
surveyed family, or establish general Hadamard-cube Conjecture 2.

**Scope of the Tao calculation.** It supports the exact nonzero value for the
recorded matrix and all balanced sign patterns. It does not turn the conjectured
Laurent vanishing condition for arbitrary MUB triples into a theorem. The narrow
claim is a finite exact invariant evaluation. A Laurent-based exclusion requires
that general necessary-condition theorem, separately from the evaluation.

### 2.1. Literature scope and classification obligations

The Fourier family is continuous, so it should not be grouped as a sporadic
matrix. [Jaming et al., arXiv:0902.0882v2](https://arxiv.org/abs/0902.0882v2) [1]
establish nonextension to a quartet for the identity together with any member
of their Fourier family. Applying that result to an arbitrary transition
requires common-unitary and monomial equivalence transport; the new concrete
transport modules supply preservation, while matching the exact Fourier
representatives to the cited theorem remains a separate obligation.

[Maxwell and Brierley, arXiv:1402.4070v2](https://arxiv.org/abs/1402.4070v2) [2]
treat the three-parameter Karlsson family and establish its balanced Laurent
vanishing identity. This does not give quartet nonextension. The inherited
description of the full Karlsson family as a two-parameter affine family is
not used here. Nor is an unspecified matrix named $H_6$ enough to identify
a separate Haagerup exclusion theorem: its concrete entries and source theorem
must first be matched.

[Cárdenes Wuttig and Tindall, arXiv:2608.18053v2](https://arxiv.org/abs/2608.18053v2) [3]
present a finite-corner classification and an accompanying Lean formalization.
Their result concerns single Hadamard matrices; it is not the five-family
partition asserted in the inherited campaign. The exact theorem and its
equivalence conventions were inspected against the concrete matrix predicates.
The source
was pinned at `57b03025ecbe259e474281f49e201ea7cb474e34`; its 136 project modules
passed the source-level unfinished-proof/added-axiom scan. After an initial
memory failure and a successful single-worker retry, the public theorem target
completed under its pinned Lean 4.33.0-rc2 and Mathlib revision. All nine
public theorem reports and the supporting Karlsson coverage report use only
standard axioms. All 215 external archive files matched the pinned ZIP.

The integration replay then recompiled the exact source bytes of 21 local
dependency modules and the new bridge under the external pin. It reconciles
`Fin 3 + Fin 3` with `Fin 6`, row and column Gram conventions, and actual
monomial equivalence. All five bridge endpoint reports use only standard
axioms. The checked conclusion is

$$
\begin{aligned}
&\exists\text{ an actual quartet in }\mathbb C^6\\
&\quad\Longleftrightarrow
\exists p,B,C:\ \operatorname{Retained}(p,B,C)
\land\operatorname{HasRawQuartet}(\operatorname{completion}(p,B,C)).
\end{aligned}
$$

Here $p$ consists of four unit phases in a dephased corner $E$; the adjacent
blocks obey $EE^*+BB^*=6I$ and $E^*E+C^*C=6I$, and the forced final block is
$D=-CE^*(B^{-1})^*$. Retention includes the external finite-corner and
unit-entry conditions. Finite candidate fibres over continuous seeds do not
give a finite global list. Exclusion over every retained reconstruction is
still open. The old five-family premise is quarantined.

[Matolcsi et al., Proposition 4.2](https://doi.org/10.1007/s10801-026-01506-x) [4]
provide a separate conditional route through their Conjectures 2 and 3.
Conjecture 2 concerns Laurent conditions on actual MUB triples; Conjecture 3
concerns quartet nonextension of their Szöllősi family. The paper explicitly
withdraws an earlier treatment of the latter as a literature theorem. Thus the
local finite class table cannot discharge either premise.

**Scope.** These source comparisons distinguish established family results,
replayed classification, concrete transport, and still-needed exclusion arguments.
They do not establish $N(6)=3$. The narrow conclusion is that the inherited
five-branch case split cannot serve as the current proof boundary. The next
test is uniform exclusion on the now-justified retained-output domain, or a
direct proof of the two conjectures in the alternative route. The independent
quantitative minor theorem does not identify its selected minor with the
external finite-fibre minor.

## 3. Gluing statements and the Route C frontier

The combinatorial theorem `g3_theorem` extracts a fourth basis for any constituent
triple of a supplied seven-basis family. The assembly theorem combines supplied
landing and obstruction data to contradict that extension. This logical assembly
does not construct the landing data.

`MUB6OrbitConfiguration` assumes

$$
6=n_D+n_T+n_S+n_H,\qquad n_T+n_S\le1,\qquad n_H\le0.
$$

These natural-number assumptions yield $n_D\ge5$ and
$n_D+\binom{n_D}{2}\ge15$. The structure contains no matrices or map from these
counts to actual transition edges. In particular, counting pairs of labels does
not establish that their relative transition matrices lie in the Fourier family.
The computation $\min(2+1,3+1)=3$ is also a numerical evaluation; it supplies no
classification of arbitrary complex MU bases.

The existing Route C conclusion has the exact premise

```lean
h_landing : CompleteMUB6 → RouteCCompleteMUBFamily
```

The smaller interface `FourierTripleLandingPremise` removes orbit counts from
the contradiction:

$$
\begin{aligned}
&\forall B:\operatorname{Fin}(7)\to\operatorname{Basis},\quad
\operatorname{PairwiseMU}(B)\Rightarrow\\
&\qquad\exists T:\operatorname{MUTriple},\quad
\operatorname{InConfig}(T,B)\land\operatorname{InFourierDitaChart}(T).
\end{aligned}
$$

`no_complete_mub6_of_fourier_triple_landing` derives the abstract obstruction
from this supplied premise. `InFourierDitaChart` requires certified domain
membership, including analytic soundness. A concrete algebraic landing theorem
and a concrete interpretation of the chart remain open.

The proposed expression $\sum_{a,b}|\operatorname{Tr}(B_a^*B_b)|^4$ depends on
basis-column phases. By contrast, the entrywise fourth-power sum is fixed by MU:
each distinct ordered pair contributes $36(1/6)^2=1$, and a self-pair contributes
$6$. For seven bases its total is $7\cdot6+7\cdot6=84$. This computation supplies
no Fourier membership map. A separate exact fixture checks that the ordinary
raw Fourier matrix has a $2\times2$ cross ratio $\zeta_6$ with
$\zeta_6^4\ne1$. Row/column rephasing preserves cross ratios. Thus the proposed
all-fourth-root entry condition is not a definition of this Fourier family.
Likewise, a simplicial coboundary identity over integer
cochains contains no complex transition matrix data unless an additional bridge
has been established.

[Jaming et al., arXiv:0902.0882](https://arxiv.org/abs/0902.0882) [1]
give a Fourier-family quartet obstruction. Applying that literature result to an
arbitrary seven-basis family still requires a Fourier-family landing statement.
It is not an unconditional classification supplied by the citation.

## 4. The 56-cell Krawczyk and reflection frontier

`canonicalModuliPartitionCover56` stores 56 intervals with endpoints $i/56$ and
$(i+1)/56$, a depth label $64$, and fixed positive rational margins. These data
do not record a depth-64 contractor execution or the three cusp collars.

The kernel-checked equivalence `certified_point_in_cover56_iff` exposes the
actual hypothesis:

$$
\begin{aligned}
&\operatorname{CertifiedPointInCover56}(\mathrm{cover},\mathrm{pt})\\
&\quad\Longleftrightarrow
\operatorname{GeometricPointInCover56}(\mathrm{cover},\mathrm{pt})\\
&\qquad\land\operatorname{HasCurvatureCertificate}(\mathrm{pt.triple}).
\end{aligned}
$$

Thus `conjecture3_szollosi_deltoid_closure` consumes a curvature certificate;
it does not derive that certificate from interval containment.

The native library `src/omega_native/mub6_smale_sentry.rs` contains rational
linear algebra and a Krawczyk contractor for supplied square quadratic systems.
The same-named binary under `src/bin/` now provides `--inspect-system` for the
exported joint system. This mode performs exact interval inspection, without
a depth-64 contractor or a complete cell/cusp run.
The terminal receipt has aggregate labels and counts, without 56 per-cell
rational boxes, interval Jacobians, or Krawczyk images. Its status label is not
an independent replay of those missing objects.

A valid completion requires a concrete chart/system encoding, all cell and collar
domains, exact Jacobian bounds, complete coverage, and checked exclusion on each
leaf. Krawczyk strict inclusion supports root existence under its hypotheses;
exclusion instead requires disjointness or another sound infeasibility condition.
A `by rfl` evaluation of a Boolean establishes that computation. A separate
soundness theorem must connect it to the concrete MU residuals and domain.

`F_system` in the current abstract Lean module repeats a basis-level MU predicate
for the row and column indices. It is not yet the 108 scalar coordinate
polynomials needed by the proposed native-to-kernel reflection. The cross-basis
residuals also need the candidate's unitarity/domain conditions: a root on an
unrestricted column array does not by itself represent a fourth basis.

The source family also needs careful domain identification.
[Szöllősi, arXiv:0811.3930v2](https://arxiv.org/pdf/0811.3930v2) [5] describes
$X_6(\alpha)$ as a two-real-parameter family over an intersection of deltoid
regions, containing the one-parameter $B_6(\theta)$ family. The stored scalar
interval cells give no coverage map for that full parameter domain. A native
certificate must specify the intended family and cover the associated domain.

`SzollosiTwoCirculant.lean` now checks the continuous block construction
$H=\begin{pmatrix}A&B\\B^*&-A^*\end{pmatrix}$, where the circulant first rows are
$(1,x,xy)$ and $(1,u,uv)$. Four unit phases satisfy
$\phi(x,y)+\phi(u,v)=0$, with $\phi(x,y)=x+y+\overline{xy}$.
The Gram identity is $HH^*=6I$, so $H/\sqrt6$ is unitary and all its
entry moduli squared are one sixth. The parameter domain is exactly six
scalar real polynomial equations in eight real coordinates. Its solutions
lie in $[-1,1]^8$, and `parameter_covers_intersection` connects those solutions
to every point of the intersection of the two phase-sum images. The cubic
root identities hold without a distinct-root premise. This is the source
block construction; equivalence transport to a selected dephased representative
and a classification of arbitrary Hadamard matrices are not supplied.

[Matolcsi et al., arXiv:2503.14752, Conjecture 3](https://arxiv.org/pdf/2503.14752) [4]
concerns arbitrary quadruplets containing a member of this family. A single
chosen Zauner triplet would not cover all possible third bases.
`SzollosiQuartetSystem.lean` therefore leaves both additional complex bases
variable. `quartet_iff_candidate_equations` retains all 144 of their real
coordinates and the actual pairwise MU equations. Every coordinate of a matrix
unbiased to the identity lies in the rational box $[-1/2,1/2]$ by
`mu_identity_coordinates_bounded`. The remaining empty-variety obligation
quantifies over every unitary third basis unbiased to both fixed bases.
No such variety is established empty. `SzollosiQuadraticSystem.lean` now gives
a joint rational polynomial specification: 440 real variables and 618 equations,
each of total degree at most two (`equation_degree`). Raw matrices are scaled by
$\sqrt6$ relative to normalized bases; three auxiliary matrices represent their
cross products, with entry norm-square target six. The equation counts are:

| Equations | Count |
|---|---:|
| Unit phases and complex compatibility | 6 |
| Family-matrix ties | 72 |
| Raw unitarity of the two additional bases | 144 |
| Unit entry norms of the two additional raw bases | 72 |
| Three cross-product matrix ties | 216 |
| Cross-product entry norms | 108 |

`exists_solution_with_parameters_iff` checks both directions between actual
quartets and solutions at every fixed admissible phase parameter.
`exists_solution_iff_quartet` gives the full existence equivalence.
`solution_in_full_box` bounds every phase and raw basis coordinate in $[-1,1]$
and every auxiliary cross-product coordinate in $[-3,3]$.
`exists_bounded_solution_iff_quartet` checks that this rational box loses no
solutions. Both additional bases remain arbitrary, including complex phases.

`SzollosiExecutableSystem.lean` adds executable expression trees for every
checked equation. `expression_polynomial` and `equation_eval` identify their
real evaluation with the rational specification for every assignment.
`variable_codes` and `equation_codes` check complete ordered IDs for all 440
coordinates and 618 equations. The exporter writes the full rational containing
box and three rational probes to `mub_szollosi_executable_system.json`; its raw
SHA-256 is `1367d390da36e5ccf65abbc8fbf529ff07f9e154c277bb14c1cd8c36ba24c947`.
Independent exports were byte-identical.

The native inspector compiled 5,128 sparse terms of degree at most two, matched
all 1,854 probe values, and emitted all 618 full-box residual intervals in
`mub_szollosi_native_replay_receipt.json`. Its observed status is
`UNRESOLVED_FULL_BOX`. Finite probes do not establish native symbolic parity for
every real assignment.

`SzollosiTermExpansion.lean` derives complete sparse normalization semantics.
The native inspector now compares all 618 rows and 5,128 nonzero terms against
the independently exported Lean coefficient table, raw SHA-256
`44656965bb72e735febfc69c1bcd599adbeea2e8512ebd6141025f8524e5d2df`.
`SzollosiNativeReflection.lean` checks the actual emitted coefficient table by
kernel reduction (`native_terms_match`); `native_coefficients_polynomial`
identifies every row with the actual rational polynomial under injective coding.
`SzollosiNativeInterval.lean` derives sparse interval enclosure with square
refinement and ordered accumulation. Kernel reduction checks all 618 actual
emitted intervals (`native_ranges_match`); `native_interval_enclosed` binds
each to all actual real assignments in the full containing box. The native
receipt raw SHA-256 is
`17b31a7eec56d0129b0b4b8a837f55d71b37ee0be0d0a91ad6fbb106949633dc`.
These identities concern the current emitted data, without generic verification
of every Rust compiler or JSON decoder input. Every emitted interval still
contains zero (`native_full_box_unresolved`). No variety emptiness or root
existence follows. Coefficient and interval literal mutations are rejected by
their kernel checks; a quadratic perturbation invisible to all three old probes
is rejected by the complete native coefficient comparison.

`SzollosiIntervalExclusion.lean` derives rational AST interval enclosure for
every contained real assignment. `exclusion_check_sound` connects a successful
residual interval check to absence of actual polynomial zeros in that box.
The full containing-box check reduces to false inside the kernel
(`full_box_check_unresolved`). A concrete first-phase box with both coordinates
in $[-1/2,1/2]$ is excluded by `phase_interior_excluded` (kernel reduction); this box
contains no admissible unit phase and supplies no exclusion of admissible
quartets. The complete containing box remains unresolved in both calculations.
A false exclusion check supplies no root-existence conclusion.

`RectangularQuadraticExclusion.lean` now supplies a rational rectangular
Krawczyk exclusion method. `list_derivative_polynomial` identifies the computed
derivative expressions with formal partial derivatives. The exact quadratic
midpoint secant identity yields `root_in_image`: every zero in the input box lies
in its image for any rational preconditioner. No inverse or square projection is
required. Strict separation in one coordinate gives `exclusion_sound`; endpoint
contact is retained. A checked three-equation, two-coordinate example separates
a coordinate even though every natural residual interval contains zero.
A second checked example has strict image inclusion and no common root, so
strict inclusion alone supplies no root conclusion for an overdetermined system.

`SzollosiRectangularExclusion.lean` derives coefficient shape from the checked
native table and retains all 618 equations and 440 coordinates.
`derivative_enclosed` encloses formal derivatives of the actual coded quartet
polynomials. `no_solution_in_box_of_check` applies each successful leaf check to
actual polynomial solutions; `no_quartet_of_check` applies a successful containing-
box check to actual quartets. Both require an actual successful rational check
and a center inside the box. No successful quartet-domain exclusion or complete
56-cell/cusp run is supplied.

The native rectangular command now emits the full containing-box request,
all 618 sparse Jacobian rows (9,000 entries), 440 images and intersections.
Its deterministic preconditioner has 28 nonzero rational entries. The zero
center lies in the containing box and need not satisfy the phase equations.
The output in `artifacts/mub_szollosi_rectangular_native_receipt.json`
(raw SHA-256 `eccd3b1c075d0058cf729e2aa0af5e210860da93d2178ea09a9d5cfb3b820a76`)
is `CONTRACTED_UNRESOLVED_BOX`: 24 coordinates contract and none
separates. These contractions restore constant entries of the constructed family
matrix; none of the 144 raw coordinates of the two additional bases is narrowed
by this run, as checked by `native_additional_bases_unchanged`. The saved request
reproduces the receipt byte for byte.

`SparseRectangularExclusion.lean` derives finite-support image soundness.
`SzollosiRectangularReflection.lean` identifies every emitted derivative
interval and image with the actual polynomial definitions, using bounded row
checks evaluated inside the Lean kernel. `native_jacobian_entry_enclosed`
bounds actual formal derivatives. `solution_in_native_retained` retains every
actual polynomial solution in every recorded intersection. The input box,
zero center, center residuals, contracted-coordinate list and non-separation
are also kernel checked. These checks apply to the current emitted data;
generic Rust/JSON verification is not supplied. No root existence follows.
`SzollosiColumnGauge.lean` now derives an independent column-phase reduction
for both additional bases. It leaves the constructed family matrix and all eight
phase coordinates fixed, and preserves the raw unitary, unit-entry and all three
MU Gram-norm equations. Conjugating each additional basis's first-row entries
sets that row to one. The same 618-equation system therefore has a representative
with 24 prescribed real coordinates whenever a quartet exists, also at every
fixed admissible family parameter. These coordinates are wire IDs 80-91 and
152-163, with alternating real value one and imaginary value zero; their complete
ordered list is checked by `gaugePointCodes_checked` using `by rfl`.
`gauge_box_firstRow` derives the first-row equalities from point-box membership;
`exists_gauge_box_solution_with_parameters_iff` gives the exact existence
reduction with no separate gauge premise. The bounds are exported in
`artifacts/mub_szollosi_column_gauge_box.json`. This normalizes columns of the
two variable bases; it does not classify or fully dephase the family matrix.
The earlier full-box contractor receipt is unchanged. No quartet-domain
exclusion or complete cell/cusp coverage follows from this reduction.

`SzollosiGaugeBalance.lean` derives row and column sums of six for the
raw transition between the two additional bases after the column gauge.
`SzollosiGaugedExecutable.lean` retains all 618 original equations and appends
24 gauge equations and 24 derived balance equations. The resulting 666
quadratics use the same 440 coordinates and preserve quartet existence at
every fixed admissible family parameter. The balance equations are conclusions
of the original equations and gauge, rather than new assumptions on quartets.
The Lean export and native replay agree on all 666 coefficient rows, 5,320
sparse terms and 1,998 rational probe values; the first 618 rows are unchanged.

`SzollosiGaugedCover.lean` checks a six-chart solution cover: at least one
real entry in the first transition row is at least one, since that row sums
to six. The six charts overlap. `SzollosiGaugedReflection.lean` connects the
actual native chart bounds to every augmented-system solution, also at each
admissible family parameter, using the earlier checked retained-box theorem.
Both additional bases remain variable. Duplicate native runs on all six
charts return `UNRESOLVED_BOX`; none of these charts has been excluded.

A separate candidate box restricts all six real entries of that transition row
to [-1/2,1/2]. Its balance equation forces the first real entry into [7/2,17/2],
separated from its own input interval. The native receipt
`artifacts/mub_szollosi_balance_exclusion_receipt.json` records this image
at coordinate 368. Kernel checks bind the 48 added coefficient rows and all
440 input bounds; the selected image has independent real semantics from the
balance identity. A contained point has admissible phases (1,-1,1,i), so this
box's exclusion is not an off-phase-domain example. That point is not a
quartet. The result excludes this candidate box, without excluding all
candidates at any family parameter. Other newly emitted images and the generic
Rust/JSON runtime are not verified by this selected-image result. The new
root replay fixes 48 coordinates (24 constructed-family constants and the 24
column gauges) with 74 nonzero preconditioner entries. It remains unresolved.
Six candidate charts do not replace the required 56 family cells and three
cusp collars, and `HasCurvatureCertificate` remains an explicit premise.

Useful preconditioners, further subdivision, further equivalence transports,
complete parameter/candidate coverage, cusp analysis and curvature remain open.
The native runtime receipt retains its `kernel_reflection_complete: false`
field; the separate checkpoint binds the subsequent Lean checks without
altering the native output.

The Lean `SmalePointCertificate` and `KrawczykContractor` structures already
contain a root, its equation, and uniqueness evidence. The current existence
lemmas project these fields; `krawczyk_inclusion_criterion` does not derive the
root from `K_subset_interior`. They therefore supply no independent analytic
soundness bridge for a native contractor receipt.

The separate deltoid-cover implementation restricts candidates to
`canonical_candidate_basis_box()`, whose first real component lies in
$[9/10,1]$. Consequently $|U_{0,0}|^2 \ge 81/100$, and its base margin is
$(81/100-1/6)^2=37249/90000$. Every basis unbiased to the standard basis has
$|U_{0,0}|^2=1/6$, outside that box. This margin therefore excludes a restricted
candidate domain that contains no such unbiased basis. Subdividing the family
parameter domain, even exhaustively, does not enlarge the candidate domain.
The restriction is explicit in
`mub6_szollosi_deltoid_cover.rs::canonical_candidate_basis_box` and
`SzollosiDeltoidCoverReport.candidate_domain_restriction`.

## 5. The flat-extension and operator frontier

For a genuine normalized moment functional $L$, a degree-two moment matrix has
entries $M_2(L)_{u,v}=L(u^*v)$ for a declared word basis. A flat-extension bridge
must bind $M_1$ to the corresponding principal submatrix, require positivity and
relation compatibility, and establish actual equality of ranks. The legacy rank labels
in `RankLoopClosure` and `CurtoFialkowFlatExtension` are not computed ranks of
these matrices. The added `rationalMomentMatrix` evaluates explicit word products
in $\mathbb Q$. `MomentPrincipalEmbedding` binds the lower word basis to a
principal submatrix, and `rationalMomentMatrix_rank_mono` establishes rank
monotonicity. `FlatMomentRankCondition` now states equality of the actual degree-two
and degree-one matrix ranks, together with this inclusion and complete, nonduplicate
indexing of all words at both degrees. Empty index lists cannot satisfy it. No MUB-specific
flatness witness, relation compatibility, or extraction follows from that definition.

`gns_extraction_theorem` takes a structure already carrying the operators and
state. It repackages that data into the present realization interface. The
legacy theorem supplies no operator extraction from moment values.
The rank-loop exclusion theorem retains `h_gns_exhaust`; the emptiness variants
retain their soundness or trace-sign arguments.

There is a preceding domain defect. `PhysicalProjectorRealization` does not
require basis completeness, rank-one ranges, Hilbert dimension six, inner-product
linearity, or cross-basis unbiasedness. `zeroActionInterfaceModel` supplies a
Boolean carrier, zero actions, and a normalized designated state satisfying every
current field. The theorem `not_universal_interface_exclusion` then gives

```lean
¬ UniversalPhysicalProjectorExclusion numBases dim
```

for arbitrary size labels, with no axiom dependencies. This is an interface
countermodel, not a concrete quantum or MUB realization. It prevents treating
the present exclusion predicate as the requested physical theorem.

`ConcreteMubProjectors.lean` provides a separate forward construction from
`FiniteComplexMubFamily ι B ι`. Its actual complex matrices are
$P_{b,l}=v_{b,l}v_{b,l}^*$. The checked lemmas establish self-adjointness,
same-basis multiplication, $\sum_l P_{b,l}=I$, trace one, rank one, and
$\operatorname{Tr}(P_{b,l}P_{c,k})=1/|\iota|$ for distinct bases. This
constructs the projectors from a supplied complex family; it neither supplies
such a family in dimension six nor extracts it from positive truncated moments.
The legacy interface countermodel therefore remains relevant.

`ConcreteMubMoments.lean` now constructs complex word moments directly from
that supplied family. Choose a state $\psi=v_{b_0,l_0}$ and a distinct basis
$b_1\ne b_0$. For a word $w$, let $P_w$ be the ordered projector product and
$L_\psi(w)=\langle\psi,P_w\psi\rangle$. The complete, nonduplicate word lists
of lengths at most one and two index actual Hermitian matrices. The theorem
`complexMomentMatrix_eq_gram` identifies each matrix with the Gram matrix of
its word-state columns; `complexMomentMatrix_posSemidef` establishes positivity.
`complexMomentMatrix_principal_degree_one` identifies the lower principal
submatrix. MU makes every overlap with basis $b_1$ nonzero, so its singleton
projector columns span the coordinate space. Consequently
`concrete_mub_moment_flatness` gives
$\operatorname{rank}(M_2)=\operatorname{rank}(M_1)=|\iota|$.
Normalization at the empty word is also checked.

This is a forward theorem for moments induced by a supplied concrete family,
with the distinct-basis and state labels explicit. It supplies neither a family
in dimension six nor a reverse extraction from arbitrary positive flat data.
The rational moment API remains separate; an adequate MUB interpretation of
abstract positive flat data remains required.

`ConcreteMubPolynomials.lean` now supplies actual coordinate polynomials for a
fixed triple of complex matrices. A candidate $U\in\mathbb C^{6\times6}$ is encoded by 72
real coordinates, with a checked inverse decoding. The 108 MU residuals are
$r_{a,i,j}=|\langle T_{a,i},U_j\rangle|^2-1/6$. The 72 real/imaginary residuals
of $U^*U-I$ impose candidate orthonormality. These are 180 indexed constraints,
without an independence claim. `polynomialIdeal` is their generated ideal in
`MvPolynomial Coord` over $\mathbb R$; `polynomialIdeal_le_eval_kernel_iff` identifies its
evaluation-kernel condition with their simultaneous vanishing.
`muPolynomial_eval_projector_trace` identifies each MU residual with the
corresponding complex projector cross-trace minus one sixth.

`polynomialVariety_eq_empty_iff` connects this actual real zero set to absence
of a unitary candidate with the stated MU overlaps. A supplied complete complex
MUB family gives a point in the zero set of its first three bases, using its
fourth basis as candidate, through `family_triple_variety_nonempty`. This is a
checked semantic bridge. It does not establish zero-set emptiness. The separate
commutative construction below now extracts a candidate from normalized positive
flat coordinate moments satisfying the finite residual equations. The fixed triple's
coefficients are real and imaginary parts of complex entries; rational enclosures over the
continuous family cells and cusp collars still require separate construction.

`FlatMomentProjectorExtraction.lean` now gives a finite reverse construction.
Its inputs are normalized complex word values, positivity of the actual
complete degree-two moment matrix, equality with the actual degree-one matrix
rank, and contextual idempotence equations
$L(u^*ggv)=L(u^*gv)$ for each generator and lower-degree words. It constructs a
Gram factor, one common complex linear space, a normalized state, and linear
idempotent actions symmetric for the explicit finite Hermitian pairing.
`extract_word_projectors` identifies every degree-two moment entry with
$L(u^*v)=\langle P_u\psi,P_v\psi\rangle$, for words of length at most two.
The space dimension is $\operatorname{rank}(M_1)$. Operators and a state are
outputs, rather than input structure fields.

`concrete_moment_extraction_inputs` checks that the previously constructed
moments from a supplied MUB family satisfy these extraction premises.
`FlatMomentBasisRelations.lean` adds the exact contextual equations
$L(u^*g_{b,l}g_{b,k}v)=\delta_{lk}L(u^*g_{b,l}v)$ and
$\sum_l L(u^*g_{b,l}v)=L(u^*v)$ for every basis and all words of length at most
one on either side. These equations are input relations, rather than
consequences of positivity alone.

From these relations, `extract_word_basis` constructs actions satisfying
$P_{b,l}P_{b,k}=\delta_{lk}P_{b,l}$ and $\sum_lP_{b,l}=I$ on the common
extracted space, while retaining symmetry, state normalization, and every
degree-two moment entry. `concrete_moment_basis_inputs` checks the contextual
relations for moments of a supplied MUB family. The normalized word assignment
that is zero on every nonempty word fails completeness, as checked by
`zero_action_moments_reject_completeness`.

For arbitrary input word data, dimension six, nonzero rank-one ranges for every
outcome, and cross-basis MU conclusions still need their corresponding
relations and derivations. The finite representation does not assert a full
star-algebra extension or transport arbitrary word data to the coordinate
polynomial zero set. These remain limits of that noncommutative word route.
The real coordinate route below supplies a separate extraction and its
empty-variety consequence without that additional word-to-coordinate transport.

`CommutativeFlatMoments.lean` constructs real coordinate multiplication
operators directly. Let the lower index list contain the constant and every
coordinate, and the upper list also contain every ordered coordinate product.
The repeated quadratic monomials are retained. For a real linear functional
$\Lambda$, the actual entries are $M_2(\Lambda)_{i,j}=\Lambda(m_i m_j)$.
Normalization $\Lambda(1)=1$, positive semidefiniteness and the actual equality
$\operatorname{rank}M_2=\operatorname{rank}M_1$ are explicit premises.

A Gram factor and rank equality identify the full column space with its lower
column space. The coordinate shifts descend to symmetric endomorphisms there;
polynomial commutativity yields commuting operators. Their joint real
eigenspaces span this finite space. A joint eigenvector with nonzero overlap
with the normalized state yields one common real point. Every quadratic
polynomial $p$ satisfying $\Lambda(p^2)=0$ vanishes at that point, through
`real_point_of_positive_flat`. The operators and point are constructed, rather
than supplied as extraction fields.

`ConcreteMubFlatExtension.lean` checks that all 180 candidate-basis residuals
$r_e$ lie in this quadratic span. `FiniteRelationCompatibility` states
$\Lambda(m_i r_e)=0$ for every upper-list monomial and every residual. These
finite equations imply $\Lambda(r_e^2)=0$, so the same extracted point
annihilates all residuals. `fourth_basis_of_positive_flat` produces an actual
complex unitary candidate with all 108 MU overlaps for the fixed triple.

Evaluation at any actual solution supplies a normalized positive moment matrix
with both ranks equal to one and satisfies every finite relation equation.
`fourth_basis_iff_positive_flat_moments` gives the resulting two-way equivalence
between candidate existence and existence of normalized positive flat compatible
coordinate moments. `moment_nonpositive_of_empty_variety` consequently excludes
positive semidefiniteness when the fixed real variety is empty, retaining
normalization, actual flatness and finite relation compatibility as hypotheses.
It does not exclude arbitrary nonflat truncations or establish variety emptiness.

The concrete flat-moment, normalized-quartet, and joint polynomial equivalences
were freshly replayed as dependencies of the 2026-10-11 transport bridge, with
only `propext`, `Classical.choice`, and `Quot.sound` in their reported axioms.
This scoped replay covers 23 local source modules and cached dependencies;
it is not a fresh build of the complete MUB6 import surface.
This real coordinate model is separate from the rational and noncommutative
word APIs; no implicit identification of their data is used.

[Laurent and Mourrain, arXiv:0812.2563](https://arxiv.org/abs/0812.2563) [6]
and [Mourrain and Schmüdgen, arXiv:1406.4975](https://arxiv.org/abs/1406.4975) [7]
provide commutative and star-algebra flat-extension settings, respectively.
The checked finite commutative construction above derives its own operator and
point extraction from explicit hypotheses. A full noncommutative extension is
not inferred from those references. Variety emptiness does not, by itself,
exclude an arbitrary fixed truncation; normalization, actual flatness and
relation compatibility remain part of the stated consequence.

## 6. Receipt custody and validation

The R6 receipt is present and has raw SHA-256
`cf8442d8fe1397226d669fcea7bc038ef8d984a9bae741772b9d742fbe62eb59`.
It records `NOT_A_CERTIFICATE`.

The Matolcsi receipt has raw SHA-256
`598d73b4f7b6807d62fc8d5c7698fd7c00ca73634c24641e0f2a848c873fc6fa`;
its internal digest is a different commitment. The historical
`zenodo/release_manifest.sha256` contains 496 entries: 493 archive file
members plus three release-metadata files. The archive extraction regression
checks all 493 file members. Digest agreement establishes the corresponding
byte or normalization commitment, rather than theorem validity.

The research source snapshot is pinned at
[commit 2d03b504106356593d76f5a6bafc259019d52247](https://github.com/dbccpage/the_symbol_game/tree/2d03b504106356593d76f5a6bafc259019d52247).
The [Lean source package](https://github.com/dbccpage/the_symbol_game/tree/2d03b504106356593d76f5a6bafc259019d52247/lean4/research_programs/mub6)
and [Rust workspace](https://github.com/dbccpage/the_symbol_game/tree/2d03b504106356593d76f5a6bafc259019d52247/omega_engine/crates_rs)
are external research materials. The preprint ZIP does not bundle those trees,
their dependencies or a new axiom census. Its integrity check verifies only the
delivered manuscript package. The historical research archive and receipt
counts above describe a separate artifact, not the preprint ZIP.

`Mub6` is the canonical package root; the external-pinned integration target
is separate. `Mub6` currently imports `MubBalancedTable`, whose full build has
not completed (Section 1.4), so a successful `lake build Mub6` has not been
recorded for this checkpoint. The full build and all-declaration axiom audit
must complete before a package-wide formal validation claim is made.
The live execution evidence and outstanding gates are recorded in the executive
checkpoint report; historical test totals are not substituted for current runs.
The 2026-10-11 finite-corner receipt separately binds the canonical index/minor
targets, the external public theorem, the 22-source integration replay, and
their printed axiom reports. It does not assert a whole-package replay.
The subsequent bounded-quartet receipt binds the two canonical block-chart
and division-free equation targets, their 34 endpoint reports, and the
rejected determinant-conjugation mutation.

The bounded export receipt binds 31 local source modules, 28 displayed index,
collection and coded-system endpoints, two rejected mutations, and the complete
native coefficient artifact. Its source-level equivalence is kernel-checked;
serialized-byte reflection and global infeasibility remain open. These scoped
receipts do not report execution of the complete validation command block above.

## 7. Publication checkpoint and completion requirements

The package is not ready for an arXiv submission asserting mathematical closure,
or for a new Zenodo release with that claim. A scoped technical checkpoint must
still complete rendering, metadata reconciliation, semantic review, and archive
re-certification before deposit. The existing archive is historical and does not
contain the current edits by implication.

The full Option B objective is retained: establish a concrete Route C landing
bridge or state its defensible remaining premises; execute and soundly reflect
the complete 56-cell/cusp exclusion calculation; construct the operator moment
and flat-extension bridge in an adequate mathematical domain. A passing suite or
a standard-axiom implication cannot replace any of those requirements.

## 8. Mechanism inventory and evidence boundaries

| Mechanism | Mathematical object or conclusion | Evidence boundary |
| --- | --- | --- |
| Concrete normalization and transport | Raw and normalized quartet equivalence | Reported external Lean endpoints; a current full replay remains required |
| Quantitative minor and block chart | Squared determinant at least 54/5; inverse-entry squared moduli at most 10/27 | Section 1.3 and named external Lean endpoints; no nonextension conclusion |
| Balanced polynomial reduction | 648 equations in 320 bounded real coordinates | Reported degree and equivalence endpoints; infeasibility open |
| Fourier-family route | Conditional contradiction from a Fourier-triple landing premise | The landing and concrete chart-soundness premises remain open |
| Interval exclusion and six charts | Sound exclusion criteria and recorded candidate boxes | No complete admissible-family exclusion or 56-cell/cusp replay |
| Positive flat moment extraction | Fourth-basis construction from explicit compatible moment hypotheses | Empty varieties and flatness for proposed data remain open |
| Finite Tao calculation | Norm 9 on all twenty balanced sign patterns | Finite matrix evaluation; no general Laurent necessary-condition theorem |
| Authorization | None | Integrity checks and reported computations confer no mathematical or publication approval |

The retained research ledgers are historical working indexes in the source
snapshot. They are not part of the standalone preprint or its verification
contract. The source theorem names in Sections 1–5 specify the individual
reported results; their stated hypotheses remain part of each statement.

## References

1. P. Jaming, M. Matolcsi, P. Móra, F. Szöllősi and M. Weiner, “A generalized Pauli problem and an infinite family of MUB-triplets in dimension 6”, [arXiv:0902.0882](https://arxiv.org/abs/0902.0882v2).
2. A. Maxwell and S. Brierley, “On properties of Karlsson Hadamards and sets of Mutually Unbiased Bases in dimension six”, [arXiv:1402.4070](https://arxiv.org/abs/1402.4070v2).
3. M. Cárdenes Wuttig and J. Tindall, “A Complete Classification of Complex Hadamard Matrices of Order Six”, [arXiv:2608.18053v2](https://arxiv.org/abs/2608.18053v2).
4. M. Matolcsi, Á. K. Matszangosz, D. Varga and M. Weiner, “Triplets of mutually unbiased bases”, Journal of Algebraic Combinatorics (2026), [doi:10.1007/s10801-026-01506-x](https://doi.org/10.1007/s10801-026-01506-x); [arXiv:2503.14752](https://arxiv.org/abs/2503.14752). Cited in Sections 2.1 and 4 under both identifiers.
5. F. Szöllősi, “A two-parameter family of complex Hadamard matrices of order 6 induced by hypocycloids”, [arXiv:0811.3930v2](https://arxiv.org/abs/0811.3930v2).
6. M. Laurent and B. Mourrain, “A Sparse Flat Extension Theorem for Moment Matrices”, [arXiv:0812.2563](https://arxiv.org/abs/0812.2563).
7. B. Mourrain and K. Schmüdgen, “Flat extensions in *-algebras”, [arXiv:1406.4975](https://arxiv.org/abs/1406.4975).
